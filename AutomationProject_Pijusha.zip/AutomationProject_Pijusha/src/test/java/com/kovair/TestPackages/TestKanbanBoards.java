/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.kovair.TestPackages;

//import static TaskList.TestKanbanCards.driver;
import com.kovair.PagelevelModule.KovairHomePageModule;
import com.kovair.PagelevelModule.KovairKanbanCard;
import com.kovair.PagelevelModule.KovairKanbanCardModule;
import com.kovair.PagelevelModule.KovairLoginPageModule;
import com.kovair.PagelevelModule.KovairKanbanBoardModule;
import com.kovair.pages.KovairKanbanTemplates;
import com.kovair.utilities.BeforeAfterClassMethods;
import com.kovair.utilities.SeleniumModules;
import com.kovair.utilities.sqlConnection;
import com.kovair.utilities.sqlQueries;
import java.io.File;
import java.util.List;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import com.kovair.PagelevelModule.KovairKanbanTemlateModule;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import TaskList.KovairGenericClass;
import com.kovair.pages.KovairKanbanTemplates.KovairKanbanTemplatesPopups;
/**
 *
 * @author sreyag
 */
public class TestKanbanBoards {
   static public WebDriver driver;
    static String ErrDesc;
    static String ExecutionStatus;
    static String TCName;
    static String TCID;
    static String PageName = "Kanban Board Creation";
    static int srlNo = 0;
    static String frameid = null;
    static File fXmlFile_Login = new File(System.getProperty("user.dir") + "//src/test/java/com/kovair/LoginInfo/LoginInfo.xml");
    static KovairLoginPageModule kovairloginpage;
    static KovairHomePageModule kovairhomepage;
    static KovairKanbanTemplates kt;
    static KovairKanbanTemplates.KovairKanbanTemplatesPopups popup;
    static KovairKanbanBoardModule kovairKanbanBoards;
    static KovairKanbanCardModule cm;
    static KovairKanbanTemlateModule template;
    static sqlQueries sql;
    static String title="AutoTest";
    static List<String> columnValue=null;
    static String userFullName;
    static KovairKanbanCard kc;
    public static String selectedTemplate="";
    public String newBoardName;
    public TestKanbanBoards()
    {
        kovairKanbanBoards=new KovairKanbanBoardModule(driver);
    }
    
    @BeforeTest
    @Parameters({"pages"})
    public  void landingClass(@Optional String landingPage) throws Exception { 
        try { 
            Object[] logdata = KovairLoginPageModule.LoginInfo(fXmlFile_Login);
            BeforeAfterClassMethods.getLogin(logdata);
            driver = KovairLoginPageModule.launchBrowser(BeforeAfterClassMethods.browser);
            driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
            BeforeAfterClassMethods.createRunId(PageName);
            driver.get(BeforeAfterClassMethods.URL);
            kovairloginpage = new KovairLoginPageModule(driver);
            Boolean n = kovairloginpage.KovairLogin(BeforeAfterClassMethods.UserId, BeforeAfterClassMethods.Password, driver);
            if (n.booleanValue()) {
                Thread.sleep(2000);
                kovairhomepage = new KovairHomePageModule(driver);
                kovairhomepage.waitforWorkspaces(driver);
                kovairhomepage.selectKovairWorkspaces(BeforeAfterClassMethods.Workspace, driver);
                Thread.sleep(4000);
                kovairhomepage.selectMenuItem("Kanban Board", driver);
                Thread.sleep(8000); 
                kovairKanbanBoards = new KovairKanbanBoardModule(driver);
                //kovairKanbanBoards.verifyAppearanceOfNotification("Action Button", driver);
//                kovairKanbanBoards.verifyApperenceOFBoard("Action Button", driver);
//                //Need To be remvoed *****************************************
//                driver.findElement(By.xpath("//span[text()='Board List']")).click();
                boolean isboardList=kovairKanbanBoards.verifyForBoardListPage(driver);
                if(!isboardList)
                {
                    System.out.println("User is not present in board list page");
                    kovairKanbanBoards.verifyApperenceOFBoard("Action Button", driver);
                    WebElement boardListIcon=kovairKanbanBoards.verifyApperenceOFBoard("Board List", driver);
                    boardListIcon.click();
                }
                else
                {
                    System.out.println("User is present in board list page");
                }
                Thread.sleep(5000);
                //********************************************************
                template= new KovairKanbanTemlateModule(driver);
                 if(landingPage.contains("Notification"))
                 {
                  WebElement l =null; 
                  String t;
                  l=kovairKanbanBoards.verifyApperenceOFBoard("Create New Board", driver);
//                  l.click();
                  driver.findElement(By.xpath("//a[text()='Create New Board']")).click();
                  l=kovairKanbanBoards.verifyApperenceOFBoard("BoardName", driver);
                  title="General Information";
                  l=kovairKanbanBoards.verifyApperenceOFBoard(title, driver);
                  l=l.findElement(By.xpath(".."));
                  t=l.getAttribute("style");
                  if(t.contains("color: rgb(64, 124, 197)"))
                   {
                   SeleniumModules.buttonClick(l, driver);
                   l=template.getGITab("Name", driver);
                   SeleniumModules.sendDataIntoTxt(l,"AutoBoard",driver);
                   l=kovairKanbanBoards.verifyApperenceOFBoard("Next Button", driver);
                   l.click();
                   title="Define Columns";
                   l=kovairKanbanBoards.verifyApperenceOFBoard(title, driver);
                   l=l.findElement(By.xpath(".."));
                   t=l.getAttribute("style");
                   if(t.contains("color: rgb(64, 124, 197)"))
                   { 
                      kovairKanbanBoards.verifyApperenceOFBoard("Next Button", driver).click();
                      title="Cards";
                      l=kovairKanbanBoards.verifyApperenceOFBoard(title, driver);
                      l=l.findElement(By.xpath(".."));
                      t=l.getAttribute("style");
                      if(t.contains("color: rgb(64, 124, 197)"))
                       { 
                       kovairKanbanBoards.verifyApperenceOFBoard("Next Button", driver).click();
                       title="Column Mapping";
                       l=kovairKanbanBoards.verifyApperenceOFBoard(title, driver);
                       l=l.findElement(By.xpath(".."));
                       t=l.getAttribute("style");
                       if(t.contains("color: rgb(64, 124, 197)"))
                        {  
                        System.out.println("In  Column Mapping tab");
                        } 
                       else{ 
                          System.out.println("Can not be reached at Column Mapping tab");
                          ErrDesc="Can not be reached at Column Mapping tab";
                          kovairloginpage.logout(driver); 
                        }
                       }else{  
                          System.out.println("Can not be reached at Cards tab");
                          ErrDesc="Can not be reached at Cards tab";
                          kovairloginpage.logout(driver); 
                       }
                     } 
                   else{  
                          System.out.println("Can not be reached at Cards tab");
                          ErrDesc="Can not be reached at Cards tab";
                          kovairloginpage.logout(driver); 
                       }
                   } 
                  else{  
                          System.out.println("Can not be reached at Cards tab");
                          ErrDesc="Can not be reached at Cards tab";
                          kovairloginpage.logout(driver); 
                       }
                 }
                
            }
        }catch (Exception e) {
            System.out.println(e);
        }
    }

    @BeforeMethod
    public void BeforeMethod() throws Exception {
        srlNo++;
        ErrDesc = "";
        ExecutionStatus = "";
        TCName = "";
        TCID = "";
        BeforeAfterClassMethods.getLogid();
    }

    @AfterMethod
    public void TestCaseResult() throws Exception {
        String filePath=BeforeAfterClassMethods.takingScreenshot(srlNo,TCID,TCName,ExecutionStatus,ErrDesc,driver);
        sqlConnection.sqlInsert(BeforeAfterClassMethods.runId, srlNo, TCID, TCName, ExecutionStatus, ErrDesc, filePath);
     }
    
    @AfterTest
    public static void afterClass() throws Exception {
        kovairloginpage.logout(driver);
        driver.quit();
    } 
    
    @Test
    public void verify_Notifications() throws InterruptedException, Exception {
        TCID = "Kanban_Notification_001";
        TCName = "Verify the nofication setup at the time of Board creation.";
        String HD[]={"Columns","Is Notify","Notify To"};
        int l=0;
        try { 
           // String n[]=kovairKanbanBoards.verifyNotificationHDAppearence("Notification", driver);
            String n[]=kovairKanbanBoards.verifyNotificationHDAppearence("Notification columns", driver);
            for(int i=0;i<n.length;i++)
            { 
             for(int j=0;j<HD.length;j++)
             {
             if(HD[j].equals(n[i]))
             { 
              l=l+1;
              break;
             }
                 }
            }
            if (l==HD.length) {
                ExecutionStatus = "Passed";
                ErrDesc = "Null";
            } else {
                ExecutionStatus = "Failed";
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    } 
    
    @Test
    public void verify_ColumnOfNotifications() throws InterruptedException, Exception {
        TCID = "Kanban_Notification_002";
        TCName = "Verify the column value of Columns at the column mapping tab in board creation.";
        String HD[]={"Columns","Is Notify","Notify To"};
        int l=0;
        try { 
            //String n[]=kovairKanbanBoards.verifyNotificationHDAppearence("Notification", driver);
            String n[]=kovairKanbanBoards.verifyNotificationHDAppearence("Notification columns", driver);
            for(int i=0;i<n.length;i++)
            { 
             for(int j=0;j<HD.length;j++)
             {
             if(HD[j].equals(n[i]))
             { 
              l=l+1;
              break;
             }
                 }
            }
            if (l==HD.length) {
                ExecutionStatus = "Passed";
                ErrDesc = "Null";
            } else {
                ExecutionStatus = "Failed";
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    } 
    @Test
    public void verifyIsNotifyValue() throws InterruptedException{
        TCID="Kanban_Notification_003";
        TCName="Verify the column value of the Is Notify.";
        List<WebElement> isNotify=null,availableColumns=null;
        int temp=1;
        try{
            isNotify=kovairKanbanBoards.verifyAppearanceOfNotification("Is notify", driver);
            availableColumns=kovairKanbanBoards.verifyAppearanceOfNotification("Available columns", driver);
            for(int i=0;i<isNotify.size();i++)
            {
                if(!isNotify.get(i).getAttribute("type").equals("checkbox"))
                {
                    temp=0;
                    break;
                }
            }
            if(temp==1 && isNotify.size()==availableColumns.size())
            {
                ExecutionStatus="Passed";
                ErrDesc="";
            }
            else
            {
                ExecutionStatus="Failed";
                ErrDesc="Is notify value is not correct for all columns";
            }
        }
        catch(Exception e)
        {
            System.out.println(e.getMessage());
            ExecutionStatus="Failed";
            ErrDesc=e.getMessage();
        }
    }
    @Test
    public void verifyNotifyToValue() throws InterruptedException{
        TCID="Kanban_Notification_004";
        TCName="Verify the column value of Notify To column at the column mapping tab in board creation.";
        List<WebElement> notifyTo,availableColumns;
        try{
            notifyTo=kovairKanbanBoards.verifyAppearanceOfNotification("Notify to", driver);
            availableColumns=kovairKanbanBoards.verifyAppearanceOfNotification("Available columns", driver);
            if(notifyTo.size()==availableColumns.size())
            {
                ExecutionStatus="Passed";
                ErrDesc="";
            }
            else
            {
                ExecutionStatus="Failed";
                ErrDesc="Notify to icon is not correct for all available columns";
            }
        }
        catch(Exception e)
        {
            System.out.println(e.getMessage());
            ExecutionStatus="Failed";
            ErrDesc=e.getMessage();
        }
    }
    @Test
    public void verifyNotifyToUserPopup() throws InterruptedException{
        TCID="Kanban_Notification_005";
        TCName="Verify the functionality of include button of Notify To column for any card type column at the column mapping tab in board creation.";
        WebElement notifyToPopup=null;
        try{
            notifyToPopup=kovairKanbanBoards.verifyNotifyToPopup("Notify To Popup", driver);
            if(notifyToPopup.isDisplayed())
            {
                ExecutionStatus="Passed";
                ErrDesc="";
            }
            else
            {
                ExecutionStatus="Failed";
                ErrDesc="Notify to pop up is not displayed";
            }
        }
        catch(Exception e)
        {
            System.out.println(e.getMessage());
            ExecutionStatus="Failed";
            ErrDesc=e.getMessage();
        }
    }
    @Test
    public void verifyPopupTitle() throws InterruptedException{
        TCID="Kanban_Notification_006";
        TCName="Verify the popup title for any column at the column mapping tab in board creation";
        WebElement popupTitle=null;
        List<WebElement> notifyTo;
        try{
            notifyTo=kovairKanbanBoards.verifyAppearanceOfNotification("Notify to", driver);
            columnValue=new ArrayList<String>();
            for(int i=0;i<notifyTo.size();i++)
            {
                columnValue.add(kovairKanbanBoards.verifyAppearanceOfNotification("Available columns", driver).get(i).getText());
            }
            notifyTo.get(0).click();
            popupTitle=kovairKanbanBoards.verifyNotifyToPopup("Popup title", driver);
            if(popupTitle.getText().equals(columnValue.get(0)))
            {
                ExecutionStatus="Passed";
                ErrDesc="";
            }
            else
            {
                ExecutionStatus="Failed";
                ErrDesc="Notify to pop up title is not correct";
            }
        }
        catch(Exception e)
        {
            System.out.println(e.getMessage());
            ExecutionStatus="Failed";
            ErrDesc=e.getMessage();
        }
    }
    @Test
    public void verifyAvailableAndSelectedSection() throws InterruptedException{
        TCID="Kanban_Notification_007";
        TCName="Verify the visibility of Available and Selected section in popup.";
        WebElement availableSection=null,selectedSection=null;
        try
        {
            availableSection=kovairKanbanBoards.verifyNotifyToPopup("Available User Section", driver);
            selectedSection=kovairKanbanBoards.verifyNotifyToPopup("Selected User Section", driver);
            if(availableSection.isDisplayed() && selectedSection.isDisplayed())
            {
                ExecutionStatus="Passed";
                ErrDesc="";
            }
            else
            {
                ExecutionStatus="Failed";
                ErrDesc="Both sections are not visible.";
            }
        }
        catch(Exception e)
        {
            System.out.println(e.getMessage());
            ExecutionStatus="Failed";
            ErrDesc=e.getMessage();
        }
    }
    @Test
    public void verifyAddButton()throws InterruptedException{
        TCID="Kanban_Notification_008";
        TCName="Verify the funtionality of add button of the popup at the column mapping tab in board creation.";
        WebElement addButton=null;
        try{
            
            kovairKanbanBoards.selectUserInNotifyToPopup(userFullName,"Available Users","N",driver);
            addButton=kovairKanbanBoards.verifyNotifyToPopup("Add", driver);
            addButton.click();
            if(kovairKanbanBoards.selectUserInNotifyToPopup(userFullName,"Selected Users","N",driver)==1)
            {
                ExecutionStatus="Passed";
                ErrDesc="";
            }
            else
            {
                ExecutionStatus="Failed";
                ErrDesc="User is not added in selected user section.";
            }
        }
        catch(Exception e)
        {
            System.out.println(e.getMessage());
            ExecutionStatus="Failed";
            ErrDesc=e.getMessage();
        }
    }
    @Test
    public void verifyRemoveButton()throws InterruptedException{
        TCID="Kanban_Notification_009";
        TCName="Verify the funtionality of remove button of the popup at the column mapping tab in board creation.";
        WebElement removeButton=null;
        try{
            kovairKanbanBoards.selectUserInNotifyToPopup(userFullName,"Selected Users","N",driver);
            removeButton=kovairKanbanBoards.verifyNotifyToPopup("Remove", driver);
            removeButton.click();
            if(kovairKanbanBoards.selectUserInNotifyToPopup(userFullName,"Selected Users","N",driver)==0)
            {
                if(kovairKanbanBoards.selectUserInNotifyToPopup(userFullName,"Available Users","N",driver)==1)
                {
                    ExecutionStatus="Passed";
                    ErrDesc="";
                }
                
            }
            else
            {
                ExecutionStatus="Failed";
                ErrDesc="User is not added in selected user section.";
            }
        }
        catch(Exception e)
        {
            System.out.println(e.getMessage());
            ExecutionStatus="Failed";
            ErrDesc=e.getMessage();
        }
    }
    @Test
    public void verifyAddButtonValidation() throws InterruptedException{
        TCID="Kanban_Notification_010";
        TCName="Verify the validation message if the add button of the popup is clicked without selecting any user from available users list at the column mapping tab in board creation.";
        WebElement addButton=null,validation=null,validationOK=null;
        try{
            addButton=kovairKanbanBoards.verifyNotifyToPopup("Add", driver);
            addButton.click();
            addButton.click();
            Thread.sleep(3000);
            validation=kovairKanbanBoards.verifyNotifyToPopup("Validation Message", driver);
            if(validation.getText().equals("Please select an item before clicking on Add button."))
            {
                validationOK=kovairKanbanBoards.verifyNotifyToPopup("Validation OK", driver);
                validationOK.click();
                kovairKanbanBoards.selectUserInNotifyToPopup(userFullName,"Selected Users","Y",driver);
                ExecutionStatus="Passed";
                ErrDesc="";
            }
            else
            {
                ExecutionStatus="Failed";
                ErrDesc="Validation is not showing proper message";
            }
        }
        catch(Exception e)
        {
            System.out.println(e.getMessage());
            ExecutionStatus="Failed";
            ErrDesc=e.getMessage();
        }
    }
    @Test
    public void verifyRemoveButtonValidation() throws InterruptedException{
        TCID="Kanban_Notification_011";
        TCName="Verify the validation message if the remove button of the popup is clicked without selecting any user from available users list at the column mapping tab in board creation. ";
        WebElement removeButton=null,validation=null,validationOK=null;
        try{
            kovairKanbanBoards.selectUserInNotifyToPopup(userFullName,"Available Users","Y",driver);
            removeButton=kovairKanbanBoards.verifyNotifyToPopup("Remove", driver);
            removeButton.click();
            validation=kovairKanbanBoards.verifyNotifyToPopup("Validation Message", driver);
            if(validation.getText().equals("Please select an item before clicking on remove button."))
            {
                validationOK=kovairKanbanBoards.verifyNotifyToPopup("Validation OK", driver);
                validationOK.click();
                kovairKanbanBoards.selectUserInNotifyToPopup(userFullName,"Selected Users","Y",driver);
                ExecutionStatus="Passed";
                ErrDesc="";
            }
            else
            {
                ExecutionStatus="Failed";
                ErrDesc="Validation is not showing proper message";
            }
        }
        catch(Exception e)
        {
            System.out.println(e.getMessage());
            ExecutionStatus="Failed";
            ErrDesc=e.getMessage();
        }
    }
    @Test
    public void verifyAddUserDoubleClick() throws InterruptedException{
        TCID="Kanban_Notification_014";
        TCName="Verify the double click on feature for adding user to notify.";
        try{
            String l[][]=sqlQueries.getSQLresult(sqlQueries.userFullName);
            userFullName=l[0][0];
            kovairKanbanBoards.selectUserInNotifyToPopup(userFullName,"Available Users","Y",driver);
            if(kovairKanbanBoards.selectUserInNotifyToPopup(userFullName,"Selected Users","N",driver)==1)
            {
                ExecutionStatus="Passed";
                ErrDesc="";
            }
            else
            {
                ExecutionStatus="Failed";
                ErrDesc="User is not added in selected user section.";
            }
        }
        catch(Exception e)
        {
            System.out.println(e.getMessage());
            ExecutionStatus="Failed";
            ErrDesc=e.getMessage();
        }
    }
    @Test
    public void verifyRemoveUserDoubleClick() throws InterruptedException{
        TCID="Kanban_Notification_015";
        TCName="Verify the double click feature for removeing user to notify.";
        try{
            kovairKanbanBoards.selectUserInNotifyToPopup(userFullName,"Selected Users","Y",driver);
            if(kovairKanbanBoards.selectUserInNotifyToPopup(userFullName,"Available Users","N",driver)==1)
            {
                ExecutionStatus="Passed";
                ErrDesc="";
            }
            else
            {
                ExecutionStatus="Failed";
                ErrDesc="User is not added in selected user section.";
            }
        }
        catch(Exception e)
        {
            System.out.println(e.getMessage());
            ExecutionStatus="Failed";
            ErrDesc=e.getMessage();
        }
    }
    @Test 
    public void verifyTopSort() throws InterruptedException{
        TCID="Kanban_Notification_016";
        TCName="Verify the funtionality of Top button for sorting user in Sected user list.";
        List<WebElement> availableUserList,selectedUserList,topSortButton;
        List<String> users=new ArrayList<String>();
        String lastUserName,firstUserName;
        try
        {
            availableUserList=kovairKanbanBoards.verifyNotifyToPopupUserList("Available Users", driver);
            if(availableUserList.size()>=4)
            {
                for(int i=0;i<4;i++)
                {
                    users.add(availableUserList.get(i).getText());
                    kovairKanbanBoards.selectUserInNotifyToPopup(users.get(i),"Available Users","Y",driver);
                }
            }
            else
            {
                for(int i=0;i<availableUserList.size();i++)
                {
                    users.add(availableUserList.get(i).getText());
                    kovairKanbanBoards.selectUserInNotifyToPopup(users.get(i),"Available Users","Y",driver);
                }
            }
            selectedUserList=kovairKanbanBoards.verifyNotifyToPopupUserList("Selected Users", driver);
            lastUserName=selectedUserList.get(selectedUserList.size()-1).getText();
            topSortButton=kovairKanbanBoards.verifyNotifyToPopupUserList("Top Sort", driver);
            topSortButton.get(topSortButton.size()-1).click();
            Thread.sleep(10000);
            selectedUserList=kovairKanbanBoards.verifyNotifyToPopupUserList("Selected Users", driver);
            firstUserName=selectedUserList.get(0).getText();
            if(firstUserName.equals(lastUserName))
            {
                ExecutionStatus="Passed";
                ErrDesc="";
            }
            else
            {
                ExecutionStatus="Failed";
                ErrDesc="Top Sort button can't move the last user at the top";
            }
        }
        catch(Exception e)
        {
            System.out.println(e.getMessage());
            ExecutionStatus="Failed";
            ErrDesc=e.getMessage();
        }
        
    }
    @Test
    public void verifyBottomSort() throws InterruptedException{
        TCID="Kanban_Notification_017";
        TCName="Verify the funtionality of Bottom button for sorting user in Selected users list.";
        List<WebElement> availableUserList,selectedUserList,bottomSortButton;
        List<String> users=new ArrayList<String>();
        String lastUserName,firstUserName;
        try{
            selectedUserList=kovairKanbanBoards.verifyNotifyToPopupUserList("Selected Users", driver);
            firstUserName=selectedUserList.get(0).getText();
            bottomSortButton=kovairKanbanBoards.verifyNotifyToPopupUserList("Bottom Sort", driver);
            bottomSortButton.get(0).click();
            Thread.sleep(10000);
            selectedUserList=kovairKanbanBoards.verifyNotifyToPopupUserList("Selected Users", driver);
            lastUserName=selectedUserList.get(selectedUserList.size()-1).getText();
            if(firstUserName.equals(lastUserName))
            {
                ExecutionStatus="Passed";
                ErrDesc="";
            }
            else
            {
                ExecutionStatus="Failed";
                ErrDesc="Top Sort button can't move the last user at the top";
            }
        }
        catch(Exception e)
        {
            System.out.println(e.getMessage());
            ExecutionStatus="Failed";
            ErrDesc=e.getMessage();
        }
    }
    @Test
    public void verifyAvailableUserSearch() throws InterruptedException{
        TCID="Kanban_Notification_018";
        TCName="Verify search for Available users List in the popup.";
        List<String> userNames=null;
        List<WebElement> userList;
        WebElement searchTxt,searchIcon;
        try{
            userNames= new ArrayList<String>();
            userList=kovairKanbanBoards.verifyNotifyToPopupUserList("Available Users", driver);
            if(userList.size()>10)
            {
                for(int i=0;i<10;i++)
                {
                    userNames.add(userList.get(i).getText());
                    
                }
            }
            else
            {
                for(int i=0;i<userList.size();i++)
                {
                    userNames.add(userList.get(i).getText());
                }
            }
            searchTxt=kovairKanbanBoards.verifyNotifyToPopup("Available User Search Txt", driver);
            searchTxt.sendKeys(userNames.get(userNames.size()-1));
            searchIcon=kovairKanbanBoards.verifyNotifyToPopup("Available User Search Icon", driver);
            searchIcon.click();
            if(kovairKanbanBoards.selectUserInNotifyToPopup(userNames.get(userNames.size()-1),"Available Users","N",driver)==1)
            {
                for(int i=0;i<userNames.size();i++)
                {
                    kovairKanbanBoards.selectUserInNotifyToPopup(userNames.get(i),"Available Users","Y",driver);
                }
                ExecutionStatus="Passed";
                ErrDesc="";
            }
            else
            {
                ExecutionStatus="Failed";
                ErrDesc="Available User search is not working properly.";
            }
        }
        catch(Exception e)
        {
            System.out.println(e.getMessage());
            ExecutionStatus="Failed";
            ErrDesc=e.getMessage();
        }
    }
    @Test
    public void verifySelectedUserSearch() throws InterruptedException{
        TCID="Kanban_Notification_019";
        TCName="Verify search for Selected users list in the popup.";
        List<String> userNames=null;
        List<WebElement> userList;
        WebElement searchTxt,searchIcon;
        try{
            userNames= new ArrayList<String>();
            userList=kovairKanbanBoards.verifyNotifyToPopupUserList("Selected Users", driver);
            if(userList.size()>10)
            {
                for(int i=0;i<10;i++)
                {
                    userNames.add(userList.get(i).getText());
                    
                }
            }
            else
            {
                for(int i=0;i<userList.size();i++)
                {
                    userNames.add(userList.get(i).getText());
                }
            }
            searchTxt=kovairKanbanBoards.verifyNotifyToPopup("Selected User Search Txt", driver);
            searchTxt.sendKeys(userNames.get(userNames.size()-1));
            searchIcon=kovairKanbanBoards.verifyNotifyToPopup("Selected User Search Icon", driver);
            searchIcon.click();
            if(kovairKanbanBoards.selectUserInNotifyToPopup(userNames.get(userNames.size()-1),"Selected Users","N",driver)==1)
            {
                for(int i=0;i<userNames.size();i++)
                {
                    kovairKanbanBoards.selectUserInNotifyToPopup(userNames.get(i),"Selected Users","Y",driver);
                }
                ExecutionStatus="Passed";
                ErrDesc="";
            }
            else
            {
                ExecutionStatus="Failed";
                ErrDesc="Available User search is not working properly.";
            }
        }
        catch(Exception e)
        {
            System.out.println(e.getMessage());
            ExecutionStatus="Failed";
            ErrDesc=e.getMessage();
        }
    }
    @Test
    public void verifySave() throws InterruptedException{
        TCID="Kanban_Notification_020";
        TCName="Verify the Save button in the popup.";
        WebElement Save=null,notifyTo=null;
        try
        {
            Save=kovairKanbanBoards.verifyNotifyToPopup("Save", driver);
            kovairKanbanBoards.selectUserInNotifyToPopup(userFullName,"Available Users","Y",driver);
            Save.click();
            notifyTo=kovairKanbanBoards.verifyAppearanceOfNotification("Notify to", driver).get(0);
            notifyTo.click();
            if(kovairKanbanBoards.selectUserInNotifyToPopup(userFullName,"Selected Users","N",driver)==1)
            {
                ExecutionStatus="Passed";
                ErrDesc="";
            }
            else
            {
                ExecutionStatus="Failed";
                ErrDesc="Clicking on Save button can not save selected users";
            }
        }
        catch(Exception e)
        {
            System.out.println(e.getMessage());
            ExecutionStatus="Failed";
            ErrDesc=e.getMessage();
        }
    }
    @Test
    public void verifyCancel() throws InterruptedException{
        TCID="Kanban_Notification_021";
        TCName="Verify the Cancel button in the popup.";
        WebElement Cancel=null,notifyTo=null;
        try
        {
            Cancel=kovairKanbanBoards.verifyNotifyToPopup("Cancel", driver);
            Cancel.click();
            notifyTo=kovairKanbanBoards.verifyAppearanceOfNotification("Notify to", driver).get(0);
            notifyTo.click();
            if(kovairKanbanBoards.selectUserInNotifyToPopup(userFullName,"Selected Users","N",driver)==0)
            {
                ExecutionStatus="Passed";
                ErrDesc="";
            }
            else
            {
                ExecutionStatus="Failed";
                ErrDesc="Clicking on Cancel button is saving selected users";
            }
        }
        catch(Exception e)
        {
            System.out.println(e.getMessage());
            ExecutionStatus="Failed";
            ErrDesc=e.getMessage();
        }
    }
    @Test 
    public void verifyClose() throws InterruptedException{
        TCID="Kanban_Notification_022";
        TCName="Verify the Close button in the popup.";
        WebElement close=null,notifyToPopup=null;
        String s;
        try{
            close=kovairKanbanBoards.verifyNotifyToPopup("Close", driver);
            close.click();
            notifyToPopup=kovairKanbanBoards.verifyNotifyToPopup("Notify To Popup", driver);
            s=notifyToPopup.getAttribute("style");
            if(s.contains("display: none"))
                {
                    ExecutionStatus="Passed";
                    ErrDesc="";
                    
                }
                else
                {
                    ExecutionStatus="Failed";
                    ErrDesc="Close button can not close Notify to popup";
                }
            }
        catch(Exception e)
        {
            System.out.println(e.getMessage());
            ExecutionStatus="Failed";
            ErrDesc=e.getMessage();
        }    
    }
   /* @Test
    public void verify_CreateNewBoardNoActiveBoard() throws Exception{
     TCID="KanbanBoardCreate_001";
     TCName="Verify the option `Create New Board` while there is no active board.";
     WebElement boardCreate=null,actionbutton=null;  
     try{
         actionbutton=kovairKanbanBoards.verifyApperenceOFBoard("Action Button", driver);
         boardCreate=kovairKanbanBoards.verifyApperenceOFBoard("Create New Board", driver);
         if(boardCreate.isDisplayed())
         {
             ExecutionStatus="Passed";
             ErrDesc="";
         }
         else
         {
             ExecutionStatus="Failed";
             ErrDesc="Create New Board header action is not visible";
         }
     }   
     catch(Exception e){
         ExecutionStatus="Not Executed";
         ErrDesc="verify_CreateNewBoard() method Failure, due to element change or instance problem";
     }
    }*/
    @Test
    public void verify_AppearanceOfCreateNewBoard() throws Exception{
        TCID="KanbanBoardCreate_001";
        TCName="Verify the option `Create New Board` in board list page.";
        WebElement createNewBoardLink=null;
        try{
            createNewBoardLink=kovairKanbanBoards.verifyApperenceOFBoardList("Create New Board", driver);
            if(createNewBoardLink.isDisplayed())
            {
                System.out.println("Create New Board option found");
                ExecutionStatus="Passed";
                ErrDesc="";
            }
            else
            {
                System.out.println("Create New Board option is not found. ");
                ExecutionStatus="Failed";
                ErrDesc="Create New Board option is not visible.";
            }
        }
        catch(Exception e){
         ExecutionStatus="Not Executed";
         ErrDesc=e.getMessage();
     }
    }
    @Test
    public void verify_ClickingOnCreateNewBoard() throws Exception{
     TCID="KanbanBoardCreate_002";
     //TCName="Verify click on `Create New Board` option in header action.";
     TCName="Verify the page that will open while clicking  on \"Create New Board\" option from borad list page.";
     WebElement createNewBoardIcon=null;
     String pageTitle;
        try{
            createNewBoardIcon=kovairKanbanBoards.verifyApperenceOFBoardList("Create New Board", driver);
            createNewBoardIcon.click();
            Thread.sleep(5000);
            pageTitle=kovairKanbanBoards.verifyApperenceOFBoard("Page Title", driver).getText();
            if(pageTitle.equals("Add New Kanban Board"))
            {
                ExecutionStatus="Passed";
                ErrDesc="";
            }
            else
            {
                ExecutionStatus="Failed";
                ErrDesc="Add New Kanban Board page is not opening after clicking Create New Board header action";
            }
     }   
     catch(Exception e){
         ExecutionStatus="Not Executed";
         ErrDesc="verify_ClickingOnCreateNewBoard() method Failure, due to element change or instance problem";
     }
    }
//    @Test
//    public void verify_CreateNewBoardActive() throws Exception{
//     TCID="KanbanBoardCreate_003";
//     TCName="Verify the option `Create New Board` while there is an active board in header action.";
//     List<WebElement> boardCreate=null;
//     WebElement archiveBoard,buttonOK;
//     try{
//         kovairKanbanBoards.verifyApperenceOFBoard("Action Button", driver);
//         boardCreate=new ArrayList<WebElement>();
//         boardCreate.add(kovairKanbanBoards.verifyApperenceOFBoard("Create New Board", driver));
//         if(boardCreate.get(0)==null)
//         {
//             ExecutionStatus="Passed";
//             ErrDesc="";
//         }
//         else
//         {
//             ExecutionStatus="Failed";
//             ErrDesc="Create New Board header action is not visible";
//         }
//     }   
//     catch(Exception e){
//         ExecutionStatus="Not Executed";
//         ErrDesc=e.getMessage();
//     }
//    }
    @Test
    public void verifyGILabels() throws Exception{
        TCID="KanbanBoardCreate_003";
        TCName="Verify three labels of General Information tab in board creation.";
        String namelabel,templatelabel,descriptionlabel;
        try{
            namelabel=kovairKanbanBoards.verifyApperenceOFBoard("Name Label", driver).getText();
            templatelabel=kovairKanbanBoards.verifyApperenceOFBoard("Template Label", driver).getText();
            descriptionlabel=kovairKanbanBoards.verifyApperenceOFBoard("Description Label", driver).getText();
            if(namelabel.equals("Name:") && templatelabel.equals("Template:") && descriptionlabel.equals("Description"))
            {
                ExecutionStatus="Passed";
                ErrDesc="";
            }
            else
            {
                ExecutionStatus="Failed";
                ErrDesc="All three labels are not displayed.";
            }
        }
        catch(Exception e)
        {
            ExecutionStatus="Not Executed";
            ErrDesc=e.getMessage();
        }
    }
    @Test
    public void verifyPageTitle() throws Exception{
     TCID="KanbanBoardCreate_004";
     TCName="Verify visibility of page title for creating a board.";
     WebElement createNewBoardIcon=null,pageTitle=null;
     
        try{
            pageTitle=kovairKanbanBoards.verifyApperenceOFBoard("Page Title", driver);
            if(pageTitle.isDisplayed())
            {
                ExecutionStatus="Passed";
                ErrDesc="";
                selectedTemplate=kovairKanbanBoards.verifyApperenceOFBoard("Selected Template",driver).getText();
            }
            else
            {
                ExecutionStatus="Failed";
                ErrDesc="Add New Kanban Board page is not opening after clicking Create New Board header action";
            }
     }   
     catch(Exception e){
         ExecutionStatus="Not Executed";
         ErrDesc=e.getMessage();
     }
    }
    @Test
    public void verifyTemplateValue() throws Exception{
     TCID="KanbanBoardCreate_006";
     TCName="Verify the value of  Template while creating board.";
     Select templateDropdown=null;
     List<WebElement> templateValues=null;
     String pageTitle;
        try{
            int temp=0;
            templateValues=new ArrayList<WebElement>();
            templateDropdown=new Select(kovairKanbanBoards.verifyApperenceOFBoard("Template Value", driver));
            templateValues=templateDropdown.getOptions();
            for(int i=0;i<templateValues.size();i++)
            {
                if(templateValues.get(i).getAttribute("selected").equals("true"))
                {
                    temp=1;
                    break;
                }
            }
            if(temp==1)
            {
                ExecutionStatus="Passed";
                ErrDesc="";
            }
            else
            {
                ExecutionStatus="Failed";
                ErrDesc="Template value is not selected by default";
            }
        }
        catch(Exception e){
            ExecutionStatus="Not Executed";
            ErrDesc=e.getMessage();
        }
    }
    @Test
    public void verifyTemplateList() throws Exception{
     TCID="KanbanBoardCreate_007";
     TCName="Verify  Template list in board creation.";
        try{
            
        }
        catch(Exception e){
            ExecutionStatus="Not Executed";
            ErrDesc=e.getMessage();
        }
    }
    @Test
    public void verifyUserSelectedTemplate() throws Exception{
     TCID="KanbanBoardCreate_008";
     TCName="Verify Template selection of Template in board creation.";
     WebElement templateDropdown=null;
         try{
            templateDropdown=kovairKanbanBoards.verifyApperenceOFBoard("Template Value", driver);
            if(templateDropdown.isEnabled())
            {
                ExecutionStatus="Passed";
                ErrDesc="";
            }
            else
            {
                ExecutionStatus="Failed";
                ErrDesc="Template can not be selected as per user choice";
            }
        }
        catch(Exception e){
            ExecutionStatus="Not Executed";
            ErrDesc=e.getMessage();
        }
    }
    @Test
    public void verifyNameFieldMandatory() throws Exception{
     TCID="KanbanBoardCreate_009";
     TCName="Verify Name field is mandatory in board creation.";
     WebElement next=null,validation=null;
         try{
             next=kovairKanbanBoards.verifyApperenceOFBoard("Next Button", driver);
             validation=kovairKanbanBoards.verifyApperenceOFBoard("Name field validation", driver);
             next.click();
             if(validation.getText().equals(" Name cannot be blank."))
             {
                 ExecutionStatus="Passed";
                 ErrDesc="";
             }
             else
             {
                 ExecutionStatus="Failed";
                 ErrDesc="Name field validation is not showing";
             }
         }
         catch(Exception e){
            ExecutionStatus="Not Executed";
            ErrDesc=e.getMessage();
        }
    }
    @Test
    public void verifyGINextButton() throws InterruptedException{
        TCID="KanbanBoardCreate_010";
        TCName="Verify tab navigation through Next button in board creation .";
        WebElement nextButton,nameTxt,l;
        String t;
        try
        {
            nameTxt=kovairKanbanBoards.verifyApperenceOFBoard("BoardName", driver);
            DateFormat dateformat=new SimpleDateFormat("DDMMYYYYHHMMSS");
            Date date=new Date();
            newBoardName="AutoBoard"+dateformat.format(date);
            nameTxt.sendKeys(newBoardName);
            nextButton=kovairKanbanBoards.verifyApperenceOFBoard("Next Button", driver);
            nextButton.click();
            Thread.sleep(3000);
            l=kovairKanbanBoards.verifyApperenceOFBoard("Define Columns", driver);
            l=l.findElement(By.xpath(".."));
                  t=l.getAttribute("style");
                  if(t.contains("color: rgb(64, 124, 197)"))
                   {
                       ExecutionStatus="Passed";
                       ErrDesc="";
                   }
                  else
                  {
                      ExecutionStatus="Failed";
                      ErrDesc="Define Columns tab didn't open after clicking next in General Information tab.";
                  }
                 
                  
        }
        catch(Exception e)
        {
            ExecutionStatus="Not Executed";
            ErrDesc=e.getMessage();
        }
    }
    @Test
    public void verifyAppearanceOfSwimlaneTab() throws InterruptedException{
        TCID="KanbanBoardCreate_019";
        TCName="Verify setup of Swimlane tab appears by default in board creation.";
        List<WebElement> swimlaneValues;
        List<String> selectedValues=null;
        WebElement value=null;
        try{
           selectedValues=new ArrayList<String>();
           swimlaneValues=kovairKanbanBoards.verifySwimLaneList("Selected swimlane values", driver);
            for (Iterator<WebElement> it = swimlaneValues.iterator(); it.hasNext();) {
                value = it.next();
                selectedValues.add(value.getText());
            }
            
        }
        catch(Exception e)
        {
            ExecutionStatus="Not Executed";
            ErrDesc=e.getMessage();
        }
        
    }
    @Test
    public void verifyCancelBoardCreate() throws InterruptedException{
        TCID="KanbanBoardCreate_024";
        TCName="Verify clicking on Cancel button no board will create.";
        WebElement cancelButton,createBoard;
        try
        {
            cancelButton=kovairKanbanBoards.verifyApperenceOFBoard("", driver);
            cancelButton.click();
//            kovairKanbanBoards.verifyApperenceOFBoard("Action Button", driver);
            createBoard=kovairKanbanBoards.verifyApperenceOFBoardList("Create New Board", driver);
            if(createBoard.isDisplayed())
            {
                ExecutionStatus="Passed";
                ErrDesc="";
                createBoard.click();
            }
            else
            {
                ExecutionStatus="Failed";
                ErrDesc="Clicking on Cancel at the time of board creation is saving board";
            }
        }
        catch(Exception e)
        {
            ExecutionStatus="Not Executed";
            ErrDesc=e.getMessage();
        }
    }
    
    @Test
    public void verifyValidationForUnmappedColumn() throws InterruptedException{
        TCID="KanbanBoardCreate_025";
        TCName="Verify the validation in Column Mapping tab for unmapped column that has created in board creation.";
        WebElement validation,nextButton,prevButton;
        try{
//            prevButton=kovairKanbanBoards.verifyApperenceOFBoard("Previous", driver);
            nextButton=kovairKanbanBoards.verifyApperenceOFBoard("Next Button", driver);
//            prevButton.click();
//            prevButton.click();
            template.getAlterColumns("Unmapped Column", "3", "2", Boolean.FALSE, driver);
            nextButton.click();
            nextButton.click();
            nextButton.click();
            validation=driver.findElement(By.xpath(kovairKanbanBoards.verifyColumnMappingList("New Column","Unmap validation", driver)));
            if(validation.isDisplayed() && (validation.getText().equals(" All columns need to be mapped with specific lookup values.")))
            {
                ExecutionStatus="Passed";
                ErrDesc="";
            }
            else
            {
                ExecutionStatus="Failed";
                ErrDesc="Validation is not showing proper message after clicking next without column mapping.";
            }
        }
        catch(Exception e){
         ExecutionStatus="Not Executed";
         ErrDesc=e.getMessage();
        }
    }
    @Test
    public void verifyDeleteMappedColumn() throws InterruptedException{
        TCID="KanbanBoardCreate_026";
        TCName="Verify delete of column that is created and mapped in board creation.";
        WebElement mapColumn=null;
        List<WebElement>mappingValues=null;
        WebElement previousButton,l,deleteColumn,validation,validationOK,nextButton;
        List<WebElement> availableValues=null;
        String t;
        try{
            mapColumn=driver.findElement(By.xpath(kovairKanbanBoards.verifyColumnMappingList("Delete Column","Map Column", driver)));
            mapColumn.click();
            mappingValues=driver.findElements(By.xpath(kovairKanbanBoards.verifyColumnMappingList("Delete Column","Mapping values", driver)));
            mappingValues.get(0).click();
            previousButton=kovairKanbanBoards.verifyApperenceOFBoard("Previous", driver);
            previousButton.click();
            previousButton.click();
            l=kovairKanbanBoards.verifyApperenceOFBoard("Define Columns", driver);
            l=l.findElement(By.xpath(".."));
                  t=l.getAttribute("style");
                  if(t.contains("color: rgb(64, 124, 197)"))
                   {
                       nextButton=kovairKanbanBoards.verifyApperenceOFBoard("Next Button", driver);
                       deleteColumn=driver.findElement(By.xpath(template.getDefineColumn("Delete Column", "Column delete", driver)));
                       deleteColumn.click();
                       validation=kovairKanbanBoards.verifyNotifyToPopup("Validation Message", driver);
                       if(validation.getText().equals("You can not delete column due to column mapping"))
                       {
                           ExecutionStatus="Passed";
                           ErrDesc="";
                           validationOK=kovairKanbanBoards.verifyNotifyToPopup("Validation OK", driver);
                           validationOK.click();
                           nextButton.click();
                           nextButton.click();
//                           nextButton.click();
                       }
                       else
                       {
                           ExecutionStatus="Failed";
                           ErrDesc="Validation message is not showing proper message after clicking delete column of a mapped column";
                       }
                   }
        }
        catch(Exception e){
         ExecutionStatus="Not Executed";
         ErrDesc=e.getMessage();
        }
    }
    @Test
    public void verifyDeleteUnMappedColumn() throws InterruptedException{
        TCID="KanbanBoardCreate_027";
        TCName="Verify delete of column that is created but  not mapped in board creation.";
        WebElement deleteColumn=null,nextButton=null,previousButton=null;
        String findColumn=null;
        try{
            previousButton=kovairKanbanBoards.verifyApperenceOFBoard("Previous", driver);
            previousButton.click();
            previousButton.click();
            deleteColumn=driver.findElement(By.xpath(template.getDefineColumn("Unmapped Column", "Column delete", driver)));
            deleteColumn.click();
            nextButton=kovairKanbanBoards.verifyApperenceOFBoard("Next Button", driver);
            findColumn=template.getDefineColumn("Unmapped Column", "Column delete", driver);
            if(findColumn.equals("Column is not present"))
            {
                ExecutionStatus="Passed";
                ErrDesc="";
            }
            else
            {
                ExecutionStatus="Failed";
                ErrDesc="Column is not deleted";
            }
            nextButton.click();
            nextButton.click();
        }
        catch(Exception e){
         ExecutionStatus="Not Executed";
         ErrDesc=e.getMessage();
        }
    }
    @Test
    public void verifyPrevious() throws InterruptedException{
        TCID="KanbanBoardCreate_028";
        TCName="Verify the previous button of kanban board creation.";
        WebElement previous,l,nextButton;
        String t;
        try{
            previous=kovairKanbanBoards.verifyApperenceOFBoard("Previous", driver);
            previous.click();
            nextButton=kovairKanbanBoards.verifyApperenceOFBoard("Next Button", driver);
            l=kovairKanbanBoards.verifyApperenceOFBoard("General Information", driver);
            l=l.findElement(By.xpath(".."));
                  t=l.getAttribute("style");
                  if(t.contains("color: rgb(64, 124, 197)"))
                   {
                       ExecutionStatus="Passed";
                       ErrDesc="";
                   }
                  else
                  {
                      ExecutionStatus="Failed";
                      ErrDesc="Previous button can not navigate to the previous tab.";
                  }
                  nextButton.click();
                  
        }
        catch(Exception e){
         ExecutionStatus="Not Executed";
         ErrDesc=e.getMessage();
        }
    }
    @Test
    public void verifyBoardSave() throws InterruptedException{
        TCID="KanbanBoardCreate_005";
        TCName="Verify save for creating a board.";
        WebElement saveBoard=null,boardColumn,nextButton=null;
        List<WebElement> boardList=null;
        try{
            boardList=new ArrayList<>();
            nextButton=kovairKanbanBoards.verifyApperenceOFBoard("Next Button", driver);
            nextButton.click();
            nextButton.click();
            saveBoard=template.getGITab("Save Board", driver);
            saveBoard.click();
            Thread.sleep(4000);
            template.searchTemplates(newBoardName, "EqualTo", driver);
            boardList=kovairKanbanBoards.kanbanListOfBoards(driver);
            if(boardList.size()>0)
            {
                ExecutionStatus="Passed";
                ErrDesc="";
            }
            else
            {
                ExecutionStatus="Failed";
                ErrDesc="Board is not created.";
            }
        }
        catch(Exception e)
        {
            ExecutionStatus="Not Executed";
            ErrDesc=e.getMessage();
        }
    }
    @Test
    public void verifyPageRedirectionWithNewUser() throws InterruptedException{
        TCID="Kanban_BoardList_001";
        TCName="Verify the page redirection after clicking on the Kanban Board Menu if the loged in user has not viewd any Active board or the loged in user is a new user.";
        WebElement createNewBoard=null;
        try{
            createNewBoard=kovairKanbanBoards.verifyApperenceOFBoardList("Create New Board", driver);
            if(createNewBoard.isDisplayed())
            {
                ExecutionStatus="Passed";
                ErrDesc="";
            }
            else
            {
                ExecutionStatus="Failed";
                ErrDesc="Board list page is not opened.";
            }
        }
        catch(Exception e)
        {
            ExecutionStatus="Not Executed";
            ErrDesc=e.getMessage();
        }
    }
    @Test
    public void verifyNoBoard() throws InterruptedException{
        TCID="Kanban_BoardList_005";
        TCName="Verify the Kanban Board List page if there is no board created.";
        WebElement noRecordFound=null;
        try{
            noRecordFound=kovairKanbanBoards.verifyApperenceOFBoardList("No record found", driver);
            if(noRecordFound.isDisplayed())
            {
                ExecutionStatus="Passed";
                ErrDesc="";
            }
            else
            {
                ExecutionStatus="Failed";
                ErrDesc="No Record(s) Found is not displayed.";
            }
        }
        catch(Exception e)
        {
             ExecutionStatus="Not Executed";
            ErrDesc=e.getMessage();
        }
    }
    @Test 
    public void verifyVisibilityOfHeaderAction() throws InterruptedException{
        TCID="Kanban_BoardList_006";
        TCName="Verify the Header Action from kanban Board List Page.";
        WebElement headerAction=null;
        try{
            headerAction=kovairKanbanBoards.verifyApperenceOFBoardList("Header Action", driver);
            if(headerAction.isDisplayed())
            {
                ExecutionStatus="Failed";
                ErrDesc="Header action is visible in board list page";
            }
             
        }
        catch(Exception e)
        {
           ExecutionStatus="Passed";
           ErrDesc="";
        }
    }
    @Test
    public void verifyCreateNewBoardVisibility() throws InterruptedException{
        TCID="Kanban_BoardList_007";
        TCName="Verify the create New Board from kanban Board List page.";
        WebElement createNewBoardLink=null;
        try{
            createNewBoardLink=kovairKanbanBoards.verifyApperenceOFBoardList("Create New Board", driver);
            if(createNewBoardLink.isDisplayed())
            {
                ExecutionStatus="Passed";
                ErrDesc="";
            }
            else
            {
                ExecutionStatus="Failed";
                ErrDesc="Board list page is not opened.";
            }
        }
        catch(Exception e)
        {
            ExecutionStatus="Not Executed";
            ErrDesc=e.getMessage();
        }
    }
    @Test
    public void verifyBoardlistColumn() throws InterruptedException{
        TCID="Kanban_BoardList_009";
        TCName="Verify the column names of the Kanban Board List page.";
        WebElement nameColumn=null,descColumn=null,createdByNameDateColumn=null;
        try 
        {
            nameColumn=kovairKanbanBoards.verifyApperenceOFBoardList("Column name", driver);
            descColumn=kovairKanbanBoards.verifyApperenceOFBoardList("Column description", driver);
            createdByNameDateColumn=kovairKanbanBoards.verifyApperenceOFBoardList("Column created by name date", driver);
            if(nameColumn.isDisplayed())
            {
                System.out.println("Name column is shown");
                if(descColumn.isDisplayed())
                {
                    System.out.println("Description column is shown");
                    if(createdByNameDateColumn.isDisplayed())
                    {
                        ExecutionStatus="Passed";
                        ErrDesc="";
                    }
                }
                else
                {
                    ExecutionStatus="Failed";
                    ErrDesc="Description column is not shown";
                }
            }
            else
            {
                ExecutionStatus="Failed";
                ErrDesc="Name column is not shown";
            }
        } 
        catch (Exception e) {
            ExecutionStatus="Not Executed";
            ErrDesc=e.getMessage();
        }
    }
    @Test
    public void verifySearchBoxVisibility() throws InterruptedException{
        TCID="Kanban_BoardList_013";
        TCName="Verify the search box from Kanban Board List page.";
        WebElement searchBox=null;
        try
        {
            searchBox=kovairKanbanBoards.verifyApperenceOFBoardList("Filter Text Box", driver);
            if(searchBox.isDisplayed())
            {
                ExecutionStatus="Passed";
                ErrDesc="";
            }
            else
            {
                ExecutionStatus="Failed";
                ErrDesc="Search box is not visible.";
            }
        }
        catch(Exception e)
        {
            ExecutionStatus="Not Executed";
            ErrDesc=e.getMessage();
        }
    }
    @Test
    public void verifyContainsCondition() throws InterruptedException{
        TCID="Kanban_BoardList_014";
        TCName="Verify search with contains option of search from Kanban Board List page.";
        WebElement searchBox=null,filterIcon=null,containsCondition=null;
        List<WebElement> boardList=null;
        int count=0;
        try
        {
            DateFormat dateformat=new SimpleDateFormat("DDMMYYYYHHMMSS");
            Date date=new Date();
            String boardTitle="Auto"+dateformat.format(date);
            kovairKanbanBoards.boardCreate(driver,boardTitle);
            boardList=new ArrayList<>();
//            searchBox=kovairKanbanBoards.verifyApperenceOFBoardList("Filter Text Box", driver);
//            filterIcon=kovairKanbanBoards.verifyApperenceOFBoardList("Filter Icon", driver);
//            containsCondition=kovairKanbanBoards.verifyApperenceOFBoardList("Contains", driver);
//            searchBox.click();
//            searchBox.clear();
//            searchBox.sendKeys("Auto");
//            filterIcon.click();
//            containsCondition.click();
            template.searchTemplates(boardTitle, "Contains", driver);
            boardList=kovairKanbanBoards.kanbanListOfBoards(driver);
            for(WebElement board:boardList)
            {
                if(board.getText().contains("Auto"))
                {
                    count++;
                }
            }
            if(count==boardList.size())
            {
                ExecutionStatus="Passed";
                ErrDesc="";
            }
            else
            {
                ExecutionStatus="Failed";
                ErrDesc="";
            }
        }
        catch(Exception e)
        {
            ExecutionStatus="Not Executed";
            ErrDesc=e.getMessage();
        }
    }
    @Test
    public void verifyDoesNotContainCondition() throws InterruptedException{
        TCID="Kanban_BoardList_015";
        TCName="Verify search with DoesNotContains option of search from Kanban Board List page.";
        WebElement searchBox=null,filterIcon=null,doesNotContainsCondition=null;
        List<WebElement> boardList=null;
        int count=0;
        try
        {
            boardList=new ArrayList<>();
//            searchBox=kovairKanbanBoards.verifyApperenceOFBoardList("Filter Text Box", driver);
//            filterIcon=kovairKanbanBoards.verifyApperenceOFBoardList("Filter Icon", driver);
//            doesNotContainsCondition=kovairKanbanBoards.verifyApperenceOFBoardList("DoesNotContain", driver);
//            searchBox.click();
//            searchBox.clear();
//            searchBox.sendKeys("Auto");
//            filterIcon.click();
//            doesNotContainsCondition.click();
            template.searchTemplates("Auto", "DoesNotContain", driver);
            boardList=kovairKanbanBoards.kanbanListOfBoards(driver);
            for(WebElement board:boardList)
            {
                if(board.getText().contains("Auto"))
                {
                    count++;
                }
            }
            if(count==0)
            {
                ExecutionStatus="Passed";
                ErrDesc="";
            }
            else
            {
                ExecutionStatus="Failed";
                ErrDesc="Board name contains search key";
            }
        }
        catch(Exception e)
        {
            ExecutionStatus="Not Executed";
            ErrDesc=e.getMessage();
        }
    }
    @Test
    public void verifyStartsWithCondition() throws InterruptedException{
        TCID="Kanban_BoardList_016";
        TCName="Verify search with StartsWith option of search from Kanban Board List page.";
        WebElement searchBox=null,filterIcon=null,startsWith=null;
        List<WebElement> boardList=null;
        int count=0;
        try{
            boardList=new ArrayList<>();
//            searchBox=kovairKanbanBoards.verifyApperenceOFBoardList("Filter Text Box", driver);
//            filterIcon=kovairKanbanBoards.verifyApperenceOFBoardList("Filter Icon", driver);
//            startsWith=kovairKanbanBoards.verifyApperenceOFBoardList("StartsWith", driver);
//            searchBox.click();
//            searchBox.clear();
//            searchBox.sendKeys("Auto");
//            filterIcon.click();
//            startsWith.click();
            template.searchTemplates("Auto", "StartsWith", driver);
            boardList=kovairKanbanBoards.kanbanListOfBoards(driver);
            for(WebElement board:boardList)
            {
                if(board.getText().startsWith("Auto"))
                {
                    count++;
                }
            }
            if(count==boardList.size())
            {
                ExecutionStatus="Passed";
                ErrDesc="";
            }
            else
            {
                ExecutionStatus="Failed";
                ErrDesc="All appeared boards are not started with the search key.";
            }
        }
        catch(Exception e)
        {
            ExecutionStatus="Not Executed";
            ErrDesc=e.getMessage();
        }
    }
    @Test
    public void verifyEndsWith() throws InterruptedException{
        TCID="Kanban_BoardList_017";
        TCName="Verify search with EndsWith option of search from Kanban Board List page.";
        WebElement searchBox=null,filterIcon=null,endsWith=null;
        List<WebElement> boardList=null;
        int count=0;
        try
        {
            DateFormat dateformat=new SimpleDateFormat("DDMMYYYYHHMMSS");
            Date date=new Date();
            String boardTitle=dateformat.format(date)+"Auto";
            kovairKanbanBoards.boardCreate(driver,boardTitle);
            boardList=new ArrayList<>();
//            searchBox=kovairKanbanBoards.verifyApperenceOFBoardList("Filter Text Box", driver);
//            filterIcon=kovairKanbanBoards.verifyApperenceOFBoardList("Filter Icon", driver);
//            endsWith=kovairKanbanBoards.verifyApperenceOFBoardList("EndsWith", driver);
//            searchBox.click();
//            searchBox.clear();
//            searchBox.sendKeys("Auto");
//            filterIcon.click();
//            Thread.sleep(1000);
//            endsWith.click();
            template.searchTemplates("Auto", "EndsWith", driver);
            boardList=kovairKanbanBoards.kanbanListOfBoards(driver);
            for(WebElement board:boardList)
            {
                if(board.getText().endsWith("Auto"))
                {
                    count++;
                }
            }
            if(count==boardList.size())
            {
                ExecutionStatus="Passed";
                ErrDesc="";
            }
            else
            {
                ExecutionStatus="Failed";
                ErrDesc="All appeared boards are not ended with search key";
            }
        }
        catch(Exception e)
        {
            ExecutionStatus="Not Executed";
            ErrDesc=e.getMessage();
        }
    }
    @Test
    public void verifyNoFilterCondition() throws InterruptedException{
        TCID="Kanban_BoardList_018";
        TCName="Verify search with NoFilter option of search from Kanban Board List page.";
        WebElement filterIcon=null,noFilter=null;
        List<WebElement> boardList=null;
        int count=0;
        try
        {
            boardList=new ArrayList<>();
            String allActiveBoards[][];
            allActiveBoards=sqlQueries.getSQLresult(sqlQueries.activeBoardsOfProject);
//            filterIcon=kovairKanbanBoards.verifyApperenceOFBoardList("Filter Icon", driver);
//            noFilter=kovairKanbanBoards.verifyApperenceOFBoardList("NoFilter", driver);
//            filterIcon.click();
//            noFilter.click();
            template.searchTemplates("", "NoFilter", driver);
            Thread.sleep(3000);
            boardList=kovairKanbanBoards.kanbanListOfBoards(driver);
            if(allActiveBoards.length==boardList.size())
            {
                for (String[] allActiveBoard : allActiveBoards) {
                    for (WebElement board : boardList) {
                        if (board.getText().equals(allActiveBoard[1])) {
                            count++;
                            break;
                        }
                    }
                }
                if(count==allActiveBoards.length)
                {
                    ExecutionStatus="Passed";
                    ErrDesc="";
                }
                else
                {
                    ExecutionStatus="Failed";
                    ErrDesc="Active board names doesnot match with visible board list ";
                }
            }
            else
            {
                ExecutionStatus="Failed";
                ErrDesc="All active boards are not shown in board list page";
            }
        }
        catch(Exception e)
        {
            ExecutionStatus="Not Executed";
            ErrDesc=e.getMessage();
        }
    }
    @Test
    public void verifySwitchKanbanBoards() throws InterruptedException
    {
        TCID="Kanban_BoardList_004";
        TCName="Verify user can switch between Kanban Boards.";
        WebElement firstBoardLink=null,secondBoardLink=null,headerAction=null,boardList=null;
        String firstBoard,secondBoard,firstBoardTitle,secondBoardTitle;
        try
        {
            firstBoardLink=kovairKanbanBoards.kanbanListOfBoards(driver).get(0);
            firstBoardTitle=firstBoardLink.getText();
            firstBoardLink.click();
            Thread.sleep(5000);
            kc=new KovairKanbanCard(driver);
            firstBoard=kc.verifyApperence("Board Title", driver).getText();
            kc.verifyApperence("Action Button", driver);
            boardList=kc.verifyApperence("Board List", driver);
            boardList.click();
            Thread.sleep(5000);
            secondBoardLink=kovairKanbanBoards.kanbanListOfBoards(driver).get(1);
            secondBoardTitle=secondBoardLink.getText();
            secondBoardLink.click();
            Thread.sleep(5000);
            secondBoard=kc.verifyApperence("Board Title", driver).getText();
            if(firstBoardTitle.equals(firstBoard))
            {
                if(secondBoardTitle.equals(secondBoard))
                {
                    ExecutionStatus="Passed";
                    ErrDesc="";
                }
                else
                {
                    ExecutionStatus="Failed";
                    ErrDesc="Second board is not opened properly.";
                }
            }
            else
            {
                ExecutionStatus="Failed";
                ErrDesc="First board is not opened properly.";
            }
        }
        catch(Exception e)
        {
            ExecutionStatus="Not Executed";
            ErrDesc="";
        }
    }
    @Test
    public void verifyKanbanBoardShowLastViewedBoard() throws InterruptedException
    {
        TCID="Kanban_BoardList_019";
        TCName="Verify whether the last viewd board is opened as active board while clicking on the Kanban Board Menu for an existing user.";
        WebElement boardName=null;
        String boardTitle,lastUsedBoard[][]=null;
        try
        {
            KovairGenericClass.logout(driver);
            Thread.sleep(5000);
            kovairloginpage.KovairLogin(BeforeAfterClassMethods.UserId, BeforeAfterClassMethods.Password, driver);
            Thread.sleep(5000);
            kovairhomepage.selectKovairWorkspaces(BeforeAfterClassMethods.Workspace, driver);
            Thread.sleep(10000);
            kovairhomepage.selectMenuItem("Kanban Board", driver);
            Thread.sleep(3000);
            boardTitle=kc.verifyApperence("Board Title", driver).getText();
            lastUsedBoard=sqlQueries.getSQLresult(sqlQueries.activeBoardOfProject);
            if(boardTitle.equals(lastUsedBoard[0][1]))
            {
                ExecutionStatus="Passed";
                ErrDesc="";
            }
            else
            {
                ExecutionStatus="Failed";
                ErrDesc="Last used board is not opened";
            }
        }
        catch(Exception e)
        {
            ExecutionStatus="Not Executed";
            ErrDesc=e.getMessage();
        }
    }
    @Test
    public void verifyKanbanBoardShowLastViewedBoardArchived() throws InterruptedException
    {
        TCID="Kanban_BoardList_020";
        TCName="Verify the opened page while cliking on Kanban Board if the last used board is archived for  an existing user.";
        WebElement createNewBoard=null,inactiveboard=null,validationOk=null;
        try
        {
            kc=new KovairKanbanCard(driver);
            kc.verifyApperence("Action Button",driver);
            inactiveboard=kc.verifyApperence("Archive Board", driver);
            inactiveboard.click();
            validationOk=kovairKanbanBoards.verifyNotifyToPopup("Validation OK", driver);
            validationOk.click();
            Thread.sleep(5000);
            KovairGenericClass.logout(driver);
            Thread.sleep(5000);
            KovairGenericClass.login(BeforeAfterClassMethods.URL, "ap", "ap", "AbhishekKanban", driver);
            Thread.sleep(5000);
            kovairhomepage.selectMenuItem("Kanban Board", driver);
            Thread.sleep(5000);
            createNewBoard=kovairKanbanBoards.verifyApperenceOFBoardList("Create New Board", driver);
            if(createNewBoard.isDisplayed())
            {
                ExecutionStatus="Passed";
                ErrDesc="";
            }
            else
            {
                ExecutionStatus="Failed";
                ErrDesc="Board list page is not opened.";
            }
        }
        catch(Exception e)
        {
            ExecutionStatus="Not Executed";
            ErrDesc=e.getMessage();
        }
    }
    @Test
    public void verifyNewUserLoggedin() throws InterruptedException
    {
        TCID="Kanban_BoardList_021";
        TCName="Verify a newly added user who is loged in ,can get the options to select  Board,Columns for creating a card.";
        WebElement createNewBoard=null;
        List<WebElement>boardList=null;
        try
        {
            boardList=new ArrayList<>();
            createNewBoard=kovairKanbanBoards.verifyApperenceOFBoardList("Create New Board", driver);
            boardList=kovairKanbanBoards.kanbanListOfBoards(driver);
            if(createNewBoard.isDisplayed())
            {
                if(!boardList.isEmpty())
                {
                    ExecutionStatus="Passed";
                    ErrDesc="";
                }
                else
                {
                    ExecutionStatus="Failed";
                    ErrDesc="Board list is not present";
                }
            }
            else
            {
                ExecutionStatus="Failed";
                ErrDesc="Create New Board is not displayed";
            }
        }
        catch(Exception e)
        {
            ExecutionStatus="Not Executed";
            ErrDesc=e.getMessage();
        }
    }
    @Test
    public void verifyNameColumnValue() throws InterruptedException
    {
        TCID="Kanban_BoardList_011";
        TCName="Verify the column value of name from Kanban Board List page.";
        WebElement searchBox=null,filterIcon=null,equalsCondition=null;
        List<WebElement> boardNames=null;
        try
        {
            DateFormat dateformat=new SimpleDateFormat("DDMMYYYYHHMMSS");
            Date date=new Date();
            newBoardName="AutoBoard"+dateformat.format(date);
            kovairKanbanBoards.boardCreate(driver, newBoardName);
            Thread.sleep(5000);
            searchBox=kovairKanbanBoards.verifyApperenceOFBoardList("Filter Text Box", driver);
            filterIcon=kovairKanbanBoards.verifyApperenceOFBoardList("Filter Icon", driver);
            equalsCondition=kovairKanbanBoards.verifyApperenceOFBoardList("Contains", driver);
            searchBox.click();
            searchBox.clear();
            searchBox.sendKeys(newBoardName);
            filterIcon.click();
            equalsCondition.click();
            boardNames=kovairKanbanBoards.verifyAppearanceOfBoardListColumns("Board Names", driver);
            if(!boardNames.isEmpty())
            {
                if(boardNames.get(0).getText().equals(newBoardName))
                {
                    ExecutionStatus="Passed";
                    ErrDesc="";
                }
                else
                {
                    ExecutionStatus="Failed";
                    ErrDesc="Board name is not showing properly";
                }
            }
            else
            {
                ExecutionStatus="Failed";
                ErrDesc="Board is not created with proper board name";
            }
        }
        catch(Exception e)
        {
            ExecutionStatus="Not Executed";
            ErrDesc=e.getMessage();
        }
        
    }
    @Test
    public void verifyBoardDescription() throws InterruptedException
    {
        TCID="Kanban_BoardList_012";
        TCName="Verify the column value of description from Kanban Board List page.";
        List<WebElement> boardDescription=null;
        try
        {
           boardDescription=kovairKanbanBoards.verifyAppearanceOfBoardListColumns("Board Description", driver);
           if(boardDescription.get(0).getText().equals(newBoardName))
           {
               ExecutionStatus="Passed";
               ErrDesc="";
           }
           else
           {
               ExecutionStatus="Failed";
               ErrDesc="Board description is not showing properly.";
           }
        }
        catch(Exception e)
        {
            ExecutionStatus="Not Executed";
            ErrDesc=e.getMessage();
        }
    }
    @Test
    public void verifyDefineColumnsNameofColumn() throws InterruptedException
    {
        TCID="KanbanBoardCreate_012";
        TCName="Verify names of column appears in Define Column tab is as similar with Template settings in board creation.";
        List<String> boardColumnNames=null;
        String[][] templateColumnNames=null;
        int count=0;
        try
        {
            boardColumnNames=template.columnNamesofDefinColumns(driver);
            templateColumnNames=sqlQueries.getSQLresult(sqlQueries.kanbanTemplateColumns);
            if(boardColumnNames.size()==templateColumnNames.length)
            {
                for(int i=0;i<boardColumnNames.size();i++)
                {
                    if(boardColumnNames.get(i).equals(templateColumnNames[i][1]))
                    {
                        count++;
                    }
                }
                if(count==templateColumnNames.length)
                {
                    ExecutionStatus="Passed";
                    ErrDesc="Failed";
                }
                else
                {
                    ExecutionStatus="Failed";
                    ErrDesc="Visible columns are not same as template column";
                }
            }
            else
            {
                ExecutionStatus="Failed";
                ErrDesc="All columns of the template are not visible";
            }
        }
        catch(Exception e)
        {
            ExecutionStatus="Not Executed";
            ErrDesc=e.getMessage();
        }
    }
    @Test
    public void verifyDefineColumnsNumberofColumn() throws InterruptedException
    {
        TCID="KanbanBoardCreate_011";
        TCName="Verify number of column appears in Define Column tab in board creation.";
        List<String> boardColumnNames=null;
        String[][] templateColumnNames=null;
        int count=0;
        try
        {
            boardColumnNames=template.columnNamesofDefinColumns(driver);
            templateColumnNames=sqlQueries.getSQLresult(sqlQueries.kanbanTemplateColumns);
            if(boardColumnNames.size()==templateColumnNames.length)
            {
                ExecutionStatus="Passed";
                ErrDesc="";    
            }
            else
            {
                ExecutionStatus="Failed";
                ErrDesc="All columns of the template are not visible";
            }
        }
        catch(Exception e)
        {
            ExecutionStatus="Not Executed";
            ErrDesc=e.getMessage();
        }
    }
    @Test
    public void verifyDefineColumnAddColumn() throws InterruptedException
    {
        TCID="KanbanBoardCreate_013";
        TCName="Verify new column can be added in Define Column tab.";
        WebElement newAddedColumn=null;
        try
        {
            template.getAlterColumns("Auto Column", "3", "2", Boolean.FALSE, driver);
            newAddedColumn=driver.findElement(By.xpath(template.getDefineColumn("Auto Column", "Column delete", driver)));
            if(newAddedColumn.equals("Column is not present"))
            {
                ExecutionStatus="Failed";
                ErrDesc="Column is not created";
            }
            else
            {
                ExecutionStatus="Passed";
                ErrDesc="";
            }
        }
        catch(Exception e)
        {
            ExecutionStatus="Not Executed";
            ErrDesc=e.getMessage();
        }
    }
    @Test
    public void verifyDeleteTemplateMappedColumn() throws InterruptedException
    {
        TCID="KanbanBoardCreate_014";
        TCName="Verify column that are created and mapped in Template Settings can not be deleted in Define Column tab in board creation.";
        String templateFirstColumn=null;
        WebElement deleteFirstColumn=null,validation=null,validationOK=null;
        try
        {
            templateFirstColumn=sqlQueries.getSQLresult(sqlQueries.kanbanTemplateColumns)[0][1];
            deleteFirstColumn=driver.findElement(By.xpath(template.getDefineColumn("Auto Column", "Column delete", driver)));
            deleteFirstColumn.click();
            validation=kovairKanbanBoards.verifyNotifyToPopup("Validation Message", driver);
            if(validation.getText().equals("You can not delete column due to column mapping"))
            {
                ExecutionStatus="Passed";
                ErrDesc="";
                validationOK=kovairKanbanBoards.verifyNotifyToPopup("Validation OK", driver);
                validationOK.click();
            }
            else
            {
                ExecutionStatus="Failed";
                ErrDesc="Deleting mapped column of template is not showing validation";
            }
        }
        catch(Exception e)
        {
          ExecutionStatus="Not Executed";
          ErrDesc=e.getMessage();  
        }
    }
    @Test
    public void verifyDefineColumnEditColumn() throws InterruptedException
    {
        TCID="KanbanBoardCreate_015";
        TCName="Verify column can be editable in Define Column tab.";
        WebElement columnHeader=null,columnName=null,submitButton=null;
        String colHeader=null,colName=null;
        try
        {
            colHeader=template.getDefineColumn("Auto Column","Edit",driver);
            columnHeader=driver.findElement(By.xpath(colHeader));
            columnHeader.click();
            colName=template.getDefineColumn("Column Name", title, driver);
            columnName=driver.findElement(By.xpath(colName));
            columnName.click();
            columnName.clear();
            columnName.sendKeys("Modified");
            popup=kt.new KovairKanbanTemplatesPopups(driver);
            submitButton=popup.submitButton;
            submitButton.click();
            Thread.sleep(2000);
            colHeader=template.getDefineColumn("Modified", "Column delete", driver);
            if(colHeader!=null)
            {
                template.getAlterColumns("Delete Column", "3", "2", Boolean.FALSE, driver);
                ExecutionStatus="Passed";
                ErrDesc="";
            }
            else
            {
                ExecutionStatus="Failed";
                ErrDesc="Column is not modified";
            }
        }
        catch(Exception e)
        {
             ExecutionStatus="Not Executed";
                ErrDesc=e.getMessage();  
        }
    }
    }
