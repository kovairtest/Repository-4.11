/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.kovair.TestPackages;

import com.kovair.PagelevelModule.KovairHomePageModule;
import com.kovair.PagelevelModule.KovairKanbanBoardModule;
import com.kovair.PagelevelModule.KovairKanbanCardModule;
import com.kovair.PagelevelModule.KovairLoginPageModule;
import com.kovair.pages.KovairKanbanTemplates;
import com.kovair.utilities.BeforeAfterClassMethods;
import com.kovair.utilities.SeleniumModules;
import com.kovair.utilities.sqlConnection;
import com.kovair.utilities.sqlQueries;
import java.io.File;
import java.util.List;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

/**
 *
 * @author prithwijitb
 */
public class Temp_Board {  
   static public WebDriver driver;
    static String ErrDesc;
    static String ExecutionStatus;
    static String TCName;
    static String TCID;
    static String PageName = "Kanban Board Creation";
    static int srlNo = 0;
    static String frameid = null;
    static File fXmlFile_Login = new File(System.getProperty("user.dir") + "//src/test/java/com/kovair/LoginInfo/LoginInfo.xml");
    static KovairLoginPageModule kovairloginpage;
    static KovairHomePageModule kovairhomepage;
    static KovairKanbanTemplates kt;
    static KovairKanbanBoardModule kovairKanbanBoards;
    static KovairKanbanCardModule cm;
    static sqlQueries sql;
    static String title="AutoTest";
    static List<String> columnValue=null;
    public Temp_Board()
    {
        kovairKanbanBoards=new KovairKanbanBoardModule(driver);
    }
    
    @BeforeTest
    @Parameters({"pages"})
    public  void landingClass(@Optional String landingPage) throws Exception { 
        try { 
            Object[] logdata = KovairLoginPageModule.LoginInfo(fXmlFile_Login);
            BeforeAfterClassMethods.getLogin(logdata);
            driver = KovairLoginPageModule.launchBrowser(BeforeAfterClassMethods.browser);
            driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
            BeforeAfterClassMethods.createRunId(PageName);
            driver.get(BeforeAfterClassMethods.URL);
            kovairloginpage = new KovairLoginPageModule(driver);
            Boolean n = kovairloginpage.KovairLogin(BeforeAfterClassMethods.UserId, BeforeAfterClassMethods.Password, driver);
            if (n.booleanValue()) {
                Thread.sleep(2000);
                kovairhomepage = new KovairHomePageModule(driver);
                kovairhomepage.waitforWorkspaces(driver);
                kovairhomepage.selectKovairWorkspaces(BeforeAfterClassMethods.Workspace, driver);
                Thread.sleep(4000);
                kovairhomepage.selectMenuItem("Kanban Board", driver);
                Thread.sleep(8000); 
                 if(landingPage.contains("Notification"))
                 {
                  kovairKanbanBoards = new KovairKanbanBoardModule(driver);
                  kovairKanbanBoards.verifyAppearanceOfNotification("Action Button", driver);
                  WebElement l =null; String t;
                  l=kovairKanbanBoards.verifyApperenceOFBoard("Create New Board", driver);
                  l.click();
                  l=kovairKanbanBoards.verifyApperenceOFBoard("BoardName", driver);
                  title="General Information";
                  l=kovairKanbanBoards.verifyApperenceOFBoard(title, driver);
                  l=l.findElement(By.xpath(".."));
                  t=l.getAttribute("style");
                  if(t.contains("color: rgb(64, 124, 197)"))
                   {
                   SeleniumModules.buttonClick(l, driver);
                   SeleniumModules.sendDataIntoTxt(l,"AutoBoard",driver);
                   l=kovairKanbanBoards.verifyApperenceOFBoard("Next Button", driver);
                   l.click();
                   title="Define Columns";
                   l=kovairKanbanBoards.verifyApperenceOFBoard(title, driver);
                   l=l.findElement(By.xpath(".."));
                   t=l.getAttribute("style");
                   if(t.contains("color: rgb(64, 124, 197)"))
                   { 
                      kovairKanbanBoards.verifyApperenceOFBoard("Next Button", driver).click();
                      title="Cards";
                      l=kovairKanbanBoards.verifyApperenceOFBoard(title, driver);
                      l=l.findElement(By.xpath(".."));
                      t=l.getAttribute("style");
                      if(t.contains("color: rgb(64, 124, 197)"))
                       { 
                       kovairKanbanBoards.verifyApperenceOFBoard("Next Button", driver).click();
                       title="Column Mapping";
                       l=kovairKanbanBoards.verifyApperenceOFBoard(title, driver);
                       l=l.findElement(By.xpath(".."));
                       t=l.getAttribute("style");
                       if(t.contains("color: rgb(64, 124, 197)"))
                        {  
                        System.out.println("In  Column Mapping tab");
                        } 
                       else{ 
                          System.out.println("Can not be reached at Column Mapping tab");
                          ErrDesc="Can not be reached at Column Mapping tab";
                          kovairloginpage.logout(driver); 
                        }
                       }else{  
                          System.out.println("Can not be reached at Cards tab");
                          ErrDesc="Can not be reached at Cards tab";
                          kovairloginpage.logout(driver); 
                       }
                     } 
                   else{  
                          System.out.println("Can not be reached at Cards tab");
                          ErrDesc="Can not be reached at Cards tab";
                          kovairloginpage.logout(driver); 
                       }
                   } 
                  else{  
                          System.out.println("Can not be reached at Cards tab");
                          ErrDesc="Can not be reached at Cards tab";
                          kovairloginpage.logout(driver); 
                       }
                 } 
            }
        }catch (Exception e) {
            System.out.println(e);
        }
    }

    @BeforeMethod
    public void BeforeMethod() throws Exception {
        srlNo++;
        ErrDesc = "";
        ExecutionStatus = "";
        TCName = "";
        TCID = "";
        BeforeAfterClassMethods.getLogid();
    }

    @AfterMethod
    public void TestCaseResult() throws Exception {
        String filePath=BeforeAfterClassMethods.takingScreenshot(srlNo,TCID,TCName,ExecutionStatus,ErrDesc,driver);
        sqlConnection.sqlInsert(BeforeAfterClassMethods.runId, srlNo, TCID, TCName, ExecutionStatus, ErrDesc, filePath);
     }
    
    @AfterTest
    public static void afterClass() throws Exception {
        kovairloginpage.logout(driver);
        driver.quit();
    }   
    
    @Test
    public void verify_CreateNewBoard() throws Exception{
     TCID="KanbanBoardCreate_001";
     TCName="Verify the option Create New Board while there is no active board.";
        try{
         
     }   
     catch(Exception e){
         ExecutionStatus="Not Executed";
         ErrDesc="verify_CreateNewBoard() method Failure, due to element change or instance problem";
     }
    }
    @Test
    public void verify_ClickingOnCreateNewBoard() throws Exception{
     TCID="KanbanBoardCreate_002";
     TCName="Verify click on Create New Board option in header action.";
        try{
         
     }   
     catch(Exception e){
         ExecutionStatus="Not Executed";
         ErrDesc="verify_ClickingOnCreateNewBoard() method Failure, due to element change or instance problem";
     }
    }
    @Test
    public void verify_AvailabalityCreateNewBoardForActiveBoard() throws Exception{
     TCID="KanbanBoardCreate_003";
     TCName="Verify the option Create New Board while there is an active board in header action.";
        try{
         
     }   
     catch(Exception e){
         ExecutionStatus="Not Executed";
         ErrDesc="verify_AvailabalityCreateNewBoardForActiveBoard() method Failure, due to element change or instance problem";
     }
    }
    @Test
    public void verify_LabelsOfGenInfoTab() throws Exception{
     TCID="KanbanBoardCreate_004";
     TCName="Verify three labels of General Information tab in board creation.";
        try{
         
     }   
     catch(Exception e){
         ExecutionStatus="Not Executed";
         ErrDesc="verify_LabelsOfGenInfoTab() method Failure, due to element change or instance problem";
     }
    }
     @Test
    public void verify_PageTitleInGenInfoTab() throws Exception{
     TCID="KanbanBoardCreate_005";
     TCName="Verify visibility of page title for creating a board.";
        try{
         
     }   
     catch(Exception e){
         ExecutionStatus="Not Executed";
         ErrDesc="verify_PageTitleInGenInfoTab() method Failure, due to element change or instance problem";
     }
    }
     @Test
    public void verify_SavingOfABoard() throws Exception{
     TCID="KanbanBoardCreate_006";
     TCName="Verify save for creating a board.";
        try{
         
     }   
     catch(Exception e){
         ExecutionStatus="Not Executed";
         ErrDesc="verify_SavingOfABoard() method Failure, due to element change or instance problem";
     }
    }
      @Test
    public void verify_TemplateValue() throws Exception{
     TCID="KanbanBoardCreate_007";
     TCName="Verify the value of  Template while creating board.";
        try{
         
     }   
     catch(Exception e){
         ExecutionStatus="Not Executed";
         ErrDesc="verify_TemplateValue() method Failure, due to element change or instance problem";
     }
    }
}
