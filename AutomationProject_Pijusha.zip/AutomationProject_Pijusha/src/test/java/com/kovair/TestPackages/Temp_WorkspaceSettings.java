/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.kovair.TestPackages;

import com.kovair.PagelevelModule.KovairHomePageModule;
import com.kovair.PagelevelModule.KovairKanbanTemlateModule;
import com.kovair.PagelevelModule.KovairLoginPageModule;
import com.kovair.PagelevelModule.WorkspaceSettingsModule;
import com.kovair.utilities.BeforeAfterClassMethods;
import com.kovair.utilities.SeleniumModules;
import com.kovair.utilities.sqlConnection;
import com.kovair.utilities.sqlQueries;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

/**
 *
 * @author Abhishekp
 */
public class Temp_WorkspaceSettings {
    static public WebDriver driver;
    static String TCID;
    static String TCName;
    static String ExecutionStatus;
    static String ErrDesc;
    static sqlQueries sql;
    static WorkspaceSettingsModule workspaceSettings;
    static List<String> entityNames=null;
    static KovairLoginPageModule kovairloginpage;
    static KovairHomePageModule kovairhomepage;
    static KovairKanbanTemlateModule kanbanTemlateModule;
    static String frameid = null;
    static int srlNo = 0;
    static String PageName = "Kanban Settings";
    static File fXmlFile_Login = new File(System.getProperty("user.dir") + "//src/test/java/com/kovair/LoginInfo/LoginInfo.xml");
//    public Temp_WorkspaceSettings()
//    {
//        
//    }
    @BeforeTest
    @Parameters({"pages"})
    public  void landingClass(@Optional String landingPage) throws Exception {
        try {
            Object[] logdata = KovairLoginPageModule.LoginInfo(fXmlFile_Login);
            BeforeAfterClassMethods.getLogin(logdata);
            driver = KovairLoginPageModule.launchBrowser(BeforeAfterClassMethods.browser);
            driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
            BeforeAfterClassMethods.createRunId(PageName);
            driver.get(BeforeAfterClassMethods.URL);
            kovairloginpage = new KovairLoginPageModule(driver);
            Boolean n = kovairloginpage.KovairLogin(BeforeAfterClassMethods.UserId, BeforeAfterClassMethods.Password, driver);
            if (n.booleanValue()) {
                Thread.sleep(2000);
                kovairhomepage = new KovairHomePageModule(driver);
                kovairhomepage.waitforWorkspaces(driver);
                kovairhomepage.selectKovairWorkspaces(BeforeAfterClassMethods.Workspace, driver);
                Thread.sleep(4000);
                kovairhomepage.Workspace_Setup_click(driver);
                Thread.sleep(8000);
                frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Workspace", "Settings", driver);
                driver.switchTo().frame(frameid);
//                kanbanTemlateModule = new KovairKanbanTemlateModule(driver);
//                 kanbanTemlateModule.getFullpageWebelment();
                if(landingPage.contains("Kanban Settings"))
                {   
                    workspaceSettings=new WorkspaceSettingsModule(driver);
                    WebElement edit,fieldsAndEntities,kanbanSettings;
                    edit= workspaceSettings.kanbanSettings("Edit", driver);
                    edit.click();
                    Thread.sleep(5000);
                    fieldsAndEntities=workspaceSettings.tabsAndSubtabs("Fields and Entities", driver);
                    fieldsAndEntities.click();
                    kanbanSettings=workspaceSettings.tabsAndSubtabs("Kanban Settings", driver);
                    kanbanSettings.click();
                }
                
            }
        } catch (Exception e) {
            System.out.println(e);
        }
    }
     @BeforeMethod
    public void BeforeMethod() throws Exception {
        srlNo++;
        ErrDesc = "";
        ExecutionStatus = "";
        TCName = "";
        TCID = "";
        BeforeAfterClassMethods.getLogid();
    }

    @AfterMethod
    public void TestCaseResult() throws Exception {
        String filePath=BeforeAfterClassMethods.takingScreenshot(srlNo,TCID,TCName,ExecutionStatus,ErrDesc,driver);
        sqlConnection.sqlInsert(BeforeAfterClassMethods.runId, srlNo, TCID, TCName, ExecutionStatus, ErrDesc, filePath);
     }
    
    @AfterTest
    public static void afterClass() throws Exception {
        kovairloginpage.logout(driver);
        driver.quit();
    } 
    @Test
    public void verifyAvailableEntities() throws InterruptedException{
       TCID="Kanban_Settings_001"; 
       TCName="Verify whether all the existing entities of a workspace  are reflecting in the Available entities of the  Kanban Settings";
       String entityDetails[][];
       List<WebElement> availableEntityList;
       int temp=0;
       try{
           entityNames= new ArrayList<String>();
           sql=new sqlQueries();
           entityDetails=sql.getSQLresult(sql.entityOfProject);
           for(int i=0;i<entityDetails.length;i++)
           {
               entityNames.add(entityDetails[i][1]);
           }
           availableEntityList=workspaceSettings.kanbanSettingsEntities("Available Entities", driver);
           if(entityNames.size()==availableEntityList.size())
           {
               for(int i=0;i<entityNames.size();i++)
               {
                   for(int j=0;j<availableEntityList.size();j++)
                   {
                       if(entityNames.get(i).equals(availableEntityList.get(j).getText()))
                        {
                           temp++;
                           break;
                        }
                   }
                   
               }
               if(temp==entityNames.size())
                {
                    ExecutionStatus="Passed";
                    ErrDesc="";
                }
                else if(temp==0)
                {
                    ExecutionStatus="Failed";
                    ErrDesc="Existing entities of the workspace are not same as Available Entities list of Kanban Settings.";
                }
           }
           else
           {
               ExecutionStatus="Failed";
               ErrDesc="Existing entities of the workspace are not same as Available Entities list of Kanban Settings.";
           }
           
       }
       catch(Exception e)
       {
           ExecutionStatus="Failed";
           ErrDesc=e.getMessage();
       }
    }
    @Test
    public void verifyAddButton() throws InterruptedException{
        TCID="Kanban_Settings_002";
        TCName="Verify moving the entities to the Selected entities in Kanban Settings with `Add` icon";
        List<WebElement> availableEntityList=null,selectedEntityList=null;
        List<String> selectedEntitiesNames=null;
        WebElement add=null;
        int temp=0;
        Actions action=new Actions(driver);
        try{
            selectedEntitiesNames=new ArrayList<String>();
            add=workspaceSettings.kanbanSettings("Add", driver);
            availableEntityList=workspaceSettings.kanbanSettingsEntities("Available Entities", driver);
            if(availableEntityList.size()>2)
            {
                action.keyDown(Keys.CONTROL).perform();
                for(int i=0;i<2;i++)
                {
                    availableEntityList.get(i).click();
                    selectedEntitiesNames.add(availableEntityList.get(i).getText());
                }
                add.click();
            }
            else
            {
                for(int i=0;i<availableEntityList.size();i++)
                {
                    action.keyDown(Keys.CONTROL).perform();
                    availableEntityList.get(i).click();
                    selectedEntitiesNames.add(availableEntityList.get(i).getText());
                }
                add.click();
            }
            selectedEntityList=workspaceSettings.kanbanSettingsEntities("Selected Entities", driver);
            if(selectedEntityList.size()==selectedEntitiesNames.size())
            {
                for(int i=0;i<selectedEntityList.size();i++)
                {
                    if(!selectedEntitiesNames.get(i).equals(selectedEntityList.get(i).getText()))
                    {
                        temp=1;
                        break;
                    }
                }
                if(temp==0)
                {
                    ExecutionStatus="Passed";
                    ErrDesc="";
                }
                else
                {
                    ExecutionStatus="Failed";
                    ErrDesc="Added entity names are not same as selected entity names.";
                }
            }
            else
            {
                ExecutionStatus="Failed";
                ErrDesc="All selected entities are not moved to Selected Entities list";
            }
        }
        catch(Exception e)
       {
           ExecutionStatus="Failed";
           ErrDesc=e.getMessage();
       }
    }
    @Test
    public void verifyAddAll() throws InterruptedException{
        TCID="Kanban_Settings_003";
        TCName="Verify moving the entities to the Selected entities in Kanban Settings with `Add All` icon";
        WebElement addAll=null;
        List<WebElement> selectedEntities=null,availableEntities=null;
        int temp=0;
        try{
            addAll=workspaceSettings.kanbanSettings("Add all", driver);
            addAll.click();
            Thread.sleep(2000);
            availableEntities=workspaceSettings.kanbanSettingsEntities("Available Entities", driver);
            if(availableEntities.isEmpty())
            {
                selectedEntities=workspaceSettings.kanbanSettingsEntities("Selected Entities", driver);
                if(entityNames.size()==selectedEntities.size())
                {
                    for(int i=0;i<selectedEntities.size();i++)
                    {
                        for(int j=0;j<entityNames.size();j++)
                        {
                            if(entityNames.get(j).equals(selectedEntities.get(i).getText()))
                             {
                                temp++;
                                break;
                             }
                        }
                    }
                    if(temp==entityNames.size())
                    {
                        ExecutionStatus="Passed";
                        ErrDesc="";
                    }
                    else 
                    {
                        ExecutionStatus="Failed";
                        ErrDesc="All selected entity names are not same as all entity names of the workspace";
                    }
                }
                else
                {
                    ExecutionStatus="Failed";
                    ErrDesc="All entities are not added in Selected Entities list";
                }
            }
            else
            {
                ExecutionStatus="Failed";
                ErrDesc="All entities are not added in Selected Entities list";
            }
        }
        catch(Exception e)
        {
           ExecutionStatus="Failed";
           ErrDesc=e.getMessage();
        }
    }
    @Test
    public void verifyRemove() throws InterruptedException{
        TCID="Kanban_Settings_004";
        TCName="Verify moving the entities to the Available entities in Kanban Settings with `Remove` icon";
        List<WebElement> selectedEntitiesList=null,availableEntitiesList=null;
        List<String> removedEntitesNames=null;
        Actions action=new Actions(driver);
        WebElement remove=null;
        int temp=0;
        try{
            removedEntitesNames=new ArrayList<String>();
            selectedEntitiesList=workspaceSettings.kanbanSettingsEntities("Selected Entities", driver);
            remove=workspaceSettings.kanbanSettings("Remove", driver);
            if(selectedEntitiesList.size()>2)
            {
                action.keyUp(Keys.CONTROL).perform();
                action.keyDown(Keys.CONTROL).perform();
                for(int i=0;i<2;i++)
                {
                    selectedEntitiesList.get(i).click();
                    removedEntitesNames.add(selectedEntitiesList.get(i).getText());
                }
                remove.click();
            }
            else
            {
                for(int i=0;i<selectedEntitiesList.size();i++)
                {
                    action.keyDown(Keys.CONTROL).perform();
                    selectedEntitiesList.get(i).click();
                    removedEntitesNames.add(selectedEntitiesList.get(i).getText());
                }
                remove.click();
            }
            availableEntitiesList=workspaceSettings.kanbanSettingsEntities("Available Entities", driver);
            if(removedEntitesNames.size()==availableEntitiesList.size())
            {
                for(int i=0;i<availableEntitiesList.size();i++)
                {
                    if(!availableEntitiesList.get(i).getText().equals(removedEntitesNames.get(i)))
                    {
                        temp=1;
                        break;
                    }
                }
                if(temp==0)
                {
                    ExecutionStatus="Passed";
                    ErrDesc="";
                }
                else if(temp==1)
                {
                    ExecutionStatus="Failed";
                    ErrDesc="Available Entities names are not same as Removed Entities names.";
                }
            }
            else
            {
                ExecutionStatus="Failed";
                ErrDesc="All removed entities are not added in Available Entities list";
            }
        }
        catch(Exception e)
        {
           ExecutionStatus="Failed";
           ErrDesc=e.getMessage();
        }
    }
    @Test
    public void verifyRemoveAll() throws InterruptedException{
        TCID="Kanban_Settings_005";
        TCName="Verify moving the entities to the Available entities in Kanban Settings with `Remove All` icon";
        WebElement removeAll=null,addAll=null;
        List<WebElement> availableEntitiesList=null,selectedEntitiesList=null;
        int temp=0;
        try{
            addAll=workspaceSettings.kanbanSettings("Add all", driver);
            addAll.click();
            removeAll=workspaceSettings.kanbanSettings("Remove all", driver);
            removeAll.click();
            selectedEntitiesList=workspaceSettings.kanbanSettingsEntities("Selected Entities", driver);
            availableEntitiesList=workspaceSettings.kanbanSettingsEntities("Available Entities", driver);
            if(selectedEntitiesList.isEmpty())
            {
                if(availableEntitiesList.size()==entityNames.size())
                {
                    for(int i=0;i<availableEntitiesList.size();i++)
                    {
                        for(int j=0;j<entityNames.size();j++)
                        {
                            if(entityNames.get(j).equals(availableEntitiesList.get(i).getText()))
                             {
                                temp++;
                                break;
                             }
                        }
                    }
                    if(temp==entityNames.size())
                    {
                        ExecutionStatus="Passed";
                        ErrDesc="";
                    }
                    else
                    {
                        ExecutionStatus="Failed";
                        ErrDesc="Available Entities names are not same as all entities names of the workspace.";
                    }
                }
                else
                {
                    ExecutionStatus="All entities are not moved to Available Entities list";
                }
            }
            else
            {
                ExecutionStatus="Failed";
                ErrDesc="All entities are not moved from Selected Entities list";
            }
        }
        catch(Exception e)
        {
           ExecutionStatus="Failed";
           ErrDesc=e.getMessage();
        }
    }
    @Test
    public void verifySave() throws InterruptedException{
        TCID="Kanban_Settings_006";
        TCName="Verify Saving the Kanban Settings";
        WebElement save=null,addAll=null,fieldsAndEntities=null,kanbanSettings=null;
        List<WebElement> selectedEntities=null,savedEntitiesList=null;
        List<String> addedEntities=null;
        int temp=0;
        try
        {
            addedEntities=new ArrayList<String>();
            addAll=workspaceSettings.kanbanSettings("Add all", driver);
            addAll.click();
            Thread.sleep(2000);
            selectedEntities=workspaceSettings.kanbanSettingsEntities("Selected Entities", driver);
            for(int i=0;i<selectedEntities.size();i++)
            {
                addedEntities.add(selectedEntities.get(i).getText());
            }
            save=workspaceSettings.kanbanSettings("Save", driver);
            save.click();
            Thread.sleep(10000);
            fieldsAndEntities=workspaceSettings.tabsAndSubtabs("Fields and Entities", driver);
            fieldsAndEntities.click();
            kanbanSettings=workspaceSettings.tabsAndSubtabs("Kanban Settings", driver);
            kanbanSettings.click();
            Select savedEntities=new Select(workspaceSettings.kanbanSettings("Saved Entities", driver));
            savedEntitiesList=savedEntities.getOptions();
            if(savedEntitiesList.size()==addedEntities.size())
            {
                for(int i=0;i<savedEntities.getOptions().size();i++)
                {
                    for(int j=0;j<addedEntities.size();j++)
                        {
                            if(savedEntitiesList.get(i).getText().equals(addedEntities.get(j)))
                            {
                                temp++;
                                break;
                            }
                        }
                   
                }
                if(temp==addedEntities.size())
                {
                    ExecutionStatus="Passed";
                    ErrDesc="";
                }
                else
                {
                    ExecutionStatus="Failed";
                    ErrDesc="";
                }
            }
            else
            {
                ExecutionStatus="All selected entities are not saved";
                ErrDesc="";
            }
        }
        catch(Exception e)
        {
           ExecutionStatus="Failed";
           ErrDesc=e.getMessage();
        }
    }
}
