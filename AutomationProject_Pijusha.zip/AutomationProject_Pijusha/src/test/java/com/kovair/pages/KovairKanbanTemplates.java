/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.kovair.pages;

import java.util.List;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;
import org.openqa.selenium.support.PageFactory;

/**
 *
 * @author sreyag
 */
public class KovairKanbanTemplates {

    @FindBy(xpath = "//td[@id='hdrLink']/div/ul/li/a")
    public WebElement createTemplateLink;

    @FindBy(xpath = "//p[@id='pageTitle']")
    public WebElement title;

    @FindBy(css = "div[id^='gridcolumn'][id$='titleEl']>span")
    public List<WebElement> columName;

    @FindBy(xpath = "//a[@id='ActionButton']")
    public WebElement kanbanaction_button;

    @FindBy(xpath = "//div[@id='KbnTemplateMenu-body']")
    public WebElement kanbanaction_buttonMenu;

    @FindBy(xpath = "//div[@id='KbnTemplateMenu-targetEl']/div/a/span")
    public List<WebElement> kanbanactionName;

    @FindBy(xpath = "//td[contains(@class,'x-grid-cell-first')]/div/span")
    public List<WebElement> kanbanTemplateListName;

    @FindBy(xpath = "//span[contains(@class,'x-btn-icon-el x-tbar-page-prev')]")
    public WebElement pageprev_button;

    @FindBy(xpath = "//span[contains(@class,'x-btn-icon-el x-tbar-page-next')]")
    public WebElement pagenext_button;

    @FindBy(xpath = "//span[contains(@class,'x-btn-icon-el x-tbar-page-last')]")
    public WebElement pagelast_button;

    @FindBy(xpath = "//span[contains(@class,'x-btn-icon-el x-tbar-page-first ')]")
    public WebElement pagefirst_button;

    @FindBy(css = "input[id^='ext-comp'][id$='inputEl']")
    public WebElement recordPerpage;

    @FindBy(xpath = "//span[@id='VALIDATOR_txtKbnTemplateName']")
    public WebElement mandatoryMessage;

    @FindBy(xpath = "//div[@id='KbnTemplateMenu-body']")
    public List<WebElement> actionMenuContainer;

    @FindBy(xpath = "//tbody[contains(@id,'gridview')]/tr/td[1]")
    public List<WebElement> firstTemplate;

    public String colorForClick = "border-bottom: 1px solid rgb(204, 204, 204); border-right: medium none; color: rgb(64, 124, 197)";
    public String colorForUnclick = "border-right: 1px solid rgb(204, 204, 204); color: rgb(184, 184, 184)";

    public KovairKanbanTemplates(WebDriver driver) {
        PageFactory.initElements(driver, this);
    }

    public class KovairKanbanActionMenuPages {

        @FindBy(xpath = "//input[@id='txtKbnTemplateName']")
        public WebElement nametxtInTemplates;

        @FindBy(xpath = "//textarea[@id='KbnTmpltDescription']")
        public WebElement descriptiontxtInTemplates;

        @FindBy(xpath = "//input[@id='Navigatenxt']")
        public WebElement NavigatenxtInTemplates;

        @FindBy(xpath = "//input[@id='NavigatePrv']")
        public WebElement NavigatePrvInTemplates;

        @FindBy(xpath = "//a[@id='A2']")
        public WebElement cancelbuttonInTemplates;

        @FindBy(xpath = "//input[@id='SaveBtn']")
        public WebElement SaveBtnInTemplates;

        @FindBy(xpath = "//input[@id='SaveSwimlaneBtn']")
        public WebElement doneButton;
                
        public KovairKanbanActionMenuPages(WebDriver driver) {
            PageFactory.initElements(driver, this);
        }
    }

    public class KovairKanbanTemplatesCardPages {

        @FindBy(xpath = "//div[@id='projectData']/ul/li")
        public List<WebElement> projectCards;

        @FindBy(xpath = "//div[@id='ColorDiv']/div")
        public List<WebElement> colors;

        @FindBy(xpath = "//div[@id='displayTbl']/table/tbody/tr/td")
        public List<WebElement> colorsAssign;

        @FindBy(xpath = "//table[@id='tblcards']/tbody/tr/td")
        public List<WebElement> cardsAssign;

        @FindBy(xpath = "//div[@id='lftPanal']/ul/li")
        public List<WebElement> tab;

        @FindBy(xpath = "//span[@id='VALIDATOR_tblcards']")
        public WebElement message;

        @FindBy(xpath = "//a[@class='EditDeleteStyle']")
        public List<WebElement> editDelete;

        @FindBy(xpath = "//select[@id='cardListdrpdwn']")
        public WebElement cards;

        @FindBy(xpath = "//input[@id='SaveCardBtn']")
        public WebElement cardsUpdate;

        @FindBy(xpath = "//span[@id='VALIDATOR_cardListdrpdwn']")
        public WebElement messagecardList;

        @FindBy(xpath = "//span[@id='VALIDATOR_ColorDiv']")
        public WebElement messageCol;

        @FindBy(xpath = "//input[@id='SaveCardBtn']")
        public WebElement saveButton;

        @FindBy(xpath = "//input[@id='NavigatePrv']")
        public WebElement previousButton;

        @FindBy(xpath = "//input[@id='Navigatenxt']")
        public WebElement nextButton;

        @FindBy(xpath = "//a[@id='A2']")
        public WebElement cancelButton;

        public KovairKanbanTemplatesCardPages(WebDriver driver) {
            PageFactory.initElements(driver, this);
        }
    }

    public class KovairKanbanTemplatesGIPages {

        @FindBy(xpath = "//label[@id='kbnnameLabel']")
        public WebElement nameTemplates;

        @FindBy(xpath = "//input[@id='txtKbnTemplateName']")
        public WebElement nameInTemplates;

        @FindBy(xpath = "//textarea [@id='KbnTmpltDescription']")
        public WebElement descriptionInTemplates;
        
        //This  element is for board creation and no use for template creation
        @FindBy(xpath = "//select[@id='ddlknbantemplate']/option[@selected='selected']")
        public WebElement selectedTemplate;
        
        @FindBy(xpath = "//ul[@id='Tab']/li/span")
        public List<WebElement> nameOfAreaInTemplates;

        @FindBy(xpath = "//a[@id='A2']")
        public WebElement cancelButton;

        @FindBy(xpath = "//input[@id='Navigatenxt']")
        public WebElement nextButton;

        public KovairKanbanTemplatesGIPages(WebDriver driver) {
            PageFactory.initElements(driver, this);
        }

    }
    
    public class deleteConfirmationPopup{
        
        @FindBy(xpath = "//input[@class='OkButton']")
        public WebElement confirmDelete;
        
        @FindBy(xpath = "//input[@class='CancelButton']")
        public WebElement cancelDelete;
        
        @FindBy(xpath = "//input[@id='btnModalOk']")
        public WebElement modalOk;
        
        public deleteConfirmationPopup(WebDriver driver)
        {
            PageFactory.initElements(driver, this);
        }
    }
    public class KovairKanbanTemplatesDCPages {

        @FindBy(xpath = "//div[@class='addNewDiv']")
        public WebElement addColumns;

        @FindBy(xpath = "//div[@id='ColumnDiv']/ul/li/div/span[1]")
        public List<WebElement> columnName;

        @FindBy(xpath = "//input[@ng-model='obj.ColumnText']")
        public WebElement columnNameTextBox;

        @FindBy(xpath = "//input[@ng-model='obj.WIPValue']")
        public WebElement wipLimit;

        @FindBy(xpath = "//input[@ng-model='obj.BufferValue']")
        public WebElement bufferValue;

        @FindBy(xpath = "//input[@ng-model='obj.ReqCycleTime']")
        public WebElement reqCycleTime;

        @FindBy(xpath = "//select[@ng-model='obj.SelectedTimeUnit']")
        public WebElement timeUnit;

        @FindBy(xpath = "//input[@ng-model='obj.FirstTimeLimit']")
        public WebElement firstTimeLimit;

        @FindBy(xpath = "//input[@ng-model='obj.SecondTimeLimit']")
        public WebElement secondTimeLimit;

        @FindBy(xpath = "//input[@ng-model='obj.MaxTimeLimit']")
        public WebElement maxTimeLimit;

        @FindBy(xpath = "//div[@class='close-button']")
        public WebElement closeButton;

        @FindBy(xpath = "//input[@value='Submit']")
        public WebElement submitButton;

        @FindBy(xpath = "//a[@id='A2']")
        public WebElement cancelButton;
        
        @FindBy(xpath = "//img[@title='Remove']")
        public List<WebElement> removeColumn;
        
        @FindBy(xpath="//img[contains(@title,'Split')]")
        public List<WebElement> splitButton;
        
        @FindBy(xpath = "//div[@id='ColumnDiv']/ul/li[3]/div/div/span[1]")
        public List<WebElement> splittedColumnNames;
        
        @FindBy(xpath = "//div[@id='ColumnDiv']/ul/li[3]/div/div/span[2]/img")
        public List<WebElement> splittedColumnDeletes;
                
        public KovairKanbanTemplatesDCPages(WebDriver driver) {
            PageFactory.initElements(driver, this);
        }
    }

    public class KovairKanbanTemplatesCMPages {

        @FindBy(xpath = "//div[@class='dropdown-menu dropdown-menu-form']/div/ul")
        public List<WebElement> Columns;

        @FindBy(xpath = "//span[@class='setSpan']")
        public List<WebElement> setButton;

        @FindBy(xpath = "//dropdown-multiselect[@class='ng-isolate-scope']/div[1]")
        public List<WebElement> addMappingValues;

//        @FindBy(xpath = "//input[contains(@class,'checkboxInput')]")
        public String MappingValuesForColumn="//input[contains(@class,'checkboxInput')]";//span[contains(@ng-click,'RemoveMapping')]
        
        @FindBy(xpath = "//span[contains(@ng-click,'RemoveMapping')]")
        public List<WebElement> removeMappedValuesOfColumn;

        @FindBy(xpath = "//div[@ng-repeat='value in item.MapedValues']")
        public List<WebElement> MappedValuesOfColumns;

        
        public String unmapValidation="//span[@id='VALIDATOR_tblmapping']";
        
      //  @FindBy(xpath = "//table[@id='tblmapping']/tbody/tr/td[1]")
       // public List<WebElement> columnNames;
        public String columnNames="//table[@id='tblmapping']/tbody/tr/td[1]";
        
        public KovairKanbanTemplatesCMPages(WebDriver driver) {
            PageFactory.initElements(driver, this);
        }
    }

    public class KovairKanbanTemplatesPopups {

        @FindBy(xpath = "//div[@id='ColumnDiv']/div[@class='popupDiv']/div[contains(@class,'PopUpModal')]")
        public WebElement popups;

        @FindBy(xpath = "//div[@id='ColumnDiv']/ul/li/div/span[1]")
        public List<WebElement> columnsName;

        @FindBy(xpath = "//div[@id='ColumnDiv']/div[@class='popupDiv']/div[contains(@class,'PopUpModal')]/div[contains(@class,'close-button')]")
        public WebElement ofPopups;

        @FindBy(xpath = "//div[@id='ColumnDiv']/div[@class='popupDiv']/div[contains(@class,'PopUpModal')]/table/tbody/tr")
        public List<WebElement> columnsOfpopups;

        @FindBy(xpath = "//div[@id='ColumnDiv']/div[@class='popupDiv']/div[contains(@class,'PopUpModal')]/table/tbody/tr/td")
        public List<WebElement> columnsOfpopup;

        @FindBy(xpath = "//input[@class='greenButtonMid'][@value='Submit']")
        public WebElement submitButton;
        //added by AP
        @FindBy(xpath = "//input[contains(@ng-model,'ReqCycleTime')]")
        public WebElement RequiredCycleTimeCheckbox;

        public String n = "//td";
        public String name = "//td[1]";
        public String nameInput = "//input";

        public KovairKanbanTemplatesPopups(WebDriver driver) {
            PageFactory.initElements(driver, this);
        }
    }
    //This contains the elements of swimlane tab at the time of board creation
    public class swimlane{
        
        @FindBy(xpath = "//div[@id='TabSwimlaneContaine']/div[1]/div[1]/span")
        public WebElement swimLaneLabel;
        
        @FindBy(xpath = "//div[@id='TabSwimlaneContaine']/div[1]/div[1]/select")
        public WebElement swimlaneOnDropdown;
        
        @FindBy(xpath = "//div[@id='TabSwimlaneContaine']/div[1]/div[2]/label")
        public List<WebElement> swimlaneAvailableValues;
        
        @FindBy(xpath = "//input[@id='SaveSwimlaneBtn']")
        public WebElement saveSwimlane;
        
        @FindBy(xpath = "//span[@style='color: blue;']")
        public List<WebElement> selectedSwimlaneValues;
        
        @FindBy(xpath = "//div[@id='TabSwimlaneContaine']/div[2]/div[2]/div/span[1]/a")
        public WebElement editSwimLane;
        
        @FindBy(xpath = "//div[@id='TabSwimlaneContaine']/div[2]/div[1]")
        public WebElement noswimLane;
        
        @FindBy(xpath = "//div[@id='TabSwimlaneContaine']/div[2]/div[2]/div/span[2]/a")
        public WebElement deleteSwimLane;
        
        public swimlane(WebDriver driver)
        {
            PageFactory.initElements(driver, this);
        }
    }
}
