/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.kovair.pages;

import java.util.List;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

/**
 *
 * @author sreyag
 */
public class KovairSearchItemElement {
   
    @FindBy(xpath = "//span[@class='tooltipDemo']")
    public WebElement KovairSearchAlt;
    
    @FindBy(how=How.ID,using="Img2")
    public WebElement KovairAdvanceSearchLogo;  
    
    @FindBy(xpath = "//input[@id='KovairMaster_Main_chkID']")
    public WebElement KovairSearchID;
    
    @FindBy(xpath = "//img[@id='cross']")
    public WebElement KovairSearchIDCross;
    
    @FindBy(xpath = "//input[@id='KovairMaster_Main_txtSearchByIdOrTxt']")
    public WebElement KovairSearchText;
    
    @FindBy(xpath = "//input[@id='KovairMaster_Main_btnSearch']")
    public WebElement KovairButtonSearch; 
    
    public KovairSearchItemElement(WebDriver driver)
    {
        //this.driver = driver;
        PageFactory.initElements(driver, this);
        
    }
}
