/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.kovair.pages;

import java.util.List;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;
import org.openqa.selenium.support.PageFactory;

/**
 *
 * @author sreyag
 */
public class KovairKanbanCardElement { 
   
   @FindBy(xpath = "//img[@class='menuIcon']")
   public WebElement logoHDAction; 
   
   //This element is invalid and need to be changed
   @FindBy(xpath = "//ul[@id='KovairMaster_Main_headerIconsUL']/li[contains(@onclick,'AddCard')]/span")
   public WebElement logoCard; 
   
   @FindBy(xpath = "//em")
   public WebElement popupHeader;
   
   @FindBy(xpath = "//a[@class='rwCloseButton'][@tabindex='0']")
   public WebElement popupClose;
   
    public KovairKanbanCardElement(WebDriver driver)
    {
        //this.driver = driver;
        PageFactory.initElements(driver, this);
        
    } 
    
    public class BoardContextMenuPopup{
        
        @FindBy(xpath = "//span[text()='Archive']")
        public WebElement archiveCard;
        
        @FindBy(xpath = "//span[text()='Add Card']")
        public WebElement addCard;
        
        @FindBy(xpath = "//span[text()='Move']")
        public WebElement moveCard;
        
        public BoardContextMenuPopup(WebDriver driver)
        {
            PageFactory.initElements(driver, this);
        }
    }
   //This contains the elements of the popup after clicking add card from action menu
   public class BoardAddcard{ 
    
    //This element was in the header action menu list and 
   @FindBy(xpath = "//ul[@id='KovairMaster_Main_headerIconsUL']/li[contains(@onclick,'AddCard')]/span")
   public WebElement titleAddCard;
   
   @FindBy(xpath = "//li[contains(@onclick,'Dashboard')]/span")
   public WebElement dashboardActionHeader;
   
   @FindBy(xpath = "//ul[@id='KovairMaster_Main_headerIconsUL']/li[contains(@onclick,'archiveBoard')]/span")
   public WebElement titleArchivedBoard;
   
   @FindBy(xpath = "//li[contains(@onclick,'ArchiveBoardList')]/span")
   public WebElement archiveBoardListActionHeader;
   
   @FindBy(xpath = "//li[contains(@onclick,'ArchivedCardList')]/span")
   public WebElement archiveCardList;
   
   @FindBy(xpath = "//li[contains(@onclick,'BackLog')]/span")
   public WebElement backlog;
   
   @FindBy(xpath = "//li[contains(@onclick,'BoardListPage')]/span")
   public WebElement boardList;
   
   @FindBy(xpath = "//div [@id='AddCardDiv']/div[1]")
   public WebElement closAddCard;
   
   @FindBy(xpath = "//ul[@id='KovairMaster_Main_headerIconsUL']/li[contains(@onclick,'createNewBoard')]/span")
   public WebElement titleAddBoard;
   
   @FindBy(xpath = "//div[@id='AddCardDiv']/div[contains(text(),'Add Card')]")
   public WebElement titleOfAddCard;
   
   @FindBy(xpath = "//select[@id='entlstdrpdwn']")
   public WebElement typeOfCard;
   
   //This element is not needed due to design change
   @FindBy(xpath = "//div[@id='RestoreCard']")
   public WebElement restoreCard;
   
   @FindBy(xpath = "//div[@id='NewRecord']")
   public WebElement create;
        
   
   public BoardAddcard(WebDriver driver)
    {
        PageFactory.initElements(driver, this);
    } 
   }  
   
   //This contains all the elements present in General Information tab at the time of board creation
   public class BoardCreateGI{  
   
       @FindBy(xpath = "//input[@id='txtKbnTemplateName']")
       public WebElement boardTitle;
       
       @FindBy(xpath = "//textarea[@id='KbnTmpltDescription']")
       public WebElement boardDescription;
       
       @FindBy(xpath = "//select[@id='ddlknbantemplate']")
       public WebElement typeOftemplate;
       
       @FindBy(xpath = "//input[@id='Navigatenxt']")
       public WebElement buttonNext;
       
       @FindBy(xpath = "//a[@id='A2']")
       public WebElement button;
       
       @FindBy(xpath = "//input[@id='SaveBtn']")
       public WebElement buttonSave;
       
       @FindBy(xpath = "//label[@id='kbnnameLabel']")
       public WebElement nameLabel;
       
       @FindBy(xpath = "//label[@id='lblknbantemplate']")
       public WebElement templateLabel;
       
       @FindBy(xpath = "//div[@id='TabGenContain']/table/tbody/tr[3]/td[1]/label")
       public WebElement descriptionLabel;
       
       public BoardCreateGI(WebDriver driver)
    {
        PageFactory.initElements(driver, this);
    } 
       
   }
   
   //This contains all the elements present at the time of card creation
   public class CreatePopup{ 
    
    @FindBy(xpath = "//p[@id='pageTitle']")
    public WebElement pageTitleLable;
       
    @FindBy(xpath = "//label[contains(@id,'KovairMaster_Main_colPanel_Section')]/b[text()='Title']")
    public WebElement cardTitleLable;
    
    @FindBy(xpath = "//label[contains(@id,'KovairMaster_Main_colPanel_Section')]/b[text()='Card Priority']")
    public WebElement cardPriorityLable;
    
    @FindBy(xpath = "(//input[@class='rcbInput radPreventDecorate form-control input-sm'])[1]")
    public WebElement cardPriorityDropdown;
    
    @FindBy(xpath = "//label[contains(@id,'KovairMaster_Main_colPanel_Section')]/b[text()='Class of Service']")
    public WebElement cardofServiceLable;
    
    @FindBy(xpath = "(//input[@class='rcbInput radPreventDecorate form-control input-sm'])[2]")
    public WebElement cardofServiceDropdown;
    
    @FindBy(xpath = "//label[contains(@id,'KovairMaster_Main_colPanel_Section')]/b[text()='Card Status']")
    public WebElement cardStatusLable;
   
    @FindBy(xpath = "//input[@id='btnSave']")
    public WebElement buttonSave;
    
    @FindBy(xpath = "//td[@id='KovairMaster_Main_Td3']/a[@id='aCancel']")
    public WebElement buttonCancel;
    
    //This two elements are removed due to design change
    //@FindBy(xpath = "//input[@id='KovairMaster_Main_btnSC']")
    //public WebElement buttonSaveContinue;
    
    //@FindBy(xpath = "//input[@id='KovairMaster_Main_btnSN']")
    //public WebElement buttonSaveN; 
    
    @FindBy(xpath = "//div[@id='icon_set_bg']/table/tbody/tr/td[2]/img[@title='Click here to Reset the page.']")
    public WebElement pageResetLable;
    
    @FindBy(xpath = "//div[@id='icon_set_bg']/table/tbody/tr/td[1]/img[@title='Click here to see the Available Sections']")
    public WebElement buttonAvailable;
    
    @FindBy(xpath = "//div[@id='icon_set_bg']/table/tbody/tr/td[3]/img[@title='Click here for adding this page to Bookmarks']")
    public WebElement buttonBookmarks;
    
    @FindBy(xpath = "//span[@id='lblAddfav']")
    public WebElement buttonAddtoBookmarks;
   
    @FindBy(xpath = "//input[@id='AddButton']")
    public WebElement buttonAddInBookmarks;
    
    @FindBy(xpath = "//span[@id='btnCancel']")
    public WebElement btnCancelInBookmarks;
    
   @FindBy(xpath = "//input[@id='FavName']")
    public WebElement nameBookmarks;

    
    public CreatePopup(WebDriver driver)
    {
        PageFactory.initElements(driver, this);
    } 
   }   
   //This contains all the elements of validation modal
   public class Validation_check{
       
    @FindBy(xpath = "//table[@id='dialog_content']/tbody/tr/td[2]")
    public WebElement validationMessage;
    
    @FindBy(xpath = "//input[@id='btnModalOk']")
    public WebElement validationOK;
    
    public Validation_check(WebDriver driver)
    {
        PageFactory.initElements(driver, this);
    } 
   }  
   
   //This contains all the elements present at the time of creating a board
   public class ActiveBoardCreation{  
   
       @FindBy(xpath = "//div[@id='board']/div")
       public WebElement boardColumn;
       
       @FindBy(xpath = "//textarea[@id='KbnTmpltDescription']")
       public WebElement boardDescription;
       
       @FindBy(xpath = "//select[@id='ddlknbantemplate']")
       public WebElement typeOftemplate;
       
       @FindBy(xpath = "//input[@id='Navigatenxt']")
       public WebElement buttonNext;
       
       @FindBy(xpath = "//a[@id='A2']")
       public WebElement button;
       
       @FindBy(xpath = "//input[@id='SaveBtn']")
       public WebElement buttonSave;
       
       
       public ActiveBoardCreation(WebDriver driver)
    {
        PageFactory.initElements(driver, this);
    } 
       
   }  
   
   //This is for the elements of an active board with one time card view elements without any popup
    public class ActiveBoard{  
       int i;
       
       @FindBy(xpath = "//p[@id='pageTitle']")
       public WebElement pageName;
       
       @FindBys(
       @FindBy(xpath = "//div[@id='board']/div"))
       public List<WebElement> boardColumn;
       
//        with multiple @FindBy annotations to look for elements that match any of the given locators:
//        @FindAll({
//        @FindBy(how=How.ID, using=”username”),
//        @FindBy(className=”username-field”)
//        })
//        private WebElement user_name;

       @FindBy(xpath = "//div[@class='item']/div[@class='containerbody']")
       public List<WebElement> boardColumnID;
       
//       @FindBy(xpath = "//div/div[contains(@class,'swimLaneheader')]")
//       public WebElement boardColumnSLName;
       public String boardColumnSLName="//div/div[contains(@class,'swimLaneheader')]";
       
       @FindBy(xpath = "//div[@class='item']/div[@class='containerbody'][@columnid='1']/div/div[contains(@class,'swimLaneheader')]")
       public List<WebElement> boardColumnSL;
       
       
       @FindBy(xpath = "//div[@class='item']/div[contains(text(),'To Do')]")
       public WebElement boardColumnName;
       
       @FindBy(xpath = "//div[@class='item']/div[@class='containerbody']/div/div[contains(@class,'SwimLaneDiv_')]/div[contains(@id,'Carditem')]")
       public List<WebElement> cardNumber;
       
       @FindBy(xpath = "//div[@class='item']/div[@class='containerbody']/div/div[contains(@class,'SwimLaneDiv_')]/div[contains(@id,'Carditem')]/div/span[@title='Title']")
       public List<WebElement> card;
       
//       @FindBy(xpath = "//div/span[@title='Title']")
//       public WebElement cardName;
       
//       @FindBy(xpath = "//div[@class='scrolldivdwn']/div[1]/img")
//       public WebElement cardOption;
       public String cardSLName="//div[@class='containerbody']/div/div/div[contains(@class,'swimLaneheader')]";
       public String cardSL="//div[contains(@class,'swimLaneheader')]";
       public String cardName="//div/span[@title='Title']";
       public String cardOptionDn="//div[@class='scrolldivdwn']/div[1]/img";
       public String cardOptionUp="//div[@class='scrolldivUp']/div[1]/img";
       public String cardOptionsNo="//div[@class='scrolldivUp']/div[2]/img";
       
       public void setData(WebDriver driver,WebElement rt)
       { 
        
        PageFactory.initElements(driver, rt);
       } 
       
       public void setData(WebElement be,WebElement rt)
       { 
        PageFactory.initElements((WebDriver) rt, be);
       } 
       
       public ActiveBoard(WebDriver driver)
       {
        PageFactory.initElements(driver, this);
       } 
       
   } 
    
    //This contains all the icon elements of an active card 
    public class cardIcons
    {
        @FindBy(xpath = "//img[contains(@src,'collapse-arrow-down')]")
        public WebElement showHideIcons;
        
        @FindBy(xpath = "//img[contains(@src,'collapse-arrow-down')]")
        public List<WebElement> expandIcons;
        
        @FindBy(xpath = "//img[contains(@src,'collapse-arrow-up')]")
        public List<WebElement> collapseIcons;
        
        @FindBy(xpath = "//img[contains(@title,'Activity Log')]")
        public WebElement activityLog;
        
        @FindBy(xpath = "//img[contains(@title,'backlog')]")
        public WebElement backlog;
        
        @FindBy(xpath = "//img[contains(@title,'Task')]")
        public WebElement task;
        
        @FindBy(xpath = "//img[contains(@title,'Comment')]")
        public WebElement comment;
        
        @FindBy(xpath = "//img[contains(@title,'Block')]")
        public WebElement blockedCard;
        
        @FindBy(xpath = "//img[contains(@title,'Unblock')]")
        public WebElement unblockedCard;
        
        @FindBy(xpath = "//img[contains(@src,'flag-gray')]")
        public List<WebElement> unflaggedCard;
        
        @FindBy(xpath = "//img[contains(@title,'Remove')]")
        public WebElement remove;
        
        @FindBy(xpath = "//img[contains(@src,'flag-red')]")
        public List<WebElement> flaggedCard;
        
        public cardIcons(WebDriver driver)
        {
            PageFactory.initElements(driver, this);
        }
    } 
    //This is for the comments for an active card present in a board
    public class cardCommentSummary{
        @FindBy(xpath = "//div[@id='CommentSection']/div[1]")
        public WebElement closeComment;
        
        @FindBy(xpath = "//div[@id='CommentSection']/div[2]/div/div[1]/div[1]/b")
        public List<WebElement> operationTag;
        
        @FindBy(xpath = "//div[@id='CommentSection']/div[2]/div/div[1]/div[1]")
        public List<WebElement> operationText;
        
        @FindBy(xpath = "//div[@id='CommentSection']/div[2]/div/div[1]/div[2]")
        public List<WebElement> commentText;
        
        @FindBy(xpath = "//div[@id='CommentSection']/div[2]/div/div[2]/span[1]")
        public List<WebElement> commentedBy;
                
        @FindBy(xpath = "//div[@id='CommentSection']/div[2]/div/div[2]/span[2]")
        public List<WebElement> commentedOn;
        
        public cardCommentSummary(WebDriver driver)
        {
            PageFactory.initElements(driver, this);
        }
    } 
    //This is for the element of comments at the time of moving or blocking/unblocking card
    public class CardComment
    {
        @FindBy(xpath = "//div[@id='Commantdiv']/div[1]")
        public WebElement popupTitle;
        
        @FindBy(xpath = "//div[@id='Commantdiv']/div[2]/textarea")
        public WebElement commentText;
        
        @FindBy(xpath = "//div[@id='Commantdiv']/div[3]/a")
        public WebElement submitComment;
        
        public CardComment(WebDriver driver)
        {
            PageFactory.initElements(driver, this);
        }
    }
    //This is for backlog elements for an active card present in the board
    public class backlog{
        
        @FindBy(xpath = "//em")
        public WebElement popupName;
        
        @FindBy(xpath = "//div[contains(@id,'titleEl')]/span")
        public List<WebElement> columnName;
        
        @FindBy(xpath = "//tr[contains(@id,'gridview')]")
        public List<WebElement> cardList;
        
        @FindBy(xpath = "(//span[contains(@id,'gridcolumn')])[1]")
        public WebElement selectAllCheckbox;
        
        @FindBy(xpath = "//span[text()='ID']")
        public WebElement IDColumnHeader;
        
        @FindBy(xpath = "//span[text()='Title']")
        public WebElement titleColumnHeader;
        
        @FindBy(xpath = "//span[text()='EntityName']")
        public WebElement entityNameColumnHeader;
        
        @FindBy(xpath = "//tbody[contains(@id,'gridview')]")
        public WebElement backlogCardList;
        
        @FindBy(xpath = "//div[@id='Add to board']")
        public WebElement addToBoardOption;
        
        @FindBy(xpath = "//tr[contains(@id,'gridview')]/td[1]/div/div")
        public List<WebElement> cardCheck;
        
        @FindBy(xpath = "//tr[contains(@id,'gridview')]/td[2]/div")
        public List<WebElement> cardID;
        
        @FindBy(xpath = "//tr[contains(@id,'gridview')]/td[3]/div")
        public List<WebElement> cardTitle;
        
        @FindBy(xpath = "//tr[contains(@id,'gridview')]/td[4]/div")
        public List<WebElement> cardEntityName;
       
        @FindBy(xpath = "//a[contains(@title,'Close')]")
        public WebElement closeBacklog;
        
        @FindBy(xpath = "//a[@id='btnFileCancelView']")
        public WebElement cancelBacklog;
        
        @FindBy(xpath = "//div[@style='width: 175px;']")
        public WebElement availableBoards;
        
        //Previously Save button was present at the bottom of the popup
        @FindBy(xpath = "//input[contains(@value,'Save')]")
        public WebElement saveBacklog;
        
        public backlog(WebDriver driver)
        {
            PageFactory.initElements(driver, this);
        }
    }

    
    // This is for column mapping at the time of Create or Edit Template
    public class columnMapping
    {
        @FindBy(xpath = "//table[contains(@id,'objectSelectionTable')]/tbody/tr/td[1]")
        public WebElement mapField;  
 
        @FindBy(xpath = "//table[contains(@id,'objectSelectionTable')]/tbody/tr/td[2]")
        public WebElement kanbanBoardStatus;
        
        @FindBy(xpath = "//table[@id='tblmapping']/tbody/tr/td[1]")
        public List<WebElement> columnName;
        
        @FindBy(xpath = "//div[contains(@ng-repeat,'value in item.MapedValues')]")
        public List<WebElement> mappedFieldValues;
        
        @FindBy(xpath = "//span[contains(text(),'X')]")
        public List<WebElement> removeMappedFields;
        
        @FindBy(css = ".multiselect-parent.btn-group.dropdown-multiselect")
        public List<WebElement> tagFieldValue;
        
        @FindBy(xpath = "//label[contains(text(),'Ready')]")
        public List<WebElement> ready;
        
        @FindBy(xpath = "//label[contains(text(),'Dev In Progress')]")
        public List<WebElement> devInProgress;
        
        @FindBy(xpath = "//label[contains(text(),'Dev Done')]")
        public List<WebElement> devDone;
        
        @FindBy(xpath = "//label[contains(text(),'Completed')]")
        public List<WebElement> completed;
        
        @FindBy(xpath = "//label[contains(text(),'QA In Progress')]")
        public List<WebElement> qaInProgress;
        
        @FindBy(xpath = "//label[contains(text(),'QA Done')]")
        public List<WebElement> qaDone;
        
        @FindBy(xpath = "//label[contains(text(),'TEST')]")
        public List<WebElement> test;
        
        @FindBy(xpath = "//label[contains(text(),'Submitted')]")
        public List<WebElement> submitted;
        
        @FindBy(xpath = "//label[contains(text(),'Pending')]")
        public List<WebElement> pending;
        
        @FindBy(xpath = "//span[contains(text(),'Set')]")
        public List<WebElement> setValue;
        
        @FindBy(xpath = "//input[@id='NavigatePrv']")
        public WebElement prevButton;
        
        @FindBy(xpath = "//span[text()='X']")
        public WebElement unmapColumnMapping;
      
        public columnMapping(WebDriver driver)
        {
            PageFactory.initElements(driver, this);
        }
    }
    
    //This is for board notification(Column mapping) at the time of Board creation
    public class boardNotification{
        @FindBy(xpath = "//div[@id='columnMappingDiv']/table[2]/tbody/tr/td")
        public List<WebElement> HDText;
        
        @FindBy(xpath = "//div[@id='columnMappingDiv']/table[2]/tbody/tr/td[1]")
        public WebElement columnText;
        
        @FindBy(xpath = "//div[@id='columnMappingDiv']/table[2]/tbody/tr/td[2]")
        public  WebElement isNotifyText;
        
        public  WebElement notifyToText;
        
        @FindBy(xpath = "//table[@id='tblmappinguser']/tbody/tr/td[1]")
        public List<WebElement> columnNames;
        //modified
        @FindBy(xpath = "//table[@id='tblmappinguser']/tbody/tr/td[2]/input")
        public List<WebElement> isNotifyCheckbox;
        
        @FindBy(xpath = "//table[@id='tblmappinguser']/tbody/tr/td[3]/div")
        public List<WebElement> addNotifyTo;
        
        
        
        public boardNotification(WebDriver driver)
        {
            PageFactory.initElements(driver, this);
        }
    }
    //This contains the elements of notify to pop up which appears after clicking on any Notify To '+' icon 
    public class addNotifyToPopup{
        
        @FindBy(xpath = "//div[contains(@aria-describedby,'UserMap')]")
        public WebElement addUserPopup;
        
        @FindBy(xpath = "//span[@id='ui-id-1']")
        public WebElement addUserPopupTitle;
        
        @FindBy(xpath = "//button[contains(@title,'close')]")
        public WebElement closePopup;
        
        @FindBy(xpath = "//div[@id='KovairMaster_Main_UserMapAvlSel_inDivLeft']")
        public WebElement availableUserSection;
        
        @FindBy(xpath = "//label[@id='KovairMaster_Main_UserMapAvlSel_avlblListHeader']")
        public WebElement availableUserSectionHeader;
        
        @FindBy(xpath = "//div[@id='KovairMaster_Main_UserMapAvlSel_inDivRight']")
        public WebElement selectedUserSection;
        
        @FindBy(xpath = "//label[@id='KovairMaster_Main_UserMapAvlSel_assignedListHeader']")
        public WebElement selectedUserSectionHeader;
        
        @FindBy(xpath = "//img[@id='KovairMaster_Main_UserMapAvlSel_Add']")
        public WebElement addUser;
        
        @FindBy(xpath = "//img[@id='KovairMaster_Main_UserMapAvlSel_Remove']")
        public WebElement removeUser;
        
        @FindBy(xpath = "//table[@id='dialog_content']/tbody/tr[2]/td[2]")
        public WebElement addRemoveValidation;
        
        @FindBy(xpath = "//input[@id='btnModalOk']")
        public WebElement validationOK;
        
        @FindBy(xpath = "//img[contains(@class,'showhidetopdn-button')][@title='Top']")
        public List<WebElement> sortTop;
        
        @FindBy(xpath = "//img[contains(@class,'showhidetopdn-button')][@title='Bottom']")
        public List<WebElement> sortBottom;
        
        @FindBy(xpath = "//input[@id='KovairMaster_Main_UserMapAvlSel_txtAvlSearch']")
        public WebElement availableUserSearch;
        
        @FindBy(xpath = "//input[@id='KovairMaster_Main_UserMapAvlSel_btnSearchAvail']")
        public WebElement availableUserSearchIcon;
        
        @FindBy(xpath = "//input[@id='KovairMaster_Main_UserMapAvlSel_txtsearchasnd']")
        public WebElement selectedUserSearch;
        
        @FindBy(xpath = "//input[@id='KovairMaster_Main_UserMapAvlSel_clientSearch']")
        public WebElement selectedUserSearchIcon;
       
        @FindBy(xpath = "//table[@class='avlNodeFinder']/tbody/tr[1]/td[1]")
        public List<WebElement> availableUsers;
        
        @FindBy(xpath = "//div[@id='KovairMaster_Main_UserMapAvlSel_SelectedWS']/ul/li/div/div/div/table/tbody/tr/td[1]/table/tbody/tr/td[1]")
        public  List<WebElement> selectedUsers;
        
        @FindBy(xpath = "//input[@id='SaveMap']")
        public WebElement saveUsers;
        
        @FindBy(xpath = "//td[@id='Cancel']/a")
        public WebElement cancelUsers;
        
        public addNotifyToPopup(WebDriver driver)
        {
            PageFactory.initElements(driver, this);
        }
    }
    
    //This contains all the elements present at the time of add task in an active card
    public class cardTask{ //is not checked
        
        @FindBy(xpath = "//a[@title='Close'][@tabindex='0']")
        public  WebElement closeTaskPopup;
        
        @FindBy(xpath = "//input[@id='ViewCombo_Task-inputEl']")
        public  WebElement viewDropdown;
        
        @FindBy(xpath = "//input[@id='FilterCombo_Task-inputEl']")
        public WebElement filterDropdown;
        
        @FindBy(xpath = "//input[@id='TaskList_Search']")
        public WebElement searchBox;
        
        @FindBy(xpath = "//input[@id='checkid']")
        public WebElement checkId;
        
        @FindBy(xpath = "//input[@id='TaskList_Search_Btn']")
        public WebElement searchButton;
        
        @FindBy(xpath = "//a[contains(text(),'Add Task')]")
        public WebElement addTask;
        
        @FindBy(xpath = "//span[@class='x-column-header-text']")
        public WebElement columns;
        
        @FindBy(xpath = "//div[contains(text(),'No Record(s) Found.')]")
        public WebElement noRecordFound;
        
        @FindBy(xpath = "//a[@data-qtip='First Page']")
        public WebElement firstPage;
        
        @FindBy(xpath = "//a[@data-qtip='Previous Page']")
        public WebElement previousPage;
        
        @FindBy(xpath = "//a[@data-qtip='Next Page']")
        public WebElement nextPage;
        
        @FindBy(xpath = "//a[@data-qtip='Last Page']")
        public WebElement lastPage;
        
        @FindBy(xpath = "//input[@name='inputItem']")
        public WebElement currentPageNumber;
        
        @FindBy(xpath = "//div[contains(text(),'of')]")
        public WebElement totalPageCount;
        
        @FindBy(xpath = "//div[@class='x-toolbar-text x-box-item x-toolbar-item x-toolbar-text-default'][3]")
        public WebElement totalRecordCount;
        
        @FindBy(xpath = "//input[@class='x-form-field x-form-required-field x-form-text x-form-focus x-field-form-focus x-field-default-toolbar-form-focus']")
        public WebElement viewRecordPerPage;
        
        @FindBy(xpath = "//div[@class='x-trigger-index-0 x-form-trigger x-form-arrow-trigger x-form-trigger-first']")
        public WebElement selectRecordsPerPage;
        
        @FindBy(xpath = "//tbody[contains(@id,'gridview')]/tr")
        public List<WebElement> taskRecords;
        
        public cardTask(WebDriver driver)
        {
            PageFactory.initElements(driver, this);
        }
    }
    
    //This contains all the elements of create new task form of an active card
    public class kanbanCreateTask //is not checked
    {
        @FindBy(xpath = "//p[@id='pageTitle']")
        public  WebElement pageTitle;
        
        @FindBy(xpath = "//img[contains(@title,'Available Sections')]")
        public WebElement availableSections;
        
        @FindBy(xpath = "//img[contains(@title,'Reset')]")
        public WebElement resetPage;
        
        @FindBy(xpath = "//img[contains(@title,'Bookmark')]")
        public WebElement bookmarkPage;
        
        @FindBy(xpath = "//span[contains(@id,'Header')]")
        public WebElement sections;
        
        @FindBy(xpath = "//label/b")
        public WebElement labels;
        
        @FindBy(xpath = "(//input[contains(@id,'btnSearch')])[2]") 
        public WebElement userSearchButton;
        
        @FindBy(xpath = "//input[@id='PlaceHolderPopUp_SelectedUserList_SelectedUserList_UserControl_txtSearchByIdOrTxt']")
        public WebElement userSearchTxtBox;
        
        @FindBy(xpath = "//input[@id='PlaceHolderPopUp_SelectedUserList_SelectedUserList_UserControl_btnSearch']")
        public WebElement searchButton;
        
        @FindBy(xpath = "(.//*[@id='PlaceHolderPopUp_SelectedUserList_SelectedUserList_UserControl_UserList_GridData']/table/tbody/tr/td/input)[1]")
        public List<WebElement> searchedUsers;
        
        @FindBy(xpath = "//span[@id='PlaceHolderPopUp_SelectedUserList_lblAddUser']")
        public WebElement addUser;
        
        @FindBy(xpath = "//input[@id='PlaceHolderPopUp_BtnDoneClicked1']")
        public WebElement doneUserSSearch;
        
        @FindBy(xpath = "//input[@id='btnSave']")
        public WebElement saveButton;
        
        @FindBy(xpath = "//input[@id='KovairMaster_Main_btnSC']")
        public WebElement saveAndContinue;
        
        @FindBy(xpath = "//input[@id='KovairMaster_Main_btnSN']")
        public WebElement saveAndNew;
        
        @FindBy(xpath = "//a[@id='aCancel']")
        public WebElement cancelButton;
        
        @FindBy(xpath = "(//a[@title='Close'])[1]")
        public WebElement closeCreateNewTask;
        
        public kanbanCreateTask(WebDriver driver)
        {
            PageFactory.initElements(driver, this);
        }
    }
    

    public class ActivityLog{
       @FindBy(xpath = "//table[@class='rwTitlebarControls']/tbody/tr/td[2]/em")
       public WebElement activityLogHeader;
       
       @FindBy(xpath = "//div[@id='divTitle']/b")
       public WebElement cardName;
       
       @FindBy(xpath = "//div[@class='x-column-header-inner']")
       public List<WebElement> cardActivityColumns;
       
       @FindBy(xpath = "//div[@class='x-column-header-inner']/span")
       public List<WebElement> cardActivityColumnNames;
       
       @FindBy(xpath = "//a[@class='rwCloseButton']")
       public WebElement closeButton;
       
       @FindBy(xpath = "//a[@class='hyperlinkNoLine'][text()='Cancel']")
       public WebElement cancelButton;
       
       @FindBy(xpath = "//tr[contains(@class,'x-grid-row')]")
       public List<WebElement> Records;
       
       @FindBy(xpath = "//span[contains(@class,'x-tbar-page-next')]")
       public WebElement nextPageButton;
       
       @FindBy(xpath = "//span[contains(@class,'x-tbar-page-prev')]")
       public WebElement previousPageButton;
       
       @FindBy(xpath = "//span[contains(@class,'x-tbar-page-first')]")
       public WebElement firstPageButton;
       
       @FindBy(xpath = "//span[contains(@class,'x-tbar-page-last')]")
       public WebElement lastPageButton;
       
       @FindBy(xpath = "//input[@name='inputItem']")
       public WebElement currentPageNumber;
       
       @FindBy(xpath = "//div[@class='x-toolbar-text x-box-item x-toolbar-item x-toolbar-text-default'][2]")
       public WebElement totalPage;
       
       @FindBy(xpath = "//div[@class='x-toolbar-text x-box-item x-toolbar-item x-toolbar-text-default'][3]")
       public WebElement recordCount;
       
       @FindBy(xpath = "//input[contains(@class,'x-form-required-field')]")
       public WebElement recordsPerPage;
       
       @FindBy(xpath = "//div[contains(@class,'x-trigger-index-0 x-form-trigger x-form-arrow-trigger')]")
       public WebElement recordsPerPageRecordsPerPageDropdown;
       public ActivityLog(WebDriver driver)
       {
        PageFactory.initElements(driver, this);
       }  
    }
    public class ArchiveBoardlist{
         
       @FindBy(xpath = "//p[@id='pageTitle']")
       public WebElement archiveBoardlistPageHeader; 
       
//       @FindBy(xpath = "//li[contains(@onclick,'ArchiveBoardList')]")
//       public WebElement archiveBoardListActionHeader;
       
       @FindBy(xpath = "//div[@id='TotalCardCount']")
       public WebElement archiveBoardCardCount;
       
       @FindBy(xpath = "//select[@id='KovairMaster_Main_boardDropDwn']")
       public WebElement selectArchiveBoardCard;
       
       @FindBy(xpath = "//label[@class='showplus']")
       public List<WebElement> collpaseColumn;
       
       @FindBy(xpath = "//label[@class='showminus']")
       public List<WebElement> expandColumn;
       
       @FindBy(xpath = "//div[contains(@class,'containerheader')]")
       public List<WebElement> columnHeaders;
       
       @FindBy(xpath = "//select[@id='KovairMaster_Main_boardDropDwn']/option")
       public List<WebElement> archiveBoardDropdownValues;
       
       @FindBy(xpath = "//div[@id='board']")
       public WebElement archiveBoardDiv;
       
       public ArchiveBoardlist(WebDriver driver)
       {
        PageFactory.initElements(driver, this);
       } 
    }
    public class ArchivedCardList{
        @FindBy(xpath = "(//div[contains(@id,'titleEl')])[1]")
        public WebElement IDColumnHeader;
        
        @FindBy(xpath = "(//div[contains(@id,'titleEl')])[2]")
        public WebElement titleColumnHeader;
        
        @FindBy(xpath = "(//div[contains(@id,'titleEl')])[3]")
        public WebElement archivedOnColumnHeader;
        
        @FindBy(xpath = "(//div[contains(@id,'titleEl')])[4]")
        public WebElement entityNameColumn;
        
        @FindBy(xpath = "//span[contains(@class,'page-first')]")
        public WebElement firstPage;
        
        @FindBy(xpath = "//span[contains(@class,'page-last')]")
        public WebElement lastPage;
         
        @FindBy(xpath = "//span[contains(@class,'page-prev')]")
        public WebElement prevPage;
        
        @FindBy(xpath = "//span[contains(@class,'page-next')]")
        public WebElement nextPage;
        
        @FindBy(xpath = "//input[contains(@id,'numberfield')]")
        public WebElement currentPageNumber;
        
        @FindBy(xpath = "//div[contains(text(),'of')][1]")
        public WebElement totalPages;
        
        @FindBy(xpath = "//div[contains(text(),'of')][2]")
        public WebElement totalRecordsCount;
        
        @FindBy(xpath = "//input[contains(@class,'required-field')]")
        public WebElement recordsPerPage;
        public ArchivedCardList(WebDriver driver)
       {
        PageFactory.initElements(driver, this);
       }
    }

}
