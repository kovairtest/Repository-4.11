/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.kovair.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

/**
 *
 * @author sreyag
 */
public class KovairNotificationElement {
   @FindBy(xpath = "//img[@alt='Notification']")
    public WebElement notificationLogo; 
   
   @FindBy(xpath = "//div[@class='notificationbx']")
    public WebElement notificationOuterCount; 
   
   @FindBy(xpath = "//div[@class='notificationbx']")
    public WebElement notificationTaskLogo; 
   
    public KovairNotificationElement(WebDriver driver)
    {
        PageFactory.initElements(driver, this);
    }
}
