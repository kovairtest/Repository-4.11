/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.kovair.pages;

import java.util.List;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

/**
 *
 * @author Abhishekp
 */
//This contains all elements of Kanban Boards page
public class KovairKanbanBoardListPageElement {
    
    @FindBy(xpath = "//p[@id='pageTitle']")
    public WebElement boardListPageTitle;
    
    @FindBy(xpath = "//td[@id='hdrLink']/div/ul/li/a")
    public WebElement createNewBoard;
    
    @FindBy(xpath = "//span[contains(@id,'gridcolumn')][text()='Name']")
    public WebElement nameColumn;
    
    @FindBy(xpath = "//span[contains(@id,'gridcolumn')][text()='Description']")
    public WebElement descriptionColumn;
    
    @FindBy(xpath = "//span[contains(@id,'gridcolumn')][text()='Created By Name/Date']")
    public WebElement createdByNameDateColumn;
    
    @FindBy(xpath = "//span[contains(@onclick,'RecordViewClick')]")
    public List<WebElement> boardName;
  
    @FindBy(xpath = "//td[contains(@class,'x-grid-cell-first')]/div/span")
    public List<WebElement> kanbanBoardListName;
    
    @FindBy(xpath = "//input[@id='FilterName1']")
    public WebElement filterTextBox;
    
    @FindBy(xpath = "//img[@id='Filterimg1']")
    public WebElement filterButton;
    
    @FindBy(xpath = "//li[@class='rmItem']//span")
    public List<WebElement> filterConditions;
    
    @FindBy(xpath = "//a[@data-qtip='First Page']")
    public WebElement firstPage;

    @FindBy(xpath = "//a[@data-qtip='Previous Page']")
    public WebElement previousPage;

    @FindBy(xpath = "//a[@data-qtip='Next Page']")
    public WebElement nextPage;

    @FindBy(xpath = "//a[@data-qtip='Last Page']")
    public WebElement lastPage;

    @FindBy(xpath = "//input[@name='inputItem']")
    public WebElement currentPageNumber;

    @FindBy(xpath = "//div[contains(text(),'of')]")
    public WebElement totalPageCount;

    @FindBy(xpath = "//div[@class='x-toolbar-text x-box-item x-toolbar-item x-toolbar-text-default'][3]")
    public WebElement totalRecordCount;

    @FindBy(xpath = "//input[@class='x-form-field x-form-required-field x-form-text']")
    public WebElement viewRecordPerPage;

    @FindBy(xpath = "//div[@class='x-trigger-index-0 x-form-trigger x-form-arrow-trigger x-form-trigger-first']")
    public WebElement selectRecordsPerPage;
    
    @FindBy(xpath = "//tbody[contains(@id,'gridview')]/tr")
    public List<WebElement> boardRecords;
   
    @FindBy(xpath = "//tbody[contains(@id,'gridview')]/tr/td[1]/div/span")
    public List<WebElement> boardNameElements;
    
    @FindBy(xpath = "//tbody[contains(@id,'gridview')]/tr/td[2]/div")
    public List<WebElement> boardDescriptionElements;
    
    @FindBy(xpath = "//tbody[contains(@id,'gridview')]/tr/td[3]/div")
    public List<WebElement> boardCreatedByElements;
    
    @FindBy(xpath = "//tbody[contains(@id,'gridview')]/tr/td[3]/div")
    public List<WebElement> boardCreationDateElements;
    
    @FindBy(xpath = "//span[text()='EqualTo']")
    public WebElement equalToCondition;
    
    @FindBy(xpath = "//img[@class='menuIcon']")
    public WebElement headerAction;
    
    @FindBy(xpath = "//div[text()='No Record(s) Found.']")
    public WebElement noRecordFound;
    
    @FindBy(xpath = "//span[text()='Contains']")
    public WebElement containsCondition;
    
    @FindBy(xpath = "//span[text()='DoesNotContain']")
    public WebElement doesNotContain;
    
    @FindBy(xpath = "//span[text()='StartsWith']")
    public WebElement startsWith;

    @FindBy(xpath = "//span[text()='EndsWith']")
    public WebElement endsWith;
    
    @FindBy(xpath = "//span[text()='NoFilter']")
    public WebElement noFilter;
    public KovairKanbanBoardListPageElement(WebDriver driver)
    {
        PageFactory.initElements(driver, this);
    }
}
