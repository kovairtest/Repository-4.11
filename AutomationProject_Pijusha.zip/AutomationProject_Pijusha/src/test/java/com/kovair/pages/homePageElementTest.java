/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.kovair.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

/**
 *
 * @author Abhishekp
 */
public class homePageElementTest {
    
        @FindBy(xpath = "//div[@id='hdrLink']/div/ul/li/a")
        public WebElement createRecordLink;
    
        @FindBy(xpath = "//div[@id='icon_set_bg']/table/tbody/tr/td/img")
        public WebElement headerActionLink;
        
        public homePageElementTest(WebDriver driver)
        {
            PageFactory.initElements(driver,this);
        }
     public class CreateRecordPageElement{
         @FindBy(xpath = "//p[@id='pageTitle']")
         public WebElement createRecordPageTitle;
         public CreateRecordPageElement(WebDriver driver)
         {
             PageFactory.initElements(driver, this);
         }
     } 
}
