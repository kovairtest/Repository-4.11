/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.kovair.pages;

import java.util.List;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

/**
 *
 * @author trainee
 */
public class KovairEntitiesFieldsElement {

    WebDriver driver;

    @FindBy(xpath = "//td[@id=\"hdrLink\"]/div/ul/li/a")
    public WebElement createNewFieldLink;

    @FindBy(how = How.ID, using = "KovairMaster_Main_ddlFieldType")
    public WebElement chooseFieldType;

    @FindBy(xpath = "//select[@id=\"KovairMaster_Main_ddlFieldType\"]/option[@value=\"Standard\"]")
    public WebElement chooseFieldTypeStandard;

    @FindBy(xpath = "//input[@value=\"Calculated\" and contains(@id,'rdFieldType')]")
    public WebElement chooseFieldTypeCalculated;

    @FindBy(how = How.ID, using = "KovairMaster_Main_txtFieldLabel")
    public WebElement enterFieldLabel;

    @FindBy(how = How.ID, using = "KovairMaster_Main_btnNext")
    public WebElement clickNextButton;

    @FindBy(how = How.ID, using = "KovairMaster_Main_btnNextField")
    public WebElement clickNextButtonShared;

    @FindBy(how = How.ID, using = "AutoSearchWK")
    public WebElement searchTextBox;

    @FindBy(xpath = "//div[@id=\"KovairMaster_Main_FieldDetailsPanel_ExpressionBuilderID_RadTreeViewField\"]/ul/li[2]/div/span[last()]")
    public WebElement fieldListBox;

    @FindBy(xpath = "//textarea[@id=\"KovairMaster_Main_FieldDetailsPanel_ExpressionBuilderID_ExpressionTextArea\"]")
    public WebElement expressionTextBox;

    @FindBy(xpath = "//div[@id=\"KovairMaster_Main_FieldDetailsPanel_ExpressionBuilderID_RadTreeViewField\"]/ul/li[not(contains(@style,'display: none;')) and not(contains(@style,'zoom'))]/div/span[@class=\"rtIn\"]")
    public WebElement fieldListBoxElement1;

    @FindBy(xpath = "//div[@id='KovairMaster_Main_FieldDetailsPanel_ExpressionBuilderID_RadTreeViewField']//ul/li[not(contains(@style,'display: none;')) and not(contains(@style,'zoom')) ]/div/span[last()]")
    public List<WebElement> fieldListStarting;

    @FindBy(how = How.ID, using = "KovairMaster_Main_btnSaveAndFinish")
    public WebElement saveAndFinishBtn;

    @FindBy(how = How.ID, using = "KovairMaster_Main_FieldDetailsPanel_ExpressionBuilderID_ReturnsDropDown")
    public WebElement returnsDrpDwn;

    @FindBy(xpath = "//select[@id=\"KovairMaster_Main_FieldDetailsPanel_ExpressionBuilderID_ReturnsDropDown\"]/option[text()='Float']")
    public WebElement returnsDrpDwnSelect;

    @FindBy(how = How.ID, using = "KovairMaster_Main_DetailCancel")
    public WebElement cancelButton;

    @FindBy(how = How.ID, using = "FilterName1")
    public WebElement filterFieldName;

    @FindBy(how = How.ID, using = "Filterimg1")
    public WebElement filterImage;

    @FindBy(xpath = "//div[@id=\"filtrMenuDiv1\"]/ul/li[6]/a/span")
    public WebElement filterImageSelect;

    @FindBy(xpath = "//table[@role=\"presentation\"]/tbody/tr[@role=\"row\"]/td[@role=\"gridcell\"]/div/span[contains(@onclick,\"_Record\")]")
    public WebElement existingField;

    @FindBy(xpath = "//table[@role=\"presentation\"]/tbody/tr[@role=\"row\"]/td[@role=\"gridcell\"]/div/span[contains(@onclick,\"_Record\")]")
    public List<WebElement> existingFieldList;

    @FindBy(xpath = "//div[@class='x-grid-empty']/div[text()='No Record(s) Found.']")
    public WebElement noRecFound;

    @FindBy(xpath = "//div[@id=\"KovairMaster_Main_tabStripEditField\"]/div/ul/li[2]/a/span/span/span")
    public WebElement existingFieldDetailsTab;

    @FindBy(how = How.ID, using = "KovairMaster_Main_btnEdit")
    public WebElement editFieldDtl;

    @FindBy(how = How.ID, using = "KovairMaster_Main_AvailCancel")
    public WebElement editCancelButton;

    @FindBy(xpath = "//div[@id='KovairMaster_Main_FieldDetailsPanel_ExpressionBuilderID_RadTreeViewField']/ul/li[2]/div[contains(@class,'rtSelected')]")
    public WebElement fieldSelected;

    public KovairEntitiesFieldsElement(WebDriver driver) {
        PageFactory.initElements(driver, this);
    }

}
