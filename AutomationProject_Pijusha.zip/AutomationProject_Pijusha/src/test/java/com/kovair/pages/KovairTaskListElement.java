/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.kovair.pages;

import java.util.List;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

/**
 *
 * @author sreyag
 */
public class KovairTaskListElement {
    
    @FindBy(xpath = "//div[contains(@id,'RadWindowWrapper')][not(contains(@style,'display: none'))]//em")
    public WebElement cardTaskPopupTitle;
    
    //@FindBy(xpath = "//td[@id='hdrLink']/div/ul/li/a")
    @FindBy(xpath = "//table[@id='SearchTable_Task']/tr/td[4]/a")
    public WebElement createTaskLink;
    
    @FindBy(xpath = "//input[@id='checkid']")
    public WebElement idSearch;
    
    @FindBy(xpath = "//input[@id='ViewCombo_Task-inputEl']")
    public WebElement viewInTask;
    
    @FindBy(xpath = "//input[@id='FilterCombo_Task-inputEl']")
    public WebElement searchFilterInTask;
    
    @FindBy(how=How.CSS,using= "span[id^='gridcolumn-'][id$='-textEl']")
    public WebElement taskCreateOwnerOuterSerachbutton;
    
    @FindBy(xpath = "//div[@class='x-grid-empty']/div")
    public WebElement noTask;
    
    public class TaskCreation{  
    
    @FindBy(xpath = "//p[@id='pageTitle']")    
    public WebElement taskCreatePageTitle;    
    
    @FindBy(xpath = "//label[contains(@id,'KovairMaster_Main_colPanel_Section')]/b[text()='Title']")
    public WebElement taskCreateTitleLable;
    
    @FindBy(xpath = "//label[contains(@id,'KovairMaster_Main_colPanel_Section')]/b[text()='Activity']")
    public WebElement taskCreateActivityLable;
    
    @FindBy(xpath = "//label[contains(@id,'KovairMaster_Main_colPanel_Section')]/b[text()='Status']")
    public WebElement taskCreateStatusLable;
    
    @FindBy(xpath = "//select[contains(@id,'KovairMaster_Main_colPanel_Section')]")
    public WebElement taskCreateAssignPolicyLable;
    
    @FindBy(xpath = "(//a[contains(@id,'HDropDown_Arrow')])[1]")
    public WebElement taskCreateStatusDownArrow;
    
    @FindBy(xpath = "(//div[contains(@id,'HDropdownTree')])[1]/ul")
    public WebElement taskCreateDropdown;
    
    @FindBy(xpath = "(//a[contains(@id,'HDropDown_Arrow')])[2]")
    public WebElement taskCreateActivityDownArrow;
    
    @FindBy(xpath = "(//select[contains(@id,'Hlist_Field')]/option[@selected='selected'])[2]")
    public WebElement taskCreateSourceItemType;
    
    @FindBy(xpath = "//input[contains(@id,'txtSearchLog')][@usertype='EITEM']")
    public WebElement taskCreateSourceItem;
    
    @FindBy(xpath = "//ul[@class='userandroleboxlink gray']/li[1]/a")
    public WebElement taskCreateOwnerUser;
    
    @FindBy(xpath = "//ul[@class='userandroleboxlink gray']/li[3]/a")
    public WebElement taskCreateOwnerRole;
    
    /*Elements of Search a user for Owner Field*/
    @FindBy(how=How.CSS,using= "input[id^='KovairMaster_Main_colPanel_Section_'][id$='_btnSearch'][title='View List']")
    public WebElement taskCreateOwnerOuterSerachbutton;
    
    @FindBy(xpath = "//*[@id='PlaceHolderPopUp_SelectedUserList_SelectedUserList_UserControl_txtSearchByIdOrTxt']")
    public WebElement taskCreateOwnerSerachText;
    
    @FindBy(xpath = "//*[@id='PlaceHolderPopUp_SelectedUserList_SelectedUserList_UserControl_btnSearch']")
    public WebElement taskCreateOwnerSerachbutton;
    
    @FindBy(xpath = "//*[@id='PlaceHolderPopUp_SelectedUserList_SelectedUserList_UserControl_UserList_GridData']/table[1]/tbody/tr[1]/td[1]/input")
    public WebElement taskCreateSelectOwnerFromList;
    
    @FindBy(xpath = "//*[@id='PlaceHolderPopUp_SelectedUserList_lblAddUser']")
    public WebElement taskCreateAddUserButton;
    
    @FindBy(xpath = "//*[@id='PlaceHolderPopUp_BtnDoneClicked1']")
    public WebElement taskCreateOwnerSelectionDoneButton; 
    
    @FindBy(xpath = "//a[@class='rwCloseButton']/span")
    public WebElement closeTask;
    
    @FindBy(xpath = "//input[@id='btnSave']")
    public WebElement taskCreateSaveButton; 
    
    @FindBy(xpath = "//input[@id='KovairMaster_Main_btnSC']")
    public WebElement taskCreateSaveContinoueButton; 
    
    @FindBy(xpath = "//input[@id='KovairMaster_Main_btnSN']")
    public WebElement taskCreateSaveNewButton; 
    
    @FindBy(xpath = "//a[@id='aCancel']")
    public WebElement taskCreateCancelButton; 
    
    @FindBy(xpath = "//tr[contains(@id,'ROLE')]//span")
    public WebElement taskCreateSearchedOwnerRole;
    
    @FindBy(xpath = "//table[@id='tblSelectedList']/tbody/tr/td[1]/span")
    public WebElement taskCreateSelectedOwner;
    
    @FindBy(xpath = "(//table[contains(@id,'searchUserDiv')]//input[contains(@id,'txtSearchLog')])[2]")
    public WebElement taskCreateOwnerSearch;
    
    @FindBy(xpath = "(//span[contains(@id,'VALIDATOR')])[1]")
    public WebElement taskCreateStatusValidation;
    
    @FindBy(xpath = "(//span[contains(@id,'VALIDATOR')])[2]")
    public WebElement taskCreateActivityValidation;
    
    @FindBy(xpath = "(//span[contains(@id,'VALIDATOR')])[3]")
    public WebElement taskCreateOwnerValidation;
    
    @FindBy(xpath = "//a[contains(@id,'removeIcon')]")
    public WebElement removeOwner;
    
    public String n="//span";
    
   public TaskCreation(WebDriver driver)
       {
        PageFactory.initElements(driver, this);
       } 
    } 
  
    public KovairTaskListElement(WebDriver driver)
    {
        PageFactory.initElements(driver, this);
    }
    
    
}
