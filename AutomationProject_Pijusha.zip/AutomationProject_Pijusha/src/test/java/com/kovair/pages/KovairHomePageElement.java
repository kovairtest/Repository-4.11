/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.kovair.pages;


import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.interactions.HasInputDevices;
import org.openqa.selenium.interactions.Mouse;
import org.openqa.selenium.internal.Locatable;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.PageFactory;

/**
 *
 * @author sreyag
 */
public class KovairHomePageElement { 
    
    WebDriver driver;
    @FindBy(how=How.CLASS_NAME,using="logohomeimage")
    public WebElement KovairLogo;
    
    @FindBy(how=How.ID,using="UserImg")
    public WebElement KovairUserLogo;
    
    @FindBy(how=How.ID,using="ddlHD_imgDrp")
    public WebElement KovairWorkspaceDwnEle;
    
    public String KovairLoading="//*[@id='img_loading']";
    
    //@FindBy(how=How.XPATH,using="//div[@id='ddlHD_mainDiv']/div/ul/li/div/span[2]")
    @FindAll({@FindBy(xpath = "//div[@id='ddlHD_mainDiv']/div/ul/li/div/span[2]")})
    public List<WebElement> WorkspacesEle;
    
    @FindBy(how=How.XPATH,using="//div[@id='MenuContainer']/div")
    public WebElement MenuContainerElement;
    
    @FindAll({@FindBy(xpath = "//div[@id='MenuContainer']/div/h2")})
    public List<WebElement> MenuElementList; 
    
    @FindBy(xpath = "//a[@title='Tasks']")
    public WebElement KovairMenuTask;
    
    @FindBy(xpath = "//span[@id='ddlHD_txtSearch']")
    public WebElement KovairWorkspace; 
    
    @FindBy(id = "UserDrp_imgDrp")
    public WebElement KovairUserDrpDwnEle; 
    
    @FindAll({@FindBy(xpath = "//div[@id='UserDrp_HDropdownTree']/ul/li/div/span[2]")})
    public List<WebElement> LoginUserElementList; 
    
    @FindBy(xpath = "//div[@id='tabHolder']/p")
    public List<WebElement> tabList; 
    
     public KovairHomePageElement(WebDriver driver)
    { 
        this.driver = driver;
        PageFactory.initElements(driver, this);
        
    }  
     
   public class KovairWorkspaceSetupElement{ 
       
   @FindAll({@FindBy(xpath = "//div[@id='MenuContainer']/div/h2/a")})
   public List<WebElement> menusList;
   
   @FindAll({@FindBy(xpath = "//div[@id='MenuContainer']/div/div/div/ul")})
   public List<WebElement> submenusList;
   
   public String subMenuTitle="//li/a";
   
   @FindBy(xpath = "//select[@id='entlstdrpdwn']")
   public WebElement typeOfCard;
   
   @FindBy(xpath = "//div[@id='NewRecord']/img")
   public WebElement create;
   
   @FindBy(xpath = "//p[@id='pageTitle']")
   public WebElement title; 
   
   @FindBy(css = "div[id^='gridcolumn'][id$='titleEl']>span")
   public List<WebElement> columName; 
   
   @FindBy(xpath = "//*[@id='right_action_btn']")
   public WebElement action_button; 
   
   public KovairWorkspaceSetupElement(WebDriver driver)
    {
        PageFactory.initElements(driver, this);
    } 
   }  
 
   public class KovairWorkspaceSetupSearch
   {
     @FindBy(xpath = "//input[@id='FilterName']")
     public WebElement search; 
     
     @FindBy(xpath = "//img[@id='Filterimg']")
     public WebElement clickSearch; 
     
     @FindBy(xpath = "//div[@id='filtrMenuDiv']/ul/li/a/span")
     public List<WebElement> listForSearch;
     
     @FindBy(xpath = "//div[@id='filtrMenuDiv']/ul")
     public WebElement listSearch;
     
     @FindBy(xpath = "//div[contains(text(),'No Record(s) Found.')]")
     public List<WebElement> noRecordFound;
             
     public KovairWorkspaceSetupSearch(WebDriver driver)
    {
        PageFactory.initElements(driver, this);
    } 
   
   }
  
   public class KovairPopup
   {
     @FindBy(xpath = "//form/div[@unselectable='on']/table/tbody/tr/td/iframe")
     public WebElement pop; 
     
    public KovairPopup(WebDriver driver)
    {
        PageFactory.initElements(driver, this);
    } 
   }
}
