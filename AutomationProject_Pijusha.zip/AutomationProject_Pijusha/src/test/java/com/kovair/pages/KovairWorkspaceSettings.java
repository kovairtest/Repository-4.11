/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.kovair.pages;

import java.util.List;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

/**
 *
 * @author Abhishekp
 */

//It contains the elements of Workspace-->Settings in edit mode
public class KovairWorkspaceSettings {
    
    @FindBy(xpath = "//span[contains(text(),'General Information')]")
    public WebElement generalInformationTab;
    
    @FindBy(xpath = "//span[contains(text(),'Fields & Entities')]")
    public WebElement fieldsAndEntitiesTab;
    
    @FindBy(xpath = "//input[@id='KovairMaster_Main_Button2']")
    public WebElement editButton;
    
    @FindBy(xpath = "//a[@id='A1']")
    public WebElement cancelButton;
    
    @FindBy(xpath = "//input[@id='KovairMaster_Main_btnSaveAndFinish0']")
    public WebElement saveButton;
    
    @FindBy(xpath = "//div[@id='div1']/span")
    public WebElement entityDisplayDuringWordImportTab;
    
    @FindBy(xpath = "//div[@id='div2']/span")
    public WebElement taskParentFieldsTab;
    
    @FindBy(xpath = "//div[@id='KovairMaster_Main_div3']/span")
    public WebElement agileSettingsTab;
    
    @FindBy(xpath = "//div[@id='KovairMaster_Main_div4']/span")
    public WebElement kanbanSettingsTab;
    
    public KovairWorkspaceSettings(WebDriver driver) {
        PageFactory.initElements(driver, this);
    }
    
    //This contains elements of Kanban Settings tab in edit mode
    public class kanbanSettingsEdit{
        
        @FindBy(xpath = "//label[@id='KovairMaster_Main_kanbanAvlSel_avlblListHeader']")
        public WebElement availableEntitiesLabel;
        
        @FindBy(xpath = "//label[@id='KovairMaster_Main_kanbanAvlSel_assignedListHeader']")
        public WebElement selectedEntitiesLabel;
        
        @FindBy(xpath = "//input[@id='KovairMaster_Main_kanbanAvlSel_txtAvlSearch']")
        public WebElement availableEntitiesSearchBox;
        
        @FindBy(xpath = "//input[@id='KovairMaster_Main_kanbanAvlSel_btnSearchAvail']")
        public WebElement availableEntitiesSearchIcon;
        
        @FindBy(xpath = "//input[@id='KovairMaster_Main_kanbanAvlSel_txtsearchasnd']")
        public WebElement selectedEntitiesSearchBox;
        
        @FindBy(xpath = "//input[@id='KovairMaster_Main_kanbanAvlSel_clientSearch']")
        public WebElement selectedEntitiesSearchIcon;
        
        @FindBy(xpath = "//div[@id='KovairMaster_Main_kanbanAvlSel_inDivLeft']")
        public WebElement availableEntitiesSection;
        
        @FindBy(xpath = "//div[@id='KovairMaster_Main_kanbanAvlSel_inDivRight']")
        public WebElement selectedEntitiesSection;
        
        @FindBy(xpath = "//img[@id='KovairMaster_Main_kanbanAvlSel_Add']")
        public WebElement add;
        
        @FindBy(xpath = "//img[@id='KovairMaster_Main_kanbanAvlSel_Remove']")
        public WebElement remove;
        
        @FindBy(xpath = "//img[@id='KovairMaster_Main_kanbanAvlSel_AddAll']")
        public WebElement addAll;
        
        @FindBy(xpath = "//img[@id='KovairMaster_Main_kanbanAvlSel_RemoveAll']")
        public WebElement removeAll;
        
        //@FindBy(xpath = "//span[contains(@id,'KovairMaster_Main_kanbanAvlSel_rdWSTreeView')][contains(@style,'display:inline-block;')]")
        @FindBy(xpath = "//div[@id='KovairMaster_Main_kanbanAvlSel_rdWSTreeView']/ul/li[not(contains(@style,'display: none'))]//span[contains(@style,'display:inline-block;')]")
        public List<WebElement> availableEntities;
        
        @FindBy(xpath = "//div[@id='KovairMaster_Main_kanbanAvlSel_SelectedWS']/ul/li//td[contains(@class,'ellipsisMe')]")
        public List<WebElement> selectedEntities;
        
        public kanbanSettingsEdit(WebDriver driver)
        {
            PageFactory.initElements(driver, this);
        }
    }
    //This contains all the elemenets of kanban settings tab under workspace settings in view mode
    public class kanbanSettingsView
    {
        @FindBy(xpath = "//select[@id='KovairMaster_Main_lstkanbanEntities']")
        public WebElement savedKanbanEntitiesContainer;
        
        public kanbanSettingsView(WebDriver driver)
        {
            PageFactory.initElements(driver, this);
        }
    }
}
