/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.kovair.PagelevelModule;

import static TaskList.KovairGenericClass.TestExeStatus;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.kovair.pages.KovairHomePageElement;
import com.kovair.utilities.SeleniumModules;
import com.kovair.utilities.sqlConnection;
import com.kovair.utilities.sqlQueries;
import java.util.List;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;


/**
 *
 * @author sreyag
 */
public class KovairHomePageModule { 
    KovairHomePageElement ob;
    KovairHomePageElement.KovairWorkspaceSetupElement se;
    KovairHomePageElement.KovairPopup po;
//    WebDriver driver = null;
    public KovairHomePageModule(WebDriver driver)
    {
//        this.driver = Driver;
//        PageFactory.initElements(Driver, this);
        ob=new KovairHomePageElement(driver);
    } 
    
    public void clickTaskMenu(WebDriver Driver) throws Exception
    {
      ob.KovairMenuTask.click();
    }
    
    public Boolean afterLogin(WebDriver Driver) throws Exception
    { 
        Boolean visibleLogo=false;
    try{
        if(ob.KovairLogo.isDisplayed())
        {
         System.out.println("Kovair logo visible");
          Thread.sleep(2000);
         if(ob.KovairUserLogo.isDisplayed())
         {
          visibleLogo=true;
          System.out.println("Kovair Userlogo visible");
          Thread.sleep(2000);
         }
        }
        }
        catch(Exception e)
        {
          System.out.println(e);
        } 
     return visibleLogo;
    }
    
    public void waitforWorkspaces(WebDriver driver) throws Exception
    { 
        try{
        WebDriverWait wait=new WebDriverWait(driver, 60);
        wait.until(ExpectedConditions.visibilityOf(ob.KovairWorkspaceDwnEle));
        }
        catch(Exception e)
        {
          System.out.println(e);
        } 
    }  
    
//    from workspace list select workspace
    public void selectKovairWorkspaces(String workspacename,WebDriver driver) throws Exception
    {
//        driver.switchTo().defaultContent();
        ob.KovairWorkspaceDwnEle.click();
        Thread.sleep(2000);
        int wssize = ob.WorkspacesEle.size();
        WebElement ws_selection;
        String ws_title;
        boolean wsfound = false;
        for(int i = 1; i<=wssize; i++)
        {
            ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", ob.WorkspacesEle.get(i));
            ws_title = ob.WorkspacesEle.get(i).getText().trim();
            if(ws_title.equals(workspacename))
            {
                
                ws_selection = ob.WorkspacesEle.get(i);
                ws_selection.click();
                wsfound = true;
                Thread.sleep(8000);
                break;
            }
            
        }
        if(!wsfound)
        {
            System.out.println("Workspace not found!");
        }
        
    }
   
    
//    select menu from enduser and workspace setup
    public String selectMenuItem(String menusubnamemenu,WebDriver driver) throws Exception
    {
        WebElement Menu = null;
        WebElement _MenuFrameIdElement = null;
        String _MenuFrameId = "";
        int menuSize = 0;
        try
        {
            Menu = driver.findElement(By.xpath("//div[@id='MenuContainer']/div/h2/a[contains(@title,'" + menusubnamemenu + "')]"));
            //Menu = ob.MenuContainerElement.findElement(By.xpath("//.h2/a[contains(@title,'"+menusubnamemenu+"')]"));
            Menu.click();
            _MenuFrameId = Menu.getAttribute("id").toString().replace("Menu_a", "cc");
            _MenuFrameIdElement = driver.findElement(By.id(_MenuFrameId));
            driver.switchTo().frame(_MenuFrameIdElement);
            
        }
        catch(Exception e)
        {
            menuSize = ob.MenuElementList.size();
            for(int i = 1;i<=menuSize;i++)
            {
                
            }
        }
        return _MenuFrameId;
    }  
    
//    click on workspace setup
    public void Workspace_Setup_click(WebDriver driver) throws Exception {
        WebDriverWait wait = new WebDriverWait(driver, 20);
        try
        {
          wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath(ob.KovairLoading)));
        }
        catch(Exception e){}
        //driver.findElement(By.xpath("//div[@id='div_icon']/ul/li/a")).click();
        ob.KovairWorkspace.click();
    }  
    
   public String clickMenuSubMenuInWorkspaceSetup(String menu,String submenu,WebDriver driver) throws Exception
    { 
     List<WebElement> subMenuli=null;
     String submenuPageid=null;
     se=ob.new KovairWorkspaceSetupElement(driver);
     try{
     int menus=se.menusList.size();
     System.out.println(menus);
     String submenus;
     for (WebElement menuTitle : se.menusList) { 
           System.out.println(menuTitle);
            ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", menuTitle);
            Thread.sleep(1000);
            if(menuTitle.getText().equals(menu)){
                  submenus=menuTitle.getAttribute("id").toString();
                  submenus=submenus.replace("Menu_a", "Menu_ul");
                  System.out.println(submenus);
                  SeleniumModules.buttonClick(menuTitle, driver);
                  Thread.sleep(4000);
                  for (WebElement subTitle : se.submenusList) {
                     if(subTitle.getAttribute("id").equals(submenus))
                     { 
                      System.out.println(subTitle);
                       subMenuli=subTitle.findElements(By.xpath(se.subMenuTitle));
                      System.out.println(subMenuli.size());
                      for (WebElement subMenuliTitle : subMenuli) {
                        if(subMenuliTitle.getText().equals(submenu))
                         {
                          SeleniumModules.buttonClick(subMenuliTitle, driver);
                          Thread.sleep(4000);
                          submenuPageid = subMenuliTitle.getAttribute("id").toString();
                          System.out.println(submenuPageid);
                          submenuPageid = submenuPageid.replace("Menu_a", "cc");
                          System.out.println(submenuPageid);
                          break;
                         }
                       } 
                      break;
                     }
                   } 
                  break;
                }
             } 
     return submenuPageid; 
     }
     catch(Exception e){
      submenuPageid=e.getMessage();
      return null;
     }
   } 

   public String popUp_Frame_Switch(WebDriver driver) throws Exception {
        //PopUp Frame Switch 
        po=ob.new KovairPopup(driver);
        try
        {
            WebElement frame = po.pop;
            driver.switchTo().frame(frame);
            return "Passed";
        }
        catch(Exception _e)
        {   return "Failed"; }
    } 
   
   public String tab_Frame_Switch(WebDriver driver) throws Exception {
        //Tab Frame Switch 
        try
        { 
            driver.switchTo().defaultContent();
            int tabcount=ob.tabList.size();
//            String NewPageFrameId=ob.tabList.get(tabcount).getAttribute("id").toString();
            String NewPageFrameId=ob.tabList.get(tabcount-1).getAttribute("id").toString();
            NewPageFrameId = NewPageFrameId.replace("c", "cc");
            driver.switchTo().frame(NewPageFrameId);
            return "Passed";
        }
        catch(Exception _e)
        {   return "Failed"; }
    }
   
   
}
