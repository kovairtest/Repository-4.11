/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.kovair.PagelevelModule;

import static com.kovair.PagelevelModule.KovairLoginPageModule.UserId;
import static com.kovair.PagelevelModule.KovairLoginPageModule.Workspace;
import com.kovair.pages.KovairHomePageElement;
import com.kovair.pages.KovairKanbanTemplates;
import com.kovair.utilities.SeleniumModules;
import com.kovair.utilities.sqlQueries;
import java.io.File;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import java.io.StringReader;
import org.w3c.dom.CharacterData;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

/**
 *
 * @author sreyag
 */
public class KovairKanbanTemlateModule {

    KovairKanbanTemplates kt;
    KovairKanbanTemplates.KovairKanbanActionMenuPages ap;
    KovairKanbanTemplates.KovairKanbanTemplatesCardPages cp;
    KovairKanbanTemplates.KovairKanbanTemplatesGIPages gp;
    KovairKanbanTemplates.KovairKanbanTemplatesDCPages dp;
    KovairKanbanTemplates.KovairKanbanTemplatesPopups po;
    KovairHomePageElement kh;
    KovairHomePageElement pe;
    KovairHomePageElement.KovairWorkspaceSetupSearch ks;
    KovairHomePageElement.KovairWorkspaceSetupElement se;
    static WebDriver driver = null;
    public static String title = null, recordPerPage = null;
    List<WebElement> columnHeaderCount;
    public Boolean actionButton;
    public WebElement create;
    KovairKanbanTemplates.deleteConfirmationPopup delPop;
    public KovairKanbanTemlateModule(WebDriver driver) {
        kt = new KovairKanbanTemplates(driver);

    }

//    getting pagelevel data 
    public void getFullpageWebelment() throws Exception {
        try {
            title = kt.title.getText();
            Thread.sleep(1000);
            columnHeaderCount = kt.columName;
            recordPerPage = kt.recordPerpage.getAttribute("value");
//            actionButton = kt.kanbanaction_button.isDisplayed();
            create = kt.createTemplateLink;
        } catch (Exception e) {

        }

    }

//    search with name and searching type 
    public String searchTemplates(String temName, String list, WebDriver driver) throws Exception {
        String result = null;
        try {
            kh = new KovairHomePageElement(driver);
            ks = kh.new KovairWorkspaceSetupSearch(driver);
            Actions action = new Actions(driver);
            SeleniumModules.sendDataIntoTxt(ks.search, temName, driver);
            Thread.sleep(1500);
            SeleniumModules.buttonClick(ks.clickSearch, driver);
            Thread.sleep(3000);
            action.moveToElement(ks.listSearch).build().perform();
            for (int i = 0; i <= ks.listForSearch.size(); i++) {
                if (ks.listForSearch.get(i).getText().equals(list)) {
                    SeleniumModules.buttonClick(ks.listForSearch.get(i), driver);
                    break;
                } else {
                    result = null;
                }
            }
            return result;
        } catch (Exception e) {
            result = e.getMessage();
            return result;
        }
    }

//    getting all listed names of Temlates in the grid
    public List<String> listTemlates(WebDriver driver) throws Exception {
        List<String> listofTeTemplates = new ArrayList<String>();
        try {
            for (WebElement tl : kt.kanbanTemplateListName) {
                System.out.println(tl.getText());
                listofTeTemplates.add(tl.getText());

            }
            return listofTeTemplates;
        } catch (Exception e) {

            return listofTeTemplates;
        }
    }

    public int findNoRecordFound(WebDriver driver) throws Exception {
        if (ks.noRecordFound.size() == 1) {
            return 1;
        } else {
            return 0;
        }
    }

    public WebElement actionMenuSearch(String menuName, WebDriver driver) throws Exception {
        WebElement n = null;
        try {
            if (kt.actionMenuContainer.size() == 0) {
                SeleniumModules.buttonClick(kt.kanbanaction_button, driver);
            }
            Actions action = new Actions(driver);
            action.moveToElement(kt.kanbanaction_buttonMenu);
            List<WebElement> menus = kt.kanbanactionName;
            for (WebElement menu : menus) {
                if (menu.getText().contains(menuName)) {
                    if (menu.isDisplayed()) {
                        n = menu;
                        break;
                    }
                }
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return n;
    }

    //Searching menu items,when right clicking on any template

    public WebElement rightClickMenuSearch(String menuName, WebDriver driver) throws Exception {
        WebElement n = null;
        try {
//            WebElement first_Template=kt.firstTemplate.get(0);
            Actions action = new Actions(driver);
//            action.moveToElement(first_Template).contextClick(first_Template).build().perform();
            action.moveToElement(kt.kanbanaction_buttonMenu);
            List<WebElement> menus = kt.kanbanactionName;
            for (WebElement menu : menus) {
                if (menu.getText().equals(menuName)) {
                    if (menu.isDisplayed()) {
                        n = menu;
                        break;
                    }
                }
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return n;
    }

    public String actionMenuClick(WebElement menuName, WebDriver driver) throws Exception {
        String n = null;
        try {
            kt.firstTemplate.get(0).click();
            Thread.sleep(1000);
            SeleniumModules.buttonClick(kt.kanbanaction_button, driver);
            Thread.sleep(1000);
            SeleniumModules.buttonClick(menuName, driver);
            Thread.sleep(1000);
            getFullpageWebelment();
            n = title;
            return n;
        } catch (Exception e) {
            n = e.getMessage();
            System.out.println(e.getMessage());
            return n;
        }
    }

    //Right Clicking any menu item on any template

    public String rightClickMenu(String menuName, WebDriver driver) throws Exception {
        Boolean n = false;
        String title = null;
        try {
            WebElement first_Template = kt.firstTemplate.get(0);
            Actions action = new Actions(driver);
//            action.moveToElement(first_Template).contextClick(first_Template).build().perform();
            action.moveToElement(kt.kanbanaction_buttonMenu);
            List<WebElement> menus = kt.kanbanactionName;
            for (WebElement menu : menus) {
                if (menu.getText().equals(menuName)) {
                    if (menu.isDisplayed()) {
                        SeleniumModules.buttonClick(menu, driver);
                        Thread.sleep(5000);
                        kh = new KovairHomePageElement(driver);
                        se = kh.new KovairWorkspaceSetupElement(driver);
                        title = se.title.getText();
                    }
                }
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return title;
    }
    
    public WebElement okCancelDeleteTemplate(String menu, WebDriver driver) {
        WebElement n = null;
        delPop = kt.new deleteConfirmationPopup(driver);
        if (menu.equals("Ok")) {
            n = delPop.confirmDelete;
        } else if (menu.equals("Cancel")) {
            n = delPop.cancelDelete;
        } else if (menu.equals("modal ok")) {
            n = delPop.modalOk;
        }
        return n;
    }
            
    public String edit_cloneTemplates(String alterTxt, String menus, WebDriver driver) throws Exception {
        String altrname = null;
        ap = kt.new KovairKanbanActionMenuPages(driver);
        try {

            if (menus.equals("Edit")) {
                SeleniumModules.sendDataIntoTxt(ap.nametxtInTemplates, alterTxt, driver);
                altrname = alterTxt;
            } else if (menus.equals("Clone")) {
                SeleniumModules.getFromTxt(ap.nametxtInTemplates, driver);
                SeleniumModules.sendDataIntoTxt(ap.nametxtInTemplates, alterTxt, driver);
            }
            SeleniumModules.buttonClick(ap.NavigatenxtInTemplates, driver);
            Thread.sleep(1000);
            SeleniumModules.buttonClick(ap.NavigatenxtInTemplates, driver);
            Thread.sleep(1000);
            SeleniumModules.buttonClick(ap.NavigatenxtInTemplates, driver);
            Thread.sleep(1000);
            SeleniumModules.buttonClick(ap.NavigatenxtInTemplates, driver);
            Thread.sleep(1000);
            SeleniumModules.buttonClick(ap.NavigatenxtInTemplates, driver);
            Thread.sleep(1000);
            SeleniumModules.buttonClick(ap.SaveBtnInTemplates, driver);
            return altrname;
        } catch (Exception e) {
            altrname = e.getMessage();
            return altrname;
        }
    }

    public void pageNavigation(String moveTo, WebDriver driver) throws Exception {
        try {
            if (moveTo.equals("Previous")) {
                SeleniumModules.buttonClick(kt.pageprev_button, driver);
            } else if (moveTo.equals("Next")) {
                SeleniumModules.buttonClick(kt.pagenext_button, driver);
            } else if (moveTo.equals("First")) {
                SeleniumModules.buttonClick(kt.pagefirst_button, driver);
            } else if (moveTo.equals("Last")) {
                SeleniumModules.buttonClick(kt.pagelast_button, driver);
            }
        } catch (Exception e) {
            System.out.println();
        }

    }

//     getting the default name of a column in Define Columns
    public String getDefineColumns(WebDriver driver) throws Exception {
        String n = null;
        try {
            dp = kt.new KovairKanbanTemplatesDCPages(driver);
            dp.addColumns.click();
            for (WebElement colName : dp.columnName) {
                n = colName.getText();
                if (n.equals("New Column")) {
                    colName.click();
                }
            }
            return n;
        } catch (Exception e) {
            return n;
        }
    }
    public String getDefineColumn(String columnName,String title,WebDriver driver)
    {
        int temp=1,flag=0;
        List<WebElement> columns;
        WebElement source = null, column = null,columnValue=null;
        String element=null;
        try {
            columns = dp.columnName;
            for(Iterator<WebElement> cols=columns.iterator(); cols.hasNext();)
            {
                columnValue=cols.next();
                if(columnValue.getText().equals(columnName))
                {
                    column=columnValue;
                    break;
                }
                else
               {
                   temp++;
               }
                    
            }
            if(column==null)
            {
                element="Column is not present";
            }
            else if(title.equals("Column delete"))
            {
                element=column.toString();
                element="("+element.substring(element.lastIndexOf("xpath:")+6, element.length()-1)+")["+temp+"]/../span/img[1]";
            }
            else if(title.equals("Split"))
            {
                element=column.toString();
                element="("+element.substring(element.lastIndexOf("xpath:")+6, element.length()-1)+")["+temp+"]/../span/img[2]";
            }
            else if(title.equals("Edit"))
            {
                element="//span[text()='"+columnName+"']";
            }
            else if(title.equals("Column Name"))
            {
                element="("+element.substring(element.lastIndexOf("xpath:")+6, element.length()-2)+")["+temp+"]//.."+po.nameInput;
            }
            return element;
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return element;
        }
    }
    public List<String> columnNamesofDefinColumns(WebDriver driver) throws Exception
    {
        dp=kt. new KovairKanbanTemplatesDCPages(driver);
        List<String> columnNames=null;
        try
        {
            columnNames=new ArrayList<String>();
            for(int i=0;i<dp.columnName.size();i++)
                columnNames.add(dp.columnName.get(i).toString());
            return columnNames;
        }
        catch(Exception e)
        {
            System.out.println(e.getMessage());
            return columnNames;
        }
    }
    
//     getting alter column popup
    public void getAlterColumns(String names, String lm, String buffer, Boolean r, WebDriver driver) throws Exception {
        Actions action = new Actions(driver);
        String l,element;
        WebElement cols;
        try {
            String n = getDefineColumns(driver);
            if (!n.isEmpty()) {
                po = kt.new KovairKanbanTemplatesPopups(driver);
                action.moveToElement(po.popups).build().perform();
//       for(int i=1;i<=po.columnsOfpopups.size();i++)
//       {
//       cols=po.columnsOfpopups.get(i).findElement(By.xpath(po.name));
//        cols=po.columnsOfpopup.findElement(By.xpath(po.name));
//        l=cols.getText();
//        cols=po.columnsOfpopup;
//        l=po.columnsOfpopup.getText();
//        System.out.println(l);
//        if(l.contains("Column Name"))
//             {
//              SeleniumModules.sendDataIntoTxt(cols,"ToDo", driver);
//             }
//             if(l.contains("Required Cycle Time"))
//             {
//              SeleniumModules.buttonClick(cols,driver);
//              SeleniumModules.buttonClick(po.submitButton, driver);
//             }
//       } 
                int j = 0;
                for (int i = 0; i <= po.columnsOfpopup.size(); i = i + 2) {
                    try {
//                  if(!po.columnsOfpopup.get(i).getText().isEmpty())
//                  { 
                        System.out.println(po.columnsOfpopup.get(i).getText());
                        if (po.columnsOfpopup.get(i).getText().contains("Column Name")) {
                            j = i + 1;
                            //SeleniumModules.sendDataIntoTxt(po.columnsOfpopup.get(j).findElement(By.xpath(po.nameInput)), names, driver);
                            element=po.columnsOfpopup.toString();
                            element="("+element.substring(element.lastIndexOf("xpath:")+6, element.length()-2)+")["+j+"]//.."+po.nameInput;
                            SeleniumModules.sendDataIntoTxt(driver.findElement(By.xpath(element)), names, driver);
                        }
                        if (po.columnsOfpopup.get(i).getText().contains("WIP Limit")) {
                            j = i + 1;
                            SeleniumModules.sendDataIntoTxt(po.columnsOfpopup.get(j), lm, driver);
                            
                        }
                        if (po.columnsOfpopup.get(i).getText().contains("Buffer Value")) {
                             j = i + 1;
                            SeleniumModules.sendDataIntoTxt(po.columnsOfpopup.get(j), buffer, driver);
                           
                        }
                        if (po.columnsOfpopup.get(i).getText().contains("Required Cycle Time")) {
                            if (!r.booleanValue()) {
                                j = i + 1;
                                //modified by AP
                                //SeleniumModules.buttonClick(po.columnsOfpopup.get(j), driver);
                                po.RequiredCycleTimeCheckbox.click();
                                SeleniumModules.buttonClick(po.submitButton, driver);
                                break;
                            }

                        }

//                  }
                    } catch (Exception e) {
                        continue;
                    }
                }
//             List<WebElement> r=columnsOfpopup.findElements(By.xpath(po.n));
//              i=0;
//              for (WebElement r1 : r) {
//                  l=r1.getText();
//                  if(i==2)
//                  {
//                  SeleniumModules.sendDataIntoTxt(r1,"ToDo", driver);
//                  break;
//                  }
//                  if(l.contains("Column Name"))
//                   { 
//                     i=2;
//                     continue;
//                   }
//              }
//              SeleniumModules.sendDataIntoTxt(columnsOfpopup.findElement(By.xpath(po.nameInput)),"ToDo", driver);
//             } 
//             if(l.contains("Required Cycle Time"))
//             {
//              SeleniumModules.buttonClick(columnsOfpopup.findElement(By.xpath(po.nameInput)),driver);
//              SeleniumModules.buttonClick(po.submitButton, driver);
//             }
//              }
//             l=columnsOfpopup.findElement(By.xpath(po.name)).getText();
//             System.out.println(columnsOfpopup.findElement(By.xpath(po.name)));
//             System.out.println(l);
//             if(l.contains("Column Name"))
//             {
//              SeleniumModules.sendDataIntoTxt(columnsOfpopup.findElement(By.xpath(po.nameInput)),"ToDo", driver);
//             }
//             if(l.contains("Required Cycle Time"))
//             {
//              SeleniumModules.buttonClick(columnsOfpopup.findElement(By.xpath(po.nameInput)),driver);
//              SeleniumModules.buttonClick(po.submitButton, driver);
//             }
//          }
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public List<String> getAssignedCards(WebDriver driver) throws Exception {
        List<String> n = new ArrayList();
        try {
            cp = kt.new KovairKanbanTemplatesCardPages(driver);
            for (int i = 0; i < cp.cardsAssign.size(); i = i + 3) {
                n.add(cp.cardsAssign.get(i).getText());
            }
            return n;
        } catch (Exception e) {
            return n;
        }
    }

    public WebElement getCardTab(String title, WebDriver driver) throws Exception {
        WebElement n = null;
        try {
            cp = kt.new KovairKanbanTemplatesCardPages(driver);
            if (title.contains("Select card types")) {
                if (cp.projectCards.get(0).getText().contains(title)) {
                    n = (WebElement) cp.projectCards.get(0);
                }
            } else if (title.contains("Card Types")) {
                if (cp.colorsAssign.get(0).getText().contains("Card types")) {
                    n = (WebElement) cp.colorsAssign.get(0);
                }
            } else if (title.contains("Card color")) {
                if (cp.colorsAssign.get(1).getText().contains("Card color")) {
                    n = (WebElement) cp.colorsAssign.get(1);
                }
            } else if (title.contains("Cards colors")) {
//                if (cp.projectCards.get(2).getText().contains(title)) { modifide by AP
                if (cp.projectCards.get(2).getText().contains("Card color")) {
                    n = (WebElement) cp.projectCards.get(2);
                }
            } else if (title.contains("Define Columns")) {
                for (int i = 0; i <= cp.tab.size(); i++) {
                    if (cp.tab.get(i).getAttribute("id").contains("Tabcolumn")) {
                        n = cp.tab.get(i);
                    }
                }
            } else if (title.contains("Get color")) {
                cp.colors.get(5).click();
            } else if (title.contains("Cards Entity")) {
                if (cp.cards.isDisplayed()) {
                    n = (WebElement) cp.cards;
                }
            } else if (title.contains("Update Button")) {
                if (cp.cardsUpdate.isDisplayed()) {
                    n = (WebElement) cp.cardsUpdate;
                }
            } else if (title.contains("Add Button")) {
                if (cp.saveButton.isDisplayed()) {
                    n = (WebElement) cp.saveButton;
                }
            } else if (title.contains("Previous Button")) {
                if (cp.previousButton.isDisplayed()) {
                    n = cp.previousButton;
                }
            } else if (title.contains("Next Button")) {
                if (cp.nextButton.isDisplayed()) {
                    n = cp.nextButton;
                }
            } else if (title.contains("CancelButton")) {
                if (cp.cancelButton.isDisplayed()) {
                    n = cp.cancelButton;
                }
            } else if (title.contains("Mandatory Massege")) {
                if (cp.message.isDisplayed()) {
                    n = cp.message;
                }
            } else if (title.contains("Mandatory Message for card")) {
                if (cp.messagecardList.isDisplayed()) {
                    //n = cp.message;
                    n = cp.messagecardList;
                }
            } else if (title.contains("Mandatory Message for col")) {
                if (cp.messageCol.isDisplayed()) {
                    //n = cp.message;
                    n = cp.messageCol;
                }
            } else if (title.contains("Edit Button")) {
                // if (cp.editDelete.get(1).getText().contains("Edit")) {
                if (cp.editDelete.get(0).getText().contains("Edit")) {
                    n = (WebElement) cp.editDelete.get(0);
                }
            } else if (title.contains("Delete Button")) {
                // if (cp.editDelete.get(1).getText().contains("Edit")) {
                if (cp.editDelete.get(1).getText().contains("Delete")) {
                    n = (WebElement) cp.editDelete.get(1);
                }
            }
//            else {
//                for (WebElement columns  : cp.projectCards) {
//                    try {
//                        if (columns.getText().contains(title)) {
//                            n = columns;
//                        }
//                    } catch (Exception en) {
//                        continue;
//                    }
//                }                
//            }            
            return n;
        } catch (Exception e) {
            return n;
        }
    }

//     getting webelement of GI
    public WebElement getGITab(String title, WebDriver driver) throws Exception {
        WebElement n = null;
        gp = kt.new KovairKanbanTemplatesGIPages(driver);
        cp = kt.new KovairKanbanTemplatesCardPages(driver);
        try {
            if (title.contains("Name")) {
                if (gp.nameInTemplates.isDisplayed()) {
                    n = gp.nameInTemplates;
                }
            } else if (title.contains("Description")) {
                if (gp.descriptionInTemplates.isDisplayed()) {
                    n = gp.descriptionInTemplates;
                }
            } else if (title.contains("NextButton")) {
                if (cp.nextButton.isDisplayed()) {
                    n = cp.nextButton;
                }
            } else if (title.contains("CancelButton")) {
                if (cp.cancelButton.isDisplayed()) {
                    n = cp.cancelButton;
                }
            } else if (title.contains("Mandatory Massege")) {
                if (kt.mandatoryMessage.isDisplayed()) {
                    n = kt.mandatoryMessage;
                }
            } else if (title.contains("General Information") || title.contains("Define Columns") || title.contains("Present Tabs")) {
                for (WebElement liName : gp.nameOfAreaInTemplates) {
                    if (liName.getText().contains(title)) {
                        n = liName;
                        break;
                    }
                }
            }
            else if(title.contains("Save Board"))
            {
                ap=kt. new KovairKanbanActionMenuPages(driver);
                if(ap.SaveBtnInTemplates.isDisplayed())
                {
                    n=ap.SaveBtnInTemplates;
                }
            }
            return n;
        } catch (Exception e) {
            return n;
        }
    }

    public void getXml() throws Exception {
        Document mapDoc = null;
        try {
            String n[][] = sqlQueries.getSQLresult(sqlQueries.kanban_policy_SwimlaneList_OfTemplate);
            System.out.println(n[0][0]);
//            DocumentBuilderFactory dbfactory = 
//               DocumentBuilderFactory.newInstance();
//      //Create the DocumentBuilder
//      DocumentBuilder docbuilder = dbfactory.newDocumentBuilder();
//      //Parse the file to create the Document
//      mapDoc = docbuilder.parse("mapping.xml");
//            //Retrieve the root element 
//      Element mapRoot = mapDoc.getDocumentElement();
//        //Retrieve the (only) data element and cast it to Element
//        Node dataNode = mapRoot.getElementsByTagName("data").item(0);
//        Element dataElement = (Element)dataNode;
//        //Retrieve the sql statement
//        String sql = dataElement.getAttribute("sql");

            //Output the SQL statement
//        System.out.println(sql);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public static Object[][] priorityInfo(File Filepath) throws Exception {
        Object[][] pLookup = null;
        try {
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            org.w3c.dom.Document doc = dBuilder.parse(Filepath);
            doc.getDocumentElement().normalize();
            //System.out.println("Root element :" + doc.getDocumentElement().getNodeName());
            pLookup[0][0] = doc.getElementsByTagName("SWIMLANEVALUETEXT");
            NodeList DataList = doc.getElementsByTagName("SELECTEDVALUES");
            for (int temp = 0; temp < DataList.getLength(); temp++) {
                Node nNode = DataList.item(temp);
                if (nNode.getNodeType() == Node.ELEMENT_NODE) {
                    org.w3c.dom.Element eElement = (org.w3c.dom.Element) nNode;
                    pLookup[temp + 1][0] = eElement.getElementsByTagName("VALUE").item(0).getTextContent();
                    pLookup[temp + 1][1] = eElement.getElementsByTagName("NAME").item(0).getTextContent();
                    return pLookup;
                }
            }
            return pLookup;
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return pLookup;
        }
    }

    public static Object[] policyInfo(File Filepath) throws Exception {
        Object[] pLookup = null;
        try {
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            org.w3c.dom.Document doc = dBuilder.parse(Filepath);
            doc.getDocumentElement().normalize();
            //System.out.println("Root element :" + doc.getDocumentElement().getNodeName());
            NodeList DataList = doc.getElementsByTagName("EVENTID");
            System.out.println(DataList.getLength());
            for (int temp = 0; temp < DataList.getLength(); temp++) {
//                        Node nNode = DataList.item(temp);
//                        if (nNode.getNodeType() == Node.ELEMENT_NODE) {
//                            org.w3c.dom.Element eElement = (org.w3c.dom.Element) nNode;
//                            System.out.println(eElement.getElementsByTagName("EVENTID").item(temp).getTextContent());
//                            pLookup[temp] = eElement.getElementsByTagName("EVENTID").item(temp).getTextContent();
//                            pLookup[temp+1] = eElement.getNodeValue();

                Element section = (Element) DataList.item(temp); // A <sect1>
                Node title = section.getFirstChild();
                while (title != null && title.getNodeType() != Node.ELEMENT_NODE) {
                    title = title.getNextSibling();
                    System.out.println(title.getNodeValue());
                }
                if (title != null) {
                    System.out.println(title.getFirstChild().getNodeValue());
                }
//                            return pLookup;
//                        }
            }
            return pLookup;
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return pLookup;
        }
    } 
    
    public static String[][] priorityOfBoard(String Filepath) throws Exception {
        Node child;
            CharacterData cd;
            String n[][]=null;
            Element element;
        try {
            DocumentBuilder db = DocumentBuilderFactory.newInstance().newDocumentBuilder();
            InputSource is = new InputSource();
            is.setCharacterStream(new StringReader(Filepath));
            Document doc = db.parse(is);
            NodeList nodeID=doc.getElementsByTagName("SWIMLANEVALUEID");
            NodeList nodeValue=doc.getElementsByTagName("SWIMLANEVALUETEXT");
            for (int i = 0; i < nodeID.getLength(); i++) {
                    element = (Element) nodeID.item(i);
                    child = element.getFirstChild();
//                    if (child instanceof CharacterData) {
//                        cd = (CharacterData) child;
//                        n[0][0]=cd.getData();
//                   }
                    element = (Element) nodeValue.item(i);
                    child = element.getFirstChild();
                    if (child instanceof CharacterData) {
                        cd = (CharacterData) child;
                        n[0][1]=cd.getData();
                   }
            }
//            NodeList DataList = doc.getElementsByTagName("SELECTEDVALUES");
//            for (int temp = 0; temp < DataList.getLength(); temp++) {
//                Node nNode = DataList.item(temp);
//                if (nNode.getNodeType() == Node.ELEMENT_NODE) {
//                    org.w3c.dom.Element eElement = (org.w3c.dom.Element) nNode;
//                    pLookup[temp + 1][0] = eElement.getElementsByTagName("VALUE").item(0).getTextContent();
//                    pLookup[temp + 1][1] = eElement.getElementsByTagName("NAME").item(0).getTextContent();
//                    return pLookup;
//                }
//            }
            return n;
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return n;
        }
    }

    public static String[] policyOFTemplate(String xmlString) throws Exception {
        {
            Node child;
            CharacterData cd;
            String n[]=null;
            try {
                DocumentBuilder db = DocumentBuilderFactory.newInstance().newDocumentBuilder();
                InputSource is = new InputSource();
                is.setCharacterStream(new StringReader(xmlString));
                Document doc = db.parse(is);
                NodeList nodes = doc.getElementsByTagName("EVENTID");
                for (int i = 0; i < nodes.getLength(); i++) {
                    Element element = (Element) nodes.item(i);
                    child = element.getFirstChild();
                    if (child instanceof CharacterData) {
                        cd = (CharacterData) child;
                        System.out.println("policyID: " + cd.getData());
                        n[i]=cd.getData();
                    }
                } 
                return n;
            } catch (Exception e) {
                System.out.println(e.getMessage());
                return n;
            }
        } 
    }
}
