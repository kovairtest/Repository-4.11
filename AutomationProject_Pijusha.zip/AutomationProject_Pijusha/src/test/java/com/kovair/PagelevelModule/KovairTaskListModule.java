/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.kovair.PagelevelModule;

import TaskList.KovairGenericClass;
import com.kovair.pages.KovairTaskListElement;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;
import com.kovair.utilities.SeleniumModules;
import java.util.List;
import org.openqa.selenium.WebElement;

/**
 *
 * @author sreyag
 */
public class KovairTaskListModule {
    KovairTaskListElement tle; 
    KovairTaskListElement.TaskCreation tc; 
    
     public KovairTaskListModule(WebDriver driver)
      {
       tle=new KovairTaskListElement(driver);
      }  
     
     public void taskCreation(String title,String asgn_policy, WebDriver driver) throws InterruptedException, Exception {
        try { 
             tc=tle.new TaskCreation(driver);
             SeleniumModules.buttonClick(tle.createTaskLink, driver);
             Thread.sleep(4000);
            //taking one level up tag
             String _for = tc.taskCreateTitleLable.findElement(By.xpath("..")).getAttribute("for");
            // task title
            SeleniumModules.sendDataIntoTxt(driver.findElement(By.id(_for)), title, driver);
            //activity
            String _forActivity = tc.taskCreateActivityLable.findElement(By.xpath("..")).getAttribute("for");
            String _activity = _forActivity + "_HDropDown_Arrow";
            driver.findElement(By.id(_activity)).click();
            Thread.sleep(1000);
            driver.findElement(By.xpath("//span[contains(@title,'Default')]")).click();
            //status
            String _forStatus = tc.taskCreateStatusLable.findElement(By.xpath("..")).getAttribute("for");
            String _status = _forStatus + "_HDropDown_Arrow";
            driver.findElement(By.id(_status)).click();
            Thread.sleep(1000);
            driver.findElement(By.xpath("//span[contains(@title,'In Progress')]")).click();
            //assignedPolicy
            SeleniumModules.selectDataFromList(tc.taskCreateAssignPolicyLable, asgn_policy, driver);
            Thread.sleep(8000);
            //assignedOwner
            tc.taskCreateOwnerOuterSerachbutton.click();
            KovairGenericClass.PopUp_Frame_Switch(driver);
//            tle.taskOwnerSerachText.click();
//            Thread.sleep(2000);
//            tle.taskOwnerSerachText.clear();
//            Thread.sleep(2000);
//            tle.taskOwnerSerachText.sendKeys(Keys.CONTROL + "a");
//            tle.taskOwnerSerachText.sendKeys(Keys.DELETE);
//            tle.taskOwnerSerachText.sendKeys("sreya");
            SeleniumModules.sendDataIntoTxt(tc.taskCreateOwnerSerachText, "Abhishek", driver);
            Thread.sleep(2000);
            tc.taskCreateOwnerSerachbutton.click();
            Thread.sleep(4000);
            tc.taskCreateSelectOwnerFromList.click();
            Thread.sleep(2000);
            tc.taskCreateAddUserButton.click();
            Thread.sleep(5000);
            tc.taskCreateOwnerSelectionDoneButton.click();
            Thread.sleep(7000);
            driver.switchTo().parentFrame();
            Thread.sleep(4000);
            tc.taskCreateSaveButton.click();
            
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        // return tastCreation_status;
    } 
     
     public WebElement verify_apearenceOfTask(String n,WebDriver driver) throws Exception
     { 
         WebElement source=null,dropDownElement=null;
       try{ 
            tc=tle.new TaskCreation(driver);
         if(n.equals("Save"))
         {
           source=tc.taskCreateSaveButton;
         }
         else if(n.equals("Save & Continue"))
         {
           source=tc.taskCreateSaveContinoueButton;
         }
         else if(n.contains("Save & New"))
         {
           source=tc.taskCreateSaveNewButton;
         }
         else if(n.contains("Cancel Button"))
         {
           source=tc.taskCreateCancelButton;
         } 
         else if(n.equals("Button"))
         {
           source=tc.taskCreateCancelButton;
         } 
         else if(n.contains("Close"))
         {
           source=tc.closeTask;
         }
         else if(n.contains("Page Title"))
         {
            source=tc.taskCreatePageTitle;
         }
         else if(n.equals("Source Item Type"))
         {
             source=tc.taskCreateSourceItemType;
         }
         else if(n.equals("Source Item"))
         {
             source=tc.taskCreateSourceItem;
         }
         else if(n.equals("Outer User Search"))
         {
             source=tc.taskCreateOwnerOuterSerachbutton;
         }
         else if(n.equals("User Search Textbox"))
         {
             source=tc.taskCreateOwnerSerachText;
         }
         else if(n.equals("User Search Button"))
         {
             source=tc.taskCreateOwnerSerachbutton;
         }
         else if(n.equals("Select User"))
         {
             source=tc.taskCreateSelectOwnerFromList;
         }
         else if(n.equals("Add User"))
         {
             source=tc.taskCreateAddUserButton;
         }
         else if(n.equals("Done Add User"))
         {
             source=tc.taskCreateOwnerSelectionDoneButton;
         }
         else if(n.equals("Owner User"))
         {
             source=tc.taskCreateOwnerUser;
         }
         else if(n.equals("Owner Role"))
         {
             source=tc.taskCreateOwnerRole;
         }
         else if(n.equals("Added Owner"))
         {
             source=tc.taskCreateSelectedOwner;
         }
         else if(n.equals("Searched Role"))
         {
             source=tc.taskCreateSearchedOwnerRole;
         }
         else if(n.equals("Owner Search"))
         {
             source=tc.taskCreateOwnerSearch;
         }
         else if(n.equals("Status Validation"))
         {
             source=tc.taskCreateStatusValidation;
         }
         else if(n.equals("Activity Validation"))
         {
             source=tc.taskCreateActivityValidation;
         }
         else if(n.equals("Owner Validation"))
         {
             source=tc.taskCreateOwnerValidation;
         }
         else if(n.equals("Activity Down Arrow"))
         {
             source=tc.taskCreateActivityDownArrow;
         }
         else if(n.equals("Status Down Arrow"))
         {
             source=tc.taskCreateStatusDownArrow;
         }
         else if(n.equals("Status Value"))
         {  
             dropDownElement=tc.taskCreateDropdown;
             source=dropDownElement.findElement(By.xpath(tc.n+"[@title='In Progress']"));
         }
         else if(n.equals("Activity Value"))
         {
             dropDownElement=tc.taskCreateDropdown;
             source=dropDownElement.findElement(By.xpath(tc.n+"[@title='Default']"));
         }
         else if(n.equals("Remove owner"))
         {
             if(tc.removeOwner.isDisplayed())
                 source=tc.removeOwner;
         }
       }
       catch (Exception e) {
            System.out.println(e.getMessage());
        } 
       return source;
     }
     
     //This returns the elements of TaskList page of a card
     public WebElement appearanceOfAssociatedTask(String title,WebDriver driver) throws Exception
     {
         WebElement source=null;
         try{
             if(title.equals("Popup Title"))
             {
                 source=tle.cardTaskPopupTitle;
             }
             else if(title.equals("Add Task"))
             {
                 source=tle.createTaskLink;
             }
         }
         catch (Exception e) {
            System.out.println(e.getMessage());
        } 
         return source;
     }
}
