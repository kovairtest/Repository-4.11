/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.kovair.PagelevelModule;

import com.kovair.pages.KovairKanbanCardElement;
import com.kovair.utilities.SeleniumModules;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import com.kovair.PagelevelModule.KovairHomePageModule;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.openqa.selenium.JavascriptExecutor;

/**
 *
 * @author sreyag
 */
public class KovairKanbanCard {

    KovairKanbanCardElement ke;
    KovairKanbanCardElement.BoardAddcard bac;
    KovairKanbanCardElement.CreatePopup cards;
    KovairKanbanCardElement.ActiveBoard ab;
    KovairKanbanCardElement.cardIcons ci;
    KovairKanbanCardElement.CardComment cm;
    KovairKanbanCardElement.backlog bl;
    KovairKanbanCardElement.Validation_check val;
    KovairKanbanCardElement.ArchiveBoardlist arch;
    KovairKanbanCardElement.ArchivedCardList acl;
    KovairHomePageModule khome;
    KovairKanbanCardElement.BoardContextMenuPopup boardContextMenu;
    //
    String cardCount, WIPLimit, columns;

    //

    public KovairKanbanCard(WebDriver driver) {
        ke = new KovairKanbanCardElement(driver);
    }

    //This returns all the elements of a Kanban Board 

    public WebElement verifyApperence(String n, WebDriver driver) throws Exception {
        WebElement l = null;
        try {
             bac = ke.new BoardAddcard(driver);
            if (n.equals("Add Card")) {
                if (bac.titleAddCard.getText().contains("Add Card")) {
                    l = bac.titleAddCard;
                }
            } else if (n.equals("Action Button")) {
                SeleniumModules.buttonClick(ke.logoHDAction, driver);
//                bac = ke.new BoardAddcard(driver);
            } 
            else if(n.equals("Popup header"))
            {
                l=ke.popupHeader;
            }
            else if(n.equals("Popup close"))
            {
                l=ke.popupClose;
            }
            else if (n.equals("Add Card Title")) {
                if (bac.titleOfAddCard.getText().contains("Add Card")) {
                    l = bac.titleOfAddCard;
                }
            } else if (n.equals("Default scope")) {
                if (bac.typeOfCard.isDisplayed()) {
                    l = bac.typeOfCard;
                }
            } else if (n.equals("Appearing scope")) {
                if (bac.typeOfCard.isDisplayed()) {
                    l = bac.typeOfCard;
                }
            } else if (n.equals("Appearing option")) {
                if (bac.create.isDisplayed()) {
                    l = bac.create;
                }
//                if (bac.restoreCard.isDisplayed()) {
//                    l = bac.restoreCard;
//                }
            }
            else if (n.equals("Archive Board")) {
                if (bac.titleArchivedBoard.getText().contains("Archive Board")) {
                    l = bac.titleArchivedBoard;
                }
            }
            else if (n.equals("Archive Board List")) {
                if (bac.archiveBoardListActionHeader.getText().contains("Archive Board List")) {
                    l = bac.archiveBoardListActionHeader;
                }
            }
            else if(n.equals("Backlogs"))
            {
                l=bac.backlog;
            }
            else if(n.equals("Archive Card List"))
            {
                l=bac.archiveCardList;
            }
            else if(n.equals("Board List"))
            {
                l=bac.boardList;
            }
            else if(n.equals("Board Title"))
            {
                ab=ke.new ActiveBoard(driver);
                l=ab.pageName;
            }
            else {
                if (bac.closAddCard.isDisplayed()) {
                    l = bac.closAddCard;
                }
            }
            return l;
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return l;
        }
    }

    //This can set the type of a card at the time of creation

    public void setcardType(WebDriver driver) throws Exception {
        try {
            SeleniumModules.selectDataByIndFromList(bac.typeOfCard, 1, null);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    //This returns all the elements of add new card popup
    public WebElement verifyApperenceOfcard(String n, WebDriver driver) throws Exception {
        WebElement l = null;
        try {
            if (n.equals("Card HD")) {
                cards = ke.new CreatePopup(driver);
//          if(cards.cardTitleLable.getText().contains("Add Card"))  
//          {
//           l=cards.cardTitleLable; 
//          }
            } else if (n.equals("Title")) {
                if (cards.pageTitleLable.getText().contains("Create New")) {
                    l = cards.pageTitleLable;
                }
            } else if (n.equals("Card Title")) {
                if (cards.cardTitleLable.getText().contains("Title")) {
                    l = cards.cardTitleLable;
                }
            } else if (n.equals("Card priority")) {
                if (cards.cardPriorityLable.getText().contains("Card priority")) {
                    l = cards.cardPriorityLable;
                }
            } else if (n.equals("Card of Service")) {
                if (cards.cardofServiceLable.getText().contains("Card of Service")) {
                    l = cards.cardofServiceLable;
                }
            } else if (n.equals("Card Status")) {
                if (cards.cardStatusLable.getText().contains("Card Status")) {
                    l = cards.cardStatusLable;
                }
            } else if (n.equals("Save Button")) {
                if (cards.buttonSave.isDisplayed()) {
                    l = cards.buttonSave;
                }
            } /*else if (n.equals("Save and Continoue Button")) {
                if (cards.buttonSaveContinue.isDisplayed()) {
                    l = cards.buttonSaveContinue;
                }
            } else if (n.equals("Save and New Button")) {
                if (cards.buttonSaveN.isDisplayed()) {
                    l = cards.buttonSaveN;
                }
            }*/ else if (n.contains("Reset Button")) {
                l = cards.pageResetLable;
            } else if (n.contains("Available Button")) {
                l = cards.buttonAvailable;
            } else if (n.contains("Bookmarks Button")) {
                l = cards.buttonBookmarks;
            } else {
                if (cards.buttonCancel.isDisplayed()) {
                    l = cards.buttonCancel;
                }
            }
            return l;
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return l;
        }
    }

    //This set the values of different fields at the time of creating a card
    public void setValueOfcard(String n, String v, WebDriver driver) throws Exception {
        WebElement l = null;
        try {
            if (n.contains("Card Title")) {
                String t = SeleniumModules.getFromTxt(cards.cardTitleLable, driver);
                System.out.println(t);
                // task title
                String _for = cards.cardTitleLable.findElement(By.xpath("..")).getAttribute("for");
                Thread.sleep(2000);
                SeleniumModules.sendDataIntoTxt(driver.findElement(By.id(_for)), v, driver);
                Thread.sleep(5000);
            } else if (n.contains("priority")) {
                String p = cards.cardPriorityLable.findElement(By.xpath("..")).getAttribute("for");
                String dpd = "//input[@id='" + p + "_HDropDown_Input']";
                String _p = "//div[@id='" + p + "_HDropDown_i0_HDropdownTree']/ul/li";
                int j = driver.findElements(By.xpath(_p)).size();
                for (int i = 2; i <= j; i++) {
                    String pt = _p + "[" + i + "]/div/span[2]";
                    String pri = driver.findElement(By.xpath(pt)).getAttribute("title");
                    System.out.println(pri);
                    if (pri.equalsIgnoreCase(v)) {
                        SeleniumModules.buttonClick(driver.findElement(By.xpath(dpd)), driver);
                        Thread.sleep(5000);
                        SeleniumModules.buttonClick(driver.findElement(By.xpath(pt)), driver);
                    }
                }
            } else if (n.contains("Class of Service")) {
                String p = cards.cardofServiceLable.findElement(By.xpath("..")).getAttribute("for");
                String dpd = "//input[@id='" + p + "_HDropDown_Input']";
                String _p = "//div[@id='" + p + "_HDropDown_i0_HDropdownTree']/ul/li";
                int j = driver.findElements(By.xpath(_p)).size();
                for (int i = 2; i <= j; i++) {
                    String pt = _p + "[" + i + "]/div/span[2]";
                    String pri = driver.findElement(By.xpath(pt)).getAttribute("title");
                    System.out.println(pri);
                    if (pri.equalsIgnoreCase(v)) {
                        SeleniumModules.buttonClick(driver.findElement(By.xpath(dpd)), driver);
                        Thread.sleep(5000);
                        SeleniumModules.buttonClick(driver.findElement(By.xpath(pt)), driver);
                    }
                }
            } else if (n.contains("Card Status")) {
                if (cards.cardStatusLable.getText().contains("Card Status")) {
                    l = cards.cardStatusLable;
                }
            } else if (n.contains("Save Button")) {
                if (cards.buttonSave.isDisplayed()) {
                    cards.buttonSave.click();
                }
            }/* else if (n.contains("Save and Continoue Button")) {
                if (cards.buttonSaveContinue.isDisplayed()) {
                    l = cards.buttonSaveContinue;
                }
            } else if (n.contains("Save and New Button")) {
                if (cards.buttonSaveN.isDisplayed()) {
                    l = cards.buttonSaveN;
                }
            } */else {
                if (cards.buttonCancel.isDisplayed()) {
                    l = cards.buttonCancel;
                }
            }

        } catch (Exception e) {
            System.out.println(e.getMessage());

        }
    }

    //This returns all the field values of an existing card
    public String getValueOfcard(String n, String v, WebDriver driver) throws Exception {
        WebElement l = null;
        String t = null;
        try {
            if (n.equals("Card Title")) {
                t = SeleniumModules.getFromTxt(cards.cardTitleLable, driver);
                System.out.println(t);
                // task title
                String _for = cards.cardTitleLable.findElement(By.xpath("..")).getAttribute("for");
                t = SeleniumModules.getFromTxt(driver.findElement(By.id(_for)), driver);
            } else if (n.equals("priority")) {
                String p = cards.cardPriorityLable.findElement(By.xpath("..")).getAttribute("for");
                String dpd = "//input[@id='" + p + "_HDropDown_Input']";
                String _p = "//div[@id='" + p + "_HDropDown_i0_HDropdownTree']/ul/li";
                int j = driver.findElements(By.xpath(_p)).size();
                for (int i = 2; i <= j; i++) {
                    String pt = _p + "[" + i + "]/div/span[2]";
                    String pri = driver.findElement(By.xpath(pt)).getAttribute("title");
                    System.out.println(pri);
                    if (pri.equalsIgnoreCase(v)) {
//                        l = driver.findElement(By.xpath(pt)).findElement(By.xpath(".."));
                        l=driver.findElement(By.xpath(pt+"/.."));
                        if (l.getAttribute("class").contains("rtSelected")) {
//                            t = "rtSelected rtHover";
                            t=v;
                        }
                    }
                }
            } else if (n.equals("Card of Service")) {
//                if (cards.cardofServiceLable.getText().contains("Card of Service")) {
//                    l = cards.cardofServiceDropdown;
//                }
                String p = cards.cardofServiceLable.findElement(By.xpath("..")).getAttribute("for");
                String dpd = "//input[@id='" + p + "_HDropDown_Input']";
                String _p = "//div[@id='" + p + "_HDropDown_i0_HDropdownTree']/ul/li";
                int j = driver.findElements(By.xpath(_p)).size();
                for (int i = 2; i <= j; i++) {
                    String pt = _p + "[" + i + "]/div/span[2]";
                    String pri = driver.findElement(By.xpath(pt)).getAttribute("title");
                    System.out.println(pri);
                    if (pri.equalsIgnoreCase(v)) {
//                        l = driver.findElement(By.xpath(pt)).findElement(By.xpath(".."));
                        l=driver.findElement(By.xpath(pt+"/.."));
                        if (l.getAttribute("class").contains("rtSelected")) {
//                            t = "rtSelected rtHover";
                            t=v;
                        }
                    }
                }
            } else if (n.equals("Card Status")) {
                if (cards.cardStatusLable.getText().contains("Card Status")) {
                    l = cards.cardStatusLable;
                }
            } else if (n.equals("Bookmarks Button") || n.equals("Add to Bookmarks")) {
                if (n.equals("Add to Bookmarks")) {
                    if (cards.buttonAddtoBookmarks.getText().equals("Add to Bookmarks")) {
                        l = cards.buttonAddtoBookmarks;
                    };
                }
                if (n.equals("Add to Bookmarks")) {
                    l = cards.buttonAddtoBookmarks;
                }
            }
            return t;
        } catch (Exception e) {
            System.out.println(e.getMessage());
            t = e.getMessage();
            return t;
        }
    }

    //This returns the element of a searched card

    public WebElement searchCard(String title, WebDriver driver) throws InterruptedException, Exception {
        WebElement source = null;
        try {
            ab = ke.new ActiveBoard(driver);
            String _title=null;
            
//            for (WebElement col : ab.card) {  // getting webelement for source from where card is taken
//                _title = col.getText();
//                System.out.println(_title);
//                if (_title.contains(title)) {
//                    source = col;
//                    System.out.println(source);
//                }
//            }
            WebElement col=null;
            for(int i=0;i<ab.card.size();i++){
                _title = ab.card.get(i).getText();
                System.out.println(_title);
                if (_title.contains(title)) {
                    source = ab.card.get(i);
                    System.out.println(source);
                }
            }
            return source;
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return source;
        }
    }

    //This returns all the different icons present in an existing card with there different states

    public WebElement verifyCard(String title, WebDriver driver) throws InterruptedException, Exception {
        WebElement source = null;
        try {
            ci = ke.new cardIcons(driver);
            if (ci.collapseIcons.size() != 0) {
                ci.collapseIcons.get(0).click();
            }
            if (title.equals("button")) {
                ci = ke.new cardIcons(driver);
                  source = ci.showHideIcons;
            } else if (title.equals("Activity Log")) {
                source = ci.activityLog;
            } else if (title.equals("Move to backlog")) {
                source = ci.backlog;
            } else if (title.equals("Task")) {
                source = ci.task;
            } else if (title.equals("Comment")) {
                source = ci.comment;
            } else if (title.equals("Block")) {
                source = ci.blockedCard;

            } else if (title.equals("Unblock")) {
                source = ci.unblockedCard;

            } else if (title.equals("Flag") || title.equals("Unflagged Card") || title.equals("Flagged Card")) {
                if (title.equals("Flag") || title.equals("Unflagged Card")) {
                    source = ci.unflaggedCard.get(0);
                } else if (title.equals("Flagged Card")) {
                    source = ci.flaggedCard.get(0);
                }
            } else if (title.equals("Remove")) {
                source = ci.remove;
            }
            else if(title.equals("Card Name"))
            {
                ab=ke.new ActiveBoard(driver);
                source=ab.card.get(0);
            }
            return source;
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return source;
        }
    }

    //This method submit comment in the comment pop up which is appeared at the time of blocking/unblocking and moving a card

    public void submitComment(WebDriver driver) {
        cm = ke.new CardComment(driver);
        cm.commentText.sendKeys("Test");
        cm.submitComment.click();
    }

    //This returns the validation message

    public String validationMessage(WebDriver driver) {
        String message;
        message = val.validationMessage.getText();
        return message;
    }

    //This click on ok button of validation popup

    public void clickValidationOK(WebDriver driver) {
        val = ke.new Validation_check(driver);
        val.validationOK.click();
    }

    //This return the card after moving that to backlog

    public List<WebElement> clickMoveToBacklog(WebDriver driver) {
        List<WebElement> card;
        card = ab.card;
        ci.unblockedCard.click();
        cm = ke.new CardComment(driver);
        cm.commentText.sendKeys("Test");
        cm.submitComment.click();
        ci.backlog.click();
        return card;
    }

    //This returns the different elements of an archived board list

    public WebElement verifyAppearenceOfarchiveBoardList(String Title, WebDriver driver) throws InterruptedException, Exception {
        WebElement source = null;
        arch = ke.new ArchiveBoardlist(driver);
        //ab=ke.new ActiveBoard(driver);
        try {
            if (Title.equals("Archive Board List")) {
                source = bac.archiveBoardListActionHeader;
            } else if (Title.equals("Archive Dropdown")) {
                source = arch.selectArchiveBoardCard;
            } else if (Title.equals("Cardcount")) {
                source = arch.archiveBoardCardCount;
            } else if (Title.equals("WIP Limit")) {
                source = arch.columnHeaders.get(0);
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return source;
        }
        return source;
    }

    //This returns the total available card count value of a board 
    public int cardCountVal(WebDriver driver) throws InterruptedException, Exception {
        int cardCount = 0;
        try {
            cardCount = Integer.parseInt(arch.archiveBoardCardCount.getText().replaceAll("[^0-9]", ""));
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return cardCount;
        }
        return cardCount;

    }

    public List<String> verifyArchivedBoardList(WebDriver driver) throws Exception {
        List<String> BoardId = null;
        try {
            arch = ke.new ArchiveBoardlist(driver);
            BoardId=new ArrayList<String>();
            for (int i = 0; i < SeleniumModules.retuenAllDataFromList(arch.selectArchiveBoardCard, driver).size(); i++) {
                BoardId.add(SeleniumModules.retuenAllDataFromList(arch.selectArchiveBoardCard, driver).get(i).getAttribute("value"));
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return BoardId;
    }

    //This returns all expanded and collapsed buttons of each column in archived board list page
    public List<WebElement> expandCollpaseOfArchivedBoardList(String title, WebDriver driver) throws InterruptedException, Exception {
        List<WebElement> source;
        source = null;
        try {
            if (title.contains("Expand")) {
                source = arch.expandColumn;
            } else if (title.contains("Collapse")) {
                source = arch.collpaseColumn;
            }

        } catch (Exception e) {
            System.out.println(e.getMessage());
            return source;
        }
        return source;
    }

  

    public void archiveBoard(WebDriver driver) throws InterruptedException {
        String columnHeaderText;
        WebElement archiveBoard;
        cardCount = arch.archiveBoardCardCount.getText().replaceAll("[^0-9]", "");
        WIPLimit = arch.columnHeaders.get(0).getText();
        WIPLimit = WIPLimit.substring(WIPLimit.lastIndexOf("/") + 1).replaceAll("[^0-9]", "");
        columnOrderInArchiveList(driver);
        ke.logoHDAction.click();
        bac.titleArchivedBoard.click();
    }

    //It returns all the values before archiving a board

    public String beforeArchiveValue(String title, WebDriver driver) throws InterruptedException {
        String value = null;
        if (title.equals("Card Count")) {
            value = cardCount;
        } else if (title.equals("WIP Limit")) {
            value = WIPLimit;
        } else if (title.equals("Columns Order")) {
            value = columns;
        }
        return value;
    }

    //It returns 1 if a board is found in Archive Board dropdown in Archive Board List page

    public int findArchiveBoardInArchiveBoardDropdown(String value, WebDriver driver) {
        int find = 0;
        try {
            khome = new KovairHomePageModule(driver);
            khome.tab_Frame_Switch(driver);
            WebElement archiveBoardDropdown = arch.selectArchiveBoardCard;
            archiveBoardDropdown.click();
            List<WebElement> dropdownValues = arch.archiveBoardDropdownValues;
            for (int i = 0; i < dropdownValues.size(); i++) {
                if (dropdownValues.get(i).getText().contains(value)) {
                    find = 1;
                    break;
                }
            }
            return find;
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        return find;
    }

    //It returns a string by concatinating all the available columns in Archive List page

    public String columnOrderInArchiveList(WebDriver driver) throws InterruptedException {
        columns = "";
        String columnOrder = null;
        for (int i = 0; i < arch.columnHeaders.size(); i++) {
            columnOrder = arch.columnHeaders.get(i).getText();
            columns = columns + columnOrder.replaceAll("[0-9,(,),/,:]", "");
        }
        return columns;
    }

    //This select a kanban board from Archive Board dropdown in Archive List page

    public void selectArchiveBoard(String boardName, WebDriver driver) throws InterruptedException {
        List<WebElement> archiveBoardDropdownValues;
        archiveBoardDropdownValues = arch.archiveBoardDropdownValues;
        WebElement selectedArchiveBoard, archiveBoardDropdown;
        archiveBoardDropdown = arch.selectArchiveBoardCard;
        for (int i = 0; i < archiveBoardDropdownValues.size(); i++) {
            ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", arch.archiveBoardDropdownValues.get(i));
            if (archiveBoardDropdownValues.get(i).getText().contains(boardName)) {
                selectedArchiveBoard = archiveBoardDropdownValues.get(i);
                selectedArchiveBoard.click();
                Thread.sleep(5000);
                break;
            }
        }
    }

    //Verifying Visibility of Scroll bar in Archive Board list page

    public String verify_Scrollbar(WebDriver driver) throws Exception {
        String value = "";
        try {
            value = arch.archiveBoardDiv.getCssValue("overflow-x");

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return value;
    }
//Clicking any menu from action header in Kanban board page

    public void clickMenuFromHeaderAction(String menuItem, WebDriver driver) throws Exception {
        try {
            verifyApperence("Action Button", driver);
            if (menuItem.equalsIgnoreCase(bac.titleAddCard.getText())) {
                bac.titleAddCard.click();
            } else if (menuItem.equalsIgnoreCase(bac.dashboardActionHeader.getText())) {
                bac.dashboardActionHeader.click();
            } else if (menuItem.equalsIgnoreCase(bac.titleArchivedBoard.getText())) {
                bac.titleArchivedBoard.click();
            } else if (menuItem .equalsIgnoreCase(bac.archiveBoardListActionHeader.getText())) {
                bac.archiveBoardListActionHeader.click();
            }

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
    //Verify the cards are editable or not
    public boolean verifyCardEditable(WebDriver driver) throws Exception {
        boolean editable=true;
        try {
//            WebElement searchedCard=searchCard(CardName, driver);
//            WebElement parentDiv=searchedCard.findElement(By.xpath(".."));
//            WebElement parentDivUp=searchedCard.findElement(By.xpath(".."));
            if(ci.expandIcons.get(0).isEnabled()){
                editable=true;
            }
            else{
                editable=false;
            }           

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return editable;
    }
    public WebElement contextMenu(String n,WebDriver driver) throws Exception
    {
        boardContextMenu=ke.new BoardContextMenuPopup(driver);
        WebElement elem=null;
        try{
            if(n.equals("Add Card"))
            {
                elem=boardContextMenu.addCard;
            }
            else if(n.equals("Archive card"))
            {
                elem=boardContextMenu.archiveCard;
            }
        }
        catch(Exception e)
        {
            System.out.println(e.getMessage());
        }
        return elem;
    }
    
    public WebElement appearanceOfArchivedCardList(String n,WebDriver driver) throws Exception{
        WebElement elem=null;
        acl=ke.new ArchivedCardList(driver);
        try
        {
            if(n.equals("ID column header"))
            {
                elem=acl.IDColumnHeader;
            }
            else if(n.equals("Title column header"))
            {
                elem=acl.titleColumnHeader;
            }
            else if(n.equals("Archived on column header"))
            {
                elem=acl.archivedOnColumnHeader;
            }
            else if(n.equals("Entity Name column header"))
            {
                elem=acl.entityNameColumn;
            }
            else if(n.equals("First Page"))
            {
                elem=acl.firstPage;
            }
            else if(n.equals("Last Page"))
            {
                elem=acl.lastPage;
            }
            else if(n.equals("Previous Page"))
            {
                elem=acl.prevPage;
            }
            else if(n.equals("Next Page"))
            {
                elem=acl.nextPage;
            }
            else if(n.equals("Current Page No"))
            {
                elem=acl.currentPageNumber;
            }
            else if(n.equals("Total Pages"))
            {
                elem=acl.totalPages;
            }
            else if(n.equals("Total Records Count"))
            {
                elem=acl.totalRecordsCount;
            }
            else if(n.equals("Records per page"))
            {
                elem=acl.recordsPerPage;
            }
        }
        catch(Exception e)
        {
            System.out.println(e.getMessage());
        }
        return  elem;
    }
    public WebElement appearanceOfBacklog(String n,WebDriver driver) throws InterruptedException
    {
        WebElement l=null;
        bl=ke.new backlog(driver);
        try
        {
            if(n.equals("Cancel Backlog Popup"))
            {
                l=bl.cancelBacklog;
            }
            else if(n.equals("Select All"))
            {
                l=bl.selectAllCheckbox;
            }
            else if(n.equals("ID column header"))
            {
                l=bl.IDColumnHeader;
            }
            else if(n.equals("Title column header"))
            {
                l=bl.titleColumnHeader;
            }
            else if(n.equals("Entity Name column header"))
            {
                l=bl.entityNameColumnHeader;
            }
            else if(n.equals("Backlog Card List"))
            {
                l=bl.backlogCardList;
            }
            else if(n.equals("Add To Board"))
            {
                l=bl.addToBoardOption;
            }
            else if(n.equals("Available Boards"))
            {
                l=bl.availableBoards;
            }
        }
        catch(Exception e)
        {
            System.out.println(e.getMessage());
        }
        return l;
    }
}
