/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.kovair.PagelevelModule;

//import TaskList.KovairGenericClass;
import com.kovair.pages.KovairKanbanCardElement;
import com.kovair.pages.KovairKanbanCardElement.BoardAddcard;
import com.kovair.pages.KovairKanbanCardElement.CreatePopup;
import com.kovair.pages.KovairKanbanCardElement.Validation_check;
import com.kovair.utilities.SeleniumModules;
import com.kovair.utilities.sqlQueries;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

/**
 *
 * @author sreyag
 */
public class KovairKanbanCardModule {
    KovairKanbanCardElement ke; 
    KovairKanbanCardElement.BoardCreateGI gi;
    KovairKanbanCardElement.BoardAddcard bac;
    KovairKanbanCardElement.CreatePopup cp;
    KovairKanbanCardElement.Validation_check vl;
    KovairKanbanCardElement.ActiveBoard ab;
    KovairKanbanCardElement.cardIcons ci;
    KovairKanbanCardElement.CardComment cm;
    KovairKanbanCardElement.ArchiveBoardlist arch;
    KovairKanbanCardElement.BoardContextMenuPopup boardContextMenu;
    KovairKanbanCardElement.ArchivedCardList acl;
    KovairKanbanCardElement.backlog bl;
    KovairKanbanCardElement.Validation_check val;
    KovairHomePageModule khome;
    KovairKanbanBoardModule bm;
    String cardCount, WIPLimit, columns; 
    HashMap<Integer, String> boardColumns = new HashMap<Integer, String>();
    public static String sql_n;
     public KovairKanbanCardModule(WebDriver driver)
      {
       ke=new KovairKanbanCardElement(driver);
      } 
     
     public void boradCreation(String title,WebDriver driver) throws InterruptedException, Exception {
        try { 
            
            SeleniumModules.buttonClick(ke.logoHDAction,driver);
            bac=ke.new BoardAddcard(driver);
            SeleniumModules.buttonClick(bac.titleAddBoard, driver);
            gi=ke.new BoardCreateGI(driver);
            SeleniumModules.sendDataIntoTxt(gi.boardTitle, title, driver);
            Thread.sleep(4000);
            SeleniumModules.buttonClick(gi.buttonNext, driver);
            Thread.sleep(4000);
            SeleniumModules.buttonClick(gi.buttonNext, driver);
            Thread.sleep(4000);
            SeleniumModules.buttonClick(gi.buttonNext, driver);
            Thread.sleep(4000);
            SeleniumModules.buttonClick(gi.buttonNext, driver);
            Thread.sleep(4000);
            SeleniumModules.buttonClick(gi.buttonNext, driver);
            Thread.sleep(4000);
            SeleniumModules.buttonClick(gi.buttonSave, driver);
            
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        // return tastCreation_status;
    } 
    
     public void boradcardCreation(String title,String cardType,String priority,WebDriver driver) throws InterruptedException, Exception {
        try { 
            
            SeleniumModules.buttonClick(ke.logoHDAction,driver);
            bac=ke.new BoardAddcard(driver);
            SeleniumModules.buttonClick(bac.titleAddCard, driver);
             Thread.sleep(4000);
            SeleniumModules.selectDataFromList(bac.typeOfCard, cardType, driver);
             Thread.sleep(4000);
            SeleniumModules.buttonClick(bac.create, driver);
            Thread.sleep(4000);
            cp=ke.new CreatePopup(driver);
             Thread.sleep(4000);
//            KovairGenericClass.PopUp_Frame_Switch(driver);
            //taking one level up tag
            String t = SeleniumModules.getFromTxt(cp.cardTitleLable, driver);
            System.out.println(t);
            // task title
            String _for = cp.cardTitleLable.findElement(By.xpath("..")).getAttribute("for");
            SeleniumModules.sendDataIntoTxt(driver.findElement(By.id(_for)), title, driver);
            //assignedPolicy 
            String p = cp.cardPriorityLable.findElement(By.xpath("..")).getAttribute("for");
            String dpd="//input[@id='"+p+"_HDropDown_Input']";
            String _p="//div[@id='"+p+"_HDropDown_i0_HDropdownTree']/ul/li";
            int n=driver.findElements(By.xpath(_p)).size();
            for(int i=2;i<=n;i++){
              String pt=_p+"["+i+"]/div/span[2]";
              String pri=driver.findElement(By.xpath(pt)).getAttribute("title");
              System.out.println(pri);
              if(pri.equalsIgnoreCase(priority))
              { 
               SeleniumModules.buttonClick(driver.findElement(By.xpath(dpd)), driver);   
               SeleniumModules.buttonClick(driver.findElement(By.xpath(pt)), driver);
              }
            }
//            SeleniumModules.selectDataFromList(driver.findElement(By.id(p)), priority, driver);
            cp.buttonSave.click();
            driver.switchTo().parentFrame();
            System.out.println("Card has saved");
             
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        // return tastCreation_status;
    }  
     
     public String boradArchived(WebDriver driver) throws InterruptedException, Exception {
         String n=null;
         try { 
            
            SeleniumModules.buttonClick(ke.logoHDAction,driver);
            bac=ke.new BoardAddcard(driver);
            SeleniumModules.buttonClick(bac.titleArchivedBoard, driver);
            vl=ke.new Validation_check(driver);
            n=SeleniumModules.getFromTxt(vl.validationMessage, driver); 
            SeleniumModules.buttonClick(vl.validationOK, driver);
            return n;
        } catch (Exception e) {
            System.out.println(e.getMessage());
            n=e.getMessage();
            return n;
        }
        // return tastCreation_status;
    } 
     
     
      public WebElement verifyApperence(String n, WebDriver driver) throws Exception {
        WebElement l = null;
        try {
             bac = ke.new BoardAddcard(driver);
            if (n.equals("Add Card")) {
                if (bac.titleAddCard.getText().contains("Add Card")) {
                    l = bac.titleAddCard;
                }
            } else if (n.equals("Action Button")) {
                SeleniumModules.buttonClick(ke.logoHDAction, driver);
//                bac = ke.new BoardAddcard(driver);
            } 
            else if(n.equals("Popup header"))
            {
                l=ke.popupHeader;
            }
            else if(n.equals("Popup close"))
            {
                l=ke.popupClose;
            }
            else if (n.equals("Add Card Title")) {
                if (bac.titleOfAddCard.getText().contains("Add Card")) {
                    l = bac.titleOfAddCard;
                }
            } else if (n.equals("Default scope")) {
                if (bac.typeOfCard.isDisplayed()) {
                    l = bac.typeOfCard;
                }
            } else if (n.equals("Appearing scope")) {
                if (bac.typeOfCard.isDisplayed()) {
                    l = bac.typeOfCard;
                }
            } else if (n.equals("Appearing option")) {
                if (bac.create.isDisplayed()) {
                    l = bac.create;
                }
//                if (bac.restoreCard.isDisplayed()) {
//                    l = bac.restoreCard;
//                }
            }
            else if (n.equals("Archive Board")) {
                if (bac.titleArchivedBoard.getText().contains("Inactive Board")) {
                    l = bac.titleArchivedBoard;
                }
            }
            else if (n.equals("Archive Board List")) {
                if (bac.archiveBoardListActionHeader.getText().contains("Archive Board List")) {
                    l = bac.archiveBoardListActionHeader;
                }
            }
            else if(n.equals("Backlogs"))
            {
                l=bac.backlog;
            }
            else if(n.equals("Archive Card List"))
            {
                l=bac.archiveCardList;
            }
            else if(n.equals("Board List"))
            {
                l=bac.boardList;
            }
            else if(n.equals("Board Title"))
            {
                ab=ke.new ActiveBoard(driver);
                l=ab.pageName;
            }
            else {
                if (bac.closAddCard.isDisplayed()) {
                    l = bac.closAddCard;
                }
            }
            return l;
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return l;
        }
    }

    //This can set the type of a card at the time of creation

    public void setcardType(WebDriver driver) throws Exception {
        try {
            SeleniumModules.selectDataByIndFromList(bac.typeOfCard, 1, null);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    //This returns all the elements of add new card popup
    public WebElement verifyApperenceOfcard(String n, WebDriver driver) throws Exception {
        WebElement l = null;
        try {
            if (n.equals("Card HD")) {
                cp = ke.new CreatePopup(driver);
//          if(cp.cardTitleLable.getText().contains("Add Card"))  
//          {
//           l=cp.cardTitleLable; 
//          }
            } else if (n.equals("Title")) {
                if (cp.pageTitleLable.getText().contains("Create New")) {
                    l = cp.pageTitleLable;
                }
            } else if (n.equals("Card Title")) {
                if (cp.cardTitleLable.getText().contains("Title")) {
                    l = cp.cardTitleLable;
                }
            } else if (n.equals("Card priority")) {
                if (cp.cardPriorityLable.getText().contains("Card priority")) {
                    l = cp.cardPriorityLable;
                }
            } else if (n.equals("Card of Service")) {
                if (cp.cardofServiceLable.getText().contains("Card of Service")) {
                    l = cp.cardofServiceLable;
                }
            } else if (n.equals("Card Status")) {
                if (cp.cardStatusLable.getText().contains("Card Status")) {
                    l = cp.cardStatusLable;
                }
            } else if (n.equals("Save Button")) {
                if (cp.buttonSave.isDisplayed()) {
                    l = cp.buttonSave;
                }
            } /*else if (n.equals("Save and Continoue Button")) {
                if (cp.buttonSaveContinue.isDisplayed()) {
                    l = cp.buttonSaveContinue;
                }
            } else if (n.equals("Save and New Button")) {
                if (cp.buttonSaveN.isDisplayed()) {
                    l = cp.buttonSaveN;
                }
            }*/ else if (n.contains("Reset Button")) {
                l = cp.pageResetLable;
            } else if (n.contains("Available Button")) {
                l = cp.buttonAvailable;
            } else if (n.contains("Bookmarks Button")) {
                l = cp.buttonBookmarks;
            } else {
                if (cp.buttonCancel.isDisplayed()) {
                    l = cp.buttonCancel;
                }
            }
            return l;
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return l;
        }
    }

    //This set the values of different fields at the time of creating a card
    public void setValueOfcard(String n, String v, WebDriver driver) throws Exception {
        WebElement l = null;
        try {
            if (n.contains("Card Title")) {
                String t = SeleniumModules.getFromTxt(cp.cardTitleLable, driver);
                System.out.println(t);
                // task title
                String _for = cp.cardTitleLable.findElement(By.xpath("..")).getAttribute("for");
                Thread.sleep(2000);
                SeleniumModules.sendDataIntoTxt(driver.findElement(By.id(_for)), v, driver);
                Thread.sleep(5000);
            } else if (n.contains("priority")) {
                String p = cp.cardPriorityLable.findElement(By.xpath("..")).getAttribute("for");
                String dpd = "//input[@id='" + p + "_HDropDown_Input']";
                String _p = "//div[@id='" + p + "_HDropDown_i0_HDropdownTree']/ul/li";
                int j = driver.findElements(By.xpath(_p)).size();
                for (int i = 2; i <= j; i++) {
                    String pt = _p + "[" + i + "]/div/span[2]";
                    String pri = driver.findElement(By.xpath(pt)).getAttribute("title");
                    System.out.println(pri);
                    if (pri.equalsIgnoreCase(v)) {
                        SeleniumModules.buttonClick(driver.findElement(By.xpath(dpd)), driver);
                        Thread.sleep(5000);
                        SeleniumModules.buttonClick(driver.findElement(By.xpath(pt)), driver);
                    }
                }
            } else if (n.contains("Class of Service")) {
                String p = cp.cardofServiceLable.findElement(By.xpath("..")).getAttribute("for");
                String dpd = "//input[@id='" + p + "_HDropDown_Input']";
                String _p = "//div[@id='" + p + "_HDropDown_i0_HDropdownTree']/ul/li";
                int j = driver.findElements(By.xpath(_p)).size();
                for (int i = 2; i <= j; i++) {
                    String pt = _p + "[" + i + "]/div/span[2]";
                    String pri = driver.findElement(By.xpath(pt)).getAttribute("title");
                    System.out.println(pri);
                    if (pri.equalsIgnoreCase(v)) {
                        SeleniumModules.buttonClick(driver.findElement(By.xpath(dpd)), driver);
                        Thread.sleep(5000);
                        SeleniumModules.buttonClick(driver.findElement(By.xpath(pt)), driver);
                    }
                }
            } else if (n.contains("Card Status")) {
                if (cp.cardStatusLable.getText().contains("Card Status")) {
                    l = cp.cardStatusLable;
                }
            } else if (n.contains("Save Button")) {
                if (cp.buttonSave.isDisplayed()) {
                    cp.buttonSave.click();
                }
            }/* else if (n.contains("Save and Continoue Button")) {
                if (cp.buttonSaveContinue.isDisplayed()) {
                    l = cp.buttonSaveContinue;
                }
            } else if (n.contains("Save and New Button")) {
                if (cp.buttonSaveN.isDisplayed()) {
                    l = cp.buttonSaveN;
                }
            } */else {
                if (cp.buttonCancel.isDisplayed()) {
                    l = cp.buttonCancel;
                }
            }

        } catch (Exception e) {
            System.out.println(e.getMessage());

        }
    }

    //This returns all the field values of an existing card
    public String getValueOfcard(String n, String v, WebDriver driver) throws Exception {
        WebElement l = null;
        String t = null;
        try {
            if (n.equals("Card Title")) {
                t = SeleniumModules.getFromTxt(cp.cardTitleLable, driver);
                System.out.println(t);
                // task title
                String _for = cp.cardTitleLable.findElement(By.xpath("..")).getAttribute("for");
                t = SeleniumModules.getFromTxt(driver.findElement(By.id(_for)), driver);
            } else if (n.equals("priority")) {
                String p = cp.cardPriorityLable.findElement(By.xpath("..")).getAttribute("for");
                String dpd = "//input[@id='" + p + "_HDropDown_Input']";
                String _p = "//div[@id='" + p + "_HDropDown_i0_HDropdownTree']/ul/li";
                int j = driver.findElements(By.xpath(_p)).size();
                for (int i = 2; i <= j; i++) {
                    String pt = _p + "[" + i + "]/div/span[2]";
                    String pri = driver.findElement(By.xpath(pt)).getAttribute("title");
                    System.out.println(pri);
                    if (pri.equalsIgnoreCase(v)) {
//                        l = driver.findElement(By.xpath(pt)).findElement(By.xpath(".."));
                        l=driver.findElement(By.xpath(pt+"/.."));
                        if (l.getAttribute("class").contains("rtSelected")) {
//                            t = "rtSelected rtHover";
                            t=v;
                        }
                    }
                }
            } else if (n.equals("Card of Service")) {
//                if (cp.cardofServiceLable.getText().contains("Card of Service")) {
//                    l = cp.cardofServiceDropdown;
//                }
                String p = cp.cardofServiceLable.findElement(By.xpath("..")).getAttribute("for");
                String dpd = "//input[@id='" + p + "_HDropDown_Input']";
                String _p = "//div[@id='" + p + "_HDropDown_i0_HDropdownTree']/ul/li";
                int j = driver.findElements(By.xpath(_p)).size();
                for (int i = 2; i <= j; i++) {
                    String pt = _p + "[" + i + "]/div/span[2]";
                    String pri = driver.findElement(By.xpath(pt)).getAttribute("title");
                    System.out.println(pri);
                    if (pri.equalsIgnoreCase(v)) {
//                        l = driver.findElement(By.xpath(pt)).findElement(By.xpath(".."));
                        l=driver.findElement(By.xpath(pt+"/.."));
                        if (l.getAttribute("class").contains("rtSelected")) {
//                            t = "rtSelected rtHover";
                            t=v;
                        }
                    }
                }
            } else if (n.equals("Card Status")) {
                if (cp.cardStatusLable.getText().contains("Card Status")) {
                    l = cp.cardStatusLable;
                }
            } else if (n.equals("Bookmarks Button") || n.equals("Add to Bookmarks")) {
                if (n.equals("Add to Bookmarks")) {
                    if (cp.buttonAddtoBookmarks.getText().equals("Add to Bookmarks")) {
                        l = cp.buttonAddtoBookmarks;
                    };
                }
                if (n.equals("Add to Bookmarks")) {
                    l = cp.buttonAddtoBookmarks;
                }
            }
            return t;
        } catch (Exception e) {
            System.out.println(e.getMessage());
            t = e.getMessage();
            return t;
        }
    }

    //This returns the element of a searched card

    public WebElement searchCard_1(String title, WebDriver driver) throws InterruptedException, Exception {
        WebElement source = null;
        try {
            ab = ke.new ActiveBoard(driver);
            String _title=null;
            
//            for (WebElement col : ab.card) {  // getting webelement for source from where card is taken
//                _title = col.getText();
//                System.out.println(_title);
//                if (_title.contains(title)) {
//                    source = col;
//                    System.out.println(source);
//                }
//            }
            WebElement col=null;
            for(int i=0;i<ab.card.size();i++){
                _title = ab.card.get(i).getText();
                System.out.println(_title);
                if (_title.contains(title)) {
                    source = ab.card.get(i);
                    System.out.println(source);
                }
            }
            return source;
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return source;
        }
    }

    //This returns all the different icons present in an existing card with there different states

    public WebElement verifyCard(String title, WebDriver driver) throws InterruptedException, Exception {
        WebElement source = null;
        try {
            ci = ke.new cardIcons(driver);
            if (ci.collapseIcons.size() != 0) {
                ci.collapseIcons.get(0).click();
            }
            if (title.equals("button")) {
                ci = ke.new cardIcons(driver);
                  source = ci.showHideIcons;
            } else if (title.equals("Activity Log")) {
                source = ci.activityLog;
            } else if (title.equals("Move to backlog")) {
                source = ci.backlog;
            } else if (title.equals("Task")) {
                source = ci.task;
            } else if (title.equals("Comment")) {
                source = ci.comment;
            } else if (title.equals("Block")) {
                source = ci.blockedCard;

            } else if (title.equals("Unblock")) {
                source = ci.unblockedCard;

            } else if (title.equals("Flag") || title.equals("Unflagged Card") || title.equals("Flagged Card")) {
                if (title.equals("Flag") || title.equals("Unflagged Card")) {
                    source = ci.unflaggedCard.get(0);
                } else if (title.equals("Flagged Card")) {
                    source = ci.flaggedCard.get(0);
                }
            } else if (title.equals("Remove")) {
                source = ci.remove;
            }
            else if(title.equals("Card Name"))
            {
                ab=ke.new ActiveBoard(driver);
                source=ab.card.get(0);
            }
            return source;
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return source;
        }
    }

    //This method submit comment in the comment pop up which is appeared at the time of blocking/unblocking and moving a card

    public void submitComment(WebDriver driver) {
        cm = ke.new CardComment(driver);
        cm.commentText.sendKeys("Test");
        cm.submitComment.click();
    }

      public String validationMessage(WebDriver driver) {
        String message;
        message = val.validationMessage.getText();
        return message;
    }

    //This click on ok button of validation popup

    public void clickValidationOK(WebDriver driver) {
        val = ke.new Validation_check(driver);
        val.validationOK.click();
    } 
    
    
    //This return the card after moving that to backlog

    public List<WebElement> clickMoveToBacklog(WebDriver driver) {
        List<WebElement> card;
        card = ab.card;
        ci.unblockedCard.click();
        cm = ke.new CardComment(driver);
        cm.commentText.sendKeys("Test");
        cm.submitComment.click();
        ci.backlog.click();
        return card;
    }

    //This returns the different elements of an archived board list

    public WebElement verifyAppearenceOfarchiveBoardList(String Title, WebDriver driver) throws InterruptedException, Exception {
        WebElement source = null;
        arch = ke.new ArchiveBoardlist(driver);
        //ab=ke.new ActiveBoard(driver);
        try {
            if (Title.equals("Archive Board List")) {
                source = bac.archiveBoardListActionHeader;
            } else if (Title.equals("Archive Dropdown")) {
                source = arch.selectArchiveBoardCard;
            } else if (Title.equals("Cardcount")) {
                source = arch.archiveBoardCardCount;
            } else if (Title.equals("WIP Limit")) {
                source = arch.columnHeaders.get(0);
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return source;
        }
        return source;
    }

      public List<String> verifyArchivedBoardList(WebDriver driver) throws Exception {
        List<String> BoardId = null;
        try {
            arch = ke.new ArchiveBoardlist(driver);
            BoardId=new ArrayList<String>();
            for (int i = 0; i < SeleniumModules.retuenAllDataFromList(arch.selectArchiveBoardCard, driver).size(); i++) {
                BoardId.add(SeleniumModules.retuenAllDataFromList(arch.selectArchiveBoardCard, driver).get(i).getAttribute("value"));
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return BoardId;
    }

    //This returns all expanded and collapsed buttons of each column in archived board list page
    public List<WebElement> expandCollpaseOfArchivedBoardList(String title, WebDriver driver) throws InterruptedException, Exception {
        List<WebElement> source;
        source = null;
        try {
            if (title.contains("Expand")) {
                source = arch.expandColumn;
            } else if (title.contains("Collapse")) {
                source = arch.collpaseColumn;
            }

        } catch (Exception e) {
            System.out.println(e.getMessage());
            return source;
        }
        return source;
    }
  
//   gettingBoardColumn method map column names and order of column 
   public HashMap gettingBoardColumn(String boardName,WebDriver driver) throws InterruptedException, Exception {
        try { 
//            Map<String,String> hmap=new HashMap<String,String>();
             KovairKanbanBoardModule.boardname=boardName;
//            System.out.println(sqlQueries.n);
//            sqlQueries.setIntoSql(boardName,);
            String l[][]=sqlQueries.getSQLresult(sqlQueries.kanbanBoardColumns);
            
//            put values into hashMap as key value pair
            for(int i=0;i<l.length;i++)
            {
              boardColumns.put(Integer.parseInt(l[i][0]), l[i][1]);
            }
            
//            Traversing elements
            Set entrySet = boardColumns.entrySet(); 
            Iterator itr= entrySet.iterator();
       
	    while(itr.hasNext()){ 
            Map.Entry ne = (Map.Entry)itr.next();
            System.out.println("Order number"+ne.getKey());
            System.out.println("Columns"+ne.getValue());
            }
            return boardColumns;
        }
        catch (Exception e) {
            System.out.println(e.getMessage());
            return null;
        }
        } 
   
//   gettingBoardColumnID method will return column index to get the columnid attribute value
   public String gettingBoardColumnID(String boardName,String colName,WebDriver driver) throws InterruptedException, Exception {
       String i=null;
       try { 
            gettingBoardColumn(boardName, driver);
            Set entrySet = boardColumns.entrySet(); 
            Iterator itr= entrySet.iterator();
       
	    while(itr.hasNext()){ 
            Map.Entry ne = (Map.Entry)itr.next();
            System.out.println("Order number"+ne.getKey());
            System.out.println("Columns"+ne.getValue());
            if(colName.equals(ne.getValue()))
            {
              i=ne.getKey().toString();
            }
            }
            return i;
        }
        catch (Exception e) {
            System.out.println(e.getMessage());
            return i;
        }
        } 
   
   
   public WebElement gettingBoardColumnWebElement(String colName,WebDriver driver) throws InterruptedException, Exception {
       try { 
            WebElement cols=null;
            ab=ke.new ActiveBoard(driver);
            int i=0;
            for (WebElement col : ab.boardColumnID) {
            i=i+1;
            if(col.getText().contains(colName))
            { 
             cols=col;   
             break;
            }
            }
            return cols;
        }
        catch (Exception e) {
            System.out.println(e.getMessage());
            return null;
        }
        } 
   
   public int gettingSLColumn(WebDriver driver) throws InterruptedException, Exception {
        try { 
//            int i=gettingBoardColumn(driver).size();
            int j=0;
//            if(i!=0)
//            {
//             j=ab.boardColumnSL.size();
//            } 
            return j;
        }
        catch (Exception e) {
            System.out.println(e.getMessage());
            return 0;
        }
        }
     
   public void moveCard(String title,String des_columns,String des_priority,WebDriver driver) throws InterruptedException, Exception {
        try { 
             ab=ke.new ActiveBoard(driver);
             String _title;
             WebElement source=null,target=null;
             WebElement sourceUp=null;
             WebElement carditem=null;
             WebElement swimlaneDiv=null;
             WebElement targetDiv=null;
             String slane=null;
             
             String columnID=null;
//             getting webelement for source from where card is taken
             source = searchCard(title, driver);
                  System.out.println(source);
                  sourceUp=source.findElement(By.xpath(".."));
                  System.out.println(sourceUp);
                  carditem=sourceUp.findElement(By.xpath(".."));
                  System.out.println(carditem);
                  System.out.println(carditem.getAttribute("id"));
                  swimlaneDiv=carditem.findElement(By.xpath(".."));
                  System.out.println(swimlaneDiv);
                  targetDiv=swimlaneDiv.findElement(By.xpath(ab.cardSL));
                  slane=targetDiv.getText();
                  //slane=carditem.findElement(By.xpath(ab.cardSLName)).getText();
                  slane="Low";
             if(slane.equalsIgnoreCase(des_priority))
             { 
               WebElement i=gettingBoardColumnWebElement(des_columns, driver);
               sourceUp=i.findElement(By.xpath(".."));
               System.out.println(sourceUp);
               List<WebElement> sl=sourceUp.findElements(By.xpath(ab.cardSLName));
                 for (WebElement cardSl : sl) {
                     if(cardSl.getText().contains(des_priority))
                     {
                      target=cardSl.findElement(By.xpath(".."));
                     }
                 }
               
              ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", source);
               Thread.sleep(2000); 
              (new Actions(driver)).dragAndDrop(source, target).perform();
             }
             else{
               System.out.println("To move card target priority and source priority must be similar");
             }      
//             getting webelement for target location to where card is dropped   
             Iterator itr = boardColumns.keySet().iterator();
             while(itr.hasNext()) { 
                 Map.Entry mp = (Map.Entry)itr.next();
                 if(mp.getValue().equals(des_columns))
                 columnID=mp.getKey().toString();
             } 
             
             for (WebElement col : ab.boardColumnID) {
              if(col.getAttribute("columnid").contains(columnID))
              { 
               List<WebElement> priority=col.findElements(By.xpath(ab.boardColumnSLName));  
                for (WebElement sml : priority) { 
                 if(sml.getText().contains(des_priority)) 
                 {
                  target=sml;
                 }
                     }
                     }
              }
              
             ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", source);
             Thread.sleep(2000); 
             (new Actions(driver)).dragAndDrop(source, target).perform();
            System.out.println("Card has saved");
             
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        // return tastCreation_status;
    }  
   
   
//   In board Card searched by Title(No duplicat card name allowed)
   public WebElement searchCard(String title,WebDriver driver) throws InterruptedException, Exception {
       WebElement source=null; 
       try { 
              ab=ke.new ActiveBoard(driver);
              String _title;
                                               
              for (WebElement col : ab.card) {  // getting webelement for source from where card is taken
                 _title=col.getText();
                 System.out.println(_title);
                 if(_title.contains(title))
                 {
                  source = col;
                  System.out.println(source);
                 }
                } 
              return source;
        } 
        catch (Exception e) {
            System.out.println(e.getMessage());
            return source;
        }
   }  
   
//   Getting visible options of a card that searched by Title within a board
   public List cardOptions(String title,WebDriver driver) throws InterruptedException, Exception {
        try { 
              ab=ke.new ActiveBoard(driver);
              String _title;
              WebElement source=null;
              WebElement sourceUp=null;
              WebElement carditem=null;
//             getting webelement for source from where card is taken
                  source = searchCard(title, driver);
                  System.out.println(source);
                  sourceUp=source.findElement(By.xpath(".."));
                  System.out.println(sourceUp);
                  carditem=sourceUp.findElement(By.xpath(".."));
                  System.out.println(carditem);
                  System.out.println(carditem.getAttribute("id"));
                  SeleniumModules.buttonClick(carditem.findElement(By.xpath(ab.cardOptionDn)),driver);
                 List<WebElement> options=carditem.findElements(By.xpath(ab.cardOptionsNo));
                 int optionCount=options.size();
                 System.out.println("The number of options present for the card - "+optionCount);
                     for (WebElement n : options) { 
                         System.out.println(n.getAttribute("title"));
                     } 
                return options;
        } 
        catch (Exception e) {
            System.out.println(e.getMessage());
            return null;
        }
   }  
   
   
    public void cardOptionsClick(String cardtitle,String option,WebDriver driver) throws InterruptedException, Exception {
        try { 
              ab=ke.new ActiveBoard(driver);
              String _title;
              WebElement source=null;
              WebElement div=null;
              WebElement carditem=null;
//             getting webelement for source from where card is taken
              List<WebElement> options=cardOptions(cardtitle, driver);
              int optionCount=options.size();
              System.out.println("The number of options present for the card - "+optionCount);
              for (WebElement n : options) {
                         System.out.println(n.getAttribute("title"));
                         if(n.getAttribute("title").equals(option))
                         {
                          SeleniumModules.buttonClick(n, driver);
                          break;
                         }
                     }
          } 
        catch (Exception e) {
            System.out.println(e.getMessage());
        }
   }  
    
     public void archiveBoard(WebDriver driver) throws InterruptedException {
        String columnHeaderText;
        WebElement archiveBoard;
        cardCount = arch.archiveBoardCardCount.getText().replaceAll("[^0-9]", "");
        WIPLimit = arch.columnHeaders.get(0).getText();
        WIPLimit = WIPLimit.substring(WIPLimit.lastIndexOf("/") + 1).replaceAll("[^0-9]", "");
        columnOrderInArchiveList(driver);
        ke.logoHDAction.click();
        bac.titleArchivedBoard.click();
    }

    //It returns all the values before archiving a board

    public String beforeArchiveValue(String title, WebDriver driver) throws InterruptedException {
        String value = null;
        if (title.equals("Card Count")) {
            value = cardCount;
        } else if (title.equals("WIP Limit")) {
            value = WIPLimit;
        } else if (title.equals("Columns Order")) {
            value = columns;
        }
        return value;
    }

    //It returns 1 if a board is found in Archive Board dropdown in Archive Board List page

    public int findArchiveBoardInArchiveBoardDropdown(String value, WebDriver driver) {
        int find = 0;
        try {
            khome = new KovairHomePageModule(driver);
            khome.tab_Frame_Switch(driver);
            WebElement archiveBoardDropdown = arch.selectArchiveBoardCard;
            archiveBoardDropdown.click();
            List<WebElement> dropdownValues = arch.archiveBoardDropdownValues;
            for (int i = 0; i < dropdownValues.size(); i++) {
                if (dropdownValues.get(i).getText().contains(value)) {
                    find = 1;
                    break;
                }
            }
            return find;
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        return find;
    }

    //It returns a string by concatinating all the available columns in Archive List page

    public String columnOrderInArchiveList(WebDriver driver) throws InterruptedException {
        columns = "";
        String columnOrder = null;
        for (int i = 0; i < arch.columnHeaders.size(); i++) {
            columnOrder = arch.columnHeaders.get(i).getText();
            columns = columns + columnOrder.replaceAll("[0-9,(,),/,:]", "");
        }
        return columns;
    }

    //This select a kanban board from Archive Board dropdown in Archive List page

    public void selectArchiveBoard(String boardName, WebDriver driver) throws InterruptedException {
        List<WebElement> archiveBoardDropdownValues;
        archiveBoardDropdownValues = arch.archiveBoardDropdownValues;
        WebElement selectedArchiveBoard, archiveBoardDropdown;
        archiveBoardDropdown = arch.selectArchiveBoardCard;
        for (int i = 0; i < archiveBoardDropdownValues.size(); i++) {
            ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", arch.archiveBoardDropdownValues.get(i));
            if (archiveBoardDropdownValues.get(i).getText().contains(boardName)) {
                selectedArchiveBoard = archiveBoardDropdownValues.get(i);
                selectedArchiveBoard.click();
                Thread.sleep(5000);
                break;
            }
        }
    }

    //Verifying Visibility of Scroll bar in Archive Board list page

    public String verify_Scrollbar(WebDriver driver) throws Exception {
        String value = "";
        try {
            value = arch.archiveBoardDiv.getCssValue("overflow-x");

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return value;
    }
//Clicking any menu from action header in Kanban board page

    public void clickMenuFromHeaderAction(String menuItem, WebDriver driver) throws Exception {
        try {
            verifyApperence("Action Button", driver);
            if (menuItem.equalsIgnoreCase(bac.titleAddCard.getText())) {
                bac.titleAddCard.click();
            } else if (menuItem.equalsIgnoreCase(bac.dashboardActionHeader.getText())) {
                bac.dashboardActionHeader.click();
            } else if (menuItem.equalsIgnoreCase(bac.titleArchivedBoard.getText())) {
                bac.titleArchivedBoard.click();
            } else if (menuItem .equalsIgnoreCase(bac.archiveBoardListActionHeader.getText())) {
                bac.archiveBoardListActionHeader.click();
            }

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
    //Verify the cards are editable or not
    public boolean verifyCardEditable(WebDriver driver) throws Exception {
        boolean editable=true;
        try {
//            WebElement searchedCard=searchCard(CardName, driver);
//            WebElement parentDiv=searchedCard.findElement(By.xpath(".."));
//            WebElement parentDivUp=searchedCard.findElement(By.xpath(".."));
            if(ci.expandIcons.get(0).isEnabled()){
                editable=true;
            }
            else{
                editable=false;
            }           

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return editable;
    }
    public WebElement contextMenu(String n,WebDriver driver) throws Exception
    {
        boardContextMenu=ke.new BoardContextMenuPopup(driver);
        WebElement elem=null;
        try{
            if(n.equals("Add Card"))
            {
                elem=boardContextMenu.addCard;
            }
            else if(n.equals("Archive card"))
            {
                elem=boardContextMenu.archiveCard;
            }
        }
        catch(Exception e)
        {
            System.out.println(e.getMessage());
        }
        return elem;
    }
    
    public WebElement appearanceOfArchivedCardList(String n,WebDriver driver) throws Exception{
        WebElement elem=null;
        acl=ke.new ArchivedCardList(driver);
        try
        {
            if(n.equals("ID column header"))
            {
                elem=acl.IDColumnHeader;
            }
            else if(n.equals("Title column header"))
            {
                elem=acl.titleColumnHeader;
            }
            else if(n.equals("Archived on column header"))
            {
                elem=acl.archivedOnColumnHeader;
            }
            else if(n.equals("Entity Name column header"))
            {
                elem=acl.entityNameColumn;
            }
            else if(n.equals("First Page"))
            {
                elem=acl.firstPage;
            }
            else if(n.equals("Last Page"))
            {
                elem=acl.lastPage;
            }
            else if(n.equals("Previous Page"))
            {
                elem=acl.prevPage;
            }
            else if(n.equals("Next Page"))
            {
                elem=acl.nextPage;
            }
            else if(n.equals("Current Page No"))
            {
                elem=acl.currentPageNumber;
            }
            else if(n.equals("Total Pages"))
            {
                elem=acl.totalPages;
            }
            else if(n.equals("Total Records Count"))
            {
                elem=acl.totalRecordsCount;
            }
            else if(n.equals("Records per page"))
            {
                elem=acl.recordsPerPage;
            }
        }
        catch(Exception e)
        {
            System.out.println(e.getMessage());
        }
        return  elem;
    }
    public WebElement appearanceOfBacklog(String n,WebDriver driver) throws InterruptedException
    {
        WebElement l=null;
        bl=ke.new backlog(driver);
        try
        {
            if(n.equals("Cancel Backlog Popup"))
            {
                l=bl.cancelBacklog;
            }
            else if(n.equals("Select All"))
            {
                l=bl.selectAllCheckbox;
            }
            else if(n.equals("ID column header"))
            {
                l=bl.IDColumnHeader;
            }
            else if(n.equals("Title column header"))
            {
                l=bl.titleColumnHeader;
            }
            else if(n.equals("Entity Name column header"))
            {
                l=bl.entityNameColumnHeader;
            }
            else if(n.equals("Backlog Card List"))
            {
                l=bl.backlogCardList;
            }
            else if(n.equals("Add To Board"))
            {
                l=bl.addToBoardOption;
            }
            else if(n.equals("Available Boards"))
            {
                l=bl.availableBoards;
            }
        }
        catch(Exception e)
        {
            System.out.println(e.getMessage());
        }
        return l;
    }
   
//   public void searchCardInfo(String title,WebDriver driver) throws InterruptedException, Exception {
//        try { 
//              String sql_cardItem="select ItemID from tEntityItem where ItemID in(select ItemID from tKBNCarddata \n" +
//                                  "where KBNBoardID=(select KBNBoardID from tKBNBoard \n" +
//                                  "where ProjectID=(select ProjectID from tProject \n" +
//                                  "where Title='Kanban Automation') and IsArchived='N')) and Title='"+title+"'";
//              String itemID[][]=KovairGenericClass.getSQLresult(sql_cardItem);
//              String sql_columnID="select ColumnID from tKBNCardData where ItemID="+itemID[0][0]+"'";
//              String columnId[][]=KovairGenericClass.getSQLresult(sql_columnID);
//              String cardid="Carditem_"+columnId[0][0]+"_"+itemID[0][0];
//              
//              ab=ke.new ActiveBoard(driver);
//              String _title;WebElement source=null;
////             getting webelement for source from where card is taken
//              for (WebElement col : ab.cardNumber) {
//                 
//                 if(_title.contains(title))
//                 {
//                  source = col;
//                  System.out.println(source);
//                 }
//                } 
//        } 
//        catch (Exception e) {
//            System.out.println(e.getMessage());
//        }
//   }
    
    public static void nn() throws Exception
    {
      try{
    
    }
      catch(Exception e)
              {
              
              }
    }
    public void dragAndDrop(String cardTitle,String toColumn,WebDriver driver)
    {
       try
       {
           List<WebElement> activeCards=ab.card;
            WebElement selectedCard=null;
            for(int i=0;i<activeCards.size();i++)
            {
                if(activeCards.get(i).getText().equals(cardTitle))
                {
                    selectedCard=activeCards.get(0);
                    break;
                }
            }
            if(selectedCard!=null)
            {
               bm= new KovairKanbanBoardModule(driver);
               String activeBoard=bm.verifyApperenceOFBoard("Page Title", driver).getText();
               String columnID=gettingBoardColumnID(activeBoard,toColumn, driver);
               System.out.println(columnID);
               WebElement toColumnElement=driver.findElements(By.xpath("//div[@class='containerbody'][@columnid="+columnID+"]//div[contains(@class,'swimLaneheader')]")).get(0);
               Actions action=new Actions(driver);
               action.dragAndDrop(selectedCard, toColumnElement);
            }
            else
            {
                System.out.println("Card with title '"+cardTitle+"' is not found.");
            }
       }
       catch(Exception e)
       {
           System.out.println(e.getMessage());
       }
       
    }
    
}
