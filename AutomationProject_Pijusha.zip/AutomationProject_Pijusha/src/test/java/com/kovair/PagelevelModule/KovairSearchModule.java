/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.kovair.PagelevelModule;

import com.kovair.pages.KovairHomePageElement;
import com.kovair.pages.KovairSearchItemElement;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

/**
 *
 * @author sreyag
 */
public class KovairSearchModule {
    KovairSearchItemElement se; 
    
     public KovairSearchModule(WebDriver driver)
      {
       se=new KovairSearchItemElement(driver);
      }  
     
     public void search_string(String serach_item, WebDriver driver) {
        try {
            String alt = se.KovairSearchAlt.getAttribute("alt");
            String _id = "Search by 'ID'";
            if (alt.contains(_id)) {
                se.KovairAdvanceSearchLogo.click();
                se.KovairSearchID.click();
                se.KovairSearchIDCross.click();
            }
            se.KovairSearchText.click();
            se.KovairSearchText.clear();
            se.KovairSearchText.sendKeys(serach_item);
            se.KovairButtonSearch.click();

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }  
     
     public void search_id(String serach_item, WebDriver driver) {
        try {
            String alt = se.KovairSearchAlt.getAttribute("alt");
            String _id = "Search by 'Text'";
            if (alt.contains(_id)) {
                se.KovairAdvanceSearchLogo.click();
                se.KovairSearchID.click();
                se.KovairSearchIDCross.click();
            }
            se.KovairSearchText.click();
            se.KovairSearchText.clear();
            se.KovairSearchText.sendKeys(serach_item);
            se.KovairButtonSearch.click();

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
}
