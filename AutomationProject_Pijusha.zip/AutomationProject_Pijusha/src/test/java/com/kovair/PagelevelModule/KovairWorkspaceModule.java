/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.kovair.PagelevelModule;

import TaskList.KovairGenericClass;
//import static TaskList.TestKanbanCards.driver;
//import static TaskList.TestKanbanTemlateSettings.driver;
import com.kovair.utilities.BeforeAfterClassMethods;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

/**
 *
 * @author sreyag
 */
public class KovairWorkspaceModule {
    public KovairHomePageModule kovairhomepage;
    public String createEntityIfRequired(String entity_Name, int workspaceID,String view,WebDriver driver) throws Exception {
      String _entity_info="false";
        try {
              int i;
                kovairhomepage.selectKovairWorkspaces(BeforeAfterClassMethods.Workspace, driver);
                System.out.println("Workspace selected");
//                String en = "select * from tEntityProjects where ProjectID=" + workspaceID + " and EntityTypeID in (select EntityTypeID from tEntity where SingularName='" + entity_Name + "')";
//                String getEntity[][] = KovairGenericClass.getSQLresult(en);
//                if (getEntity.length == 0) {
//                    System.out.println("Entity need to create....");
                    Thread.sleep(5000);
                    KovairGenericClass.Workspace_Setup_click(driver);
                    Thread.sleep(5000);
                    kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Kanban Settings", "Template", driver);
                    KovairGenericClass._swithchtonewframe(driver);
                    Thread.sleep(5000);
                    driver.findElement(By.xpath("//input[@id='KovairMaster_Main_Button2']")).click();
                    Thread.sleep(5000);
                    driver.findElement(By.xpath("//span[text()='Entities']")).click();
                    Thread.sleep(5000);
              driver.findElement(By.id("KovairMaster_Main_ltlNewEntity1")).click();
              Thread.sleep(5000);
              int entity=driver.findElements(By.xpath("//div[@id='KovairMaster_Main_WspEntityInfo_DIVContainer']/div")).size();
              entity=entity+1;         
              String initial;
                            driver.findElement(By.id("KovairMaster_Main_WspEntityInfo_SingularName")).click();
                            driver.findElement(By.id("KovairMaster_Main_WspEntityInfo_SingularName")).clear();
                            Thread.sleep(2000);
                            driver.findElement(By.id("KovairMaster_Main_WspEntityInfo_SingularName")).sendKeys(entity_Name);
                            Thread.sleep(2000);
                            driver.findElement(By.xpath("//input[@id='KovairMaster_Main_WspEntityInfo_SeedVal']")).click();
                            driver.findElement(By.xpath("//input[@id='KovairMaster_Main_WspEntityInfo_SeedVal']")).sendKeys(Integer.toString(entity));
                            Thread.sleep(5000);
                            driver.findElement(By.id("KovairMaster_Main_WspEntityInfo_btnAddEntity")).click();
                            Thread.sleep(5000);
                            int n = driver.findElements(By.xpath("//span[@id='VALIDATOR_KovairMaster_Main_WspEntityInfo_Initial']")).size();
                            if (n > 0) {
                                initial = entity_Name.substring(0, 1) + entity;
                                driver.findElement(By.xpath("//input[@id='KovairMaster_Main_WspEntityInfo_Initial']")).click();
                                driver.findElement(By.xpath("//input[@id='KovairMaster_Main_WspEntityInfo_Initial']")).clear();
                                driver.findElement(By.xpath("//input[@id='KovairMaster_Main_WspEntityInfo_Initial']")).sendKeys(initial);
                                driver.findElement(By.id("KovairMaster_Main_WspEntityInfo_btnAddEntity")).click();
                            }
                          Thread.sleep(8000);
                          if(!view.equals("None")){
                           if(view.equals("Review Initiate"))
                           {
                            driver.findElement(By.xpath("//input[@id='KovairMaster_Main_WspEntityInfo_chkReviewInitiate']")).click();
                           }
                           else if(view.equals("TabView"))
                           {
                            driver.findElement(By.xpath("//input[@id='KovairMaster_Main_WspEntityInfo_chkTabView']")).click();
                           }
                           else if(view.equals("Expose For Selection"))
                           {
                            driver.findElement(By.xpath("//input[@id='KovairMaster_Main_WspEntityInfo_chkShow']")).click();
                           } 
                           Thread.sleep(5000);
                          }
                          
                         driver.findElement(By.id("KovairMaster_Main_btnSaveAndFinish0")).click();
                         Thread.sleep(5000);
                          _entity_info="true";
//            }           
//            else {
//                    System.out.println("Entity is present in the Workspace");
//                    _entity_info = "Done";
//                }
          }
       catch (Exception e) {
            System.out.println(e.getMessage());
         }  
       return _entity_info;
    }
}
