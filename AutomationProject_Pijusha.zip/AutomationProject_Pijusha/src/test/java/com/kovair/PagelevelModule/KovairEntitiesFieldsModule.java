/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.kovair.PagelevelModule;

import TaskList.KovairGenericClass;
import static com.kovair.SearchCapability.SearchCapability_TC.driver;
import com.kovair.pages.KovairEntitiesFieldsElement;
import com.kovair.pages.KovairHomePageElement;

import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

/**
 *
 * @author trainee
 */
public class KovairEntitiesFieldsModule {

    KovairEntitiesFieldsElement kef;
    KovairHomePageElement ob;
    WebElement we;
    WebDriver wd;
    List<WebElement> fieldList = null;
    static String frameid = null;
    static KovairHomePageModule kovairhomepage;

    public KovairEntitiesFieldsModule(WebDriver driver) {
        kef = new KovairEntitiesFieldsElement(driver);
        ob = new KovairHomePageElement(driver);
    }

    public void clickCreateNewLink(WebDriver Driver) throws Exception {
        we = kef.createNewFieldLink;
        we.click();
    }

    public void chooseFieldType(WebDriver Driver) throws Exception {
        we = kef.chooseFieldType;
        we.click();
    }

    public void chooseFieldTypeStandard(WebDriver Driver) throws Exception {
        we = kef.chooseFieldTypeStandard;
        we.click();
    }

    public void chooseFieldTypeCalculated(WebDriver Driver) throws Exception {
        we = kef.chooseFieldTypeCalculated;
        we.click();
    }

    public void enterFieldLabel(WebDriver Driver, String str) throws Exception {
        we = kef.enterFieldLabel;
        we.sendKeys(str);
    }

    public void clickNextButton(WebDriver Driver) throws Exception {
        we = kef.clickNextButton;
        we.click();
    }

    public void clickNextButtonShared(WebDriver Driver) throws Exception {
        we = kef.clickNextButtonShared;
        we.click();
    }

    public boolean searchTextBox(WebDriver Driver) throws Exception {

        we = kef.searchTextBox;
        return we.isDisplayed();
    }

    public boolean searchTextBoxBorder(WebDriver Driver) throws Exception {

        we = kef.searchTextBox;
        if (we.getAttribute("class").equals("form-control")) {
            return true;
        } else {
            return false;
        }
    }

    public String searchTextBoxPlaceholder(WebDriver Driver) throws Exception {
        String s;
        we = kef.searchTextBox;

        s = we.getAttribute("placeholder");
        // str=we.getCssValue("placeholder");
        return s;

    }

    public String searchTextBoxBorderColor(WebDriver Driver) throws Exception {
        String str;
        int b;
        we = kef.searchTextBox;
        str = we.getCssValue("border-color");

        return str;

    }

    public void searchTextBoxClick(WebDriver Driver) throws Exception {

        we = kef.searchTextBox;
        we.click();

    }

    public void searchTextBoxEnterValue(WebDriver Driver, String str) throws Exception {
        we = kef.searchTextBox;
        we.sendKeys(str);
    }

    public String fieldListBox(WebDriver Driver) throws Exception {
        String str = null;
        we = kef.fieldListBox;
        str = we.getText();

        return str;
    }

    public String expressionTextBox(WebDriver Driver) throws Exception {
        String str;

        we = kef.expressionTextBox;
        str = we.getText();
        return str;
    }

    public void expressionTextBoxFirst(WebDriver Driver) throws Exception {
        we = kef.fieldListBoxElement1;
        we.click();
    }

    public void selectReturnType(WebDriver Driver) throws Exception {
        we = kef.returnsDrpDwn;
        we.click();
        we = kef.returnsDrpDwnSelect;
        we.click();
    }

    public boolean fieldAlreadyExists(WebDriver Driver, String str) throws Exception {

        we = kef.filterFieldName;
        we.click();
        we.sendKeys(str);
        Thread.sleep(3000);
        we = kef.filterImage;
        we.click();
        Thread.sleep(3000);
        we = kef.filterImageSelect;
        we.click();
        Thread.sleep(4000);
        List<WebElement> ElemList = null;
        ElemList = kef.existingFieldList;
        if (ElemList.size() == 0) {
            return true;
        } else {
            return false;
        }
    }

    public void saveAndFinish(WebDriver Driver) throws Exception {
        we = kef.saveAndFinishBtn;
        we.click();
    }

    public List<WebElement> fieldListStarting(WebDriver Driver) throws Exception {
        //kef = new KovairEntitiesFieldsElement(Driver);
        List<WebElement> ElemList = null;
        ElemList = kef.fieldListStarting;
        return ElemList;

    }

    public void searchTextBoxShiftLeft(WebDriver Driver, String str, int len) throws Exception {
        we = kef.searchTextBox;
        we.click();
        while (len != 0) {
            we.sendKeys(Keys.ARROW_LEFT);
            len--;
        }
        we.sendKeys(str);

    }

    public void searchTextBoxDelete(WebDriver Driver, int len) throws Exception {
        we = kef.searchTextBox;
        we.click();
        while (len != 1) {
            we.sendKeys(Keys.ARROW_LEFT);
            len--;
        }
        we.sendKeys(Keys.BACK_SPACE);

    }

    public void searchTextBoxDeleteEnd(WebDriver Driver) throws Exception {
        we = kef.searchTextBox;
        we.click();

        we.sendKeys(Keys.BACK_SPACE);

    }

    public void searchTextBoxClear(WebDriver Driver) throws Exception {

        we = kef.searchTextBox;
        we.clear();

    }

    public void cancelButtonClick(WebDriver Driver) throws Exception {
        we = kef.cancelButton;
        we.click();

    }

    public void editPage(WebDriver Driver, String str) throws Exception {
        we = kef.filterFieldName;
        we.click();
        we.sendKeys(str);
        Thread.sleep(3000);
        we = kef.filterImage;
        we.click();
        Thread.sleep(3000);
        we = kef.filterImageSelect;
        we.click();
        Thread.sleep(4000);
        we = kef.existingField;
        we.click();
        Thread.sleep(4000);
        we = kef.editFieldDtl;
        we.click();
        Thread.sleep(4000);
        we = kef.existingFieldDetailsTab;
        we.click();

    }

    public void editCancelButtonClick(WebDriver Driver) throws Exception {
        we = kef.editCancelButton;
        we.click();

    }

    public boolean fieldSelected(WebDriver Driver) throws Exception {

        we = kef.fieldSelected;
        if (we.isDisplayed()) {
            return true;
        } else {
            return false;
        }
    }

    public String findFilterSearchPlaceHolderColor(WebDriver Driver) throws Exception {
        String strPlaceHolderColor = null;
        try {

            WebElement elemFilterSearchPlaceHolder = null;
            elemFilterSearchPlaceHolder = kef.searchTextBox;
            // WebElement filterSearchBoxPlaceHolder = 
            String script = "return window.getComputedStyle(document.querySelector('.form-control'),'::placeholder').getPropertyValue('color')";
            JavascriptExecutor js = (JavascriptExecutor) Driver;
            strPlaceHolderColor = (String) js.executeScript(script);

            //strPlaceHolderColor = elemSearchPlaceHolder.getAttribute("placeholder");
            return strPlaceHolderColor;
        } catch (Exception ex) {
            System.out.println(ex.toString());
            return strPlaceHolderColor;
        }
    }

}
