/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.kovair.PagelevelModule;

import com.kovair.pages.KovairKanbanCardElement;
import com.kovair.pages.KovairKanbanTemplates;
import com.kovair.utilities.SeleniumModules;
import com.kovair.utilities.sqlQueries;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import com.kovair.pages.KovairKanbanBoardListPageElement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import org.apache.poi.ss.formula.functions.Today;
import org.openqa.selenium.interactions.Actions;

/**
 *
 * @author sreyag
 */
public class KovairKanbanBoardModule {
  KovairKanbanCardElement ke;
  KovairKanbanCardElement.BoardAddcard bac;
  KovairKanbanCardElement.boardNotification bn;
  KovairKanbanTemplates kt;
  KovairKanbanTemplates.KovairKanbanTemplatesCardPages cp;
  KovairKanbanTemplates.swimlane sl;
  KovairKanbanTemplates.KovairKanbanTemplatesGIPages gp;
  KovairKanbanTemplates.KovairKanbanTemplatesDCPages dp;
  KovairKanbanTemplates.KovairKanbanTemplatesPopups po;
  KovairKanbanCardElement.addNotifyToPopup notifyToPopup;
  KovairKanbanCardElement.Validation_check val;
  KovairKanbanCardElement.BoardCreateGI bgi;
  KovairKanbanTemplates.KovairKanbanTemplatesCMPages cm;
  KovairKanbanTemplates.KovairKanbanActionMenuPages ac;
  KovairKanbanCardElement.ActiveBoardCreation activeBoard;
  KovairKanbanBoardListPageElement boardList;
  KovairKanbanBoardListPageElement bl;
  public static String boardTemplate="KanbanTemplate";
  static KovairKanbanTemlateModule template;
  public static String boardname;
   public KovairKanbanBoardModule(WebDriver driver) {
        ke = new KovairKanbanCardElement(driver);
    }
    
    public String[] verifyNotificationHDAppearence(String n,WebDriver driver)
    {
     String[] l=new String[3];
     try{
         if(n.equals("Notification columns"))
         {
          bn=ke.new boardNotification(driver); 
          for(int i=0;i<bn.HDText.size();i++)
          {
           l[i]=bn.HDText.get(i).getText();
          }
         }
     return l;
    }
     catch (Exception e) {
            System.out.println(e.getMessage());
             return l;
        } 
    }
    //It returns the elements of notify to popup as a single webelement
    public WebElement verifyNotifyToPopup(String title,WebDriver driver)
    {
        notifyToPopup=ke. new addNotifyToPopup(driver);
        val=ke. new Validation_check(driver);
        WebElement source=null;
        try{
            if(title.equals("Notify To Popup"))
            {
                source=notifyToPopup.addUserPopup;
            }
            else if(title.equals("Popup title"))
            {
                source=notifyToPopup.addUserPopupTitle;
            }
            else if(title.equals("Available User Section"))
            {
                 source=notifyToPopup.availableUserSection;
            }
            else if(title.equals("Selected User Section"))
            {
                 source=notifyToPopup.selectedUserSection;
            }
            else if(title.equals("Add"))
            {
                source=notifyToPopup.addUser;
            }
            else if(title.equals("Remove"))
            {
                source=notifyToPopup.removeUser;
            }
            else if(title.equals("Validation Message"))
            {
                source=val.validationMessage;
            }
            else if(title.equals("Validation OK"))
            {
                source=val.validationOK;
            }
            else if(title.equals("Save"))
            {
                source=notifyToPopup.saveUsers;
            }
            else if(title.equals("Close"))
            {
                source=notifyToPopup.closePopup;
            }
            else if(title.equals("Cancel"))
            {
                source=notifyToPopup.cancelUsers;
            }
            else if(title.equals("Available User Search Txt"))
            {
                source=notifyToPopup.availableUserSearch;
            }
            else if(title.equals("Available User Search Icon"))
            {
                source=notifyToPopup.availableUserSearchIcon;
            }
            else if(title.equals("Selected User Search Txt"))
            {
                source=notifyToPopup.selectedUserSearch;
            }
            else if(title.equals("Selected User Search Icon"))
            {
                source=notifyToPopup.selectedUserSearchIcon;
            }
        }
        catch(Exception e)
        {
            System.out.println(e.getMessage());
            return source;
        }
        return  source;
    }
    //It returns list webelement of notify to popup
    public List<WebElement> verifyNotifyToPopupUserList(String title,WebDriver driver)
    {
        List<WebElement> source=null;
                if(title.equals("Available Users"))
               {
                   source=notifyToPopup.availableUsers;
               }
               else if(title.equals("Selected Users"))
               {
                   source=notifyToPopup.selectedUsers;
               }
                else if(title.equals("Top Sort"))
                {
                    source=notifyToPopup.sortTop;
                }
                else if(title.equals("Bottom Sort"))
                {
                    source=notifyToPopup.sortBottom;
                }
         return source;
    }
    //It returns the elements of notification table in column mapping tab of create board page
    public List<WebElement> verifyAppearanceOfNotification(String title,WebDriver driver)
    {
        List<WebElement> source=null;
        try{
               if(title.equals("Is notify"))
               {
                   source=bn.isNotifyCheckbox;
               }
               else if(title.equals("Notify to"))
               {
                   source=bn.addNotifyTo;
               }
               else if(title.equals("Available columns"))
               {
                   source=bn.columnNames;
               }
               
        }
      catch(Exception e)
      {
          System.out.println(e.getMessage());
          return source;
      }
        return source;
    }
    //This return 0 or 1 if  a particular user is present in Available User or Selected User section  and click/double click on it
    public int selectUserInNotifyToPopup(String userName,String option,String doubleClick  ,WebDriver driver)
    {
        Actions action=new Actions(driver);
        int find=0;
        List<WebElement> userOption=null;
        WebElement selectUser=null;
        try{
                if(option.equals("Available Users"))
                    userOption=notifyToPopup.availableUsers;
                else if(option.equals("Selected Users"))
                    userOption=notifyToPopup.selectedUsers;
                for(int i=0;i<userOption.size();i++)
                {
                    ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);",userOption.get(i));
                    if(userOption.get(i).getText().contains(userName))
                    {
                        find=1;
                        selectUser=userOption.get(i);
                        selectUser.click();
                        Thread.sleep(1000);
                        break;
                    }
               }
                if(doubleClick.equals("Y"))
                    action.doubleClick(selectUser).perform();
                
        }
        catch(Exception e)
        {
            System.out.println(e.getMessage());
        }
        return find;
    } 
    
    public WebElement verifyApperenceOFBoard(String n, WebDriver driver) throws Exception {
        WebElement l = null;
        try {
            kt=new KovairKanbanTemplates(driver);
            gp=kt.new KovairKanbanTemplatesGIPages(driver);
            activeBoard=ke. new ActiveBoardCreation(driver);
            bac = ke.new BoardAddcard(driver);
            if (n.equals("Action Button")) {
                SeleniumModules.buttonClick(ke.logoHDAction, driver);
                bac = ke.new BoardAddcard(driver);
            }
            else if(n.equals("Archive Board"))
            {
                l=bac.titleArchivedBoard;
            }
            else if (n.equals("Create New Board")) {
               // if (bac.titleAddBoard.getText().contains("Add CardCreate New Board")) {
                if (bac.titleAddBoard.getText().contains("Create New Board")) {
                    l = bac.titleAddBoard ;
                }
            }
            else if(n.equals("Board List"))
            {
                l=bac.boardList;
            }
            else if(n.equals("Page Title")){
                l=kt.title;
            }
            else if (n.equals("BoardName")) { 
                
                
                l=gp.nameInTemplates;
           }
            else if(n.equals("Board Description"))
            {
                l=gp.descriptionInTemplates;
            }
            else if(n.equals("Selected Template"))
            {
                l=gp.selectedTemplate;
            }
            else if (n.equals("Next Button")) { 
                l=gp.nextButton;
           } 
            else if (n.contains("General Information")||n.contains("Define Columns")||n.contains("Cards")||n.contains("Column Mapping")) {
                for (WebElement liName : gp.nameOfAreaInTemplates) {
                    if (liName.getText().contains(n)) {
                        l = liName;
                        break;
                    }
                } 
            }
            else if(n.equals("Name field validation"))
            {
                l=kt.mandatoryMessage;
            }
            else if(n.equals("Name Label"))
            {
                bgi= ke.new BoardCreateGI(driver);
                l=bgi.nameLabel;
            }
            else if(n.equals("Template Label"))
            {
                
                l=bgi.templateLabel;
            }
            else if(n.equals("Description Label"))
            {
                l=bgi.descriptionLabel;
            }
            else if(n.equals("Template Value"))
            {
                l=bgi.typeOftemplate;
            }
            else if(n.equals("Previous"))
            {
                ac=kt. new KovairKanbanActionMenuPages(driver);
                l=ac.NavigatePrvInTemplates;
            }
            else if(n.equals("Board Column"))
            {
                l=activeBoard.boardColumn;
            }
            else {
                if (gp.cancelButton.isDisplayed()) {
                    l = gp.cancelButton;
                }
            }
            
            return l;
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return l;
        }
    }
    //This returns the list elements of Board List page
    public WebElement verifyApperenceOFBoardList(String title,WebDriver driver)
    {
        WebElement elem=null;
        boardList=new KovairKanbanBoardListPageElement(driver);
        try{
            if(title.equals("Create New Board"))
            {
                elem=boardList.createNewBoard;
            }
            else if(title.equals("Filter Text Box"))
            {
                elem=boardList.filterTextBox;
            }
            else if(title.equals("Filter Icon"))
            {
                elem=boardList.filterButton;
            }
            else if(title.equals("EqualTo Condition"))
            {
                elem=boardList.equalToCondition;
            }
            else if(title.equals("Board title"))
            {
                elem=boardList.boardName.get(0);
            }
            else if(title.equals("Page Title"))
            {
                elem=boardList.boardListPageTitle;
            }
            else if(title.equals("Column name"))
            {
                elem=boardList.nameColumn;
            }
            else if(title.equals("Column description"))
            {
               elem=boardList.descriptionColumn;
            }
            else if(title.equals("Column created by name date"))
            {
                elem=boardList.createdByNameDateColumn;
            }
            else if(title.equals("First page"))
            {
                elem=boardList.firstPage;
            }
            else if(title.equals("Previous Page"))
            {
                elem=boardList.previousPage;
            }
            else if(title.equals("Next Page"))
            {
                elem=boardList.nextPage;
            }
            else if(title.equals("Last Page"))
            {
                elem=boardList.lastPage;
            }
            else if(title.equals("Current Page Number"))
            {
                elem=boardList.currentPageNumber;
            }
            else if(title.equals("Total page count"))
            {
                elem=boardList.totalPageCount;
            }
            else if(title.equals("Total record count"))
            {
                elem=boardList.totalRecordCount;
            }
            else if(title.equals("View Records per page"))
            {
                elem=boardList.viewRecordPerPage;
            }
            else if(title.equals("Select Records per page"))
            {
                elem=boardList.selectRecordsPerPage;
            }
            else if(title.equals("No record found"))
            {
                elem=boardList.noRecordFound;
            }
            else if(title.equals("Header Action"))
            {
                elem=boardList.headerAction;
            }
            else if(title.equals("Contains"))
            {
                elem=boardList.containsCondition;
            }
            else if(title.equals("DoesNotContain"))
            {
                elem=boardList.doesNotContain;
            }
            else if(title.equals("StartsWith"))
            {
                elem=boardList.startsWith;
            }
            else if(title.equals("EndsWith"))
            {
                elem=boardList.endsWith;
            }
            else if(title.equals("NoFilter"))
            {
                elem=boardList.noFilter;
            }
            return elem;
        }
        catch (Exception e) {
            System.out.println(e.getMessage());
            return elem;
        }
    }
    public List<WebElement> verifyAppearanceOfBoardListColumns(String n,WebDriver driver)
    {
        List<WebElement> elem=null;
        try
        {
            if(n.equals("Board Names"))
            {
                elem=bl.boardNameElements;
            }
            else if(n.equals("Board Description"))
            {
                elem=bl.boardDescriptionElements;
            }
            else if(n.equals("Board Created By"))
            {
                elem=bl.boardCreatedByElements;
            }
            else if(n.equals("Board Creation Date"))
            {
                elem=bl.boardCreationDateElements;
            }
            return  elem;
        }
        catch(Exception e)
        {
            System.out.println(e.getMessage());
            return  elem;
        }
    }
    
    //This returns the List elements of swimlane tab at the time of creation board
    public List<WebElement> verifySwimLaneList(String title,WebDriver driver)
    {
        sl=kt. new swimlane(driver);
        List<WebElement> source=null;
        try{
            if(title.equals("Swimlane"))
            {
                source=sl.swimlaneAvailableValues;
            }
            else if(title.equals("Selected swimlane values"))
            {   
               source=sl.selectedSwimlaneValues;
            }
            else if(title.equals(""))
            {
              System.out.println("No Swimlane has selected ");
              source.add(sl.noswimLane);
            }
            return source;
        }
        catch(Exception e)
        {
            System.out.println(e.getMessage());
            return source;
        }
    }
    //This returns list webelements of column mapping table at the time of board creation
    public String verifyColumnMappingList(String columnName,String title,WebDriver driver)
    {
        cm=kt. new KovairKanbanTemplatesCMPages(driver);
        List<WebElement> columnrows=null;
        WebElement col=null,source=null;
        int temp=1;
        String element=null;
        try{
            columnrows=driver.findElements(By.xpath(cm.columnNames));
            for(Iterator<WebElement> cols=columnrows.iterator(); cols.hasNext();)
            {
                col=cols.next();
                if(col.getText().equals(columnName))
                {
                    break;
                }
                else
                {
                    temp++;
                }
            }
            if(title.equals("Unmap Column"))
            {
//                source=col.findElement(By.xpath("//../td[2]/div[1]/span"));
                element="("+cm.columnNames+")"+"["+temp+"]//../td[2]/div[1]/span";
            }
            else if(title.equals("Map Column"))
            {
               // source=col.findElement(By.xpath("//..//dropdown-multiselect"));
                element="("+cm.columnNames+")"+"["+temp+"]//..//dropdown-multiselect/div";////////
            }
            else if(title.equals("Mapped Values"))
            {
//                source=col.findElement(By.xpath("//../td[2]/div[1]"));
                element="("+cm.columnNames+")"+"["+temp+"]//../td[2]/div[1]";
            }
            else if(title.equals("Unmap validation"))
            {
//                source=cm.unmapValidation;
                element=cm.unmapValidation;
            }
            else if(title.equals("Mapping values"))
            {
//                source=col.findElement(By.xpath("//..//div[@class='menudiv']"));
                element="("+cm.columnNames+")"+"["+temp+"]/..//input[contains(@class,'checkboxInput')]";
            }
            return element;
        }
        catch(Exception e)
        {
            System.out.println(e.getMessage());
            return element;
        }
    }
    public boolean verifyForBoardListPage(WebDriver driver)
    {
        boolean flag=false;
        try{
            WebElement boardList;
            String lastUsedBoardID[][]=sqlQueries.getSQLresult(sqlQueries.boardUsageOfProject);
            if(!(lastUsedBoardID.length==0))
            {
                String archiveBoardList[][]=sqlQueries.getSQLresult(sqlQueries.archivedBoardOfProject);
                for(int i=0;i<archiveBoardList.length;i++)
                {
                    if(lastUsedBoardID[0][0].equals(archiveBoardList[i][0]))
                    {
                        flag=true;
                        System.out.println("Last used board is in archived board list. So the user is in  board list page");
                        break;
                    }
                    else
                    {
                        System.out.println("Last used board is not found in archived board list.");
                    }
                }
            }
            else
            {
                System.out.println("Last used board ID is null. So it may happen that user is in Board List page");
            }
        }
        catch(Exception e)
        {
            System.out.println(e.getMessage());
        }
        return flag;
    }
    public List<WebElement> kanbanListOfBoards(WebDriver driver) throws Exception
    {
        bl=new KovairKanbanBoardListPageElement(driver);
        List<WebElement> boardNames=null;
        try{
            boardNames=new ArrayList<>();
            for(WebElement boards:bl.kanbanBoardListName)
            {
                System.out.println(boards.getText());
                boardNames.add(boards);
            }
            return  boardNames;
        }
        catch(Exception e)
        {
            System.out.println(e.getMessage());
            return boardNames;
        }
    }
    public void boardCreate(WebDriver driver,String boardName) throws Exception
    {
        WebElement nextButton,nameTxt,saveBoard,createNewBoardOption,boardDesc;
        try
        { 
//          add template selection code.Temlates string should match with list of template otherwise show message and take default teamplate.If no tempalte in list then do not proceed execution.
          createNewBoardOption=verifyApperenceOFBoardList("Create New Board", driver);
          createNewBoardOption.click();
          nameTxt=verifyApperenceOFBoard("BoardName", driver);
          nameTxt.sendKeys(boardName);
          boardDesc=verifyApperenceOFBoard("Board Description", driver);
          boardDesc.sendKeys(boardName);
          Thread.sleep(1000);
          nextButton=verifyApperenceOFBoard("Next Button", driver);
          nextButton.click();  
          Thread.sleep(1000);
          nextButton.click();
          Thread.sleep(1000);
          nextButton.click();
          Thread.sleep(1000);
          nextButton.click();
          Thread.sleep(1000);
          nextButton.click();
          Thread.sleep(1000);
          template=new KovairKanbanTemlateModule(driver);
          saveBoard=template.getGITab("Save Board", driver);
          saveBoard.click();
          Thread.sleep(5000);
        }
        catch(Exception e)
        {
            System.out.println(e.getMessage());
        }
     }
    
    public void clickOnOptionsFromRightclick(String menu_name,String rightClick_on,WebDriver driver) throws Exception
    {
      try{
           if(rightClick_on.equals("Board"))
           {
             
           }
           else if(rightClick_on.equals("Card"))
            {
                   
            }
           else{
                System.out.println("Right click would not work for this option");
            }
      }
      catch(Exception e)
      {
        System.out.println(e);
      }
    }
}
