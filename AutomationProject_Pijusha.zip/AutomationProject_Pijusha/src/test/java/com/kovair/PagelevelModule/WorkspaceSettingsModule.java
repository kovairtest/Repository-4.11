/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.kovair.PagelevelModule;

import com.kovair.pages.KovairWorkspaceSettings;
import java.util.List;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

/**
 *
 * @author Abhishekp
 */
public class WorkspaceSettingsModule {
    
    KovairWorkspaceSettings kws;
    KovairWorkspaceSettings.kanbanSettingsEdit ks;
    KovairWorkspaceSettings.kanbanSettingsView ksv;
    public WorkspaceSettingsModule(WebDriver driver)
    {
        kws=new KovairWorkspaceSettings(driver);
    }
    //It returns available entities,selected entities and Saved entities list
    public List<WebElement> kanbanSettingsEntities(String title,WebDriver driver)
    {
        
        List<WebElement> entityList=null;
        try{
            if(title.equals("Available Entities"))
            {
                entityList=ks.availableEntities;
            }
            else if(title.equals("Selected Entities"))
            {
                entityList=ks.selectedEntities;
            }
            return entityList;
        }
        catch(Exception e)
        {
            System.out.println(e.getMessage());
            return entityList;
        }
    }
    //This returns all elements of Kanban Settings tab except entity lists
    public WebElement kanbanSettings(String title,WebDriver driver)
    {
        ks=kws. new kanbanSettingsEdit(driver);
        WebElement source=null;
        try
        {
            if(title.equals("Add"))
            {
                source=ks.add;
            }
            else if(title.equals("Remove"))
            {
                source=ks.remove;
            }
            else if(title.equals("Add all"))
            {
                source=ks.addAll;
            }
            else if(title.equals("Remove all"))
            {
                source=ks.removeAll;
            }
            else if(title.equals("Edit"))
            {
                source=kws.editButton;
            }
            else if(title.equals("Save"))
            {
                source=kws.saveButton;
            }
            else if(title.equals("Saved Entities"))
            {   
                ksv=kws. new kanbanSettingsView(driver);
                source=ksv.savedKanbanEntitiesContainer;
            }
            return source;
        }
        catch(Exception e)
        {
            System.out.println(e.getMessage());
            return source;
        }
        
    }
    //This returns all tabs and subtabs of Workspace-->Settings page
    public WebElement tabsAndSubtabs(String title,WebDriver driver)
    {
        WebElement source=null;
        try{
            if(title.equals("General Information"))
            {
                source=kws.generalInformationTab;
            }
            else if(title.equals("Fields and Entities"))
            {
                source=kws.fieldsAndEntitiesTab;
            }
            else if(title.equals("Entity Display During Word Import"))
            {
                source=kws.entityDisplayDuringWordImportTab;
            }
            else if(title.equals("Task Parent Fields"))
            {
                source=kws.taskParentFieldsTab;
            }
            else if(title.equals("Agile Settings"))
            {
                source=kws.agileSettingsTab;
            }
            else if(title.equals("Kanban Settings"))
            {
                source=kws.kanbanSettingsTab;
            }
            return source;
        }
        catch(Exception e)
        {
            System.out.println(e.getMessage());
            return source;
        }
    }
}
