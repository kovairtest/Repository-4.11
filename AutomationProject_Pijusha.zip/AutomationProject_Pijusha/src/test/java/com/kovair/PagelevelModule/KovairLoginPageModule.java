/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.kovair.PagelevelModule;


import com.kovair.pages.KovairLoginPageElement;
import com.kovair.pages.KovairHomePageElement;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import com.kovair.utilities.SeleniumModules;
import com.kovair.utilities.sqlConnection;
import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.openqa.selenium.Capabilities;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
/**
 *
 * @author sreyag
 */
public class KovairLoginPageModule {
    KovairLoginPageElement oblogin;
    KovairHomePageElement hpm;
    static WebDriver driver = null;
    static String ChromedriverPath = System.getProperty("user.dir") + "//src/test/java/com/kovair/Chromedriver/chromedriver.exe";
    public static String BrowserProperty = null;
    public static String Solution = null;
    static String URL = null;
    static String UserId = null;
    static String Password = null;
    static String Workspace = null;
    public KovairLoginPageModule(WebDriver driver)
    {
        //this.driver = driver;
        //PageFactory.initElements(driver, this);
        oblogin=new KovairLoginPageElement(driver);
    }
    
    public static Object[] LoginInfo(File Filepath) throws Exception {
        Object[] logdata = new Object[5];
        DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
        org.w3c.dom.Document doc = dBuilder.parse(Filepath);
        doc.getDocumentElement().normalize();
        //System.out.println("Root element :" + doc.getDocumentElement().getNodeName());

        if (sqlConnection.RunId == 0) {
            sqlConnection.sqlGetRunId();
        }
        int runId = sqlConnection.RunId;
        if (sqlConnection.Solution == null) {
            String query = "select Solution from RunIdDetails where RunID=" + runId;
            String[][] res = getSQLresult(query);
            if (res != null) {
                Solution = res[0][0];
            } else {
                Solution = sqlConnection.DefaultSolution;
            }
        } else {
            Solution = sqlConnection.Solution;
        }
        NodeList _DataList = doc.getElementsByTagName("Build");
        for (int _temp = 0; _temp < _DataList.getLength(); _temp++) {
            Node _nNode = _DataList.item(_temp);
            if (_nNode.getNodeType() == Node.ELEMENT_NODE) {
                org.w3c.dom.Element _eElement = (org.w3c.dom.Element) _nNode;
                String Sol = _eElement.getAttribute("Solution").toString().trim();
                if (Sol.trim().contains(Solution)) {
                    NodeList DataList = _eElement.getElementsByTagName("URLSite");
                    for (int temp = 0; temp < DataList.getLength(); temp++) {
                        Node nNode = DataList.item(temp);
                        if (nNode.getNodeType() == Node.ELEMENT_NODE) {
                            org.w3c.dom.Element eElement = (org.w3c.dom.Element) nNode;
                            logdata[0] = eElement.getElementsByTagName("URL").item(0).getTextContent();
                            UserId=eElement.getElementsByTagName("UserId").item(0).getTextContent();
                            logdata[1] = UserId;
                            logdata[2] = eElement.getElementsByTagName("Password").item(0).getTextContent();
                            Workspace=eElement.getElementsByTagName("Workspace").item(0).getTextContent();;
                            logdata[3] = Workspace;
                            logdata[4] = eElement.getElementsByTagName("Browser").item(0).getTextContent();
                            return logdata;
                        }
                    }
                }
            }
        }
        return logdata;
    }
    
    
   public static String getBrowserDetail(WebDriver _driver) {
        driver = _driver == null ? driver : _driver;
        String browser_version = null;
        Capabilities cap = ((RemoteWebDriver) driver).getCapabilities();
        String browsername = cap.getBrowserName();
        /*Properties Browser = new Properties();
         Browser.put("Name", browsername);*/
        // IE Version number
        if ("internet explorer".equalsIgnoreCase(browsername)) {
            String uAgent = (String) ((JavascriptExecutor) driver).executeScript("return navigator.userAgent;");
            //System.out.println(uAgent);
            //uAgent return as "MSIE 8.0 Windows" for IE8
            if (uAgent.contains("MSIE") && uAgent.contains("Windows")) {
                browser_version = uAgent.substring(uAgent.indexOf("MSIE") + 5, uAgent.indexOf("Windows") - 2);
            } else if (uAgent.contains("Trident/7.0")) {
                browser_version = "11.0";
            } else {
                browser_version = "0.0";
            }
        } else {
            //Firefox and Chrome
            browser_version = cap.getVersion();// .split(".")[0];
        }

        //Browser.put("Version", browser_version);
        BrowserProperty = browsername + " : " + browser_version;
        return BrowserProperty;
    }
   
   public static WebDriver launchBrowser(String browser) throws Exception { 
    System.setProperty("webdriver.chrome.driver", ChromedriverPath);
    if(browser.contains("IE"))
    {
     driver=new InternetExplorerDriver();
    } 
    if (browser.equals("Chrome")) {
        ChromeOptions options=new ChromeOptions();
            options.addArguments("disable-infobars");
            driver = new ChromeDriver(options);
            
     }
    if(browser.contains("Firefox"))
    {
     driver=new FirefoxDriver();
    } 
    driver.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
    getBrowserDetail(driver);
    return driver;
   } 
   
   
 
   
   public static String[][] getSQLresult(String query) throws Exception {

        String userName = null;
        String password = null;
        String url = null;

        try {

            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            if (url == null || userName == null || password == null) {
                boolean res = sqlConnection.getAppDBdetails();
                url = sqlConnection.app_url;
                userName = sqlConnection.app_userName;
                password = sqlConnection.app_password;
                if (res == false) {
                    userName = "sa";
                    password = "kov1$air";
                    url = "jdbc:sqlserver://databaseperform:1433" + ";databaseName=AMAT BVT";
                }
            }
            Connection con = DriverManager.getConnection(url, userName, password);
            Statement s1 = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            //Statement s1 = con.createStatement();
//            if(query.split(";").length!=0){
//                for(int i=0;i<query.split(";").length;i++){
//                    s1.addBatch(query.split(";")[i]);
//                }
//            }
            
            ResultSet rs = s1.executeQuery(query);
            //s1.execute(query);
            //ResultSet rs = s1.getResultSet();
            ResultSetMetaData rsmd = rs.getMetaData();
            int columnsNumber = rsmd.getColumnCount();
            rs.last();
            //System.out.println("Row Count = "+rs.getRow());
            String[][] relations = new String[rs.getRow()][rsmd.getColumnCount()];
            int currentRow = 0;
            rs.beforeFirst();
            if (rs != null) {
                //System.out.println("Following relations are available for the entity: "+entityName);	        	  
                while (rs.next()) {
                    for (int i = 0; i < columnsNumber; i++) {
                        relations[currentRow][i] = rs.getString(i + 1);
                    }
                    currentRow++;
                }
            }
            s1.close();
            return relations;
            //String result = new result[20];
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
   
    public Boolean KovairLogin(String username,String password,WebDriver driver)
    {  
        Boolean login=true;
       try
        {
            driver.manage().window().maximize();
            System.out.println(username);
           oblogin.KovairUsername.sendKeys(username);
//            setUsername(username);
           oblogin.KovairPassword.sendKeys(password);
           System.out.println(password);
//            setPassword(password);
           SeleniumModules.buttonClick(oblogin.KovairLoginButton, driver);
//            oblogin.KovairLoginButton.click();
            Thread.sleep(10000);
//            return new KovairHomePageModule(driver);
            return login;
            
        }
        catch(Exception e)
        {   
            login=false;
            System.out.println("Cannot login to Kovair");
            System.out.println(e);
            return login;
        }
    }   
    
    public Boolean logout(WebDriver driver) throws Exception {
         Boolean log=true;
        try { 
            String text = "Logout";
            hpm=new KovairHomePageElement(driver);
            hpm.KovairUserDrpDwnEle.click();
            for (int i=0;i<=hpm.LoginUserElementList.size();i++) {
                if(hpm.LoginUserElementList.get(i).getText().contains(text))
                {
                  hpm.LoginUserElementList.get(i).click();
                  break;
                }
            }
            if (oblogin.KovairLoginButton.isDisplayed()) {
                log=true;
            } else {
                log=false;
            } 
            return log;
        } catch (Exception e) {
            log=false;
            return log;
        }
    }
}
