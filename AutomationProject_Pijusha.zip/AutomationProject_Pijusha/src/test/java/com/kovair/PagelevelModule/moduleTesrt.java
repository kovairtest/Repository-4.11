/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.kovair.PagelevelModule;

import org.openqa.selenium.WebElement;
import com.kovair.pages.homePageElementTest;
//import com.kovair.pages.homePageElementTest.CreateRecordPageElement;
import org.openqa.selenium.WebDriver;
/**
 *
 * @author Abhishekp
 */
public class moduleTesrt {
   
    homePageElementTest hp;
    homePageElementTest.CreateRecordPageElement cr;
    static WebDriver driver;
    public WebElement homePageModule(String title)
    {
        hp=new homePageElementTest(driver);
        WebElement elem=null;
        try{
            if(title.equals("Create Link"))
            {
                elem=hp.createRecordLink;
            }
            else if(title.equals("Header Action"))
            {
                elem=hp.headerActionLink;
            }
            return elem;
        }
        catch(Exception e)
        {
            System.out.println(e.getMessage());
            return elem;
        }
        
    }
    public WebElement createRecordModule(String title)
    {
        cr=hp.new CreateRecordPageElement(driver);
        WebElement recordElem=null;
        try{
            if(title.equals("Page title"))
            {
               recordElem=cr.createRecordPageTitle;
            }
            return recordElem;
        }
        catch(Exception e)
        {
            System.out.println(e.getMessage());
            return recordElem;
        }
    }
}
