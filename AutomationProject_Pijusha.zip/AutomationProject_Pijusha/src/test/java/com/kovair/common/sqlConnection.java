/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.kovair.common;

/**
 *
 * @author sutapam
 */
import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;
import java.sql.Types;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import org.testng.annotations.Test;

public class sqlConnection {

	/**
	 * @param args
	 */
        public static String BatchName="";
        public static String userName =null;// "sa";
        public static String password =null;// "kov1$air";
        public static String url =null;// "jdbc:sqlserver://db-qa:1433"+";databaseName=AMAT BVT";
        public static String app_userName =null;// "sa";
        public static String app_password =null;// "kov1$air";
        public static String app_url =null;// "jdbc:sqlserver://db-qa:1433"+";databaseName=AMAT BVT";
        public static File fXmlFile_DBdetails= new File(System.getProperty("user.dir") + "//src/test/java/com/kovair/LoginInfo/LoginInfo.xml");
        public static int length=8000;
        public static int RunId=0;
        
        static String Browser=null;
        public static String OS = null;
        public static String OSArch = null;
        public static String Solution=null;
        public static String TestDB_Server = null;
        public static String TestDB_Name=null;
        
        public static String DefaultSolution="Main";

        
        public static boolean getTestDBdetails() throws Exception{ 
          try
           {
            String[] logdata = new String[5];
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.parse(fXmlFile_DBdetails);
            doc.getDocumentElement().normalize();
            //System.out.println("Root element :" + doc.getDocumentElement().getNodeName());
            //Build
            NodeList __nNode1 =doc.getElementsByTagName("Build");
            for (int temp1 = 0; temp1 < __nNode1.getLength(); temp1++) 
            {
               Node Node1 = __nNode1.item(temp1);
               if (Node1 instanceof Element) 
               {
               Element _eElement = (Element) Node1;    
               String sol=_eElement.getAttribute("Solution").toString().trim();
               if(sol.trim().contains(Solution))
               {
                  NodeList DataList = _eElement.getElementsByTagName("DataBase");
                  for (int temp = 0; temp < DataList.getLength(); temp++) {
                    Node nNode = DataList.item(temp);
                    if (nNode.getNodeType() == Node.ELEMENT_NODE) {
                        Element eElement = (Element) nNode;  
                        String DBType=eElement.getAttribute("type").toString().trim();
                        if(DBType.contains("Test DataBase"))
                        {
                            logdata[0] = eElement.getElementsByTagName("DBType").item(0).getTextContent();
                            logdata[1] = eElement.getElementsByTagName("ServerIP").item(0).getTextContent();
                            logdata[2] = eElement.getElementsByTagName("ServerName").item(0).getTextContent();
                            logdata[3] = eElement.getElementsByTagName("DataBaseName").item(0).getTextContent();
                            logdata[4] = eElement.getElementsByTagName("Port").item(0).getTextContent();
                            userName   = eElement.getElementsByTagName("DBUserName").item(0).getTextContent();
                            password   = eElement.getElementsByTagName("DBPassword").item(0).getTextContent(); 
                            TestDB_Server=logdata[2];
                            TestDB_Name=logdata[3];
                            url ="jdbc:"+logdata[0]+"://"+logdata[2]+":"+logdata[4]+";databaseName="+logdata[3];
                            return true;
                        }
                    }
                  } 
                }
            }}}
            catch(Exception e)
            {
               return false;
            }
          return false;         
       }
        
        public static boolean getAppDBdetails() throws Exception{ 
          try
           {
            String[] logdata = new String[5];
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.parse(fXmlFile_DBdetails);
            doc.getDocumentElement().normalize();
            //System.out.println("Root element :" + doc.getDocumentElement().getNodeName());
            //Build
            NodeList __nNode1 =doc.getElementsByTagName("Build");
            for (int temp1 = 0; temp1 < __nNode1.getLength(); temp1++) 
            {
               Node Node1 = __nNode1.item(temp1);
               if (Node1 instanceof Element) 
               {
               Element _eElement = (Element) Node1;    
               String sol=_eElement.getAttribute("Solution").toString().trim();
               if(sol.trim().contains(Solution))
               {
                    NodeList DataList = _eElement.getElementsByTagName("DataBase");
                    for (int temp = 0; temp < DataList.getLength(); temp++) {
                        Node nNode = DataList.item(temp);
                        if (nNode.getNodeType() == Node.ELEMENT_NODE) {
                            Element eElement = (Element) nNode;  
                            String DBType=eElement.getAttribute("type").toString().trim();
                            if(DBType.contains("Application DataBase"))
                            {
                                logdata[0] = eElement.getElementsByTagName("DBType").item(0).getTextContent();
                                logdata[1] = eElement.getElementsByTagName("ServerIP").item(0).getTextContent();
                                logdata[2] = eElement.getElementsByTagName("ServerName").item(0).getTextContent();
                                logdata[3] = eElement.getElementsByTagName("DataBaseName").item(0).getTextContent();
                                logdata[4] = eElement.getElementsByTagName("Port").item(0).getTextContent();
                                app_userName   = eElement.getElementsByTagName("DBUserName").item(0).getTextContent();
                                app_password   = eElement.getElementsByTagName("DBPassword").item(0).getTextContent();                      
                                app_url ="jdbc:"+logdata[0]+"://"+logdata[2]+":"+logdata[4]+";databaseName="+logdata[3];
                                return true;
                            }
                        }
                      } 
                    }
               }}}
            catch(Exception e)
            {
               return false;
            }
          return false;         
       }
    
	public static void main(String[] args) throws Exception{
 
		// TODO Auto-generated method stub
		sqlConnection.sqlGetRunId();
                //getDBdetails();
		System.out.println("RunId="+RunId);
		/*
		for(int i=1;i<=10;i++){
			String ErrDesc=null;
			String PassFail=null;
			if(i%2==0){
				ErrDesc="Some Error Occurred";
				PassFail="Fail";
			}
			sqlInsert(runId,i,i,"TestCase "+i,PassFail,ErrDesc);
		}
		*/
		
		//sqlRead(runId);          

	}
	
	public static void sqlInsert(int runId,int srlNo,String tcId,String TCName,String PassFail,String ErrDesc,String Screenshot){
             try
                {
                    //Class.forName("com.microsoft.jdbc.sqlserver.SQLServerDriver");
                    Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");   
                    if(url==null || userName==null || password==null )
                    {
                        boolean res=getTestDBdetails();
                        if(res==false)
                        {
                             userName = "sa";
                             password = "kov1$air";
                             url = "jdbc:sqlserver://db-qa:1433"+";databaseName=MainBVT";
                        }
                    }
                    Connection con = DriverManager.getConnection(url, userName, password);
                    Statement s1 = con.createStatement();
                    if(PassFail.contains("Passed"))
                    {
                        s1.executeUpdate("insert into TestResult (RunId,SrlNo,TCId,TCName,Result,ErrDesc,RunDate,BatchName,Screenshot) values ("+runId+","+srlNo+",'"+tcId+"','"+TCName+"','"+PassFail+"','"+ErrDesc+"',GETDATE(),'"+BatchName+"','"+Screenshot+"')");
                        //s1.executeUpdate("insert into TestResult (RunId,SrlNo,TCId,TCName,Result,ErrDesc,RunDate,BatchName,Screenshot) values ("+runId+","+srlNo+",'"+tcId+"','"+TCName+"','"+PassFail+"','"+ErrDesc+"','GETDATE()','"+BatchName+"','"+Screenshot+"')");
                    }
                    else{
                        ErrDesc=ErrDesc.replace("'", "");
                        if(ErrDesc.length() > length)
                        {
                            ErrDesc=ErrDesc.substring(0, length - 3) + "...";
                        }
                        Thread.sleep(1000);
                        s1.executeUpdate("insert into TestResult (RunId,SrlNo,TCId,TCName,Result,ErrDesc,RunDate,BatchName,Screenshot) values ("+runId+","+srlNo+",'"+tcId+"','"+TCName+"','"+PassFail+"','"+ErrDesc+"',GETDATE(),'"+BatchName+"','"+Screenshot+"')");
                        //s1.executeUpdate("insert into TestResult (RunId,SrlNo,TCId,TCName,Result,ErrDesc,RunDate,BatchName,Screenshot) values ("+runId+","+srlNo+",'"+tcId+"','"+TCName+"','"+PassFail+"','"+ErrDesc+"','GETDATE()','"+BatchName+"','"+Screenshot+"')");
                        Thread.sleep(1000);
                    }
                    s1.close();

                } 
             catch (Exception e)
                {
                    e.printStackTrace();
                }               
	  }
	
	public static void sqlRead(int runId){
		try
		{
          //Class.forName("com.microsoft.jdbc.sqlserver.SQLServerDriver");
          Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver"); 
          if(url==null || userName==null || password==null )
            {
                boolean res=getTestDBdetails();
                if(res==false)
                {
                     userName = "sa";
                     password = "kov1$air";
                     url = "jdbc:sqlserver://db-qa:1433"+";databaseName=MainBVT";
                }
            }
          Connection con = DriverManager.getConnection(url, userName, password);
          Statement s1 = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
          //s1.executeQuery("insert into TestResult values (1,1,'TestCase 1','Pass',null)");
          ResultSet rs=s1.executeQuery("select * from TestResult where RunId="+runId+"order by srlNo");
          ResultSetMetaData rsmd = rs.getMetaData();

          int columnsNumber = rsmd.getColumnCount();
          
          if(rs!=null){
              while (rs.next()){
              		
            	  for(int i=1;i<=columnsNumber;i++){
            		  int type = rsmd.getColumnType(i);
                      if (type == Types.VARCHAR || type == Types.CHAR) {
                          System.out.print(rs.getString(i)+" ");
                      } else {
                          System.out.print(rs.getLong(i)+" ");
                      }
            		  
            	  }
            	  System.out.print("\n");
              }
          }
          s1.close();

          //String result = new result[20];

            } 
		catch (Exception e)
          {
              e.printStackTrace();
          }    
       }
        
        //@
        
	@Test
	public static int sqlGetRunId(){
              int result = 0;
              if(Solution == null)
              { Solution=DefaultSolution;}
              try
              {
                      Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
                      if(url==null || userName==null || password==null )
                        {
                            boolean res=getTestDBdetails();
                            if(res==false)
                            {
                                 userName = "sa";
                                 password = "kov1$air";
                                 url = "jdbc:sqlserver://db-qa:1433"+";databaseName=MainBVT";
                            }
                        }
                      Connection con = DriverManager.getConnection(url, userName, password);
                      Statement s1 = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
                      ResultSet rs = s1.executeQuery("select max(RunId) From RunIdDetails");

                      if(rs!=null)
                      {
                         while (rs.next())
                         {
                                //System.out.println("Row Count= "+rs.getRow());
                                 result=rs.getInt(1);
                         }
                      }
                      s1.close();
              }
              catch (Exception e)
              {
                      e.printStackTrace();
              } 
              RunId=result;
              System.out.println("TestRun DataBase Server:"+TestDB_Server);
              System.out.println("TestRun DataBase :"+TestDB_Name);
              //System.out.println("RunId :"+RunId);
              return result;
	  }
	public static ResultSet getResultfrQry(String qry) throws Exception
        {
            
            
            Browser=KovairGenericClass.BrowserProperty;
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            if(app_url==null || app_userName==null || app_password==null )
            {
                boolean res=getAppDBdetails();
                if(res==false)
                {
                     userName = "sa";
                     password = "kov1$air";
                     url = "jdbc:sqlserver://db-qa:1433"+";databaseName=ALM_APP_IQA";
                }
            }
            Connection con = DriverManager.getConnection(app_url, app_userName, app_password);
            Statement stmt = con.createStatement();
            ResultSet rs;
 
            rs = stmt.executeQuery(qry);
            
            
            //rs.executeUpdate("update RunIdDetails SET EndTime = GETDATE(),BrowserDetails ='"+Browser+"' where RunId="+_RunId);
            
            return rs;
        }
	public static void readApplicationDB(){
		try
		{
                      //Class.forName("com.microsoft.jdbc.sqlserver.SQLServerDriver");
                      Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");    
                      if(url==null || userName==null || password==null )
                        {
                            boolean res=getTestDBdetails();
                            if(res==false)
                            {
                                 userName = "sa";
                                 password = "kov1$air";
                                 url = "jdbc:sqlserver://db-qa:1433"+";databaseName=MainBVT";
                            }
                        }
                      Connection con = DriverManager.getConnection(url, userName, password);
                      Statement s1 = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
                      //s1.executeQuery("insert into TestResult values (1,1,'TestCase 1','Pass',null)");
                      ResultSet rs=s1.executeQuery("select ToolName from tklfAvailableTools where Tool");
                      ResultSetMetaData rsmd = rs.getMetaData();

                      int columnsNumber = rsmd.getColumnCount();

                      if(rs!=null){
                          while (rs.next()){

                              for(int i=1;i<=columnsNumber;i++){
                                      int type = rsmd.getColumnType(i);
                                  if (type == Types.VARCHAR || type == Types.CHAR) {
                                      System.out.print(rs.getString(i)+" ");
                                  } else {
                                      System.out.print(rs.getLong(i)+" ");
                                  }

                              }
                              System.out.print("\n");
                          }
                      }
                      s1.close();

                      //String result = new result[20];

                  } 
                  catch (Exception e)
                  {
                      e.printStackTrace();
                  }
	}
	
        @BeforeTest
        @Parameters("Solution")
        public static void SetSolutionType(@Optional String solution) throws Exception
        {
            if(solution == null)
            { Solution=DefaultSolution;}
            else
            {
                Solution= solution;
            }
        }
        
	@Test
	public static void enterRunIdInDatabase(){
	  try
        {
            if(OS == null) 
                OS = System.getProperty("os.name"); 
            if(OSArch == null) 
                OSArch = System.getProperty("os.arch");
            
            String wow64Arch = System.getenv("PROCESSOR_ARCHITEW6432");
            OSArch =OSArch.endsWith("64")||wow64Arch!=null && wow64Arch.endsWith("64")?"64":"32";

            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            if(url==null || userName==null || password==null )
            {
                boolean res=getTestDBdetails();
                if(res==false)
                {
                     userName = "sa";
                     password = "kov1$air";
                     url = "jdbc:sqlserver://db-qa:1433"+";databaseName=MainBVT";
                }
            }
            Connection con = DriverManager.getConnection(url, userName, password);
            Statement s1 = con.createStatement();
            s1.executeUpdate("insert into RunIdDetails (StartTime,EndTime,OSDetails,Solution) values (GETDATE(),GETDATE(),'"+OS+" : "+ OSArch+"','"+Solution+"')");
            s1.close();
           }
           catch (Exception e)
           {
                e.printStackTrace();
           }
	}
	
	@Test
	public static void updateRunDetailsInDatabase(@Optional Integer _RunId){
         try
        {
            _RunId= (_RunId==null)? RunId : (_RunId.toString().isEmpty()? RunId: _RunId);
            
            Browser=KovairGenericClass.BrowserProperty;
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            if(url==null || userName==null || password==null )
            {
                boolean res=getTestDBdetails();
                if(res==false)
                {
                     userName = "sa";
                     password = "kov1$air";
                     url = "jdbc:sqlserver://db-qa:1433"+";databaseName=MainBVT";
                }
            }
            Connection con = DriverManager.getConnection(url, userName, password);
            Statement s1 = con.createStatement();
            //getBrowserAndVersion
            Date date = new Date();
            SimpleDateFormat dateFormatter = new SimpleDateFormat("MMMM dd, yyyy hh-mm-ss");
            s1.executeUpdate("update RunIdDetails SET EndTime = "+dateFormatter.format(date)+",BrowserDetails ='"+Browser+"' where RunId="+_RunId);
            s1.close();
  
        }
	  catch (Exception e)
        {
            e.printStackTrace();
        }
	}

	

public static Map<String, Object> putJsonDocument(int runId,int srlNo,String tcId,String TCName,String PassFail,String ErrDesc,String Screenshot){

    
//public static Map<String, Object> putJsonDocument(String title, String content, Date postDate,String[] tags, String author){

       Map<String, Object> jsonDocument = new HashMap<String, Object>();

      /* Client client = NodeBuilder.nodeBuilder()
                                .client(true)
                                .node()
                                .client(); */

    

        jsonDocument.put("runId", runId);
        jsonDocument.put("srlNo", srlNo);
        jsonDocument.put("tcId", tcId);
        jsonDocument.put("TCName", TCName);
        jsonDocument.put("PassFail", PassFail);
        jsonDocument.put("ErrDesc", ErrDesc);
        jsonDocument.put("Screenshot", Screenshot);

        return jsonDocument;
  

}
}



