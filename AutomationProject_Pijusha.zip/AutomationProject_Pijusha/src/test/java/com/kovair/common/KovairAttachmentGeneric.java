/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.kovair.common;
import org.openqa.selenium.*;
import org.testng.Assert;
import org.jsoup.Jsoup;
import org.openqa.selenium.interactions.Actions;
import org.jsoup.select.Elements;
import org.openqa.selenium.support.ui.WebDriverWait;
/**
 *
 * @author priyankad
 */
public class KovairAttachmentGeneric {
    static String Attachmentidpart="";
    static String TestExeStatus = null;
    static String TestErrDesc = null;
    
    public static String Add_Attachment_Link(String InPage,WebDriver driver) throws Exception{
       try{
        if(InPage.equals("List"))
        {
         Attachmentidpart="PlaceHolderPopUp_";
        }
        else if(InPage.equals("Task Parent"))
        {
         Attachmentidpart="KovairMaster_Main_colPanel_Section_19_";
        }
        else
            Attachmentidpart="KovairMaster_Main_colPanel_Section_2_";
        WebElement AddAttchmentlnk=driver.findElement(By.id(Attachmentidpart+"AttachFileLbl"));
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", AddAttchmentlnk);
        AddAttchmentlnk.click();                 
//        WebElement LiEle=driver.findElement(By.id("KovairMaster_Main_fileUploadUser_Attachment_RadAsyncUpload1file0"));
//        JavascriptExecutor executor = (JavascriptExecutor) driver;
//        executor.executeScript("arguments[0].click();", LiEle);
//        Thread.sleep(2500);
//        LiEle.click();
//        Thread.sleep(10000); 
//        Runtime.getRuntime().exec("C:\\Users\\vpramoda\\Desktop\\AutoIt\\TestAttUpload.exe");
//        Thread.sleep(5000);
//        driver.findElement(By.id(Attachmentidpart+"btnFileSave")).click();
//        Thread.sleep(3000);
//        driver.findElement(By.id("btnModalOk")).click();
//        Thread.sleep(2000);
        }
       catch(Exception e)
       {
           TestExeStatus="Failed";
       }
        return TestExeStatus;
    }

    public static String Add_Attachment_click(String InPage,WebDriver driver) throws Exception{
       try{
        if(InPage.equals("List"))
        {
         Attachmentidpart="PlaceHolderPopUp_";
        }
       else if(InPage.equals("Task Parent"))
        {
         Attachmentidpart="KovairMaster_Main_colPanel_Section_19_";
        }
        else
            Attachmentidpart="KovairMaster_Main_colPanel_Section_2_"; 
//        WebElement AddAttchmentlnk=driver.findElement(By.id(Attachmentidpart+"AttachFileLbl"));
//        AddAttchmentlnk.click();
        WebElement AddAttchmentdiv=driver.findElement(By.id(Attachmentidpart+"AddAttachContainerTable"));
        WebElement AddAttchmentlnk=driver.findElement(By.id(Attachmentidpart+"AttachFileLbl"));
        AddAttchmentlnk.click(); 
        Thread.sleep(3000);
       ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", AddAttchmentlnk);
       
//        WebElement LiEle=driver.findElement(By.id("KovairMaster_Main_fileUploadUser_Attachment_RadAsyncUpload1file0"));
//        JavascriptExecutor executor = (JavascriptExecutor) driver;
//        executor.executeScript("arguments[0].click();", LiEle);
//        Thread.sleep(2500);
//        LiEle.click();
        Thread.sleep(3000);
        if(AddAttchmentdiv.isDisplayed())
        {
            TestExeStatus="Passed";
        }
        else
        {
            TestExeStatus="Failed";
        }
       }
       catch(Exception e)
       {
           TestExeStatus="Failed";
       }
        return TestExeStatus;
    }    
     public static String ExpandCollapseAttachment(String InPage,WebDriver driver) throws Exception{
       try{
           //KovairMaster_Main_colPanel_Section_2_TdExdColImg
            if(InPage.equals("List"))
            {
             Attachmentidpart="PlaceHolderPopUp_";
            }
           else if(InPage.equals("Task Parent"))
            {
             Attachmentidpart="KovairMaster_Main_colPanel_Section_19_";
            }
            else
             Attachmentidpart="KovairMaster_Main_colPanel_Section_2_"; 
          driver.findElement(By.id(Attachmentidpart+"button")).click();
          Thread.sleep(2000);
          driver.findElement(By.id(Attachmentidpart+"button")).click();
          Thread.sleep(2000);
         if(driver.findElement(By.id(Attachmentidpart+"button")).getAttribute("alt").toString().equals("Click here to expand"))
         { driver.findElement(By.id(Attachmentidpart+"button")).click();
           Thread.sleep(3000);
         }
         TestExeStatus="Passed";
       }
       catch(Exception e)
       {
           TestExeStatus="Attachment Tab is not present";
       }
        return TestExeStatus;
    }    
     public static String ExpandCollapseAttachmentInView(String InPage,WebDriver driver) throws Exception{
       try{
           //KovairMaster_Main_colPanel_Section_2_TdExdColImg
            if(InPage.equals("List"))
            {
             Attachmentidpart="PlaceHolderPopUp_";
            }
           else if(InPage.equals("Task Parent"))
            {
             Attachmentidpart="KovairMaster_Main_colPanel_Section_19_";
            }
            else
             Attachmentidpart="KovairMaster_Main_colPanel_Section_2_"; 
            
            WebDriverWait wait = new WebDriverWait(driver, 120);
            String togglerClass = driver.findElement(By.cssSelector("div.toggler > span")).getAttribute("class");
            if (togglerClass.contains("glyphicon-chevron-left"))
            {
               driver.findElement(By.cssSelector("div.toggler > span")).click();
            }
           WebElement sideBar = driver.findElement(By.cssSelector("div[id='FloatDiv'][class*='sidebar ']"));
           sideBar.findElement(By.cssSelector("img[title='Attachment(s)']")).click();
           Thread.sleep(5000);
//           String Att= Attachmentidpart+"AddNoteLbl";
//           if(driver.findElement(By.cssSelector("span#PlaceHolderPopUp_AddNoteLbl")).isDisplayed())
             TestExeStatus="Passed";
           
       }
       catch(Exception e)
       {
           TestExeStatus="Failed"; 
       }
        return TestExeStatus;
    } 
     
       
    public static String Browse_click(String filename,String filepath,String InPage,WebDriver driver) throws Exception{
        //KovairMaster_Main_colPanel_Section_2_AttachmentID_fileUploadUser_RadAsyncUpload1file1
       try{
        if(InPage.equals("List"))
        {
         Attachmentidpart="PlaceHolderPopUp_";
        }
        else if(InPage.equals("Task Parent"))
        {
         Attachmentidpart="KovairMaster_Main_colPanel_Section_19_";
        }
        else
          Attachmentidpart="KovairMaster_Main_";
        WebElement browse=driver.findElement(By.id(Attachmentidpart+"fileUploadUser_Attachment_RadAsyncUpload1file0"));
        JavascriptExecutor executor = (JavascriptExecutor)driver;
        executor.executeScript("arguments[0].click();", browse);
        Runtime.getRuntime().exec(filepath);
        browse.click();
        Thread.sleep(5000);
//        //driver.switchTo().activeElement().sendKeys(filepath);
//        //driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
//        //System.Windows.Forms.SendKeys.SendWait("complete path of the file");
//        //System.Windows.Forms.SendKeys.SendWait("{ENTER}");
//        //browse.sendKeys(filepath);        
//        KovairGenericClass.setClipboardData(filename);
//        //native key strokes for CTRL, V and ENTER keys
//        Robot robot = new Robot();
//        robot.keyPress(KeyEvent.VK_CONTROL);
//        robot.keyPress(KeyEvent.VK_V);
//        robot.keyRelease(KeyEvent.VK_V);
//        robot.keyRelease(KeyEvent.VK_CONTROL);
//        robot.keyPress(KeyEvent.VK_ENTER);
//        robot.keyRelease(KeyEvent.VK_ENTER);
//        robot.delay(1000);
          }
       catch(Exception e)
       {
           TestExeStatus="Failed";
       }
        return TestExeStatus;
    }
    public static String Add_AttachmentCancel_click(String ItemType,String InPage,WebDriver driver) throws Exception{
       try{
        if(InPage.equals("List"))
        {
         Attachmentidpart="PlaceHolderPopUp_";
        }
         else if(InPage.equals("Task Parent"))
        {
         Attachmentidpart="KovairMaster_Main_colPanel_Section_19_";
        }
         else 
            Attachmentidpart="KovairMaster_Main_colPanel_Section_2_"; //KovairMaster_Main_colPanel_Section_2_btnFileCancel
        //KovairMaster_Main_colPanel_Section_2_btnNoteCancel
         WebElement Cancel=driver.findElement(By.id(Attachmentidpart+"btn"+ItemType+"Cancel"));
         Cancel.click();    
         Thread.sleep(4000);
         if(!driver.findElement(By.id(Attachmentidpart+"btnNoteAdd")).isDisplayed())
         {
             TestExeStatus="Passed";
         }
         else
         {
             TestExeStatus="Failed";
         }  
       }
       catch(Exception e)
       {
           TestExeStatus="Failed";
       }
         return TestExeStatus;
     }
    public static String Add_AttachmentSave_click(String Attachmentname,String Attachmentdesc,String Verification_msg,String InPage,WebDriver driver) throws Exception{
       
       try{
        if(InPage.equals("List"))
        {
         Attachmentidpart="PlaceHolderPopUp_";
        }
         else if(InPage.equals("Task Parent"))
        {
         Attachmentidpart="KovairMaster_Main_colPanel_Section_19_";
        }
        else
          Attachmentidpart="KovairMaster_Main_colPanel_Section_2_";  
          WebElement name=driver.findElement(By.id(Attachmentidpart+"txtFileName"));
          name.clear();
          name.sendKeys(Attachmentname);  
          WebElement Save=driver.findElement(By.id(Attachmentidpart+"btnFileSave"));
          Save.click();
          KovairGenericClass.Modal_OKClick_Verification("OK",driver);
          Thread.sleep(2000);
          if(driver.findElements(By.id(Attachmentidpart+"AddAttachContainer")).size()==0)
          {
            TestExeStatus="Passed";
          }
          else
          {
            TestExeStatus="Attachment didnot attach properly.";
          }
        //}
//         if(_flname==null)
//         {
//            TestExeStatus="File didn't get browsed.";
//         }
        }
       catch(Exception e)
       {
           TestExeStatus="Failed";
       }
         return TestExeStatus;
     }
    public static String Attachment_NewNote_URl_Save_verify(String ItemType,String ItemText,String InPage,WebDriver driver) throws Exception{
       try{ 
        if(InPage.equals("List"))
        {
         Attachmentidpart="PlaceHolderPopUp_";
        }
         else if(InPage.equals("Task Parent"))
        {
         Attachmentidpart="KovairMaster_Main_colPanel_Section_19_";
        }
        else
           Attachmentidpart="KovairMaster_Main_colPanel_Section_2_"; 
         WebElement Attachmentmentspan=null;                 
         if(ItemType =="URL")            
         {   
             //KovairMaster_Main_colPanel_Section_2_GridAttachment
             Attachmentmentspan=driver.findElement(By.xpath("//div[@id='"+Attachmentidpart+"GridAttachment']/table[1]/tbody/tr[2]/td[4]/a"));
//             Attachmentmentspan=driver.findElement(By.xpath("//tr[@id='"+Attachmentidpart+"AttachmentID_RadGrid_AttachmentList_ctl00__0']/td[4]/a"));
         }
         else
         {
             Attachmentmentspan=driver.findElement(By.xpath("//div[@id='"+Attachmentidpart+"GridAttachment']/table[1]/tbody/tr[2]/td[4]/a[2]"));
         }
         String _item=Attachmentmentspan.getText().toString();
        // String Type=driver.findElement(By.xpath("//img[@id='"+Attachmentidpart+"AttachmentID_RadGrid_AttachmentList_ctl00_ctl04_imgGridImageColumn1']")).getAttribute("title").toString().trim();
         String Type=driver.findElement(By.xpath("//div[@id='"+Attachmentidpart+"GridAttachment']/table[1]/tbody/tr[2]/td[3]/img")).getAttribute("title").toString().trim();
         if(Type.equals(ItemType) && _item.equals(ItemText))
         {
             TestExeStatus="Passed";
         }
         else
         {
             TestExeStatus="Failed";
         }
        }
       catch(Exception e)
       {
           TestExeStatus="Failed";
       }
         return TestExeStatus;
     }   
    public static String Add_NewURL_Link(String InPage,WebDriver driver) throws Exception{
        //KovairMaster_Main_colPanel_Section_2_AttachmentID_NewUrlLb
       try{
        if(InPage.equals("List"))
        {
         Attachmentidpart="PlaceHolderPopUp_";
        }
         else if(InPage.equals("Task Parent"))
        {
         Attachmentidpart="KovairMaster_Main_colPanel_Section_19_";
        }
        else
            Attachmentidpart="KovairMaster_Main_colPanel_Section_2_";//////////////didn't understand
        WebElement NewURL=driver.findElement(By.xpath("//table[@id='"+Attachmentidpart+"AttachmentID_AttachmentActionListTable']/tbody/tr[1]/td[4]/span"));
        Assert.assertEquals(true,NewURL.isDisplayed());
       }
       catch(Exception e)
       {
           TestExeStatus="Failed";
       }
		 return TestExeStatus;
    }
    public static String Add_NewURL_click(String InPage,WebDriver driver) throws Exception{
        try{
        if(InPage.equals("List"))
        {
         Attachmentidpart="PlaceHolderPopUp_";
        }
         else if(InPage.equals("Task Parent"))
        {
         Attachmentidpart="KovairMaster_Main_colPanel_Section_19_";
        }
        else
            Attachmentidpart="KovairMaster_Main_colPanel_Section_2_";
        //KovairMaster_Main_colPanel_Section_2_AttachmentID_NewUrlLbl// KovairMaster_Main_colPanel_Section_2_NewUrlLbl
//        WebElement NewURL=driver.findElement(By.xpath("//span[@id='"+Attachmentidpart+"AttachmentID_AttachmentActionListTable']/tbody/tr[1]/td[4]/span"));
        //NewURL.click();                 NewUrlLbl
        WebElement NewURL= driver.findElement(By.id(Attachmentidpart+ "NewUrlLbl")); 
        JavascriptExecutor executor = (JavascriptExecutor)driver;
        executor.executeScript("arguments[0].click();", NewURL);
        WebElement AddURLdiv=driver.findElement(By.id(Attachmentidpart+"AddURLContainer"));
        if(AddURLdiv.isDisplayed())
            TestExeStatus="Passed";
        }
       catch(Exception e)
       {
           TestExeStatus="Failed";
       }
		 return TestExeStatus;
    } 
    public static String Add_NewURLSave_click(String textURLname_msg,String textURL_msg,String textdesc_msg,String Verification_msg,String InPage,WebDriver driver) throws Exception{
      try{ 
        if(InPage.equals("List"))
        {
         Attachmentidpart="PlaceHolderPopUp_";
        }
        else if(InPage.equals("Task Parent"))
        {
         Attachmentidpart="KovairMaster_Main_colPanel_Section_19_";
        }
        else
            Attachmentidpart="KovairMaster_Main_colPanel_Section_2_";  //PlaceHolderPopUp_txtlblURLName
         WebElement textURLname=driver.findElement(By.id(Attachmentidpart+"txtlblURLName"));
         textURLname.clear();
         textURLname.sendKeys(textURLname_msg);
         WebElement textURL=driver.findElement(By.id(Attachmentidpart+"txtURL"));
         textURL.clear();
         textURL.sendKeys(textURL_msg);
         WebElement textdesc=driver.findElement(By.id(Attachmentidpart+"txtdesc"));
         textdesc.clear();
         textdesc.sendKeys(textdesc_msg);
         WebElement Save=driver.findElement(By.id(Attachmentidpart+"btnURLAdd"));
         Save.click();
         KovairGenericClass.Modal_OKClick_Verification("OK",driver);
         Thread.sleep(2000);
         //WebElement AddURLdiv=driver.findElement(By.id("KovairMaster_Main_colPanel_Section_2_AttachmentID_AddURLContainerTable"));
         //Assert.assertEquals(false,AddURLdiv.isDisplayed());
           }
       catch(Exception e)
       {
           TestExeStatus="Failed";
       }
         return TestExeStatus;
     }
    public static String Add_NewURLCancel_click(String InPage,WebDriver driver) throws Exception{       
       try{
        if(InPage.equals("List"))
        {
         Attachmentidpart="PlaceHolderPopUp_";
        }
        else if(InPage.equals("Task Parent"))
        {
         Attachmentidpart="KovairMaster_Main_colPanel_Section_19_";
        }
        else
            Attachmentidpart="KovairMaster_Main_colPanel_Section_2_";  //KovairMaster_Main_colPanel_Section_2_btnURLCancel
         WebElement Cancel=driver.findElement(By.id(Attachmentidpart+"btnURLCancel"));
         Cancel.click();
//         WebElement AddURLdiv=driver.findElement(By.id(Attachmentidpart+"AttachmentID_AddURLContainerTable"));
//         Assert.assertEquals(false,AddURLdiv.isDisplayed());
         if(driver.findElements(By.id(Attachmentidpart+"AddURLContainerTable")).size()==0)
         {
            TestExeStatus="Passed";
         }
         else
         {
            TestExeStatus="Failed";
         }
           }
       catch(Exception e)
       {
           TestExeStatus="Failed";
       }
         return TestExeStatus;
     } 
    public static String Add_NewNote_Link(String InPage,WebDriver driver) throws Exception{
       try{
         if(InPage.equals("List"))
        {
         Attachmentidpart="PlaceHolderPopUp_";
        }
          else if(InPage.equals("Task Parent"))
        {
         Attachmentidpart="KovairMaster_Main_colPanel_Section_19_";
        }
        else
            Attachmentidpart="KovairMaster_Main_colPanel_Section_2_";
//        WebElement NewNote=driver.findElement(By.id(Attachmentidpart+"AttachmentID_AddNoteLbl"));
//        Assert.assertEquals(true,NewNote.isDisplayed());
          if(driver.findElements(By.id(Attachmentidpart+"AddNoteLbl")).size()==0)
         {
            TestExeStatus="Passed";
         }
         else
         {
            TestExeStatus="Failed";
         }
            }
       catch(Exception e)
       {
           TestExeStatus="Failed";
       }
		 return TestExeStatus;
    }
    public static String Add_NewNote_click(String InPage,WebDriver driver) throws Exception{
       try{
         if(InPage.equals("List"))
        {
         Attachmentidpart="PlaceHolderPopUp_";
        }
          else if(InPage.equals("Task Parent"))
        {
         Attachmentidpart="KovairMaster_Main_colPanel_Section_19_";
        }
        else
            Attachmentidpart="KovairMaster_Main_colPanel_Section_2_";  
        WebElement NewNote=driver.findElement(By.id(Attachmentidpart+"AddNoteLbl"));
        NewNote.click();
        Thread.sleep(4000);
        WebElement AddNotediv=driver.findElement(By.id(Attachmentidpart+"AddNoteContainer"));
        if(AddNotediv.isDisplayed()== true)
        {
            TestExeStatus="Passed";
        }
        else
        {
            TestExeStatus="Failed";
        }
        }
       catch(Exception e)
       {
           TestExeStatus="Failed";
       }
	return TestExeStatus;
     }
    public static String Add_NewUrl_click(String InPage,WebDriver driver) throws Exception{
       try{
         if(InPage.equals("List"))
        {
         Attachmentidpart="PlaceHolderPopUp_";
        }
          else if(InPage.equals("Task Parent"))
        {
         Attachmentidpart="KovairMaster_Main_colPanel_Section_19_";
        }
        else
            Attachmentidpart="KovairMaster_Main_colPanel_Section_2_";  
        WebElement NewNote=driver.findElement(By.id(Attachmentidpart+"NewUrlLbl"));
        NewNote.click();
        Thread.sleep(4000);
        WebElement AddNotediv=driver.findElement(By.id(Attachmentidpart+"AddURLContainer"));
        if(AddNotediv.isDisplayed()== true)
        {
            TestExeStatus="Passed";
        }
        else
        {
            TestExeStatus="Failed";
        }
        }
       catch(Exception e)
       {
           TestExeStatus="Failed";
       }
	return TestExeStatus;
     }
    public static String Add_NewFile_click(String InPage,WebDriver driver) throws Exception{
       try{
         if(InPage.equals("List"))
        {
         Attachmentidpart="PlaceHolderPopUp_";
        }
          else if(InPage.equals("Task Parent"))
        {
         Attachmentidpart="KovairMaster_Main_colPanel_Section_19_";
        }
        else
            Attachmentidpart="KovairMaster_Main_colPanel_Section_2_"; 
        WebElement NewNote=driver.findElement(By.id(Attachmentidpart+"AttachFileLbl"));
        NewNote.click();
        Thread.sleep(4000);
        WebElement AddNotediv=driver.findElement(By.id(Attachmentidpart+"AddAttachContainer"));
        if(AddNotediv.isDisplayed()== true)
        {
            TestExeStatus="Passed";
        }
        else
        {
            TestExeStatus="Failed";
        }
        }
       catch(Exception e)
       {
           TestExeStatus="Failed";
       }
	return TestExeStatus;
     }
    
     public static String add_file_without_upload(String InPage,WebDriver driver) throws Exception{
       try{
         if(InPage.equals("List"))
        {
         Attachmentidpart="PlaceHolderPopUp_";
        }
          else if(InPage.equals("Task Parent"))
        {
         Attachmentidpart="KovairMaster_Main_colPanel_Section_19_";
        }
        else
        Attachmentidpart="KovairMaster_Main_colPanel_Section_2_"; 
        WebElement name=driver.findElement(By.id(Attachmentidpart+"txtFileName"));
        name.clear();
        name.sendKeys("TestFile");  
        WebElement Save=driver.findElement(By.id(Attachmentidpart+"btnFileSave"));
        Save.click();
        Thread.sleep(1500);
        WebElement Validation_msg =driver.findElement(By.id("VALIDATOR_KovairMaster_Main_fileUploadUser_Attachment_RadAsyncUpload1"));
        if(Validation_msg.getText().trim().equals("Select a file to upload"))
        {
            TestExeStatus="Passed";
        }
        else
        {
            TestExeStatus="Failed";
        }
        }
       catch(Exception e)
       {
           TestExeStatus="Failed";
       }
	return TestExeStatus;
     }
    public static String Add_NewNoteSave_click(String textname_msg,String textnote_msg,String Verification_msg,String InPage,WebDriver driver) throws Exception{
     try{
        if(InPage.equals("List"))
        {
         Attachmentidpart="PlaceHolderPopUp_";
        }
        else if(InPage.equals("Task Parent"))
        {
         Attachmentidpart="KovairMaster_Main_colPanel_Section_19_";
        }
        else
            Attachmentidpart="KovairMaster_Main_colPanel_Section_2_";
         WebElement textname=driver.findElement(By.id(Attachmentidpart+"txtName"));
         textname.clear();
         textname.sendKeys(textname_msg);
         WebElement textnote=driver.findElement(By.id(Attachmentidpart+"txtNote"));
         textnote.clear();
         textnote.sendKeys(textnote_msg);
         WebElement Save=driver.findElement(By.id(Attachmentidpart+"btnNoteAdd"));
         Save.click();
         Thread.sleep(1000);
         KovairGenericClass.Modal_OKClick_Verification("OK",driver);
         Thread.sleep(2500);
         TestExeStatus="Passed";
         }
       catch(Exception e)
       {
           TestExeStatus="Failed";
       }
	return TestExeStatus;
     }
    
     public static String Verify_Save_click(String ItemName,String ItemType,String InPage,WebDriver driver) throws Exception{
     try{
        if(InPage.equals("List"))
        {
         Attachmentidpart="PlaceHolderPopUp_";
        }
        else if(InPage.equals("Task Parent"))
        {
         Attachmentidpart="KovairMaster_Main_colPanel_Section_19_";
        }
        else
         Attachmentidpart="KovairMaster_Main_colPanel_Section_2_";
//        driver.findElement(By.xpath("//div[@id='icon_set_bg']/table/tbody/tr/td[3]/img")).click();
//        Thread.sleep(5000);
         int i=0,j=0;
        String _item = null;
        WebElement Attachmentmentspan=null;
        int attachmentcount= driver.findElements(By.xpath("//div[@id='"+Attachmentidpart+"GridAttachment']/table[1]/tbody/tr")).size();
        if(attachmentcount != 0)
        {
            for(i=2;i<=attachmentcount;i++)
            {
                try{
                     if(ItemType =="URL")            
                     {
                         Attachmentmentspan=driver.findElement(By.xpath("//div[@id='"+Attachmentidpart+"GridAttachment']/table[1]/tbody/tr["+i+"]/td[4]/a"));
                     }
                     else 
                     { 
                         Attachmentmentspan=driver.findElement(By.xpath("//div[@id='"+Attachmentidpart+"GridAttachment']/table[1]/tbody/tr["+i+"]/td[4]/a[2]"));
                     }
                      _item=Attachmentmentspan.getText().toString().trim();
                     String ItemTypeInImg = driver.findElement(By.xpath("//div[@id='"+Attachmentidpart+"GridAttachment']/table[1]/tbody/tr["+i+"]/td[3]/img")).getAttribute("title").toString().trim();
                     if((_item.equals(ItemName))&& ItemType.equals(ItemTypeInImg))
                      {   TestExeStatus="Passed"; 
                           break;
                      }
                }
                catch(Exception e1)
                     {}
                
              }       
         }
     }
       catch(Exception e)
       {
           TestExeStatus="Failed";
       }
	return TestExeStatus;
     }
     public static String MandatoryCheck_AddNote(String InPage,String ItemType,WebDriver driver) throws Exception{
     try{
        if(InPage.equals("List"))
        {
         Attachmentidpart="PlaceHolderPopUp_";
        }
        else if(InPage.equals("Task Parent"))
        {
         Attachmentidpart="KovairMaster_Main_colPanel_Section_19_";
        }
        else
         Attachmentidpart="KovairMaster_Main_colPanel_Section_2_";
                   
        String Nametxt=null, DescTxt=null, Btn=null, validmsg1="Attachment name cannot be blank",validmsg2=null,AddBtn=null;
        if(ItemType.equals("URL"))
        {
            Btn = "URL";
            Nametxt = "txtlblURLName" ;
            DescTxt = "txtURL";
            validmsg2 = "URL cannot be blank";
            AddBtn = "NewUrlLbl";
        }
        else if(ItemType.equals("Note"))
        {
            Btn = "Note";
            Nametxt ="txtName" ;
            DescTxt = "txtNote" ;
            validmsg2 = "Attachment note cannot be blank";
            AddBtn = "AddNoteLbl";
        }
        else
        {
              AddBtn = "AttachFileLbl";
        }
        driver.findElement(By.id(Attachmentidpart+ AddBtn)).click(); 
        Thread.sleep(2000);     
        WebElement AddAttchmentlnk= driver.findElement(By.id(Attachmentidpart+"btn"+Btn+"Add"));
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", AddAttchmentlnk);
        AddAttchmentlnk.click();
        Thread.sleep(2000);//VALIDATOR_KovairMaster_Main_colPanel_Section_2_txtlblURLName 
        //KovairMaster_Main_colPanel_Section_2_txtURL  "URL cannot be blank"  "Attachment name cannot be blank"
        String NameSpan= "VALIDATOR_"+Attachmentidpart+Nametxt ;
        String NoteSpan=  "VALIDATOR_"+Attachmentidpart+DescTxt;
        if((driver.findElement(By.id(NameSpan)).getText().trim().equals(validmsg1))&&
                (driver.findElement(By.id(NoteSpan)).getText().trim().equals(validmsg2)))
        { TestExeStatus="Passed";
        }
        else
            TestExeStatus="Failed";
       } 
         catch(Exception e)
       {
           TestExeStatus="Failed";
       }
	return TestExeStatus;
     }
     public static String MaximumCharCheck(String InPage,String ItemType,WebDriver driver) throws Exception{
      try{
        String largetext ="abcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyz";
        if(InPage.equals("List"))
        {
         Attachmentidpart="PlaceHolderPopUp_";
        }
        else if(InPage.equals("Task Parent"))
        {
         Attachmentidpart="KovairMaster_Main_colPanel_Section_19_";
        }
        else
         Attachmentidpart="KovairMaster_Main_colPanel_Section_2_"; 
         String Nametxt=null, DescTxt=null, Btn=null, validmsg1="Attachment name cannot be blank",validmsg2=null,AddBtn=null;
        if(ItemType.equals("URL"))
        {
            Btn = "URL";
            Nametxt = "txtlblURLName" ;
            DescTxt = "txtURL";
            validmsg2 = "URL cannot be blank";
            AddBtn = "NewUrlLbl";
        }
        else if(ItemType.equals("NOTE"))
        {
            Btn = "Note";
            Nametxt ="txtName" ;
            DescTxt = "txtNote" ;
            validmsg2 = "Attachment note cannot be blank";
            AddBtn = "AddNoteLbl";
        }
        else
        {
              AddBtn = "AttachFileLbl";
              Nametxt = "txtFileName" ;
        }
        driver.findElement(By.id(Attachmentidpart+ AddBtn)).click(); 
        Thread.sleep(2000);     //"txtName   txtFileName  txtlblURLName
        driver.findElement(By.id(Attachmentidpart+ Nametxt)).sendKeys(largetext);
        Thread.sleep(1500);
        WebElement AddAttchmentlnk= driver.findElement(By.id(Attachmentidpart+"btn"+Btn+"Add"));
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", AddAttchmentlnk);
        AddAttchmentlnk.click();
        Thread.sleep(3000);
        WebElement Attachmentmentspan=null;
        String _item =null;
        int i,attachmentcount= driver.findElements(By.xpath("//div[@id='"+Attachmentidpart+"GridAttachment']/table[1]/tbody/tr")).size();
        if(attachmentcount != 0)
        {
            for(i=2;i<=attachmentcount;i++)
            {
                 if(ItemType =="URL")            
                 {
                     Attachmentmentspan=driver.findElement(By.xpath("//div[@id='"+Attachmentidpart+"GridAttachment']/table[1]/tbody/tr["+i+"]/td[4]/a"));
                 }
                 else  //KovairMaster_Main_colPanel_Section_2_GridAttachment         div/table[1]/tbody/tr[2]/td[4]/a[2]
                 { 
                     Attachmentmentspan=driver.findElement(By.xpath("//div[@id='"+Attachmentidpart+"GridAttachment']/table[1]/tbody/tr["+i+"]/td[4]/a[2]"));
                 }
                 _item=Attachmentmentspan.getText().toString().trim();
                 if( _item.equals(largetext.substring(0, 254)))
                  {   TestExeStatus="Passed"; 
                       break;
                  }
              }       
        }  
      }
         catch(Exception e)
       {
           TestExeStatus="Failed";
       }
	return TestExeStatus;
     }
     
      
      
    public static String Attachment_NewNote_URl_delete_click(String ItemType,String ItemText,String Verification_msg,String InPage,WebDriver driver) throws Exception
    {
       try{ 
        if(InPage.equals("List"))
        {
         Attachmentidpart="PlaceHolderPopUp_";
        }
        else if(InPage.equals("Task Parent"))
        {
         Attachmentidpart="KovairMaster_Main_colPanel_Section_19_";
        }
        else
          Attachmentidpart="KovairMaster_Main_colPanel_Section_2_";
        WebElement Attachmentmentspan=null;   
        String _item="";
        String Type="";
        String trid_tobe_deleted="";
        int i=0,j=0;
        //KovairMaster_Main_colPanel_Section_2_AttachmentID_RadGrid_AttachmentList_ctl00 //div[@id='"+Attachmentidpart+"GridAttachment']/table[1]/tbody/tr[2]/td[4]/a
        int attachmentcount= driver.findElements(By.xpath("//div[@id='"+Attachmentidpart+"GridAttachment']/table[1]/tbody/tr")).size();
        if(attachmentcount != 0)
        {
            for(i=2;i<=attachmentcount;i++)
            {
                 if(ItemType =="URL")            
                 {
                     Attachmentmentspan=driver.findElement(By.xpath("//div[@id='"+Attachmentidpart+"GridAttachment']/table[1]/tbody/tr["+i+"]/td[4]/a"));
                 }
                 else
                 { 
                     Attachmentmentspan=driver.findElement(By.xpath("//div[@id='"+Attachmentidpart+"GridAttachment']/table[1]/tbody/tr["+i+"]/td[4]/a[2]"));
                 }
                 _item=Attachmentmentspan.getText().toString().trim();
                 if(_item.equals(ItemText))
                  {                                            
                    Type=driver.findElement(By.xpath("//div[@id='"+Attachmentidpart+"GridAttachment']/table[1]/tbody/tr[2]/td[3]/img")).getAttribute("title").toString().trim();
                    WebElement Delete=driver.findElement(By.xpath("//div[@id='"+Attachmentidpart+"GridAttachment']/table[1]/tbody/tr["+i+"]/td[1]/img"));
                    Delete.click();
                    Thread.sleep(2000);
                    KovairGenericClass.Modal_OKClick_Verification("OKCANCEL",driver);
                    Thread.sleep(2000);
                    KovairGenericClass.Modal_OKClick_Verification("OK",driver);
                    Thread.sleep(2500);
                    break;
                  }
              }                
//             WebElement Delete=driver.findElement(By.id(trid_tobe_deleted));
           
             //KovairGenericClass.Modal_Text_Verification(Verification_msg,driver);
//             KovairGenericClass.Modal_OKClick_Verification("OKCANCEL",driver);
//             KovairGenericClass.Modal_OKClick_Verification("OK",driver);
//             Thread.sleep(2500);
             TestExeStatus=Attachment_NewNote_URl_delete_verify(ItemType,ItemText,InPage,driver);
        }
        }
       catch(Exception e)
       {
           TestExeStatus="Failed";
       }
	return TestExeStatus;
     }
    
    
    public static String AddURLImproperFormat(String InPage,WebDriver driver) throws Exception{
       try{
         if(InPage.equals("List"))
        {
         Attachmentidpart="PlaceHolderPopUp_";
        }
          else if(InPage.equals("Task Parent"))
        {
         Attachmentidpart="KovairMaster_Main_colPanel_Section_19_";
        }
        else
            Attachmentidpart="KovairMaster_Main_colPanel_Section_2_";         
        driver.findElement(By.id(Attachmentidpart+ "NewUrlLbl")).click(); 
        Thread.sleep(2000);     //"txtName   txtFileName  txtlblURLName
        driver.findElement(By.id(Attachmentidpart+ "txtlblURLName")).sendKeys("TestURL");
        Thread.sleep(1000);
        driver.findElement(By.id(Attachmentidpart+ "txtURL")).sendKeys("TestImproperURL");
        WebElement AddAttchmentlnk= driver.findElement(By.id(Attachmentidpart+"btnURLAdd"));
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", AddAttchmentlnk);
        AddAttchmentlnk.click();
        Thread.sleep(2000);
        String NameSpan= "VALIDATOR_"+Attachmentidpart +"txtURL" ;
        if(driver.findElement(By.id(NameSpan)).getText().trim().equals("This is not a valid url."))
            TestExeStatus="Passed";
         else
          TestExeStatus="Failed";
       }
       catch(Exception e)
       {
           TestExeStatus="Failed";
       }
		 return TestExeStatus;
    }
            
    public static String AddURLProperFormat(String InPage,WebDriver driver) throws Exception{
       try{
         if(InPage.equals("List"))
        {
         Attachmentidpart="PlaceHolderPopUp_";
        }
          else if(InPage.equals("Task Parent"))
        {
         Attachmentidpart="KovairMaster_Main_colPanel_Section_19_";
        }
        else
            Attachmentidpart="KovairMaster_Main_colPanel_Section_2_";         
        driver.findElement(By.id(Attachmentidpart+ "NewUrlLbl")).click(); 
        Thread.sleep(2000);     //"txtName   txtFileName  txtlblURLName
        driver.findElement(By.id(Attachmentidpart+ "txtlblURLName")).sendKeys("TestURL");
        Thread.sleep(1000);
        driver.findElement(By.id(Attachmentidpart+ "txtURL")).sendKeys("TestImproperURL");
        WebElement AddAttchmentlnk= driver.findElement(By.id(Attachmentidpart+"btnURLAdd"));
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", AddAttchmentlnk);
        AddAttchmentlnk.click();
        Thread.sleep(2000);
        String NameSpan= "VALIDATOR_"+Attachmentidpart +"txtURL" ;
        if(driver.findElement(By.id(NameSpan)).getText().equals("This is not a valid url."))
            TestExeStatus="Passed";
         else
          TestExeStatus="Failed";
       }
       catch(Exception e)
       {
           TestExeStatus="Failed";
       }
		 return TestExeStatus;
    }         
    public static String Attachment_NewNote_URl_delete_verify(String ItemType,String ItemText,String InPage,WebDriver driver) throws Exception{
        int res=SeacrhSpecificAttachment_trid(ItemType,ItemText,InPage,driver);
        try{
        if(res != 0)
        {
            TestExeStatus="Item has not been Deleted.Found in List after Deletion.";
        }
        else
           TestExeStatus="Passed"; 
          }
       catch(Exception e)
       {
           TestExeStatus="Failed";
       }
        return TestExeStatus;
     }
    public static int SeacrhSpecificAttachment_trid(String ItemType,String ItemText,String InPage,WebDriver driver) throws Exception{
      
        try{
        if(InPage.equals("List"))
        {
         Attachmentidpart="PlaceHolderPopUp_";//From EntityList
        }
        else if(InPage.equals("Task Parent"))
        {
         Attachmentidpart="KovairMaster_Main_colPanel_Section_19_";
        }
        else
         Attachmentidpart="KovairMaster_Main_colPanel_Section_2_";//From Form Section
        String _item="";
        String Type="";
        String tr_id=null;
        int i=0,j=0,flag=0;//PlaceHolderPopUp_GridAttachment
//        int attachmentcount= driver.findElements(By.xpath("//table[@id='"+Attachmentidpart+"AttachmentID_RadGrid_AttachmentList_ctl00']/tbody/tr")).size();
        int attachmentcount= driver.findElements(By.xpath("//div[@id='"+Attachmentidpart+"GridAttachment']/table[1]/tbody/tr")).size();
//        int attachmentcount= driver.findElements(By.xpath("//div[@id='PlaceHolderPopUp_GridAttachment']/table[1]/tbody/tr")).size();
        if (attachmentcount ==0)
        {
            return 0;
        }
        else if(ItemText == "") 
        {
           tr_id=Attachmentidpart+"AttachmentID_RadGrid_AttachmentList_ctl00__0";
           return i;  
        }
        else
        {
           for(i=2;i<=attachmentcount;i++)
            {
//                String Attachmentmentspantitle=null;
               //try
                if(ItemType =="URL")            
                 {
                    try
                    { 
                        _item = driver.findElement(By.xpath("//div[@id='"+Attachmentidpart+"GridAttachment']/table[1]/tbody/tr["+i+"]/td[4]/a")).getText().toString();
                    }
                    catch(Exception e){}
                 }
                else
                 { 
                    try
                    {
                       _item=driver.findElement(By.xpath("//div[@id='"+Attachmentidpart+"GridAttachment']/table[1]/tbody/tr["+i+"]/td[4]/a[2]")).getText().toString();
                    }
                      catch(Exception e1){}
                 }
                  if(_item.equals(ItemText))
                  {
                   Type=driver.findElement(By.xpath("//div[@id='"+Attachmentidpart+"GridAttachment']/table[1]/tbody/tr["+i+"]/td[3]/img")).getAttribute("title").toString().trim();
                   if(Type.equals(ItemType))
                   {
                    return i;  
                   }
                 }
            }
        }
          }
       catch(Exception e)
       {
           TestExeStatus="Failed";
       }
        return 0;
    }
     public static String Get_FormSection_FieldLabel_trid(String FieldLabel,WebDriver driver) throws Exception{     
        try{
          String source = "<td>" + driver.findElement(By.xpath("//table/tbody/tr/td[@id='KovairMaster_Main_colPanel_Section_5013_cellLayout_5013']")).getAttribute("innerHTML") + "</td>";       
          org.jsoup.nodes.Document doc = Jsoup.parse(source, "UTF-8");
          int i=0,j=0;
          Elements span=doc.getElementsByAttributeValueContaining("id","_Label_");
          for(org.jsoup.nodes.Element tr : span)
           {
             if(tr.text().equals(FieldLabel))
             {
                String trid=tr.attr("id").toString();
                int pos= trid.indexOf("_Label_")+7;
                String lblseq=trid.substring(pos);
                String spanid="KovairMaster_Main_colPanel_Section_5013_Field_"+lblseq+"_Section_5013";
                return spanid;
             }
           }
           }
       catch(Exception e)
       {
           TestExeStatus="Failed";
       }
          return null;      
     }
    public static String ExistingAttachmentTaskParent(String ItemType,String ItemText,String InPage,String TargetItem,WebDriver driver) throws Exception
    {      
        try{
       int x =SeacrhSpecificAttachment_trid(ItemType,ItemText,InPage,driver);
       // if(tr_id != null)
       if(x!=0)
        {
        TestExeStatus=ViewAttachment(ItemType,ItemText,"",InPage,x,driver);
//        if(TargetItem== "Entity")
//         {
//            KovairGenericClass.Form_Section_click("General",driver);
//            String id=Get_FormSection_FieldLabel_trid("Source Item",driver);
//            WebElement sourceitem=driver.findElement(By.id(id));
//            sourceitem.click();
//            KovairGenericClass.PopUp_Frame_Switch(driver);
//            KovairGenericClass.Form_Section_click("Attachments",driver);
//            String tr_id1=SeacrhSpecificAttachment_trid(ItemType,ItemText,InPage,driver);
//            if(tr_id != null )
//            {
//                TestExeStatus="Passed";
//            }
//            else
//               TestExeStatus="Attachments found in Task does not exist in Source Entity Item.";  
//         }
        }
        else
        { 
            TestExeStatus="No Pre-Existing Attachments."; 
        }
        }
       catch(Exception e)
       {
           TestExeStatus="Failed";
       }
        return TestExeStatus;
    }  
    public static String Add_NewNoteCancel_click(String InPage,WebDriver driver) throws Exception{
       try{
        if(InPage.equals("List"))
        {
         Attachmentidpart="PlaceHolderPopUp_";
        }
        else if(InPage.equals("Task Parent"))
        {
         Attachmentidpart="KovairMaster_Main_colPanel_Section_19_";
        }
        else
            Attachmentidpart="KovairMaster_Main_colPanel_Section_2_"; 
        WebElement Cancel=driver.findElement(By.id(Attachmentidpart+"btnNoteCancel"));
         Cancel.click();
         WebElement AddNotediv=driver.findElement(By.id(Attachmentidpart+"AddNoteContainerTable"));
         Assert.assertEquals(false,AddNotediv.isDisplayed());
          }
       catch(Exception e)
       {
           TestExeStatus="Failed";
       }
        return TestExeStatus;
     }
    public static String Attachment_NewNote_URl_Edit_click(String ItemType,String ItemText,String InPage,WebDriver driver) throws Exception{ 
      try{ 
        if(InPage.equals("List"))
        {
         Attachmentidpart="PlaceHolderPopUp_";
        }
        else if(InPage.equals("Task Parent"))
        {
         Attachmentidpart="KovairMaster_Main_colPanel_Section_19_";
        }
        else
          Attachmentidpart="KovairMaster_Main_colPanel_Section_2_";
        WebElement Attachmentmentspan=null;   
        String _item="";
        String Type="";
        String trid_tobe_edited="";
        int i=0,j=0;
        //KovairMaster_Main_colPanel_Section_2_AttachmentID_RadGrid_AttachmentList_ctl00
        int attachmentcount= driver.findElements(By.xpath("//div[@id='"+Attachmentidpart+"GridAttachment']/table[1]/tbody/tr")).size();
        if(attachmentcount != 0)
        {
           for(i=2;i<=attachmentcount;i++)
            {
                 if(ItemType =="URL")            
                 {
//                     Attachmentmentspan=driver.findElement(By.xpath("//tr[@id='"+Attachmentidpart+"AttachmentID_RadGrid_AttachmentList_ctl00__"+i+"']/td[4]/a"));
                       Attachmentmentspan=driver.findElement(By.xpath("//div[@id='"+Attachmentidpart+"GridAttachment']/table[1]/tbody/tr[2]/td[4]/a"));
                 }
                 else
                 { 
//                     Attachmentmentspan=driver.findElement(By.xpath("//tr[@id='"+Attachmentidpart+"AttachmentID_RadGrid_AttachmentList_ctl00__"+i+"']/td[4]/a[2]"));
                       Attachmentmentspan=driver.findElement(By.xpath("//div[@id='"+Attachmentidpart+"GridAttachment']/table[1]/tbody/tr[2]/td[4]/a[2]"));
                 }
                 _item=Attachmentmentspan.getText().toString().trim();
                  if(_item.equals(ItemText))
                  {
//                   j=(i+1)*2 +2;
//                   String index=String.valueOf(j);
//                   if(j<10)
//                       index="0"+j;
//                   Type=driver.findElement(By.xpath("//img[@id='"+Attachmentidpart+"AttachmentID_RadGrid_AttachmentList_ctl00_ctl"+index+"_imgGridImageColumn1']")).getAttribute("title").toString().trim();
//                   trid_tobe_edited=Attachmentidpart+"AttachmentID_RadGrid_AttachmentList_ctl00_ctl"+index+"_imgReplaceRowImage";
                     Type=driver.findElement(By.xpath("//div[@id='"+Attachmentidpart+"GridAttachment']/table[1]/tbody/tr["+i+"]/td[3]/img")).getAttribute("title").toString().trim();
                   break;
                  }
              }                
             WebElement Edit=driver.findElement(By.xpath("//div[@id='"+Attachmentidpart+"GridAttachment']/table[1]/tbody/tr["+i+"]/td[2]"));
             Edit.click();
             //KovairGenericClass.Modal_Text_Verification(Verification_msg,driver);
             Thread.sleep(500);	
             //TestExeStatus=Attachment_NewNote_URl_EditDataValidation(ItemType,ItemText,InPage,driver);
        }
         }
       catch(Exception e)
       {
           TestExeStatus="Failed";
       }
        return TestExeStatus;
      }
    public static String Attachment_NewNote_URl_EditDataValidation(String textname_msg,String textnote_msg,String InPage,WebDriver driver) throws Exception
    {
        String ExeStatus= null;
	String ErrDesc= null; 
       try{
        if(InPage.equals("List"))
        {
         Attachmentidpart="PlaceHolderPopUp_";
        }
         else if(InPage.equals("Task Parent"))
        {
         Attachmentidpart="KovairMaster_Main_colPanel_Section_19_";
        }
        else
           Attachmentidpart="KovairMaster_Main_colPanel_Section_2_";
         }
       catch(Exception e)
       {
           TestExeStatus="Failed";
       }
        return TestExeStatus;
    }
    public static String ViewAttachment(String ItemType,String ItemText,String NoteMsg,String InPage,int j,WebDriver driver) throws Exception
    {
        try{
        if(InPage.equals("List"))
        {
         Attachmentidpart="PlaceHolderPopUp_";
        }
        else if(InPage.equals("Task Parent"))
        {
         Attachmentidpart="KovairMaster_Main_colPanel_Section_19_";
        }
        else
            Attachmentidpart="KovairMaster_Main_colPanel_Section_2_";
        if(j==0)
          j=SeacrhSpecificAttachment_trid(ItemType,ItemText,InPage,driver);
        if(j != 0)
        {
             if(ItemType.equals(""))
             {
                ItemType =driver.findElement(By.xpath("//div[@id='"+Attachmentidpart+"GridAttachment']/div/table[1]/tbody/tr["+j+"]/td[3]/img']")).getAttribute("title").toString().trim();
             }
             WebElement Attachmentmenttitle=null;
             WebElement AttachmentDesc=null;
             if(ItemType =="URL")            
                 {
                       Attachmentmenttitle=driver.findElement(By.xpath("//div[@id='"+Attachmentidpart+"GridAttachment']/table[1]/tbody/tr["+j+"]/td[4]/a"));
                 }
                 else
                 { 
                     Attachmentmenttitle=driver.findElement(By.xpath("//div[@id='"+Attachmentidpart+"GridAttachment']/table[1]/tbody/tr["+j+"]/td[4]/a[2]"));
                 }
             Attachmentmenttitle.click(); 
             Thread.sleep(4000);
             WebElement AddAttchmentlnk =null;
             if(ItemType =="NOTE")          
              {
                 AddAttchmentlnk=driver.findElement(By.id(Attachmentidpart+"btnNoteCancel"));
                ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", AddAttchmentlnk);
                if(Attachmentmenttitle.getText().equals(ItemText))
                {  TestExeStatus="Passed";
                   AddAttchmentlnk.click();
                   Thread.sleep(3000);
                }
             }else  if(ItemType =="URL")        
             {
                  TestExeStatus="Passed";
             }          
       }
      }
       catch(Exception e)
       {
           TestExeStatus="Failed";
       }
        return TestExeStatus;
    }
      public static String EditAttachment(String ItemType,String ItemText,String NoteMsg,String modName, String ModMsg,String InPage,int j,WebDriver driver) throws Exception
    {
        try{
        if(InPage.equals("List"))
        {
         Attachmentidpart="PlaceHolderPopUp_";
        }
        else if(InPage.equals("Task Parent"))
        {
         Attachmentidpart="KovairMaster_Main_colPanel_Section_19_";
        }
        else
            Attachmentidpart="KovairMaster_Main_colPanel_Section_2_";
        if(j==0)
          j=SeacrhSpecificAttachment_trid(ItemType,ItemText,InPage,driver);
        if(j != 0)
        {
             if(ItemType.equals(""))
             {
                ItemType =driver.findElement(By.xpath("//div[@id='"+Attachmentidpart+"GridAttachment']/div/table[1]/tbody/tr["+j+"']/td[3]/img']")).getAttribute("title").toString().trim();
             }
             WebElement Attachmentmenttitle=null;
             if(ItemType =="URL")            
                 {
                       Attachmentmenttitle=driver.findElement(By.xpath("//div[@id='"+Attachmentidpart+"GridAttachment']/table[1]/tbody/tr["+j+"]/td[4]/a"));
                 }
                 else
                 { 
                     Attachmentmenttitle=driver.findElement(By.xpath("//div[@id='"+Attachmentidpart+"GridAttachment']/table[1]/tbody/tr["+j+"]/td[4]/a[2]"));
                 }
             //Attachmentmenttitle.click(); 
             driver.findElement(By.xpath("//div[@id='"+Attachmentidpart+"GridAttachment']/table[1]/tbody/tr["+j+"]/td[2]/img")).click();
             Thread.sleep(4000);
             if(ItemType =="NOTE")           
              {
                WebElement AddAttchmentlnk=driver.findElement(By.id(Attachmentidpart+"btnNoteCancel"));
               ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", AddAttchmentlnk);
                WebElement NameTxt=driver.findElement(By.id(Attachmentidpart+"txtName"));
                WebElement NoteTxt=driver.findElement(By.id(Attachmentidpart+"txtNote"));
                NameTxt.clear();
                NoteTxt.clear();
                NameTxt.sendKeys(modName);
                NoteTxt.sendKeys(ModMsg);
                driver.findElement(By.id(Attachmentidpart+"btnNoteAdd")).click();
                Thread.sleep(1000);
                KovairGenericClass.Modal_OKClick_Verification("OK",driver);
                Thread.sleep(2500);
                TestExeStatus="Passed";
              }
             else
              if(ItemType =="URL")
             {//KovairMaster_Main_colPanel_Section_2_btnURLAdd KovairMaster_Main_colPanel_Section_2_txtlblURLName
                 WebElement AddAttchmentlnk=driver.findElement(By.id(Attachmentidpart+"btnURLCancel"));
                ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", AddAttchmentlnk);
                 WebElement Nameurl=driver.findElement(By.id(Attachmentidpart+"txtlblURLName"));
                 WebElement Newurl =driver.findElement(By.id(Attachmentidpart+"txtURL")); 
                 Nameurl.clear();
                 Newurl.clear();
                 Nameurl.sendKeys(modName);
                 Newurl.sendKeys(ModMsg);
                 driver.findElement(By.id(Attachmentidpart+"btnURLAdd")).click();
                 Thread.sleep(1000);
                 KovairGenericClass.Modal_OKClick_Verification("OK",driver);
                 Thread.sleep(2500);
                 TestExeStatus="Passed";
             }
             else
              if(ItemType =="File")
                   TestExeStatus="Passed";
        }
      }
       catch(Exception e)
       {
           TestExeStatus="Failed";
       }
        return TestExeStatus;
    }
    
    public static String VerifyURLByClick(String ItemType,String ItemText,String URLName,String InPage,WebDriver driver) throws Exception{
       try{
        if(InPage.equals("List"))
        {
         Attachmentidpart="PlaceHolderPopUp_";//From EntityList
        }
        else if(InPage.equals("Task Parent"))
        {
         Attachmentidpart="KovairMaster_Main_colPanel_Section_19_";
        }
        else
         Attachmentidpart="KovairMaster_Main_colPanel_Section_2_";
         int j=SeacrhSpecificAttachment_trid(ItemType,ItemText,InPage,driver);
         WebElement Attachmentmenttitle=driver.findElement(By.xpath("//div[@id='"+Attachmentidpart+"GridAttachment']/table[1]/tbody/tr["+j+"]/td[4]/a"));
         Attachmentmenttitle.click();
         Thread.sleep(3000);
         String WindowTitle = null;
                try{ 
                for(String windowHandler : driver.getWindowHandles()){
                  driver.switchTo().window(windowHandler);
                }
                WindowTitle = driver.getCurrentUrl();        
                driver.close();
                 for(String windowHandler2 : driver.getWindowHandles()){
                  driver.switchTo().window(windowHandler2);
                 }
                }
                catch(Exception e){}
                 finally {
                            KovairGenericClass._swithchtonewframe(driver);
                       }
        if(URLName.contains("google.com"))
           URLName= URLName.replace("com", "co.in");
        if(WindowTitle.contains(URLName))
        {
         TestExeStatus="Passed";
        }else
         TestExeStatus="Failed";
       
       }
       catch(Exception e)
       {
           TestExeStatus="Failed";
       }
         return TestExeStatus;
    }
   
     public static String EditURLFunctionality(String ItemType,String ItemText,String URLName,String InPage,WebDriver driver) throws Exception{
       try{
        if(InPage.equals("List"))
        {
         Attachmentidpart="PlaceHolderPopUp_";//From EntityList
        }
        else if(InPage.equals("Task Parent"))
        {
         Attachmentidpart="KovairMaster_Main_colPanel_Section_19_";
        }
        else
         Attachmentidpart="KovairMaster_Main_colPanel_Section_2_";
        driver.findElement(By.xpath("//div[@id='"+Attachmentidpart+"GridAttachment']/table[1]/tbody/tr[2]/td[4]/a")).click();
        Thread.sleep(3000);
        String WindowTitle=null;
                try{
                for(String windowHandler : driver.getWindowHandles()){
                  driver.switchTo().window(windowHandler);
                }
                WindowTitle = driver.getCurrentUrl();        
                driver.close();
                 for(String windowHandler2 : driver.getWindowHandles()){
                  driver.switchTo().window(windowHandler2);
                 }
                }
                catch(Exception e){}
                finally {
                            KovairGenericClass._swithchtonewframe(driver);
                       }
       if(WindowTitle.contains(URLName))
       {
         TestExeStatus="Passed";
       }else
         TestExeStatus="Failed";
       }
       catch(Exception e)
       {
           TestExeStatus="Failed";
       }
        return TestExeStatus;
    }
    
   public static String Add_A_File_As_An_Attachment(String InPage,String mode,String FileName,String []FilePath,int LiId, WebDriver driver) throws Exception{
       try{
       String LiElement=null;
       if(InPage.equals("List"))
        {
         Attachmentidpart= "PlaceHolderPopUp_";
         LiElement="PlaceHolderPopUp_";
        }
       else if(InPage.equals("Task Parent"))
        {
           LiElement = "KovairMaster_Main_";
           Attachmentidpart="KovairMaster_Main_colPanel_Section_19_";
        }
        else
       {    Attachmentidpart="KovairMaster_Main_colPanel_Section_2_"; 
            LiElement = "KovairMaster_Main_";
       }
        WebElement AddAttchmentlnk= null;
        if(mode=="Add")
        {
        AddAttchmentlnk=driver.findElement(By.id(Attachmentidpart+"AttachFileLbl"));
        AddAttchmentlnk.click(); 
        Thread.sleep(3000);
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", AddAttchmentlnk);
        WebElement AddAttchmentlnk1=driver.findElement(By.id(Attachmentidpart+"btnFileCancel"));
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", AddAttchmentlnk1);
        }
        else
          FileName=  "Mod"+FileName;  
        WebElement NameFile=driver.findElement(By.id(Attachmentidpart+"txtFileName"));  
        NameFile.clear();
        NameFile.sendKeys(FileName);
        WebElement LiEle=null;                  //PlaceHolderPopUp_fileUploadUser_Attachment_RadAsyncUpload1  div/ul/li/span/input[3]
         if(InPage.equals("List"))
         {                                           //("input[id^='RelListTab_Search_']")
           LiEle=driver.findElement(By.cssSelector("li[id^='PlaceHolderPopUp_fileUploadUser_Attachment_RadAsyncUpload1row']")); 
//           LiEle=driver.findElement(By.xpath("//div[@id='"+LiElement+"fileUploadUser_Attachment_RadAsyncUpload1']/ul/li"));   
           LiEle.click();
         }
         else
         {
            LiEle=driver.findElement(By.xpath("//div[@id='"+LiElement+"fileUploadUser_Attachment_RadAsyncUpload1']/ul/li/span/input[3]"));
            Actions action = new Actions(driver).doubleClick(LiEle);
            action.build().perform();   //works for entity attachments
         }
        //Browse
//        Actions action = new Actions(driver);
//        action.moveToElement(LiEle).click().perform();
//        WebDriverWait wait = new WebDriverWait(driver, 15);
//        wait.until(ExpectedConditions.elementToBeClickable(By.id("PlaceHolderPopUp_fileUploadUser_Attachment_RadAsyncUpload1file0")));       
//        JavascriptExecutor executor = (JavascriptExecutor)driver;
//        executor.executeScript("arguments[0].click();", LiEle);
//        JavascriptExecutor js =(JavascriptExecutor)driver;
//        js.executeScript("window.scrollTo(0,"+LiEle.getLocation().y+")");
//        WebDriverWait wait = new WebDriverWait(driver, 3);
//        wait.until(ExpectedConditions.presenceOfElement(LiEle));
//        wait.until(ExpectedConditions.elementToBeClickable(LiEle));
        
        Thread.sleep(3000);
        Runtime.getRuntime().exec(FilePath);
        Thread.sleep(10000);
        driver.findElement(By.id(Attachmentidpart+"btnFileSave")).click();
        Thread.sleep(1000);
        KovairGenericClass.Modal_OKClick_Verification("OK",driver);
        Thread.sleep(2500);
        int j=0;
        if(FileName=="")
            j=1;
        j=SeacrhSpecificAttachment_trid("FILE",FileName,InPage,driver);
        if(j != 0)
            { 
                  TestExeStatus = "Passed";
            }             else
            {
                  TestExeStatus = "Passed";
            }
        }
        catch(Exception e)
        {
           TestExeStatus="Failed";
        }
        return TestExeStatus;
    }    
     public static String CancelFromEntity(String Mode,WebDriver driver) throws Exception{
       try{
          WebElement Cancel=null;
         if(Mode.equals("View"))
                 {  Cancel= driver.findElement(By.id("btnFileCancelView")); }
         else if(Mode.equals("Create"))
           Cancel= driver.findElement(By.id("aCancel"));
         Cancel.click();
         TestExeStatus="Passed";
         Thread.sleep(4000);
          }
       catch(Exception e)
       {
           TestExeStatus="Failed";
       }
        return TestExeStatus;
     }


 public static void PopupSwitch(WebDriver driver) throws Exception{
       try{
           WebElement frame = driver.findElement(By.xpath("//form/div[@unselectable='on']/table/tbody/tr/td/iframe"));
           driver.switchTo().frame(frame);
          }
       catch(Exception e)
          {
//           TestExeStatus="Failed";
          }
   }
 
   public static String Add_A_File_As_An_Attachment_EntityList(String InPage,String mode,String FileName,String []FilePath, WebDriver driver) throws Exception{
       try{
       String LiElement=null;
       if(InPage.equals("List"))
        {
         Attachmentidpart= "PlaceHolderPopUp_";
         LiElement="PlaceHolderPopUp_";
        }
       else if(InPage.equals("Task Parent"))
        {
         Attachmentidpart="KovairMaster_Main_colPanel_Section_19_";
        }
        else
       { Attachmentidpart="KovairMaster_Main_colPanel_Section_2_"; 
            LiElement = "KovairMaster_Main_";
       }
        WebElement AddAttchmentlnk= null;
        if(mode=="Add")
        {
        AddAttchmentlnk=driver.findElement(By.id(Attachmentidpart+"AttachFileLbl"));
        AddAttchmentlnk.click(); 
        Thread.sleep(3000);
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", AddAttchmentlnk);
        WebElement AddAttchmentlnk1=driver.findElement(By.id(Attachmentidpart+"btnFileCancel"));
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", AddAttchmentlnk1);
        }
        else
          FileName=  "Mod"+FileName;  
        WebElement NameFile=driver.findElement(By.id(Attachmentidpart+"txtFileName"));  
        NameFile.clear();
        NameFile.sendKeys(FileName);
        WebElement LiEle=null;                  //PlaceHolderPopUp_fileUploadUser_Attachment_RadAsyncUpload1  div/ul/li/span/input[3]
         if(InPage.equals("List"))
         {                                           //("input[id^='RelListTab_Search_']")
           LiEle=driver.findElement(By.cssSelector("li[id^='PlaceHolderPopUp_fileUploadUser_Attachment_RadAsyncUpload1row']")); 
//           LiEle=driver.findElement(By.xpath("//div[@id='"+LiElement+"fileUploadUser_Attachment_RadAsyncUpload1']/ul/li"));   
           LiEle.click();
         }
         else
         {
            LiEle=driver.findElement(By.xpath("//div[@id='"+LiElement+"fileUploadUser_Attachment_RadAsyncUpload1']/ul/li/span/input[3]"));
            Actions action = new Actions(driver).doubleClick(LiEle);
            action.build().perform();   //works for entity attachments
         }
        //Browse
//        Actions action = new Actions(driver);
//        action.moveToElement(LiEle).click().perform();
//        WebDriverWait wait = new WebDriverWait(driver, 15);
//        wait.until(ExpectedConditions.elementToBeClickable(By.id("PlaceHolderPopUp_fileUploadUser_Attachment_RadAsyncUpload1file0")));       
//        JavascriptExecutor executor = (JavascriptExecutor)driver;
//        executor.executeScript("arguments[0].click();", LiEle);
//        JavascriptExecutor js =(JavascriptExecutor)driver;
//        js.executeScript("window.scrollTo(0,"+LiEle.getLocation().y+")");
//        WebDriverWait wait = new WebDriverWait(driver, 3);
//        wait.until(ExpectedConditions.presenceOfElement(LiEle));
//        wait.until(ExpectedConditions.elementToBeClickable(LiEle));
        
        Thread.sleep(3000);
        Runtime.getRuntime().exec(FilePath);
        Thread.sleep(10000);
        driver.findElement(By.id(Attachmentidpart+"btnFileSave")).click();
        Thread.sleep(1000);
        KovairGenericClass.Modal_OKClick_Verification("OK",driver);
        Thread.sleep(2500);
        int j=0;
        if(FileName=="")
            j=1;
        j=SeacrhSpecificAttachment_trid("FILE",FileName,InPage,driver);
        if(j != 0)
            { 
                  TestExeStatus = "Passed";
            }             else
            {
                  TestExeStatus = "Passed";
            }
        }
        catch(Exception e)
        {
           TestExeStatus="Failed";
        }
        return TestExeStatus;
    }    
}
