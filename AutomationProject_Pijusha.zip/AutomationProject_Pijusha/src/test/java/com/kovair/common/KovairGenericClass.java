/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.kovair.common;

import java.util.regex.Pattern;
import java.util.concurrent.TimeUnit;
//import java.util.ArrayList;_
//import org.junit.*;
//import static org.junit.Assert.*;
//import static org.hamcrest.CoreMatchers.*;
import org.openqa.selenium.*;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.chrome.ChromeDriver;
//import org.openqa.selenium.support.ui.Select;
import java.text.SimpleDateFormat;
import java.util.Date;
import org.jsoup.select.Elements;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.openqa.selenium.interactions.Actions;

import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import au.com.bytecode.opencsv.CSVWriter;

//import org.w3c.dom.Document;
//import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import java.io.File;
import java.io.FileWriter;
import java.sql.CallableStatement;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.HasInputDevices;
import org.openqa.selenium.interactions.Mouse;
import org.openqa.selenium.internal.Locatable;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

//////////////////////
/**
 *
 * @author priyankad
 */
public class KovairGenericClass {

    public static String TestExeStatus = null;
    public static String TestErrDesc = null;
    public static String baseUrl = "http://192.168.2.17/kovair7";
    public static int runId = 0;
    public static String Solution = null;
    public static WebDriver driver;
    public static int lastItemID = 0;
    public static String BrowserProperty = null;
    public static String ChromedriverPath = System.getProperty("user.dir") + "//src/test/java/com/kovair/Chromedriver/chromedriver.exe";
    public static String URL = null;
    public static String UserId = null;
    public static String Password = null;
    public static String Workspace = null;
    public static String CurrentPageName = "";
    
    static DesiredCapabilities dr = null;

    /*public static void set_browserProperty (){
     BrowserProperty = browserProperty==null ? getBrowserDetail(null) : browserProperty;
     }
     public static String get_browserProperty() {
     return BrowserProperty;
     }*/
    public static void setClipboardData(String string) {
        StringSelection stringSelection = new StringSelection(string);
        Toolkit.getDefaultToolkit().getSystemClipboard().setContents(stringSelection, null);
    }

    public static WebDriver launchBrowser(String _browser) throws Exception {
//        dr=DesiredCapabilities.chrome();
//       //dr.setCapability(ChromeOptions.CAPABILITY, options);  
//        dr.setBrowserName("chrome");
//        dr.setPlatform(Platform.VISTA);
//        WebDriver driver=new RemoteWebDriver(new URL("http://192.168.2.124:4446/wd/hub"), dr);

        System.setProperty("webdriver.chrome.driver", ChromedriverPath);

        if (_browser.equals("IE")) {
            // driver = new InternetExplorerDriver();
            driver = null;
        }
        if (_browser.equals("Chrome")) {
            ChromeOptions options = new ChromeOptions();
           options.addArguments("disable-infobars");
           driver = new ChromeDriver(options);
          //  driver = new ChromeDriver();
        } else if (_browser.equals("Firefox")) {
            driver = new FirefoxDriver();
        }
        driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
        driver.manage().window().maximize();
        Thread.sleep(2000);
        getBrowserDetail(driver);
        return driver;
    }

    public static String getBrowserDetail(WebDriver _driver) {

        driver = _driver == null ? driver : _driver;

        String browser_version = null;

        Capabilities cap = ((RemoteWebDriver) driver).getCapabilities();
        String browsername = cap.getBrowserName();
        /*Properties Browser = new Properties();
         Browser.put("Name", browsername);*/
        // IE Version number
        if ("internet explorer".equalsIgnoreCase(browsername)) {
            String uAgent = (String) ((JavascriptExecutor) driver).executeScript("return navigator.userAgent;");
            //System.out.println(uAgent);
            //uAgent return as "MSIE 8.0 Windows" for IE8
            if (uAgent.contains("MSIE") && uAgent.contains("Windows")) {
                browser_version = uAgent.substring(uAgent.indexOf("MSIE") + 5, uAgent.indexOf("Windows") - 2);
            } else if (uAgent.contains("Trident/7.0")) {
                browser_version = "11.0";
            } else {
                browser_version = "0.0";
            }
        } else {
            //Firefox and Chrome
            browser_version = cap.getVersion();// .split(".")[0];
        }

        //Browser.put("Version", browser_version);
        BrowserProperty = browsername + " : " + browser_version;
        return BrowserProperty;
    }
    public static void switchToTab(String tabName, WebDriver driver) throws Exception {
        driver.switchTo().defaultContent();
        int tabCount = driver.findElements(By.xpath("//*[@id=\"tblTabContainer\"]/tbody/tr/td[1]/ul/li")).size();
        String frameid = "";
        int flag = 0;
        if (tabCount > 0) {
            try {
                for (int i = 1; i <= tabCount - 1; i++) {
                    if (driver.findElement(By.xpath("//*[@id=\"tblTabContainer\"]/tbody/tr/td[1]/ul/li[" + i + "]/span")).getAttribute("Title").equals(tabName)) {
                        driver.findElement(By.xpath("//*[@id=\"tblTabContainer\"]/tbody/tr/td[1]/ul/li[" + i + "]/span")).click();
                        Thread.sleep(5000);
                        frameid = driver.findElement(By.xpath("//*[@id=\"tblTabContainer\"]/tbody/tr/td[1]/ul/li[" + i + "]")).getAttribute("count");
                        frameid = "cc" + frameid;
                        driver.switchTo().frame(frameid);
                        flag = 1;
                        break;
                    }
                }
                if (flag == 0) {
                    try {
                        driver.findElement(By.id("Img5")).click();
                        //driver.findElement(By.cssSelector("div[id='dropDownTabsContainer']/div/ul/li/a[title*='"+TabName+"']")).click();
                        driver.findElement(By.cssSelector("a[title*='" + tabName + "'][class='textEllipsis breadcrumbSpanFloat tabWidth_span']")).click();
                        switchToTab(tabName, driver);
                    } catch (Exception ex) {
                        throw new Exception("Specified tab does not exist");
                    }
                }
            } catch (Exception e) {
                throw new Exception(e.getMessage());
            }
        } else {
            throw new Exception("No tabs found");
        }
    }
    public static int GetRecordCountForFilter(String FilterId, String EntityTypeId, String FilterType, String ConditionFieldType, String Projectid) throws Exception {

        int filterRelatedRecordCount = 0;
        if (!FilterType.equals("Advanced")) {
            try {
                //for entity
                String result[][] = getSQLresult("select 'select count(*) from tEntityItem where EntityTypeID='+cast('" + EntityTypeId + "' as varchar)+' and ISNULL(RecordStatus,''A'') = ''A'' and '+replace(SQL,'$FIELDVALUE$',Value2) from tFilterConditionLines where FilterId='" + FilterId + "'");

                //for task
                String result1[][] = getSQLresult("select 'select count(*) from tTask where ProjectID='+cast('" + Projectid + "' as varchar)+' and ISNULL(RecordStatus,''A'') = ''A'' and '+replace(SQL,'$FIELDVALUE$',Value2) from tFilterConditionLines where FilterId='" + FilterId + "'");

                //if entity
                if (!EntityTypeId.equals("0")) {
                    
//                     if(ConditionFieldType.equals("Lookup")){
//                        result = getSQLresult("select 'select count(*) from tEntityItem where EntityTypeID='+cast('" + EntityTypeId + "' as varchar)+' and ISNULL(RecordStatus,''A'') = ''A'' and '+replace(ExpressionExecSQL,'$PROJECTID$','"+Projectid+"') from tFilter where FilterId='" + FilterId + "'");
//                    }
                    if (ConditionFieldType.equals("MLT") || ConditionFieldType.equals("HTML")) {
                        result = getSQLresult("select 'select count(*) from tEntityItem left join tEntityItemMLData on tEntityItem.ItemId = tEntityItemMLData.ItemId where EntityTypeID='+cast('" + EntityTypeId + "' as varchar)+' and ISNULL(RecordStatus,''A'') = ''A'' and '+replace(SQL,'$FIELDVALUE$',Value2) from tFilterConditionLines where FilterId='"+FilterId+"'");
                    }
                    
                    
                    
                    if (result[0][0] != null) {
                        String sql = result[0][0];
                        String rawValue[][] = getSQLresult(sql);
                        filterRelatedRecordCount = rawValue != null ? Integer.parseInt(rawValue[0][0]) : 0;
                    }

                } //if task
                
                
                
                else if (EntityTypeId.equals("0")) {
                    
//                    if(ConditionFieldType.equals("Lookup")){
//                        result1 = getSQLresult("select 'select count(*) from tTask where tTask.ProjectID='+cast('" + Projectid + "' as varchar)+' and  ISNULL(RecordStatus,''A'') = ''A'' and '+replace(ExpressionExecSQL,'$PROJECTID$','"+Projectid+"') from tFilter where FilterId='" + FilterId + "'");
//                    }
                    if (ConditionFieldType.equals("MLT") || ConditionFieldType.equals("HTML") ) {
                        result1 = getSQLresult("select 'select count(*) from tTask left join tTaskMLData on tTask.ItemId = tTaskMlData.ItemId where tTask.ProjectID='+cast('"+Projectid+"' as varchar)+' and ISNULL(RecordStatus,''A'') = ''A'' and '+replace(SQL,'$FIELDVALUE$',Value2) from tFilterConditionLines where FilterId='"+FilterId+"'");
                      
                    }
                    
                    
                    
                    
                    
                    if (result1[0][0] != null) {
                        String sql = result1[0][0];
                        String rawValue[][] = getSQLresult(sql);
                        filterRelatedRecordCount = rawValue != null ? Integer.parseInt(rawValue[0][0]) : 0;
                    }

                }
            } catch (Exception e) {
                System.out.println("Error:=" + e.getMessage());
            }
        } else {
            try {
                //for entity
                String result[][] = getSQLresult("select 'select count(*) from tEntityItem where EntityTypeID='+cast('" + EntityTypeId + "' as varchar)+' and ISNULL(RecordStatus,''A'') = ''A'' and '+ExpressionExecSQL from tFilter where FilterId='" + FilterId + "'");
                // for task
                String result1[][] = getSQLresult("select 'select count(*) from tTask where ProjectID='+cast('" + Projectid + "' as varchar)+' and  ISNULL(RecordStatus,''A'') = ''A'' and '+ExpressionExecSQL from tFilter where FilterId='" + FilterId + "'");

                //for entity
                if (!EntityTypeId.equals("0")) {
                    if(ConditionFieldType.equals("Lookup")){
                        result = getSQLresult("select 'select count(*) from tEntityItem where EntityTypeID='+cast('" + EntityTypeId + "' as varchar)+' and ISNULL(RecordStatus,''A'') = ''A'' and '+replace(ExpressionExecSQL,'$PROJECTID$','"+Projectid+"') from tFilter where FilterId='" + FilterId + "'");
                    }
                    if (ConditionFieldType.equals("MLT") || ConditionFieldType.equals("HTML")) {
                        result = getSQLresult("select 'select count(*) from tEntityItem left join tEntityItemMLData on tEntityItem.ItemID = tEntityItemMLData.ItemID where EntityTypeID='+cast('" + EntityTypeId + "' as varchar)+' and ISNULL(RecordStatus,''A'') = ''A'' and '+ExpressionExecSQL from tFilter where FilterId='" + FilterId + "'");
                    }
                    if (result[0][0] != null) {
                        String sql = result[0][0];
                        String rawValue[][] = getSQLresult(sql);
                        filterRelatedRecordCount = rawValue != null ? Integer.parseInt(rawValue[0][0]) : 0;
                    }

                }

                //for task
                if (EntityTypeId.equals("0")) {
                    if(ConditionFieldType.equals("Lookup")){
                        result1 = getSQLresult("select 'select count(*) from tTask where tTask.ProjectID='+cast('" + Projectid + "' as varchar)+' and  ISNULL(RecordStatus,''A'') = ''A'' and '+replace(ExpressionExecSQL,'$PROJECTID$','"+Projectid+"') from tFilter where FilterId='" + FilterId + "'");
                    }
                    if (ConditionFieldType.equals("MLT") || ConditionFieldType.equals("HTML") ) {
                        result1 = getSQLresult("select 'select count(*) from tTask left join tTaskMLData on tTask.ItemID = tTaskMLData.ItemID where tTask.ProjectID='+cast('" + Projectid + "' as varchar)+' and  ISNULL(RecordStatus,''A'') = ''A'' and '+ExpressionExecSQL from tFilter where FilterId='" + FilterId + "'");
                    }
                    if (result1[0][0] != null) {
                        String sql = result1[0][0];
                        String rawValue[][] = getSQLresult(sql);
                        filterRelatedRecordCount = rawValue != null ? Integer.parseInt(rawValue[0][0]) : 0;
                    }

                }
            } catch (Exception e) {

                System.out.println("Error:=" + e.getMessage());
            }
        }

        return filterRelatedRecordCount;
    }
    public static int GetRecordCountForFilter(String FilterId, String EntityTypeId, String FilterType, String Projectid) throws Exception {

        int filterRelatedRecordCount = 0;
        if (!FilterType.equals("Advanced")) {
            try {
                //for entity
                String result[][] = getSQLresult("select 'select count(*) from tEntityItem where EntityTypeID='+cast('" + EntityTypeId + "' as varchar)+' and ISNULL(RecordStatus,''A'') = ''A'' and '+replace(SQL,'$FIELDVALUE$',Value2) from tFilterConditionLines where FilterId='" + FilterId + "'");
                
                //for task
                String result1[][] = getSQLresult("select 'select count(*) from tTask where ProjectID='+cast('" + Projectid + "' as varchar)+' and ISNULL(RecordStatus,''A'') = ''A'' and '+replace(SQL,'$FIELDVALUE$',Value2) from tFilterConditionLines where FilterId='" + FilterId + "'");
                
                //if entity
                if (!EntityTypeId.equals("0")) {
                    if (result[0][0] != null) {
                        String sql = result[0][0];
                        String rawValue[][] = getSQLresult(sql);
                        filterRelatedRecordCount = rawValue != null ? Integer.parseInt(rawValue[0][0]) : 0;
                    }

                } 
                //if task
                else if (EntityTypeId.equals("0")) {
                    if (result1[0][0] != null) {
                        String sql = result1[0][0];
                        String rawValue[][] = getSQLresult(sql);
                        filterRelatedRecordCount = rawValue != null ? Integer.parseInt(rawValue[0][0]) : 0;
                    }

                }
            } catch (Exception e) {
            System.out.println("Error:="+e.getMessage());
            }
        } else {
            try {
                //for entity
                String result[][] = getSQLresult("select 'select count(*) from tEntityItem where EntityTypeID='+cast('" + EntityTypeId + "' as varchar)+' and ISNULL(RecordStatus,''A'') = ''A'' and '+ExpressionExecSQL from tFilter where FilterId='" + FilterId + "'");
                // for task
                String result1[][] = getSQLresult("select 'select count(*) from tTask where ProjectID='+cast('" + Projectid + "' as varchar)+' and  ISNULL(RecordStatus,''A'') = ''A'' and '+ExpressionExecSQL from tFilter where FilterId='" + FilterId + "'");
                
                //for entity
                if (!EntityTypeId.equals("0")) {
                    if (result[0][0] != null) {
                        String sql = result[0][0];
                        String rawValue[][] = getSQLresult(sql);
                        filterRelatedRecordCount = rawValue != null ? Integer.parseInt(rawValue[0][0]) : 0;
                    }

                }

                //for task
                if (EntityTypeId.equals("0")) {
                    if (result1[0][0] != null) {
                        String sql = result1[0][0];
                        String rawValue[][] = getSQLresult(sql);
                        filterRelatedRecordCount = rawValue != null ? Integer.parseInt(rawValue[0][0]) : 0;
                    }

                }
            } catch (Exception e) {
            
            System.out.println("Error:="+e.getMessage());
            }
        }

        return filterRelatedRecordCount;
    }
     public static Object[] getApplicationDbInfo(File Filepath) throws Exception {
        Object[] logdata = new Object[7];
        DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
        org.w3c.dom.Document doc = dBuilder.parse(Filepath);
        doc.getDocumentElement().normalize();
        //System.out.println("Root element :" + doc.getDocumentElement().getNodeName());

        if (sqlConnection.RunId == 0) {
            sqlConnection.sqlGetRunId();
        }
        runId = sqlConnection.RunId;
        if (sqlConnection.Solution == null) {
            String query = "select Solution from RunIdDetails where RunID=" + runId;
            String[][] res = getSQLresult(query);
            if (res != null) {
                Solution = res[0][0];
            } else {
                Solution = sqlConnection.DefaultSolution;
            }
        } else {
            Solution = sqlConnection.Solution;
        }
        NodeList _DataList = doc.getElementsByTagName("Build");
        for (int _temp = 0; _temp < _DataList.getLength(); _temp++) {
            Node _nNode = _DataList.item(_temp);
            if (_nNode.getNodeType() == Node.ELEMENT_NODE) {
                org.w3c.dom.Element _eElement = (org.w3c.dom.Element) _nNode;
                String Sol = _eElement.getAttribute("Solution").toString().trim();
                if (Sol.trim().contains(Solution)) {
                    NodeList DataList = _eElement.getElementsByTagName("DataBase");
                    for (int temp = 0; temp < DataList.getLength(); temp++) {
                        Node nNode = DataList.item(temp);
                        if (nNode.getNodeType() == Node.ELEMENT_NODE) {
                            String nodeType = nNode.getAttributes().getNamedItem("type").getNodeValue();
                            if(nodeType.equals("Application DataBase"))
                            {
                                org.w3c.dom.Element eElement = (org.w3c.dom.Element) nNode;
                                logdata[0] = eElement.getElementsByTagName("DBType").item(0).getTextContent();
                                
                                logdata[1] = eElement.getElementsByTagName("ServerIP").item(0).getTextContent();
                                logdata[2] = eElement.getElementsByTagName("ServerName").item(0).getTextContent();
                                
                                logdata[3] = eElement.getElementsByTagName("Port").item(0).getTextContent();;
                                logdata[4] = eElement.getElementsByTagName("DataBaseName").item(0).getTextContent();
                                logdata[5] = eElement.getElementsByTagName("DBUserName").item(0).getTextContent();
                                logdata[6] = eElement.getElementsByTagName("DBPassword").item(0).getTextContent();
                                return logdata;
                            }
                        }
                    }
                }
            }
        }
        return logdata;
    }
    public static String[][] GetAttachmentCountForTask(String RecName) throws Exception{
//        int filterRelatedRecordCount = 0;
        String rawValue[][]=null;
        try {
           String result[][] = getSQLresult("select AttachmentName,Description, AttachmentType  from tAttachment where ObjectID=(select ParentItemID from tentityItem where  title='"+RecName+"')");
           if(result[0][0] != null){
//               String sql = result[0][0];
               rawValue =result;
//               rawValue = getSQLresult(sql);
//               filterRelatedRecordCount = rawValue != null ? Integer.parseInt(rawValue[0][0]) : 0;
           }
        } 
        
        catch (Exception e1) {
        }
        return rawValue;
    }
    public static Object[] LoginInfo(File Filepath) throws Exception {
        Object[] logdata = new Object[5];
        DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
        org.w3c.dom.Document doc = dBuilder.parse(Filepath);
        doc.getDocumentElement().normalize();
        //System.out.println("Root element :" + doc.getDocumentElement().getNodeName());

        if (sqlConnection.RunId == 0) {
            sqlConnection.sqlGetRunId();
        }
        runId = sqlConnection.RunId;
        if (sqlConnection.Solution == null) {
            String query = "select Solution from RunIdDetails where RunID=" + runId;
            String[][] res = getSQLresult(query);
            if (res != null) {
                Solution = res[0][0];
            } else {
                Solution = sqlConnection.DefaultSolution;
            }
        } else {
            Solution = sqlConnection.Solution;
        }
        NodeList _DataList = doc.getElementsByTagName("Build");
        for (int _temp = 0; _temp < _DataList.getLength(); _temp++) {
            Node _nNode = _DataList.item(_temp);
            if (_nNode.getNodeType() == Node.ELEMENT_NODE) {
                org.w3c.dom.Element _eElement = (org.w3c.dom.Element) _nNode;
                String Sol = _eElement.getAttribute("Solution").toString().trim();
                if (Sol.trim().contains(Solution)) {
                    NodeList DataList = _eElement.getElementsByTagName("URLSite");
                    for (int temp = 0; temp < DataList.getLength(); temp++) {
                        Node nNode = DataList.item(temp);
                        if (nNode.getNodeType() == Node.ELEMENT_NODE) {
                            org.w3c.dom.Element eElement = (org.w3c.dom.Element) nNode;
                            logdata[0] = eElement.getElementsByTagName("URL").item(0).getTextContent();
                            UserId = eElement.getElementsByTagName("UserId").item(0).getTextContent();
                            logdata[1] = UserId;
                            logdata[2] = eElement.getElementsByTagName("Password").item(0).getTextContent();
                            Workspace = eElement.getElementsByTagName("Workspace").item(0).getTextContent();;
                            logdata[3] = Workspace;
                            logdata[4] = eElement.getElementsByTagName("Browser").item(0).getTextContent();
                            return logdata;
                        }
                    }
                }
            }
        }
        return logdata;
    }

    public static String login(String URL, String UserId, String Password, String Workspace, WebDriver driver) throws Exception {
        try {
            driver.get(URL);
            baseUrl = URL;
            driver.manage().window().maximize();
            driver.findElement(By.id("USERNAME")).sendKeys(UserId);
            driver.findElement(By.id("PWD")).sendKeys(Password);
            driver.findElement(By.id("Button1")).click();
            Thread.sleep(3000);
            try {
                WebDriverWait wait = new WebDriverWait(driver, 5);
                wait.until(ExpectedConditions.invisibilityOfElementLocated(By.id("img_loading")));
            } catch (Exception ex) {
            }

            TestExeStatus = "Passed";
        } catch (Exception e) {
            TestExeStatus = "Login failed for Invalid Dataset.";
        }
        return TestExeStatus;
    }

    public static String logout(WebDriver driver) throws Exception {
        try {
            driver.switchTo().defaultContent();
            String text = "Logout";
            driver.findElement(By.id("UserDrp_imgDrp")).click();
            WebElement Logout_btn = driver.findElement(By.xpath("//div[@id='UserDrp_mainDiv']/div/ul/li/div/span[@title='" + text + "']"));
            if (Logout_btn.isDisplayed()) {
                Logout_btn.click();
                TestExeStatus = "Passed";
            } else {
                TestExeStatus = "Logout option is not available from application.";
            }
        } catch (Exception e) {
            TestExeStatus = "Page Level Error";
        }
        return TestExeStatus;
    }

    public static void Workspace_Selection(String Workspace, WebDriver driver) throws Exception {
        try {
            WebDriverWait wait = new WebDriverWait(driver, 30);
            wait.until(ExpectedConditions.invisibilityOfElementLocated(By.id("img_loading")));
            //ddlHD_DivSearch
            driver.findElement(By.id("ddlHD_imgDrp")).click();
            WebElement project = driver.findElement(By.xpath("//div[@id='ddlHD_mainDiv']/div/ul/li/div/span[@title='" + Workspace + "']"));
            ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", project);
            project.click();
        } catch (Exception e) {
            TestExeStatus = "Workspace Dropdown is not present.";
        }
    }

    public static void Workspace_Setup_click(WebDriver driver) throws Exception {
        WebDriverWait wait = new WebDriverWait(driver, 30);
        try {
            wait.until(ExpectedConditions.invisibilityOfElementLocated(By.id("img_loading")));
        } catch (Exception e) {
        }
        //driver.findElement(By.xpath("//div[@id='div_icon']/ul/li/a")).click();
        driver.findElement(By.id("ddlHD_txtSearch")).click();
    }

    public static String[][] AllWorkspaceEntities(String Project, WebDriver driver) throws Exception {
        String[][] _entity = null;
        String query = "select A.ProjectID,B.EntityTypeID,B.PluralName from tentity B inner join tentityprojects C on C.EntityTypeId=B.EntityTypeId "
                + "inner join tproject A on A.ProjectId=C.ProjectId where A.title like '%" + Project + "%' and B.RecordStatus <> 'D'";
        _entity = getSQLresult(query);
        return _entity;
    }

    public static void Site_Setup_click(WebDriver driver) throws Exception {
        try {
            WebDriverWait wait = new WebDriverWait(driver, 10);
            wait.until(ExpectedConditions.invisibilityOfElementLocated(By.id("img_loading")));
            driver.switchTo().defaultContent();
            //driver.findElement(By.xpath("//div[@id='div_icon']/ul/li[2]/a")).click();
            driver.findElement(By.xpath(".//*[@id='div_icon']/img")).click();
            Thread.sleep(2000);
            driver.findElement(By.xpath(".//*[@id='LiSite']/a")).click();
            
        } catch (Exception e) {
        }
    }

    public static String Menu_Clicked(String MenuText, WebDriver driver) throws Exception {
        String MenuFrameId = null;
        try {
            WebElement Menu = null;
            Menu = driver.findElement(By.xpath("//div[@id='MenuContainer']/div/h2/a[@title='" + MenuText + "']"));
            MenuFrameId = Menu.getAttribute("id").toString().replace("Menu_a", "cc");
            ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", Menu);
            Menu.click();
            Thread.sleep(3000);
        } catch (Exception e) {
        }
        return MenuFrameId;
    }
    
    public static int GetRecordCountForRunTimeUpdate(String FilterId, String EntityTypeId, String Value) throws Exception {
        int filterRelatedRecordCount = 0;
        try {
            String result[][] = getSQLresult("select 'select count(*) from tEntityItem where EntityTypeID='+cast('" + EntityTypeId + "' as varchar)+' and ISNULL(RecordStatus,''A'') = ''A'' and '+replace(SQL,'$FIELDVALUE$'," + Value + ") from tFilterConditionLines where FilterId='" + FilterId + "'");
            if (result[0][0] != null) {
                String sql = result[0][0];
                String rawValue[][] = getSQLresult(sql);
                filterRelatedRecordCount = rawValue != null ? Integer.parseInt(rawValue[0][0]) : 0;
            }
        } catch (Exception e) {
        }
        return filterRelatedRecordCount;
    }

    public static String _getFrameIdfromSubmenu(String MenuText, String SubMenuText, WebDriver driver) throws Exception {
        WebElement Menu = null;
        String Submenu_pageframeid = null;
        driver.switchTo().defaultContent();
        Menu = driver.findElement(By.xpath("//div[@id='MenuContainer']/div/h2/a[@title='" + MenuText + "']"));
        String Submenudiv_Id = Menu.getAttribute("id").toString().replace("Menu_a", "Menu_subMenucontainer");
        try {
            WebElement submenudiv = driver.findElement(By.id(Submenudiv_Id));
            int Submenu_atagsize = driver.findElements(By.xpath("//div[@id='" + Submenudiv_Id + "']/ul/li/a")).size();
            for (int j = 0; j < Submenu_atagsize; j++) {
                WebElement Submenu_atag = driver.findElements(By.xpath("//div[@id='" + Submenudiv_Id + "']/ul/li/a")).get(j);
                Thread.sleep(2000);
                if (Submenu_atag.getAttribute("text").toString().trim().contains(SubMenuText)) {
                    Submenu_pageframeid = Submenu_atag.getAttribute("id").toString();
                    Submenu_pageframeid = Submenu_pageframeid.replace("Menu_a", "cc");
                    break;
                }
            }
            return Submenu_pageframeid;
        } catch (Exception e) {
            return null;
        }
    }

    public static String SpecificMenu_SubMenu_Clicked(String MenuSubMenuText, WebDriver driver) throws Exception {
        String MenuFrameId = null;
        String ExecStatus = null;
        WebElement Menu = null;
        try {
            WebDriverWait wait = new WebDriverWait(driver, 10);
            wait.until(ExpectedConditions.invisibilityOfElementLocated(By.id("img_loading")));
        } catch (Exception ex) {
            Thread.sleep(5000);
        }

        try {
            //Menu = driver.findElement(By.xpath("//div[@id='MenuContainer']/div/h2/a[@title='" + MenuSubMenuText + "']"));
            //Menu = driver.findElement(By.xpath("//div[@id='MenuContainer']/div/h2/a[contains(@title,'" + MenuSubMenuText + "')]"));
            // Menu.click();
            int menuCount = driver.findElements(By.xpath("//div[@id='MenuContainer']/div/h2")).size();
            String EntityName = MenuSubMenuText;
            System.out.println("The required string in kovairGenericClass is " + EntityName);
            for (int i = 1; i <= menuCount; i++) {
                Menu = driver.findElement(By.xpath("//div[@id='MenuContainer']/div/h2[" + i + "]/a"));
                String EntityName1 = Menu.getAttribute("title");
                if (EntityName1.equals(EntityName)) {
                    ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", Menu);
                    Menu.click();
                    break;
                }

            }
            MenuFrameId = Menu.getAttribute("id").toString().replace("Menu_a", "cc");
            WebElement _MenuFrameId = driver.findElement(By.id(MenuFrameId));
            driver.switchTo().frame(_MenuFrameId);
            System.out.println(_MenuFrameId);
            //int tabcount= driver.findElements(By.xpath("//div[@id='tabHolder']/p")).size();
            //System.out.println("The required p count is " +tabcount);
            //   String frameid="cc7159_0_7329";
            //for(int i=1;i<=tabcount;i++)
            //{
            //WebElement gh=driver.findElement(By.xpath("//div[@id='tabHolder']/p["+i+"]/iframe"));
            // WebElement gh=driver.findElement(By.xpath("//iframe[@id='cc36_36_0_2']"));
            // MenuFrameId= gh.getAttribute("id");
            //  if(MenuFrameId.equals(frameid))
            //{
            // System.out.println("The name of the iframe is" + MenuFrameId);
            //driver.switchTo().frame(MenuFrameId);
            //  break;
            //  }
            // }
            ExecStatus = "Passed";
        } catch (Exception e) {
            int menuCount = driver.findElements(By.xpath("//div[@id='MenuContainer']/div/h2")).size();
            int countUserDefinedMenu = 0;
            for (int i = 1; i <= menuCount; i++) {
                Menu = driver.findElement(By.xpath("//div[@id='MenuContainer']/div/h2[" + i + "]/a"));
                String HasLink = null;
                try {
                    HasLink = Menu.getAttribute("nolnk").toString();
                } catch (Exception e1) {
                    continue;
                }
                if (HasLink.trim().equals("Y")) {
                    WebElement h_Menu = driver.findElement(By.xpath("//div[@id='MenuContainer']/div/h2[" + i + "]"));
                    String menudiv_id = Menu.getAttribute(("id"));
                    menudiv_id = menudiv_id.replace("Menu_a", "Menu_subMenucontainer");
                    int SubmenuCount = driver.findElements(By.xpath("//div[@id='" + menudiv_id + "']/ul/li/a")).size();
                    if (!h_Menu.getAttribute("class").contains("active")) {
                        Menu.click();
                        Thread.sleep(2000);
                    }
                    countUserDefinedMenu++;
                    int j, flag = 0;
                    for (j = 0; j < SubmenuCount; j++) {
                        WebElement submenuatag = driver.findElements(By.xpath("//div[@id='" + menudiv_id + "']/ul/li/a")).get(j);
                        if (submenuatag.getText().trim().contains(MenuSubMenuText.trim())) {
                            submenuatag.click();
                            Thread.sleep(3000);
                            flag = 1;
                            String MenuFrame = menudiv_id;
                            MenuFrame = MenuFrame.replace("Menu_subMenucontainer", "cc");
                            //WebElement _MenuFrameId=driver.findElement(By.id(MenuFrame+"_"+(j+1)));
                            //driver.switchTo().frame(_MenuFrameId);
                            MenuFrameId = MenuFrame + "_" + (j + 1);
                            System.out.println("Inside Catch MenuFrameId=  " + MenuFrameId);
                            driver.switchTo().frame(MenuFrameId);
                            ExecStatus = "Passed";
                            break;
                        }
                        Thread.sleep(1000);
                    }
                    if (flag == 1) {
                        break;
                    }
                }
            }
        }
        Thread.sleep(1000);
        return MenuFrameId;

    }

    public static String _findOmnibusid(String Entity, String _findtext, WebDriver driver) throws Exception {
        WebElement menu = driver.findElement(By.xpath("//div[@id='MenuContainer']/div/h2/a[@title='" + Entity + "']"));
        String Submenudiv_Id = menu.getAttribute("id");
        Submenudiv_Id = Submenudiv_Id.replace("Menu_a", "Menu_subMenucontainer");
        int Submenu_atagsize = driver.findElements(By.xpath("//div[@id='" + Submenudiv_Id + "']/ul/li/a")).size();
        int j = 0;
        for (j = 0; j < Submenu_atagsize; j++) {
            WebElement Submenu_atag = driver.findElements(By.xpath("//div[@id='" + Submenudiv_Id + "']/ul/li/a")).get(j);
            Thread.sleep(2000);
            if (Submenu_atag.getAttribute("text").toString().trim().contains(_findtext)) {
                ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", Submenu_atag);
                Submenu_atag.click();
                TestExeStatus = "Passed";
                Thread.sleep(1200);
                break;
            }
        }
        String pageframe = Submenudiv_Id;
        pageframe = pageframe.replace("Menu_subMenucontainer", "cc");
        WebElement pageFrameId = driver.findElement(By.id(pageframe + "_" + (j + 1)));
        driver.switchTo().frame(pageFrameId);
        return TestExeStatus;
    }

    public static String[] _getPageDetails(String Entity, WebDriver driver) throws Exception {
        String[] result = new String[2];
        WebElement Menu = null;
        String frameid = null;
        driver.switchTo().defaultContent();
        try {
            Menu = driver.findElement(By.xpath("//div[@id='MenuContainer']/div/h2/a[@title='" + Entity + "']"));
            String text = Menu.getAttribute("onclick").toString().trim();
            int index1 = text.indexOf("ProjectId");
            result[0] = text.substring(index1 + 10, index1 + 14);
            int index2 = text.indexOf("EntityTypeId");
            result[1] = text.substring(index2 + 13, index2 + 17);
            frameid = Menu.getAttribute("id").replace("Menu_a", "cc");
        } catch (Exception e1) {
            WebElement Submenu_litag = driver.findElement(By.xpath("//li[@class='activeMenu']"));
            String _submenutext = Submenu_litag.getText().toString().trim();
            if (_submenutext.contains(Entity)) {
                String url = Submenu_litag.getAttribute("onclick").toString().trim();
                try {
                    int index1 = url.indexOf("ProjectId");
                    result[0] = url.substring(index1 + 10, index1 + 14);
                    Integer.parseInt(result[0].toString());
                } catch (Exception e) {
                    result[0] = "0";
                }
                try {
                    int index2 = url.indexOf("EntityTypeId");
                    result[1] = url.substring(index2 + 13, index2 + 17);
                    Integer.parseInt(result[1].toString());
                } catch (Exception e) {
                    result[1] = "0";
                }
                frameid = Submenu_litag.getAttribute("id").toString();
                frameid = frameid.replace("Menu_li", "cc");
            }
            //}
            //addTabs('125_5131_5006_8','..\\Policy\\..\\Policy\\PolicyList.aspx?SessionId=92C6D376-BFC0-47E7-A1FB-F99CD5CCB1BA&ProjectId=5003&ObjectType=EITEM&EntityTypeId=5006&CompanyId=0&EntityPuralName=Policies&PMId=125&MId=132&TabId=125_5131_5006_8&GrpMText=Requirements&MText=Policies&appUserMode=Admin&IsMenu=Y','Policies: Requirements');return false;
            //}
        }
        if (!frameid.isEmpty()) {
            driver.switchTo().frame(frameid);
        }
        return result;
    }

    public static String Create_link_Click(String PageName, WebDriver driver) throws Exception {
        try {
            WebElement _createnewlink = driver.findElement(By.xpath("//td[@id='hdrLink']/div/ul/li/a"));
            JavascriptExecutor executor = (JavascriptExecutor) driver;
            executor.executeScript("arguments[0].click();", _createnewlink);
            Thread.sleep(3000);
            TestExeStatus = "Passed";
        } catch (Exception e) {
            String title = Page_Proper_Title("", driver);
            if (title.contains("Create New")) {
                TestExeStatus = "Passed";
            } else {
                TestExeStatus = "Page Level Error" + e.getMessage();
            }
        }
        return TestExeStatus;
    }

    public static String Get_FormSection_FieldLabel_trid(String FieldLabel, WebDriver driver) throws Exception {
        String source = "<td>" + driver.findElement(By.xpath("//table/tbody/tr/td[@id='KovairMaster_Main_colPanel_Section_5013_cellLayout_5013']")).getAttribute("innerHTML") + "</td>";
        org.jsoup.nodes.Document doc = Jsoup.parse(source, "UTF-8");
        int i = 0, j = 0;
        Elements span = doc.getElementsByAttributeValueContaining("id", "_Label_");
        for (org.jsoup.nodes.Element tr : span) {
            if (tr.text().equals(FieldLabel)) {
                String trid = tr.attr("id").toString();
                int pos = trid.indexOf("_Label_") + 7;
                String lblseq = trid.substring(pos);
                String spanid = "KovairMaster_Main_colPanel_Section_5013_Field_" + lblseq + "_Section_5013";
                return spanid;
            }
        }
        return null;
    }

    public static String Form_Section_MaximizeMinimise(String SectionName, WebDriver driver) throws Exception {
        String Sectionid = "";
        if (SectionName.equals("Attachments")) {
            Sectionid = "KovairMaster_Main_colPanel_Section_2";
        } else if (SectionName.equals("Comments")) {
            Sectionid = "KovairMaster_Main_colPanel_Section_1";
        } else if (SectionName.equals("Parent Attachments")) {
            Sectionid = "KovairMaster_Main_colPanel_Section_19";
        } else if (SectionName.equals("Parent Comments")) {
            Sectionid = "KovairMaster_Main_colPanel_Section_20";
        }
        try {
            //for maximize
            WebElement td = driver.findElement(By.xpath("//tr[@id='" + Sectionid + "_hdrRow']/td[4]"));
            WebElement _Img = driver.findElement(By.xpath("//tr[@id='" + Sectionid + "_hdrRow']/td[4]/div/img[@id='" + Sectionid + "_maxButton']"));
            JavascriptExecutor executor = (JavascriptExecutor) driver;
            executor.executeScript("arguments[0].click();", _Img);
            Thread.sleep(1000);
            //for minimize         
            //executor.executeScript("arguments[0].click();", _Img);
            TestExeStatus = "Passed";
        } catch (Exception e) {
            TestExeStatus = "Maximize/Minimize Icon didnot get displayed.";
        }
        Thread.sleep(1000);
        return TestExeStatus;
    }

    public static String Form_Section_ExpandCollapse_Mode(String SectionName, WebDriver driver) throws Exception {
        String Sectionid = "";
        if (SectionName.equals("Attachments")) {
            Sectionid = "KovairMaster_Main_colPanel_Section_2";
        } else if (SectionName.equals("Comments")) {
            Sectionid = "KovairMaster_Main_colPanel_Section_1";
        } else if (SectionName.equals("Parent Attachments")) {
            Sectionid = "KovairMaster_Main_colPanel_Section_19";
        } else if (SectionName.equals("Parent Comments")) {
            Sectionid = "KovairMaster_Main_colPanel_Section_20";
        }
        /*else if (SectionType.equals("Relation")) {  
         //KovairMaster_Main_colPanel_RelationField_5087005_button
         Sectionid = "KovairMaster_Main_colPanel_RelationField_";
         }*/
        WebElement Img = driver.findElement(By.id(Sectionid + "_button"));
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", Img);
        String Imgtitle = Img.getAttribute("title").toString().trim();
        if (Imgtitle.contains("expand")) {
            return "Collapsed";
        } else if (Imgtitle.contains("collapse")) {
            return "Expanded";
        }
        return null;
    }

    public static String automap_button(String PageName, WebDriver driver) throws Exception {
        WebElement AutomapBtn = null;
        if (PageName.contains("Relationship")) {
            AutomapBtn = driver.findElement(By.xpath("//input[@id='KovairMaster_Main_RelMappingDetails_AutomapOfRelationFields']"));
        } else {
            AutomapBtn = driver.findElement(By.xpath("//input[@id='PlaceHolderPopUp_AutoMappofLookup']"));
        }
        if (AutomapBtn.isDisplayed()) {
            TestExeStatus = "Passed";
        } else {
            TestExeStatus = "Failed";
        }
        return TestExeStatus;
    }

    public static String disabledadd_removebutton(String PageName, WebDriver driver) throws Exception {
        WebElement AddBtn = driver.findElement(By.xpath("//input[@value='Add ']"));
        String rmvlbl = null;
        if (PageName.contains("Relationship")) {
            rmvlbl = "Remove";
        } else {
            rmvlbl = " Remove";
        }
        WebElement RemoveBtn = driver.findElement(By.xpath("//input[@value='" + rmvlbl + "']"));
        if (!AddBtn.isEnabled() && !RemoveBtn.isEnabled()) {
            TestExeStatus = "Passed";
        } else {
            TestExeStatus = "Failed";
        }
        return TestExeStatus;
    }

    public static String previous_button(WebDriver driver) throws Exception {
        WebElement PrevBtn = driver.findElement(By.xpath("//div[@id='KovairMaster_Main_div2']/table/tbody/tr/td/input[@value='Previous']"));
        //Assert.assertEquals(true, PrevBtn.isDisplayed());
        if (PrevBtn.isDisplayed()) {
            TestExeStatus = "Passed";
        } else {
            TestExeStatus = "Failed";
        }
        return TestExeStatus;
    }

    public static String OnlineHelp_click(String IsPopUp, String Helptitle, WebDriver driver) throws Exception {
        WebElement HelpImage = null;
        if (IsPopUp.equals("Y")) {
            HelpImage = driver.findElement(By.id("HelpImage"));
        } else {
            HelpImage = driver.findElement(By.xpath("//div[@id='helpImag']/img"));
        }
        String Title = null;
        WebElement currentFrame = (WebElement) ((JavascriptExecutor) driver).executeScript("return window.frameElement");
        String parentWindow = driver.getWindowHandle();
        try {
            HelpImage.click();
            for (String winHandle : driver.getWindowHandles()) {
                driver.switchTo().window(winHandle);
                Title = driver.getTitle();
                if (Title.contains(Helptitle)) {
                    TestExeStatus = "Passed";
                    driver.close();
                    driver.switchTo().window(parentWindow);
                    driver.switchTo().frame(currentFrame);
                    return TestExeStatus;
                }
            }
        } catch (Exception e) {
            TestExeStatus = "Help Window is not found.";
        }
        return TestExeStatus;
    }

    public static String Page_Proper_Title(String title, WebDriver driver) throws Exception {
        try {
            WebElement _title2 = driver.findElement(By.id("pageTitle"));
            String actual_res = _title2.getAttribute("textContent");
            if (title.isEmpty()) {
                return actual_res;
            }
            if (actual_res.contains(title) || title.contains(actual_res)) {
                TestExeStatus = "Passed";
            } else {
                TestExeStatus = "Page title didn't match.";
            }
            Thread.sleep(1000);
        } catch (Exception e) {
            TestExeStatus = "Control is not redirected to " + title + " Page.";
        }
        return TestExeStatus;
    }

    //**************************************Pop Up*******************************************//
    public static String PopUp_Proper_Title(String title, WebDriver driver) throws Exception {
        WebElement _title = driver.findElement(By.xpath("//table/tbody/tr/td[@class='rwTitlebar']/table/tbody/tr/td/em"));
        String actual_res = _title.getAttribute("textContent");
        //Assert.assertEquals(actual_res,title);
        if (title.isEmpty()) {
            return actual_res;
        }
        if (actual_res.equals(title)) {
            TestExeStatus = "Passed";
        } else {
            TestExeStatus = "Failed";
        }
        //PopUp Frame Switch 
        WebElement frame = driver.findElement(By.xpath("//form/div[@unselectable='on']/table/tbody/tr/td/iframe"));
        driver.switchTo().frame(frame);
        return TestExeStatus;
    }

    public static String PopUp_Frame_Switch(WebDriver driver) throws Exception {
        //PopUp Frame Switch 
        try {
            WebDriverWait wait = new WebDriverWait(driver, 180);
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//form/div[@unselectable='on']/table/tbody/tr/td/iframe")));
            WebElement frame = driver.findElement(By.xpath("//form/div[@unselectable='on']/table/tbody/tr/td/iframe"));
            driver.switchTo().frame(frame);
            return "Passed";
        } catch (Exception _e) {
            return "Failed";
        }
    }

    public static String PopUp_close(String PageName, String ControlName, WebDriver driver) throws Exception {
        try {
            Boolean btnclicked = false;
            if (ControlName == "cancellink") {
                WebElement cancellink = driver.findElement(By.xpath("//a[@class='hyperlinkNoLine'][contains(text(),'Cancel')]"));
                cancellink.click();
                driver.switchTo().parentFrame();
            } else {
                WebElement Xicon = null;
                try {
                    int size = driver.findElements(By.xpath("//a[@title='Close']/span")).size();
                    if (size > 0) {
                        for (int i = 0; i < size; i++) {
                            Xicon = driver.findElements(By.xpath("//a[@title='Close']/span")).get(i);
                            if (Xicon.isDisplayed()) {
                                Xicon.click();
                                btnclicked = true;
                                driver.switchTo().parentFrame();
                                break;
                            }
                        }
                    }
                    if (btnclicked != true) {
                        try {
                            driver.switchTo().parentFrame();
                            Xicon = driver.findElement(By.xpath("//a[@title='Close']/span"));
                            Xicon.click();
                        } catch (Exception _e) {
                        }
                    }
                } catch (Exception e) {
                    //PopUp_Frame_Switch(driver);
                    driver.switchTo().parentFrame();
                    Xicon = driver.findElement(By.xpath("//a[@title='Close']/span"));
                    Xicon.click();
                }
            }
            Thread.sleep(2000);
            if (PageName.contains("Registration")) {
                TestExeStatus = KovairGenericClass.listpage_title(PageName, driver);
                TestExeStatus = "Passed";
            }
        } catch (Exception _e) {
        }
        return TestExeStatus;
    }

    public static String PopUp_size(WebDriver driver) throws Exception {
        WebElement popup = driver.findElement(By.xpath("//form/div[@unselectable='on']"));
        int width = Integer.parseInt(popup.getCssValue("width").toString().replace("px", ""));
        int height = Integer.parseInt(popup.getCssValue("height").toString().replace("px", ""));
        //String height=( popup.getCssValue("height"));
        if ((width < 850 && width > 750) && (height > 400 && height < 520)) {
            TestExeStatus = "Passed";
            //System.out.println("Proper width");
        } else {
            TestExeStatus = "Failed";
        }
        return TestExeStatus;
    }

    //***********************************************************Pop Up Ends**************************************************************************//    
    //************************************************************List Page***************************************************************************//    
    //Workspace Setup
    public static String ListPageClick(String Entity, String PageName, WebDriver driver) throws Exception {
        if (!Entity.equals("Users")) {
            Menu_Clicked(Entity, driver);
            Thread.sleep(1000);
        }
        //****************************SubMenu Click*******************************//
        _findOmnibusid(Entity, PageName, driver);
        TestExeStatus = KovairGenericClass.listpage_title(PageName, driver);
        Thread.sleep(1000);
        return TestExeStatus;
    }

    public static String listpage_title(String pagename, WebDriver driver) throws Exception {
        String Listpgtitle = driver.findElement(By.id("pageTitle")).getText();
        if (pagename.contains("-") && pagename.contains("Form-Section")) {
            pagename = pagename.replace("-", " ");
        }
        if (Listpgtitle.contains(pagename)) {
            TestExeStatus = "Passed";
        } else {
            TestExeStatus = "Failed";
        }
        return TestExeStatus;
    }

    public static String LoadListPageAgain(String Entity, String PageName, WebDriver driver) throws Exception {
        try {
            String frameid = null;
            driver.switchTo().defaultContent();
            //_findOmnibusid(Entity, PageName, driver);
            WebElement Submenu_litag = driver.findElement(By.xpath("//li[@class='activeMenu']"));
            String _submenutext = Submenu_litag.getText().toString().trim();
            if (_submenutext.contains(PageName)) {
                Submenu_litag.click();
                frameid = Submenu_litag.getAttribute("id").toString();
                frameid = frameid.replace("Menu_li", "cc");
                if (!frameid.isEmpty()) {
                    driver.switchTo().frame(frameid);
                }
            }
            TestExeStatus = KovairGenericClass.listpage_title(PageName, driver);
            Thread.sleep(1500);
        } catch (Exception e) {
            TestExeStatus = "Page is not reloaded.";
        }
        return TestExeStatus;
    }

    public static String LoadCurrentPageAgain(String Entity, WebDriver driver) throws Exception {
        //For Workspace Setup
        try {
            driver.switchTo().defaultContent();
            opencurrentpage(Entity, driver);
            TestExeStatus = KovairGenericClass.listpage_title(Entity, driver);
            try {
                WebDriverWait wait = new WebDriverWait(driver, 5);
                wait.until(ExpectedConditions.invisibilityOfElementLocated(By.id("img_loading")));
            } catch (Exception ex) {
            }
        } catch (Exception e) {
            TestExeStatus = "Page is not reloaded.";
        }
        return TestExeStatus;
    }

    public static void opencurrentpage(String Entity, WebDriver driver) throws Exception {
        WebElement Menu = null;
        String frameid = null;
        try {
            driver.switchTo().defaultContent();
            Menu = driver.findElement(By.xpath("//div[@id='MenuContainer']/div/h2/a[@title='" + Entity + "']"));
            Menu.click();
            frameid = frameid.replace("Menu_a", "cc");
        } catch (Exception e1) {
            WebElement Submenu_litag = driver.findElement(By.xpath("//li[@class='activeMenu']"));
            String _submenutext = Submenu_litag.getText().toString().trim();
            if (_submenutext.contains(Entity)) {
                Submenu_litag.click();
                frameid = Submenu_litag.getAttribute("id").toString();
                frameid = frameid.replace("Menu_li", "cc");
            }
        }
        if (!frameid.isEmpty()) {
            driver.switchTo().frame(frameid);
        }
    }

    public static String Get_specific_tr_id(String ItemName, String PageName, String ListPageType, WebDriver driver) throws Exception {
        String Listidpart = null;
        String tr_id = null;
        if (ListPageType.equals("OmnibusList")) {
            Listidpart = "EntityMappingList";
        } else {
            if (PageName.contains("Section")) {
                Listidpart = "FRMSECLIST";
            } else {
                Listidpart = PageName.toUpperCase() + "LIST";
            }
        }
        String source = "<tbody>" + driver.findElement(By.xpath("//table[@id='KovairMaster_Main_GRID_" + Listidpart + "_ctl00']/tbody")).getAttribute("innerHTML") + "</tbody>";
        Document doc = Jsoup.parse(source, "UTF-8");
        if (PageName.equals("Registration")) {
            PageName = "ToolInstance";
        }
        //int spancount=doc.getElementsByAttributeValueContaining("id","DISPLAY_"+PageName+"Name").size();
        Elements span = doc.getElementsByAttributeValueContaining("id", "DISPLAY_" + PageName + "Name");
        String trid = null;
        int i = 0;
        for (Element tr : span) {
            String _text = tr.text().toString();
            if (_text.equals(ItemName)) {
                trid = "KovairMaster_Main_GRID_" + Listidpart + "_ctl00__" + i;
                break;
            }
            i++;
        }
        return trid;
    }

    public static String Get_LastRecord_tr_id(String PageName, WebDriver driver) throws Exception {
        String source = "<tbody>" + driver.findElement(By.xpath("//table[@id='KovairMaster_Main_GRID_EntityMappingList_ctl00']/tbody")).getAttribute("innerHTML") + "</tbody>";
        Document doc = Jsoup.parse(source, "UTF-8");
        if (PageName.equals("Registration")) {
            PageName = "ToolInstance";
        }
        int spancount = doc.getElementsByAttributeValueContaining("id", "DISPLAY_" + PageName + "Name").size();
        Elements span = doc.getElementsByAttributeValueContaining("id", "DISPLAY_" + PageName + "Name");
        String trid = "KovairMaster_Main_GRID_EntityMappingList_ctl00__" + (spancount - 1);
        return trid;
    }

    //With Sencha
    public static String RecordList_RightClick_Command_Availability(String ParentCommandcommandText, String SubCommandcommandText, String Entity, WebDriver driver) throws Exception {
        WebElement tr = null;
        try {
            String Gridid = (driver.findElement(By.xpath("//div[@id='EntityGrid-body']/div"))).getAttribute("id").toString().trim();
            String trid = Gridid + "-record-ext-record-";
            try {
                String data_par_div = (driver.findElement(By.xpath("//div[@id='EntityGrid-body']/div"))).getAttribute("id").toString();
                int row_size = driver.findElements(By.xpath("//tbody[@id='" + data_par_div + "-body']/tr")).size();
                Thread.sleep(2000);
                if (row_size > 0) {
                    tr = (driver.findElement(By.xpath("//div[@id='EntityGrid-body']/div/table/tbody/tr[1]")));
                    tr.click();
                    Thread.sleep(2000);
                } else {
                    TestExeStatus = "No Records found.";
                    return TestExeStatus;
                }
            } catch (Exception e1) {
                tr = (driver.findElement(By.xpath("//tr[contains(id,'" + trid + "')]")));
                tr.click();
                Thread.sleep(2000);
            }
            Actions oAction = new Actions(driver);
            oAction.moveToElement(tr);
            oAction.contextClick(tr).build().perform();
            Thread.sleep(2500);
            WebElement elementOpen = null;
            if (SubCommandcommandText.equals("")) {
                try {
                    elementOpen = driver.findElement(By.xpath("//span[contains(text(),'" + ParentCommandcommandText + "')]"));
                    TestExeStatus = "Passed";
                } catch (Exception _e) {
                    TestExeStatus = "Command : '" + ParentCommandcommandText + "' is not avaiable.";
                }
            } else {
                try {
                    WebElement elementParentOpen = driver.findElement(By.xpath("//span[contains(text(),'" + ParentCommandcommandText + "')]"));
                    String _id = elementParentOpen.getAttribute("id").toString();
                    String div_id = _id.substring(0, _id.indexOf("-textEl"));
                    WebElement _div = driver.findElement(By.id(div_id));
                    oAction.moveToElement(_div).build().perform();
                    Thread.sleep(1500);
                    try {
                        elementOpen = driver.findElement(By.linkText(SubCommandcommandText));
                        TestExeStatus = "Passed";
                    } catch (Exception _e) {
                        TestExeStatus = "Command : '" + SubCommandcommandText + "' is not avaiable.";
                    }
                } catch (Exception _e1) {
                    TestExeStatus = "Command : '" + ParentCommandcommandText + "' is not avaiable.";
                }
            }
            driver.findElement(By.id("pageTitle")).click();
        } catch (Exception e) {

            TestExeStatus = "Page Level Error." + e.getMessage();
        }
        return TestExeStatus;
    }

    public static String RecordList_RightClick_Command_click(String ParentCommandcommandText, String SubCommandcommandText, String frameid, String Entity, WebDriver driver) throws Exception {
        WebElement tr = null;
        try {
            if (!frameid.isEmpty()) {
                //WebElement frame=driver.findElement(By.id(frameid));
                driver.switchTo().frame(frameid);
            }
            String Gridid = (driver.findElement(By.xpath("//div[@id='EntityGrid-body']/div"))).getAttribute("id").toString().trim();
            String trid = Gridid + "-record-ext-record-";
            try {
                String data_par_div = (driver.findElement(By.xpath("//div[@id='EntityGrid-body']/div"))).getAttribute("id").toString();
                int row_size = driver.findElements(By.xpath("//tbody[@id='" + data_par_div + "-body']/tr")).size();
                Thread.sleep(3000);
                if (row_size > 0) {
                    tr = (driver.findElement(By.xpath("//div[@id='EntityGrid-body']/div/table/tbody/tr[1]")));
                    tr.click();
                    Thread.sleep(3000);
                } else {
                    TestExeStatus = "No Records found.";
                    return TestExeStatus;
                }
            } catch (Exception e1) {
                tr = (driver.findElement(By.xpath("//tr[contains(id,'" + trid + "')]")));
                tr.click();
                Thread.sleep(2000);
            }
            Actions oAction = new Actions(driver);
            oAction.moveToElement(tr);
            oAction.contextClick(tr).build().perform();
            Thread.sleep(2000);
            WebElement elementOpen = null;
            if (SubCommandcommandText.equals("")) {
                //elementOpen = driver.findElement(By.linkText(ParentCommandcommandText)); 
                elementOpen = driver.findElement(By.xpath("//span[contains(text(),'" + ParentCommandcommandText + "')]"));
            } else {
                // WebElement elementParentOpen = driver.findElement(By.linkText(ParentCommandcommandText)); 
                WebElement elementParentOpen = driver.findElement(By.xpath("//span[contains(text(),'" + ParentCommandcommandText + "')]"));
                String _id = elementParentOpen.getAttribute("id").toString();
                String div_id = _id.substring(0, _id.indexOf("-textEl"));
                WebElement _div = driver.findElement(By.id(div_id));
                Thread.sleep(1500);
                oAction.moveToElement(_div).build().perform();
                Thread.sleep(1500);
                elementOpen = driver.findElement(By.linkText(SubCommandcommandText));
                Thread.sleep(1500);
            }
            JavascriptExecutor executor = (JavascriptExecutor) driver;
            executor.executeScript("arguments[0].click();", elementOpen);
            Thread.sleep(2500);
            TestExeStatus = "Passed";
        } catch (Exception e) {

            TestExeStatus = "Page Level Error." + e.getMessage();
        }
        return TestExeStatus;
    }

    public static String RecordList_ActionButton_Command_Availability(String ParentCommandcommandText, String SubCommandcommandText, String Entity, WebDriver driver) throws Exception {
        WebElement tr = null;
        try {
            String Gridid = (driver.findElement(By.xpath("//div[@id='EntityGrid-body']/div"))).getAttribute("id").toString().trim();
            String trid = Gridid + "-record-ext-record-";
            try {
                String data_par_div = (driver.findElement(By.xpath("//div[@id='EntityGrid-body']/div"))).getAttribute("id").toString();
                int row_size = driver.findElements(By.xpath("//tbody[@id='" + data_par_div + "-body']/tr")).size();
                Thread.sleep(500);
                if (row_size > 0) {
                    tr = (driver.findElement(By.xpath("//div[@id='EntityGrid-body']/div/table/tbody/tr[1]")));
                    tr.click();
                } else {
                    TestExeStatus = "No Records found.";
                    return TestExeStatus;
                }
            } catch (Exception e1) {
                tr = (driver.findElement(By.xpath("//tr[contains(id,'" + trid + "')]")));
                tr.click();
            }
            Actions oAction = new Actions(driver);
            driver.findElement(By.id("ActionButton-btnIconEl")).click();
            try {
                driver.findElement(By.id("EntityMenu"));
            } catch (Exception e) {
                driver.findElement(By.id("ActionButton-btnIconEl")).click();
            }
            WebElement elementOpen = null;
            if (SubCommandcommandText.equals("")) {
                try {
                    elementOpen = driver.findElement(By.xpath("//span[contains(text(),'" + ParentCommandcommandText + "')]"));
                    TestExeStatus = "Passed";
                } catch (Exception _e) {
                    TestExeStatus = "Command : '" + ParentCommandcommandText + "' is not avaiable.";
                }
            } else {
                try {
                    WebElement elementParentOpen = driver.findElement(By.xpath("//span[contains(text(),'" + ParentCommandcommandText + "')]"));
                    String _id = elementParentOpen.getAttribute("id").toString();
                    String div_id = _id.substring(0, _id.indexOf("-textEl"));
                    WebElement _div = driver.findElement(By.id(div_id));
                    oAction.moveToElement(_div).build().perform();
                    try {
                        elementOpen = driver.findElement(By.linkText(SubCommandcommandText));
                        TestExeStatus = "Passed";
                    } catch (Exception _e) {
                        TestExeStatus = "Command : '" + SubCommandcommandText + "' is not avaiable.";
                    }
                } catch (Exception _e1) {
                    TestExeStatus = "Command : '" + ParentCommandcommandText + "' is not avaiable.";
                }
            }
            driver.findElement(By.id("pageTitle")).click();
        } catch (Exception e) {
            TestExeStatus = "Page Level Error.";
        }
        return TestExeStatus;
    }

    public static String RecordList_ActionButton_Command_click(String ParentCommandcommandText, String SubCommandcommandText, String frameid, String Entity, WebDriver driver) throws Exception {
        WebElement tr = null;
        try {
            if (!frameid.isEmpty()) {
                //WebElement frame=driver.findElement(By.id(frameid));
                driver.switchTo().frame(frameid);
            }
            String Gridid = (driver.findElement(By.xpath("//div[@id='EntityGrid-body']/div"))).getAttribute("id").toString().trim();
            String trid = Gridid + "-record-ext-record-";
            try {
                String data_par_div = (driver.findElement(By.xpath("//div[@id='EntityGrid-body']/div"))).getAttribute("id").toString();
                int row_size = driver.findElements(By.xpath("//tbody[@id='" + data_par_div + "-body']/tr")).size();
                Thread.sleep(500);
                if (row_size > 0) {
                    tr = (driver.findElement(By.xpath("//div[@id='EntityGrid-body']/div/table/tbody/tr[1]")));
                    tr.click();
                } else {
                    TestExeStatus = "No Records found.";
                    return TestExeStatus;
                }
            } catch (Exception e1) {
                tr = (driver.findElement(By.xpath("//tr[contains(id,'" + trid + "')]")));
                tr.click();
            }
            Actions oAction = new Actions(driver);
            driver.findElement(By.id("ActionButton-btnIconEl")).click();
            try {
                driver.findElement(By.id("EntityMenu"));
            } catch (Exception e) {
                driver.findElement(By.id("ActionButton-btnIconEl")).click();
            }
            WebElement elementOpen = null;
            if (SubCommandcommandText.isEmpty()) {
                elementOpen = driver.findElement(By.linkText(ParentCommandcommandText));
            } else {
                WebElement elementParentOpen = driver.findElement(By.xpath("//span[contains(text(),'" + ParentCommandcommandText + "')]"));
                String _id = elementParentOpen.getAttribute("id").toString();
                String div_id = _id.substring(0, _id.indexOf("-textEl"));
                WebElement _div = driver.findElement(By.id(div_id));
                oAction.moveToElement(_div).build().perform();
                elementOpen = driver.findElement(By.linkText(SubCommandcommandText));
            }
            JavascriptExecutor executor = (JavascriptExecutor) driver;
            executor.executeScript("arguments[0].click();", elementOpen);
            Thread.sleep(1000);
            TestExeStatus = "Passed";
        } catch (Exception e) {
            TestExeStatus = "Page Level Error.";
        }
        return TestExeStatus;
    }

    public static String RecordList_ActionButton_Command_click(String ParentCommandText, String SubCommandText, String SubCommandText_2, String frameid, String Entity, WebDriver driver) throws Exception {
        WebElement tr = null;
        try {
            if (!frameid.isEmpty()) {
                //WebElement frame=driver.findElement(By.id(frameid));
                driver.switchTo().frame(frameid);
            }
            String Gridid = (driver.findElement(By.xpath("//div[@id='EntityGrid-body']/div"))).getAttribute("id").toString().trim();
            String trid = Gridid + "-record-ext-record-";
            try {
                String data_par_div = (driver.findElement(By.xpath("//div[@id='EntityGrid-body']/div"))).getAttribute("id").toString();
                int row_size = driver.findElements(By.xpath("//tbody[@id='" + data_par_div + "-body']/tr")).size();
                Thread.sleep(500);
                if (row_size > 0) {
                    tr = (driver.findElement(By.xpath("//div[@id='EntityGrid-body']/div/table/tbody/tr[1]")));
                    tr.click();
                } else {
                    TestExeStatus = "No Records found.";
                    return TestExeStatus;
                }
            } catch (Exception e1) {
                tr = (driver.findElement(By.xpath("//tr[contains(id,'" + trid + "')]")));
                tr.click();
            }
            Actions oAction = new Actions(driver);
            driver.findElement(By.id("ActionButton-btnIconEl")).click();
            try {
                driver.findElement(By.id("EntityMenu"));
            } catch (Exception e) {
                driver.findElement(By.id("ActionButton-btnIconEl")).click();
            }
            WebElement elementOpen = null;
            if (SubCommandText.isEmpty()) {
                elementOpen = driver.findElement(By.linkText(ParentCommandText));
            } else {
                WebElement elementParentOpen = driver.findElement(By.xpath("//span[contains(text(),'" + ParentCommandText + "')]"));
                String _id = elementParentOpen.getAttribute("id").toString();
                String div_id = _id.substring(0, _id.indexOf("-textEl"));
                WebElement _div = driver.findElement(By.id(div_id));
                oAction.moveToElement(_div).build().perform();
                if (SubCommandText_2.isEmpty()) {
                    elementOpen = driver.findElement(By.linkText(SubCommandText));
                } else {
                    WebElement elementSubChildOpen = driver.findElement(By.xpath("//span[contains(text(),'" + SubCommandText + "')]"));
                    _id = elementSubChildOpen.getAttribute("id").toString();
                    div_id = _id.substring(0, _id.indexOf("-textEl"));
                    _div = driver.findElement(By.id(div_id));
                    oAction.moveToElement(_div).build().perform();
                    elementOpen = driver.findElement(By.linkText(SubCommandText_2));
                }
            }

            JavascriptExecutor executor = (JavascriptExecutor) driver;
            executor.executeScript("arguments[0].click();", elementOpen);
            Thread.sleep(1000);
            TestExeStatus = "Passed";
        } catch (Exception e) {
            TestExeStatus = "Page Level Error.";
        }
        return TestExeStatus;
    }

    public static String RecordList_RecordTitle_Click(String frameid, WebDriver driver) throws Exception {
        try {
            if (!frameid.isEmpty()) {
                WebElement frame = driver.findElement(By.id(frameid));
                driver.switchTo().frame(frameid);
            }
            Thread.sleep(2000);
            int col_no = 0;
            String col_par_div = (driver.findElement(By.xpath("//div[@id='EntityGrid']/div"))).getAttribute("id").toString();
            int col_count = (driver.findElements(By.xpath("//div[@id='" + col_par_div + "']/div/div/div"))).size();
            String col_text;
            for (int i = 0; i < col_count; i++) {
                col_text = driver.findElements(By.xpath("//div[@id='" + col_par_div + "']/div/div/div")).get(i).getText().toString();
                if (col_text.contains("Title")) {
                    col_no = i + 1;
                    break;
                }
            }
            String data_par_div = (driver.findElement(By.xpath("//div[@id='EntityGrid-body']/div"))).getAttribute("id").toString();
            int row_size = 1;
            WebElement _cell = driver.findElement(By.xpath("//tbody[@id='" + data_par_div + "-body']/tr[" + row_size + "]/td[" + col_no + "]/div/a"));
            //WebElement recordElement = driver.findElement(By.xpath("//tr[@id='"+trid+"']/td[2]/div/a"));
            JavascriptExecutor executor = (JavascriptExecutor) driver;
            executor.executeScript("arguments[0].click();", _cell);
            Thread.sleep(10000);
            //executor.executeScript("arguments[0].click();", _cell);
            //Thread.sleep(7000);
            KovairGenericClass._swithchtonewframe(driver);
            TestExeStatus = "Passed";
        } catch (Exception e) {
            TestExeStatus = "Page Level Error.";
        }
        return TestExeStatus;
    }
    
     public static String EndUser_ListPage_SearchBox(String SearchText, String IsPopUp, String PageName, WebDriver driver) throws Exception {
        String controlid = "KovairMaster_Main_";
        if (IsPopUp == "Y") {
            if (PageName.contains("User")) {
                controlid = "PlaceHolderPopUp_SelectedUserList_SelectedUserList_UserControl_";
            } else {
                controlid = "PlaceHolderPopUp_SelectedEntityList_SelectedEntityList_EntityListControl_SelectedEntityList_EntityListControl_";
            }
        }
        String srchbox = controlid + "txtSearchByIdOrTxt";
        try {
            if (driver.findElement(By.id(srchbox)) != null) {
                WebElement searchbox = driver.findElement(By.id(srchbox));
                searchbox.click();
                Thread.sleep(1000);
                searchbox.clear();
                WebDriverWait wait1 = new WebDriverWait(driver, 5);
                wait1.until(ExpectedConditions.textToBePresentInElement(searchbox, ""));
                searchbox.sendKeys(SearchText);
                Thread.sleep(1500);
                WebElement searchimg = driver.findElement(By.id(controlid + "btnSearch"));
                JavascriptExecutor executor = (JavascriptExecutor) driver;
                //search
                executor.executeScript("arguments[0].click();", searchimg);
                WebDriverWait wait = new WebDriverWait(driver, 60);
                wait.until(ExpectedConditions.invisibilityOfElementLocated(By.id("img_loading")));
                String data_par_div = (driver.findElement(By.xpath("//div[@id='EntityGrid-body']/div"))).getAttribute("id").toString();
                int row_size = 0;
                try {
                    row_size = driver.findElements(By.xpath("//tbody[@id='" + data_par_div + "-body']/tr")).size();
                } //For MultiEdit - Without Sencha
                catch (Exception e) {   //KovairMaster_Main_EntityList_5198_GridData
                    row_size = driver.findElements(By.xpath("//div[@id^='KovairMaster_Main_EntityList_'][@id$='GridData']/table/tbody/tr")).size();
                }
                if (row_size > 0) {
                    TestExeStatus = "Passed";
                } else {
                    TestExeStatus = "No Record Found with given Search Key.";
                }
            } else {
                TestExeStatus = "No Search Key given";
            }
        } catch (Exception e) {
            TestExeStatus = "Page Level Error.";
        }
        return TestExeStatus;
    }


    public static String EndUser_ListPage_SearchBox(String SearchText, String IsPopUp, String PageName, String SearchByID, WebDriver driver) throws Exception {
        String controlid = "KovairMaster_Main_";
        WebElement searchbox = null;
        if (IsPopUp == "Y") {
            //For User List
            if (PageName.contains("User")) {
                controlid = "PlaceHolderPopUp_SelectedUserList_SelectedUserList_UserControl_";
            } //For Relational Lookup Field
            else if (PageName.contains("Relational Lookup")) {
                controlid = "PlaceHolderPopUp_SelectedEntityList_SelectedEntityList_EntityListControl_SelectedEntityList_EntityListControl_";
            }
            //For Relate Existing List of Relation section
            if (PageName.contains("Relation List")) {
                searchbox = driver.findElement(By.cssSelector("input[id$='txtSearchByIdOrTxt']"));
                controlid = searchbox.getAttribute("id").toString().trim();
                controlid = controlid.replace("txtSearchByIdOrTxt", "").trim();
            } else {
                searchbox = driver.findElement(By.id(controlid + "txtSearchByIdOrTxt"));
            }
        } else if (PageName.contains("Relation")) {
            searchbox = driver.findElement(By.cssSelector("input[id^='RelListTab_Search_']"));
            //controlid=searchbox.getAttribute("id").toString().trim();
            //controlid=controlid.replace("txtSearchByIdOrTxt", "").trim();
        } else {
            searchbox = driver.findElement(By.id(controlid + "txtSearchByIdOrTxt"));
        }
        try {
            try {
                if (!PageName.contains("Multi Edit")) {
                    boolean Ischecked = driver.findElement(By.id("KovairMaster_Main_chkID")).isSelected();
                    if (Ischecked == false && SearchByID.equals("Y") || Ischecked == true && SearchByID.equals("N")) {
                        driver.findElement(By.id("KovairMaster_Main_chkID")).click();
                        //Modal_OKClick_Verification("OK", driver);
                    }
                }
            } catch (Exception e) {
            }

            searchbox.click();
            //Thread.sleep(1000);
            searchbox.clear();
//                WebDriverWait wait1 = new WebDriverWait(driver, 15);
//                wait1.until(ExpectedConditions.textToBePresentInElement(searchbox, ""));
            searchbox.sendKeys(SearchText);
            Thread.sleep(1500);

            WebElement searchimg = null;
            //For Relation Section Search Image
            if (PageName.contains("Relation") && IsPopUp == "N") {
                searchimg = driver.findElement(By.cssSelector("input[id^='RelListTab_Search_Btn_']"));
            } else {
                searchimg = driver.findElement(By.id(controlid + "btnSearch"));
            }
            //search
            JavascriptExecutor executor = (JavascriptExecutor) driver;
            executor.executeScript("arguments[0].click();", searchimg);
            try {
                WebDriverWait wait = new WebDriverWait(driver, 20);
                wait.until(ExpectedConditions.invisibilityOfElementLocated(By.id("img_loading")));
            } catch (Exception _e3) {
            }
            if (IsPopUp == "Y" || PageName.contains("Relation")) {
                return "Passed";
            }
            String data_par_div = (driver.findElement(By.xpath("//div[@id='EntityGrid-body']/div"))).getAttribute("id").toString();
            int row_size = 0;
            try {
                row_size = driver.findElements(By.xpath("//tbody[@id='" + data_par_div + "-body']/tr")).size();
            } //For MultiEdit - Without Sencha
            catch (Exception e) {
                //KovairMaster_Main_EntityList_5198_GridData
                row_size = driver.findElements(By.xpath("//div[@id^='KovairMaster_Main_EntityList_'][@id$='GridData']/table/tbody/tr")).size();
            }
            if (row_size > 0) {
                TestExeStatus = "Passed";
            } else {
                TestExeStatus = "No Record Found with given Search Key.";
            }
        } catch (Exception e) {
            TestExeStatus = "Page Level Error.";
        }
        return TestExeStatus;
    }
    
     public static String EndUser_ListPage_SearchBox1(String SearchText, String IsPopUp, String PageName, WebDriver driver) throws Exception {
        String controlid = "KovairMaster_Main_";
        if (IsPopUp == "Y") {
            if (PageName.contains("User")) {
                controlid = "PlaceHolderPopUp_SelectedUserList_SelectedUserList_UserControl_";
            } else {
                controlid = "PlaceHolderPopUp_SelectedEntityList_SelectedEntityList_EntityListControl_SelectedEntityList_EntityListControl_";
            }
        }
        String srchbox = controlid + "txtSearchByIdOrTxt";
        try {
            if (driver.findElement(By.id(srchbox)) != null) {
                WebElement searchbox = driver.findElement(By.id(srchbox));
                searchbox.click();
                Thread.sleep(1000);
                searchbox.clear();
                WebDriverWait wait1 = new WebDriverWait(driver, 5);
                wait1.until(ExpectedConditions.textToBePresentInElement(searchbox, ""));
                searchbox.sendKeys(SearchText);
                Thread.sleep(1500);
                WebElement searchimg = driver.findElement(By.id(controlid + "btnSearch"));
                JavascriptExecutor executor = (JavascriptExecutor) driver;
                //search
                executor.executeScript("arguments[0].click();", searchimg);
                WebDriverWait wait = new WebDriverWait(driver, 60);
                wait.until(ExpectedConditions.invisibilityOfElementLocated(By.id("img_loading")));
                String data_par_div = (driver.findElement(By.xpath("//div[@id='EntityGrid-body']/div"))).getAttribute("id").toString();
                int row_size = 0;
                try {
                    row_size = driver.findElements(By.xpath("//tbody[@id='" + data_par_div + "-body']/tr")).size();
                } //For MultiEdit - Without Sencha
                catch (Exception e) {   //KovairMaster_Main_EntityList_5198_GridData
                    row_size = driver.findElements(By.xpath("//div[@id^='KovairMaster_Main_EntityList_'][@id$='GridData']/table/tbody/tr")).size();
                }
                if (row_size > 0) {
                    TestExeStatus = "Passed";
                } else {
                    TestExeStatus = "No Record Found with given Search Key.";
                }
            } else {
                TestExeStatus = "No Search Key given";
            }
        } catch (Exception e) {
            TestExeStatus = "Page Level Error.";
        }
        return TestExeStatus;
    }
    

    public static String IfFieldExistInView(String View, String FieldName, WebDriver driver) throws Exception {
        String Fldvalue = null;
        try {
            if (!View.isEmpty()) {
                KovairGenericClass.ViewSelection(View, "N", "", "", driver);
            }
            WebDriverWait _wait = new WebDriverWait(driver, 120);
            Thread.sleep(1500);
            int col_no = 0;
            String col_par_div = (driver.findElement(By.xpath("//div[@id='EntityGrid']/div"))).getAttribute("id").toString();
            int col_count = (driver.findElements(By.xpath("//div[@id='" + col_par_div + "']/div/div/div"))).size();
            String col_text;
            for (int i = 0; i < col_count; i++) {
                col_text = driver.findElements(By.xpath("//div[@id='" + col_par_div + "']/div/div/div")).get(i).getText().toString();
                if (col_text.contains(FieldName)) {
                    col_no = i + 1;
                    break;
                }
            }
            if (col_no > 0) {
                TestExeStatus = "Passed";
            } else {
                TestExeStatus = "Failed";
                TestErrDesc = "Field does not exist in View.";
            }
        } catch (Exception e) {
            TestExeStatus = "Failed";
            TestErrDesc = "Page Level Error";
        }
        return TestExeStatus;
    }

    public static String GetSpecificFieldValue(String View, String FieldName, int RecordSeq, WebDriver driver) throws Exception {
        String Fldvalue = null;
        try {
            if (!View.isEmpty()) {
                KovairGenericClass.ViewSelection(View, "N", "", "", driver);
            }
            /* try
             {
             SortSpecificField("","Submit Date",driver);
             Thread.sleep(1000);
             SortSpecificField("","ID",driver);
             }
             catch(Exception e2){}*/
            WebDriverWait _wait = new WebDriverWait(driver, 120);
            Thread.sleep(1500);
            int col_no = 0;
            String col_par_div = (driver.findElement(By.xpath("//div[@id='EntityGrid']/div"))).getAttribute("id").toString();
            int col_count = (driver.findElements(By.xpath("//div[@id='" + col_par_div + "']/div/div/div"))).size();
            String col_text;
            for (int i = 0; i < col_count; i++) {
                col_text = driver.findElements(By.xpath("//div[@id='" + col_par_div + "']/div/div/div")).get(i).getText().toString();
                if (col_text.contains(FieldName)) {
                    col_no = i + 1;
                    break;
                }
            }
            String data_par_div = (driver.findElement(By.xpath("//div[@id='EntityGrid-body']/div"))).getAttribute("id").toString();
            int row_size = 0;
            if (RecordSeq != 0) {
                row_size = RecordSeq;
            } else {
                row_size = driver.findElements(By.xpath("//tbody[@id='" + data_par_div + "-body']/tr")).size();
            }
            WebElement _cell = driver.findElement(By.xpath("//tbody[@id='" + data_par_div + "-body']/tr[" + row_size + "]/td[" + col_no + "]"));
            Fldvalue = _cell.getText().toString();
        } catch (Exception e) {
            return null;
        }
        return Fldvalue;
    }

    
    public static String SpecificMenu_SubMenu_Clicked1(String MenuSubMenuText, WebDriver driver) throws Exception {
        String MenuFrameId = null;
        String ExecStatus = null;
        WebElement Menu = null;
        try {
            Menu = driver.findElement(By.xpath("//div[@id='MenuContainer']/div/h2/a[@title='" + MenuSubMenuText + "']"));
            Menu.click();
            MenuFrameId = Menu.getAttribute("id").toString().replace("Menu_a", "cc");
            WebElement _MenuFrameId = driver.findElement(By.id(MenuFrameId));
            driver.switchTo().frame(_MenuFrameId);
            //System.out.println(_MenuFrameId);
            ExecStatus = "Passed";
        } catch (Exception e) {
            int menuCount = driver.findElements(By.xpath("//div[@id='MenuContainer']/div/h2")).size();
            int countUserDefinedMenu = 0;
            for (int i = 1; i <= menuCount; i++) {
                Menu = driver.findElement(By.xpath("//div[@id='MenuContainer']/div/h2[" + i + "]/a"));
                String HasLink = null;
                try {
                    HasLink = Menu.getAttribute("nolnk").toString();
                } catch (Exception e1) {
                    continue;
                }
                if (HasLink.trim().equals("Y")) {
                    String menudiv_id = Menu.getAttribute(("id"));
                    menudiv_id = menudiv_id.replace("Menu_a", "Menu_subMenucontainer");
                    int SubmenuCount = driver.findElements(By.xpath("//div[@id='" + menudiv_id + "']/ul/li/a")).size();
                    Menu.click();
                    Thread.sleep(2000);
                    countUserDefinedMenu++;
                    int j, flag = 0;
                    for (j = 0; j < SubmenuCount; j++) {
                        WebElement submenuatag = driver.findElements(By.xpath("//div[@id='" + menudiv_id + "']/ul/li/a")).get(j);
                        if (submenuatag.getText().trim().contains(MenuSubMenuText.trim())) {
                            submenuatag.click();
                            Thread.sleep(3000);
                            flag = 1;
                            String MenuFrame = menudiv_id;
                            MenuFrame = MenuFrame.replace("Menu_subMenucontainer", "cc");
                            //WebElement _MenuFrameId=driver.findElement(By.id(MenuFrame+"_"+(j+1)));
                            //driver.switchTo().frame(_MenuFrameId);
                            MenuFrameId = MenuFrame + "_" + (j + 1);
                            //System.out.println("Inside Catch MenuFrameId=  "+MenuFrameId);
                            driver.switchTo().frame(MenuFrameId);
                            ExecStatus = "Passed";
                            break;
                        }
                        Thread.sleep(1000);
                    }
                    if (flag == 1) {
                        break;
                    }
                }
            }
        }
        Thread.sleep(1000);
        return MenuFrameId;
    }

    public static String SortSpecificField(String View, String FieldName, WebDriver driver) throws Exception {
        try {
            if (!View.isEmpty()) {
                KovairGenericClass.ViewSelection(View, "N", "", "", driver);
            }
            WebDriverWait _wait = new WebDriverWait(driver, 120);
            Thread.sleep(1500);
            int col_no = 0;
            WebElement _col = driver.findElement(By.xpath("//div[@data-qtip='" + FieldName + "']"));
            _col.click();
            /*String col_par_div = (driver.findElement(By.xpath("//div[contains(@id,'EntityGrid')]/div"))).getAttribute("id").toString();
             int col_count = (driver.findElements(By.xpath("//div[@id='" + col_par_div + "']/div/div/div"))).size();
             String col_text;
             for (int i = 0; i < col_count; i++) 
             {
             col_text = driver.findElements(By.xpath("//div[@id='" + col_par_div + "']/div/div/div")).get(i).getText().toString();
             if (col_text.contains(FieldName)) 
             {
             col_no = i + 1;
             WebElement colmn = driver.findElement(By.xpath("//div[@id='" + col_par_div + "']/div/div/div[" + col_no + "]"));
             colmn.click();
             break;
             }
             }*/
            TestExeStatus = "Passed";
        } catch (Exception e) {
            TestExeStatus = "Page Level Error.";
        }
        return TestExeStatus;
    }

    public static String IDTextSearchResult(String SearchText, String SearchType, String IsSearchByID, String USerId, String View, String PageMenuTagName, String ObjectType, String[] Pagedetails, WebDriver driver) throws Exception {
        try {
            int i = 0;
            String query = null;
            String _query = null;
            String ProjectId = null;
            String EntityTypeId = null;
            String shownval = null;
            //String searchno = null;
            String querytext = SearchText;
            if (IsSearchByID.isEmpty()) {
                IsSearchByID = "N";
            }

            if (Pagedetails == null)// && !PageMenuTagName.contains("Multi Edit"))// && !ObjectType.equals("Task"))
            {
                Pagedetails = _getPageDetails(PageMenuTagName, driver);

            }
            Thread.sleep(2000);
            ProjectId = Pagedetails[0];
            if (!ObjectType.equals("Task")) {
                EntityTypeId = Pagedetails[1];
            }

            //String frameid=_getFrameIdfromSubmenu(PageMenuTagName,"",driver);
            //driver.switchTo().frame(frameid);
            if (SearchType.equals("Last") || SearchType.equals("First")) {
                String searchorder = "";
                if (SearchType.equals("Last")) {
                    searchorder = "desc";
                }
                querytext = SearchText.replaceAll("[^0-9]", "").trim();
                if (ObjectType.equals("Task") && PageMenuTagName.equals("Home")) {
                    query = "select top " + querytext + " ItemIDInProject from tTask where ItemID in(select ItemID from tTaskOwners where ItemID is not NULL and UserId in (select UserID from tUser where LoginId='" + USerId + "')) and statusID <>5 order by CreationDate " + searchorder;
                } else if (ObjectType.equals("Task") && PageMenuTagName.equals("Task")) {
                    query = "select top " + querytext + " ItemIDInProject from tTask  where ProjectID=" + ProjectId + " and TaskType is not NULL order by CreationDate " + searchorder;
                } else if (ObjectType.equals("Entity")) {
                    query = "select top " + querytext + " ItemIDInProject from tentityitem where projectid=" + ProjectId + " and EntityTypeid=" + EntityTypeId + " order by CreationDate " + searchorder;
                }
            } else if (SearchType.equals("Text")) {
                //SearchById="N";
                if (ObjectType.equals("Task") && PageMenuTagName.equals("Home")) {
                    query = "select ItemIDInProject from tTask where ItemID in (select ItemID from tTaskOwners where ItemID is not NULL and ItemID in (select ItemID from tTask where title like '%" + querytext + "%' and statusID <>5) and UserId in (select UserID from tUser where LoginId='" + USerId + "')) order by CreationDate desc";
                } else if (ObjectType.equals("Task") && PageMenuTagName.equals("Task")) {
                    query = "select ItemIDInProject from tTask  where title like '%" + querytext + "%' and ProjectID=" + ProjectId + " and TaskType is not NULL order by CreationDate desc";
                } else if (ObjectType.equals("Entity")) {
                    query = "select ItemIDInProject from tentityitem where projectid=" + ProjectId + " and EntityTypeid=" + EntityTypeId + " and title like '%" + querytext + "%' order by CreationDate desc";
                }
            } else if (SearchType.equals("Greater Than") || SearchType.equals("Less Than") || SearchType.equals("Hyphen")) {
                if (SearchText.length() < 2) {
                    if (ObjectType.equals("Task") && PageMenuTagName.equals("Home")) {
                        _query = "select top 1 ItemIDInProject from tTask where ItemID in(select ItemID from tTaskOwners where ItemID is not NULL and UserId in (select UserID from tUser where LoginId='" + USerId + "')) and statusID <>5 and ProjectID=" + ProjectId + "order by CreationDate desc";
                    } else if (ObjectType.equals("Task") && PageMenuTagName.equals("Task")) {
                        _query = "select top 1 ItemIDInProject from tTask  where ProjectID=" + ProjectId + " and TaskType is not NULL order by CreationDate desc";
                    } else if (ObjectType.equals("Entity")) {
                        _query = "select top 1 ItemIDInProject from tentityitem where projectid=" + ProjectId + " and EntityTypeid=" + EntityTypeId + " order by CreationDate desc";
                    }
                    String value1[][] = getSQLresult(_query);
                    if (value1.length != 0) {
                        int ID = Integer.parseInt(value1[0][0]);
                        if (SearchType.equals("Hyphen")) {
                            int Id1 = 0;
                            if (ID >= 20 && (SearchType.equals("Hyphen"))) {
                                Id1 = ID - 20;
                            } else {
                                Id1 = 10;
                                ID = 1;
                            }
                            SearchText = Id1 + "-" + ID;
                            querytext = ">" + (Id1 - 1) + " and ItemIDInProject <" + (ID + 1);
                        } else {
                            if (ID >= 10 && (SearchType.equals("Greater Than"))) {
                                ID = ID - 10;
                            } else {
                                ID = 10;
                            }
                            SearchText = SearchText + ID;
                            querytext = SearchText;
                        }
                    }
                }
                if (ObjectType.equals("Task") && PageMenuTagName.equals("Home")) {
                    query = "select ItemIDInProject from tTask where ItemID in(select ItemID from tTaskOwners where ItemID is not NULL and ItemIDInProject" + querytext + " and UserId in (select UserID from tUser where LoginId='" + USerId + "')) and statusID <>5 order by CreationDate desc";
                } else if (ObjectType.equals("Task") && PageMenuTagName.equals("Task")) {
                    query = "select ItemIDInProject from tTask where ItemIDInProject" + querytext + " and ProjectID=" + ProjectId + " and TaskType is not NULL order by CreationDate desc";
                } else if (ObjectType.equals("Entity")) {
                    query = "select ItemIDInProject from tentityitem where projectid=" + ProjectId + " and EntityTypeid=" + EntityTypeId + " and ItemIDInProject" + querytext + " order by CreationDate desc";
                }
            } else if ((SearchType.equals("ID") || SearchType.equals("Comma") || SearchType.equals("Comma-Whitespace"))) {
                IsSearchByID = "Y";
                //if (SearchText.length() == 1) 
                //{
                if (ObjectType.equals("Task") && PageMenuTagName.equals("Home")) {
                    _query = "select top 1 ItemIDInProject from tTask where ItemID in(select ItemID from tTaskOwners where ItemID is not NULL and UserId in (select UserID from tUser where LoginId='" + USerId + "')) and statusID <>5 order by CreationDate desc";
                } else if (ObjectType.equals("Task") && PageMenuTagName.equals("Task")) {
                    _query = "select top 1 ItemIDInProject from tTask where ProjectID=" + ProjectId + " and TaskType is not NULL order by CreationDate desc";
                } else if (ObjectType.equals("Entity")) {
                    _query = "select top 1 ItemIDInProject from tentityitem where projectid=" + ProjectId + " and EntityTypeid=" + EntityTypeId + " order by CreationDate desc";
                }
                String value1[][] = getSQLresult(_query);
                int ID = Integer.parseInt(value1[0][0]);
                if (SearchType.equals("ID")) {
                    querytext = String.valueOf(ID);
                    SearchText = querytext;
                } else {
                    querytext = ID + "," + (ID - 1) + "," + (ID - 2) + "," + (ID - 3);
                    if (SearchType.equals("Comma-Whitespace")) {
                        SearchText = ID + " , " + (ID - 1) + " , " + (ID - 2) + " , " + (ID - 3) + "    ";
                    } else {
                        SearchText = querytext;
                    }
                }
                //}
                if (ObjectType.equals("Task") && PageMenuTagName.equals("Home")) {
                    query = "select ItemIDInProject from tTask where ItemID in (select ItemID from tTaskOwners where ItemID is not NULL and ItemID in (select ItemID from tTask where ItemIDInProject in (" + querytext + ") and statusID <>5) and UserId in (select UserID from tUser where  LoginId='" + USerId + "')) order by CreationDate desc";
                } else if (ObjectType.equals("Task") && PageMenuTagName.equals("Task")) {
                    query = "select ItemIDInProject from tTask  where ItemIDInProject in (" + querytext + ") and ProjectID=" + ProjectId + " and TaskType is not NULL order by CreationDate desc";
                } else if (ObjectType.equals("Entity")) {
                    query = "select ItemIDInProject from tentityitem where projectid=" + ProjectId + " and EntityTypeid=" + EntityTypeId + " and ItemIDInProject in (" + querytext + ") order by CreationDate desc";
                }
            }
            Thread.sleep(3000);
            if (!query.isEmpty()) {
                //int rowcnt=_getSearchRecordCount(SearchText,"",driver); 
                System.out.println(SearchText);
                EndUser_ListPage_SearchBox(SearchText, "N", "", IsSearchByID, driver);
                Thread.sleep(2000);
                String _recno = "";
                int rowcnt = 0;
                try {
                    _recno = driver.findElement(By.xpath("//*[contains(text(),'Total ')][contains(text(),' record(s)')]")).getText().toString().trim();
                } catch (Exception e) {
                    _recno = driver.findElement(By.xpath("//*[contains(text(),'Retrieved ')][contains(text(),' record(s)')]")).getText().toString().trim();
                    if (_recno.contains("3000")) {
                        rowcnt = 3000;
                    }
                }
                if (rowcnt == 0) {
                    rowcnt = Integer.parseInt(_recno.replaceAll("[^0-9]", ""));
                }
                /*String _recno = driver.findElement(By.xpath("//div[@id='PageBar-targetEl']/div[7]")).getText().toString().trim();
                 int pos1 = 0, pos2 = 0;
                 if (_recno.contains("Total")) {
                 pos1 = (_recno.indexOf("Total ") + 6);
                 pos2 = _recno.indexOf(" record(s)");
                 } else if (_recno.contains("Retrieved")) {
                 pos1 = (_recno.indexOf("Retrieved ") + 10);
                 pos2 = _recno.indexOf(" record(s)");
                 }
                 int rowcnt = Integer.parseInt(_recno.substring(pos1, pos2));*/
                String value[][] = getSQLresult(query);
                Thread.sleep(2000);
                if (value == null) {
                    TestExeStatus = "No Records are fetched by SQL query.";
                    return TestExeStatus;
                }
                i = value.length;
                if (rowcnt > 0) {
                    if (i == rowcnt) {
                        while (i != 0 && i < 11 && !CurrentPageName.contains("Multi Edit")) {
                            Thread.sleep(1500);
                            shownval = GetSpecificFieldValue(View, "ID", i, driver);
                            try {
                                if (!shownval.equals(value[i - 1][0])) {
                                    SortSpecificField("", "Title", driver);
                                    Thread.sleep(1000);
                                    SortSpecificField("", "ID", driver);
                                    shownval = GetSpecificFieldValue("", "ID", i, driver);
                                    if (!shownval.equals(value[i - 1][0])) {
                                        SortSpecificField("", "ID", driver);
                                        shownval = GetSpecificFieldValue("", "ID", i, driver);
                                        if (!shownval.equals(value[i - 1][0])) {
                                            TestExeStatus = "Search Result didn't match.";
                                            return TestExeStatus;
                                        }
                                    }
                                }
                            } catch (Exception e) {
                            }
                            i--;
                            View = "";
                        }
                        TestExeStatus = "Passed";
                    } else {
                        TestExeStatus = "Record count didn't match.";
                    }
                } else {
                    if (value == null) {
                        TestExeStatus = "Passed";
                    }
                }
            }
        } catch (Exception e1) {
            TestExeStatus = "Page Level Error." + e1.getMessage();
        }
        return TestExeStatus;
    }
    
    public static int getLastTaskID(String tasks, String ObjectId, String Workspace) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public static int _getSearchRecordCount(String SearchText, String View, WebDriver driver) throws Exception {
        String srchbox = "KovairMaster_Main_txtSearchByIdOrTxt";
        int row_size = 0;
        try {
            WebDriverWait wait = new WebDriverWait(driver, 90);
            if (!View.isEmpty()) {
                KovairGenericClass.ViewSelection(View, "N", "", "", driver);
            }
            wait = new WebDriverWait(driver, 120);
            wait.until(ExpectedConditions.visibilityOf((driver.findElement(By.id(srchbox)))));
            if (driver.findElement(By.id(srchbox)) != null) {
                if (!SearchText.isEmpty()) {
                    WebElement searchbox = driver.findElement(By.id(srchbox));
                    searchbox.click();
                    Thread.sleep(1000);
                    searchbox.clear();
                    //Thread.sleep(1500);
                    searchbox.sendKeys(SearchText);
                    Thread.sleep(1500);
                    WebElement searchimg = driver.findElement(By.id("KovairMaster_Main_btnSearch"));
                    JavascriptExecutor executor = (JavascriptExecutor) driver;
                    //search
                    executor.executeScript("arguments[0].click();", searchimg);
                    wait = new WebDriverWait(driver, 120);
                }
                String _recno = driver.findElement(By.xpath("//div[@id='PageBar-targetEl']/div[7]")).getText().toString().trim();
                int pos1 = (_recno.indexOf("Total ") + 6);
                int pos2 = _recno.indexOf(" record(s)");
                row_size = Integer.parseInt(_recno.substring(pos1, pos2));
            }
        } catch (Exception e) {
            return -1;
        }
        return row_size;
    }
    
    public static int GetRecordCountForFilter(String FilterId, String EntityTypeId) throws Exception {
        int filterRelatedRecordCount = 0;
        try {
            String result[][] = getSQLresult("select 'select count(*) from tEntityItem where EntityTypeID='+cast('" + EntityTypeId + "' as varchar)+' and ISNULL(RecordStatus,''A'') = ''A'' and '+replace(SQL,'$FIELDVALUE$',Value2) from tFilterConditionLines where FilterId='" + FilterId + "'");
            if (result[0][0] != null) {
                String sql = result[0][0];
                String rawValue[][] = getSQLresult(sql);
                filterRelatedRecordCount = rawValue != null ? Integer.parseInt(rawValue[0][0]) : 0;
            }
        } catch (Exception e) {
        }
        return filterRelatedRecordCount;
    }

    public static String TaskStatusDoubleClick(String View, String StatusValue, String frameid, WebDriver driver) throws Exception {
        String Fldvalue = null;
        try {
            if (!View.isEmpty()) {
                KovairGenericClass.ViewSelection(View, "N", "", "", driver);
            }
            WebDriverWait _wait = new WebDriverWait(driver, 120);
            Thread.sleep(1500);
            int col_no = 0;
            String col_par_div = (driver.findElement(By.xpath("//div[@id='EntityGrid']/div"))).getAttribute("id").toString();
            int col_count = (driver.findElements(By.xpath("//div[@id='" + col_par_div + "']/div/div/div"))).size();
            String col_text;
            for (int i = 0; i < col_count; i++) {
                col_text = driver.findElements(By.xpath("//div[@id='" + col_par_div + "']/div/div/div")).get(i).getText().toString();
                if (col_text.contains("Status")) {
                    col_no = i + 1;
                    break;
                }
            }
            String data_par_div = (driver.findElement(By.xpath("//div[@id='EntityGrid-body']/div"))).getAttribute("id").toString();
            int row_size = driver.findElements(By.xpath("//tbody[@id='" + data_par_div + "-body']/tr")).size();
            WebElement _cell = driver.findElement(By.xpath("//tbody[@id='" + data_par_div + "-body']/tr[" + row_size + "]/td[" + col_no + "]/div"));
            Actions oAction = new Actions(driver);
            Actions dblclk = oAction.doubleClick(_cell);
            dblclk.build().perform();
            //oAction.doubleClick().perform();
            Thread.sleep(1000);
            //((JavascriptExecutor) driver).executeScript("arguments[0].fireEvent('ondblclick');", _cell); 
            JavascriptExecutor executor = (JavascriptExecutor) driver;
            executor.executeScript("var evt = document.createEvent('MouseEvents');"
                    + "evt.initMouseEvent('dblclick',true, true,window, 0, 0, 0, 0, 0, false, false, false, false, 0,null);"
                    + "arguments[0].dispatchEvent(evt);", _cell);
            //oAction.doubleClick().build().perform();
            //oAction.doubleClick(_cell).build().perform();
            try {
                WebElement status_div = driver.findElement(By.xpath("//div[@id='EntityGrid']/div[5]"));
                WebElement dropdown = driver.findElement(By.xpath("//div[@id='EntityGrid']/div[5]/table/tbody/tr/td[2]/table/tbody/tr/td[2]/div[@role='button']"));
                JavascriptExecutor executor1 = (JavascriptExecutor) driver;
                executor1.executeScript("arguments[0].click();", dropdown);
                WebElement status_options = driver.findElement(By.xpath("//iframe[@id='" + frameid + "'/html/body/div[contains(id,'boundlist')]"));
                int _rows = status_options.findElements(By.xpath("//ul[@class='x-list-plain']/li")).size();
                for (int i = 1; i <= _rows; i++) {
                    Thread.sleep(500);
                    WebElement status_val = driver.findElements(By.xpath("////ul[@class='x-list-plain']")).get(i);
                    if (status_val.getText().toString().trim().equals(StatusValue)) {
                        status_val.click();
                        Thread.sleep(2000);
                        TestExeStatus = "Passsed";
                        break;
                    }
                }
            } catch (Exception e) {
            }
        } catch (Exception e) {
            return null;
        }
        return TestExeStatus;
    }

    public static String Pagination(int RecordCount, String Filter, WebDriver driver) throws Exception {
        try {
            if (RecordCount == 10 || RecordCount < 10) {
                RecordCount = 10;
            } else if ((RecordCount < 20 && RecordCount > 10) || RecordCount == 20) {
                RecordCount = 20;
            } else if ((RecordCount < 30 && RecordCount > 20) || RecordCount == 30) {
                RecordCount = 30;
            } else if (RecordCount >= 50) {
                RecordCount = 50;
            }
            if (!Filter.isEmpty()) {
                KovairGenericClass.FilterSelection(Filter, "N", "", driver);
            }
            Thread.sleep(1500);
            //driver.findElement(By.cssSelector("table[^=ext-comp-]")).getText().toString().trim();
            String drpdwn_tblid = driver.findElement(By.xpath("//div[@id='PageBar-targetEl']/table[contains(@id,'ext-comp-')]")).getAttribute("id").toString().trim();
            WebElement drpdwn = driver.findElement(By.xpath(("//table[@id='" + drpdwn_tblid + "-triggerWrap']/tbody/tr/td[2]/div")));
            drpdwn.click();
            WebElement pagelist_li = driver.findElement(By.xpath("//div[contains(@id,'boundlist-')]/ul/li[contains(.,'" + RecordCount + "')]"));
            pagelist_li.click();
            Thread.sleep(1000);
            String _pageno = driver.findElement(By.xpath("//div[@id='PageBar-targetEl']/div[3]")).getText().toString().trim();
            int pageno = Integer.parseInt(_pageno.replace("of", "").trim());
            //int pageno=Integer.parseInt(_pageno.substring(_pageno.length()-1));
            String _recno = driver.findElement(By.xpath("//div[@id='PageBar-targetEl']/div[7]")).getText().toString().trim();
            int pos1 = 0, pos2 = 0;
            if (_recno.contains("Total")) {
                pos1 = (_recno.indexOf("Total ") + 6);
                pos2 = _recno.indexOf(" record(s)");
            } else if (_recno.contains("Retrieved")) {
                pos1 = (_recno.indexOf("Retrieved ") + 10);
                pos2 = _recno.indexOf(" record(s)");
            }
            int rowcnt = Integer.parseInt(_recno.substring(pos1, pos2));
            float recno = Float.parseFloat(_recno.substring(pos1, pos2));
            double currentpage = Math.ceil(recno / RecordCount);
            if (currentpage == pageno) {
                if (driver.findElement(By.xpath("//div[@id='PageBar-targetEl']/a[3]")).isDisplayed()) {
                    driver.findElement(By.xpath("//div[@id='PageBar-targetEl']/a[3]")).click();
                }
                Thread.sleep(2000);
                if (driver.findElement(By.xpath("//div[@id='PageBar-targetEl']/a[2]")).isEnabled()) {
                    driver.findElement(By.xpath("//div[@id='PageBar-targetEl']/a[2]")).click();
                }
                Thread.sleep(2000);
                if (driver.findElement(By.xpath("//div[@id='PageBar-targetEl']/a[4]")).isEnabled()) {
                    driver.findElement(By.xpath("//div[@id='PageBar-targetEl']/a[4]")).click();
                }
                Thread.sleep(2000);
                if (driver.findElement(By.xpath("//div[@id='PageBar-targetEl']/a[1]")).isEnabled()) {
                    driver.findElement(By.xpath("//div[@id='PageBar-targetEl']/a[1]")).click();
                }
                Thread.sleep(2000);
                TestExeStatus = "Passed";
            }
        } catch (WebDriverException e) {
            TestExeStatus = "Failed";
            TestErrDesc = e.getMessage();
        }
        return TestExeStatus;
    }
    //Sencha Ends

    public static String ListPage_SearchBox(String ItemName, String PageName, String ListPageType, WebDriver driver) throws Exception {
        String Listidpart = null;
        String tr_id = null;
        String property = "Name";;
        if (ListPageType.equals("OmnibusList")) {
            Listidpart = "EntityMappingList";
        } else {
            if (PageName.contains("Section")) {
                Listidpart = "FRMSECLIST";
            } else if (PageName.contains("Report")) {
                Listidpart = "RPTSECLIST";
            } else if (PageName.contains("Lookup")) {
                Listidpart = PageName + "List";
                PageName = PageName + "Type";
            } else if (PageName.contains("Policy")) {
                Listidpart = PageName + "List";
            } else if (PageName.contains("Access")) {
                Listidpart = "ACCESSGRPLIST";
                PageName = "Group";
            } else if (PageName.contains("Filters")) {
                Listidpart = "FilterList";
                PageName = "Filter";
            } //            else if (PageName.contains("Roles")) {
            //                Listidpart = "ROLELIST";
            //                PageName = "Role";
            //            } 
            else {
                Listidpart = PageName.toUpperCase() + "LIST";
            }

            //_labelpart
            if (PageName.contains("Field")) {
                property = "Label";
            }
        }
        if (PageName.equals("Registration")) {
            PageName = "ToolInstance";
        }
        String srchbox = "FilterName";
        try {
            if (driver.findElement(By.id(srchbox)) != null) {
                WebElement searchbox = driver.findElement(By.id(srchbox));
                searchbox.clear();
                WebDriverWait wait = new WebDriverWait(driver, 30);
                wait.until(ExpectedConditions.textToBePresentInElement(searchbox, ""));
                searchbox.sendKeys(ItemName);
                Thread.sleep(1500);
//                WebElement searchimg = driver.findElement(By.id("KovairMaster_Main_GRID_" + Listidpart + "_ctl00_ctl02_ctl02_Filter_DISPLAY_" + PageName + property));
                WebElement searchimg = driver.findElement(By.id("Filterimg"));
                wait.until(ExpectedConditions.elementToBeClickable(searchimg));
                JavascriptExecutor executor = (JavascriptExecutor) driver;
                executor.executeScript("arguments[0].click();", searchimg);
                //searchimg.click();
//                String srchcontextdiv = "KovairMaster_Main_GRID_" + Listidpart + "_rfltMenu_detached";
                String srchcontextdiv = "filtrMenuDiv";
                WebElement Text = driver.findElement(By.xpath("//div[@id='" + srchcontextdiv + "']/ul/li[6]/a/span"));
                Thread.sleep(1500);
                if (Text.getText().toString().trim().equals("EqualTo")) {
                    WebDriverWait wait1 = new WebDriverWait(driver, 30);
                    wait.until(ExpectedConditions.elementToBeClickable(Text));
                    JavascriptExecutor executor1 = (JavascriptExecutor) driver;
                    executor1.executeScript("arguments[0].click();", Text);
                    try {
                        wait.until(ExpectedConditions.invisibilityOfElementLocated(By.id("img_loading")));
                    } catch (Exception e) {
                    }
//                    tr_id = "KovairMaster_Main_GRID_" + Listidpart + "_ctl00__0";
                    WebElement tr = driver.findElement(By.xpath("//div[@id='LkupListGrid-body']/div/table/tbody/tr"));
                    tr_id = tr.getAttribute("id");
                    try {
                        driver.findElement(By.id(tr_id));
                    } catch (Exception e4) {
                        tr_id = null;
                    }
                }
            }
        } catch (Exception e) {
        }
        return tr_id;
    }
    public static String SpecificMenu_SubMenu_ClickedNew(String MenuSubMenuText, WebDriver driver) throws Exception {
        String MenuFrameId = null;
        String ExecStatus = null;
        WebElement Menu = null;
        WebDriverWait wait = new WebDriverWait(driver, 100);
        try {
            driver.findElement(By.xpath("//div[@id='collapseDiv']/table/tbody/tr/td[2]/img")).click();
            wait.until(ExpectedConditions.invisibilityOfElementLocated(By.id("img_loading")));
        } catch (Exception ex) {
            Thread.sleep(5000);
        }
        try {
            //Menu = driver.findElement(By.xpath("//div[@id='MenuContainer']/div/h2/a[@title='" + MenuSubMenuText + "']"));
            //Menu = driver.findElement(By.xpath("//div[@id='MenuContainer']/div/h2/a[contains(@title,'" + MenuSubMenuText + "')]"));
            // Menu.click();


            int menuCount = driver.findElements(By.xpath("//div[@id='MenuContainer']/div/h2")).size();
            String EntityName = MenuSubMenuText;
            System.out.println("The required string in kovairGenericClass is " + EntityName);
            for (int i = 1; i <= menuCount; i++) {
                Menu = driver.findElement(By.xpath("//div[@id='MenuContainer']/div/h2[" + i + "]/a"));
                String EntityName1 = Menu.getAttribute("title");
                if (EntityName1.equals(EntityName)) {
                    ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", Menu);
                    Menu.click();
                    break;
                }

            }
            MenuFrameId = Menu.getAttribute("id").toString().replace("Menu_a", "cc");
            WebElement _MenuFrameId = driver.findElement(By.id(MenuFrameId));
            driver.switchTo().frame(_MenuFrameId);
            System.out.println(_MenuFrameId);
            //int tabcount= driver.findElements(By.xpath("//div[@id='tabHolder']/p")).size();
            //System.out.println("The required p count is " +tabcount);
            //   String frameid="cc7159_0_7329";
            //for(int i=1;i<=tabcount;i++)
            //{
            //WebElement gh=driver.findElement(By.xpath("//div[@id='tabHolder']/p["+i+"]/iframe"));
            // WebElement gh=driver.findElement(By.xpath("//iframe[@id='cc36_36_0_2']"));
            // MenuFrameId= gh.getAttribute("id");
            //  if(MenuFrameId.equals(frameid))
            //{
            // System.out.println("The name of the iframe is" + MenuFrameId);
            //driver.switchTo().frame(MenuFrameId);
            //  break;
            //  }
            // }
            ExecStatus = "Passed";
        } catch (Exception e) {
            int menuCount = driver.findElements(By.xpath("//div[@id='MenuContainer']/div/h2")).size();
            int countUserDefinedMenu = 0;
            for (int i = 1; i <= menuCount; i++) {
                Menu = driver.findElement(By.xpath("//div[@id='MenuContainer']/div/h2[" + i + "]/a"));
                String HasLink = null;
                try {
                    HasLink = Menu.getAttribute("nolnk").toString();
                } catch (Exception e1) {
                    continue;
                }
                if (HasLink.trim().equals("Y")) {
                    WebElement h_Menu = driver.findElement(By.xpath("//div[@id='MenuContainer']/div/h2[" + i + "]"));
                    String menudiv_id = Menu.getAttribute(("id"));
                    menudiv_id = menudiv_id.replace("Menu_a", "Menu_subMenucontainer");
                    int SubmenuCount = driver.findElements(By.xpath("//div[@id='" + menudiv_id + "']/ul/li/a")).size();
                    if (!h_Menu.getAttribute("class").contains("active")) {
                        Menu.click();
                        Thread.sleep(2000);
                    }
                    countUserDefinedMenu++;
                    int j, flag = 0;
                    for (j = 0; j < SubmenuCount; j++) {
                        WebElement submenuatag = driver.findElements(By.xpath("//div[@id='" + menudiv_id + "']/ul/li/a")).get(j);
                        if (submenuatag.getText().trim().contains(MenuSubMenuText.trim())) {
                            submenuatag.click();
                            Thread.sleep(3000);
                            flag = 1;
                            String MenuFrame = menudiv_id;
                            MenuFrame = MenuFrame.replace("Menu_subMenucontainer", "cc");
                            //WebElement _MenuFrameId=driver.findElement(By.id(MenuFrame+"_"+(j+1)));
                            //driver.switchTo().frame(_MenuFrameId);
                            MenuFrameId = MenuFrame + "_" + (j + 1);
                            System.out.println("Inside Catch MenuFrameId=  " + MenuFrameId);
                            driver.switchTo().frame(MenuFrameId);
                            ExecStatus = "Passed";
                            break;
                        }
                        Thread.sleep(1000);
                    }
                    if (flag == 1) {
                        break;
                    }
                }
            }
        }
        Thread.sleep(1000);
        return MenuFrameId;

    }

    
    public static String RequiredField(String FieldName, String PageName, WebDriver driver) throws Exception {
        String Result = "";
        try {

            WebElement pagetitle = driver.findElement(By.id("pageTitle"));
            if (pagetitle.getText().contains("Fields")) {
                WebElement searchbox = driver.findElement(By.id("FilterName"));
                Thread.sleep(1000);
                searchbox.clear();
                Thread.sleep(2000);
                searchbox.sendKeys(FieldName);
                Thread.sleep(3000);
                driver.findElement(By.id("Filterimg")).click();
                Thread.sleep(2000);
                driver.findElement(By.xpath("//div[@id='filtrMenuDiv']/ul/li[2]/a/span")).click();
                Thread.sleep(3000);
                WebElement Recordname = driver.findElement(By.xpath("//div[@id='FieldListGrid-body']/div/table/tbody/tr[1]/td[1]/div/span"));
                Thread.sleep(3000);
                if (Recordname.getText().equals(FieldName)) {
                    Result = "True";
                } else {
                    Result = "False";
                }
            }
        } catch (Exception e) {
            Result = "False";
        }
        return Result;
    }


    public static void ListPage_SearchBox_Clear(String PageName, String ListPageType, WebDriver driver) throws Exception {
        String Listidpart = null;
        String tr_id = null;
        if (ListPageType.equals("OmnibusList")) {
            Listidpart = "EntityMappingList";
        } else {
            if (PageName.contains("Section")) {
                Listidpart = "FRMSECLIST";
            } else {
                Listidpart = PageName.toUpperCase() + "LIST";
            }
        }
        if (PageName.equals("Registration")) {
            PageName = "ToolInstance";
        }
        String srchbox = "FilterName";
        try {
            if (driver.findElement(By.id(srchbox)) != null) {
                WebElement searchbox = driver.findElement(By.id(srchbox));
                searchbox.clear();
            }
        } catch (Exception e) {
        }
    }

    public static String SaveItemVerify(String ItemName, String PageName, String ListPageType, WebDriver driver) throws Exception {
        String trid = null;
        try {
            trid = ListPage_SearchBox(ItemName, PageName, ListPageType, driver);
            if (trid.isEmpty()) {
                trid = Get_specific_tr_id(ItemName, PageName, ListPageType, driver);
                if (trid != null) {
                    TestExeStatus = "Passed";
                } else {
                    TestExeStatus = PageName + " named " + ItemName + " not found.";
                }
                Thread.sleep(2000);
                return TestExeStatus;
            } else {

                /*try
                 {
                 WebElement tr =driver.findElement(By.id(trid));
                 tr.findElement(By.xpath("//td[3]/span")).getText().toString();
                 String _text=tr.findElement(By.xpath("//td/span/span")).getText().toString();
                 if(_text.equals(ItemName))
                 {
                 TestExeStatus="Passed";
                 }
                 else
                 {
                 TestExeStatus=PageName+" named "+ItemName+" not found.";
                 }
                 }
                 catch(Exception e1)
                 {
                 TestExeStatus="Page Control Level Error.'Contains' is not clicked.";
                 }*/
                TestExeStatus = "Passed";
            }
        } catch (Exception e) {
            TestExeStatus = "Page Level Error.";
        }
        return TestExeStatus;
    }

    public static String List_ItemName_Double_click(String ItemName, String PageName, String ListPageType, WebDriver driver) throws Exception {
        String ActionMenuIdPart = null;
        String trid = null;
        try {
            Thread.sleep(3000);
            trid = ListPage_SearchBox(ItemName, PageName, ListPageType, driver);
            Thread.sleep(2000);
            if (trid != null) {
                WebElement Name_Span = driver.findElement(By.xpath("//*[contains(text(),'" + ItemName + "')]"));
                Actions oAction = new Actions(driver);
                oAction.moveToElement(Name_Span).doubleClick().perform();
                Thread.sleep(3500);
                TestExeStatus = KovairGenericClass.Page_Proper_Title("View Form", driver);
            }
        } catch (Exception e) {
            TestExeStatus = "Page Level Error.";
        }
        return TestExeStatus;
    }
    
    public static String IDTextSearchResult(String SearchText, String SearchType, String USerId, String View, String PageMenuTagName, String ObjectType, String[] Pagedetails, WebDriver driver) throws Exception {
        try {
            int i = 0;
            String query = null;
            String _query = null;
            String ProjectId = null;
            String EntityTypeId = null;
            String shownval = null;
            String searchno = null;

            if (Pagedetails == null)// && !ObjectType.equals("Task"))
            {
                Pagedetails = _getPageDetails(PageMenuTagName, driver);

            }
            Thread.sleep(2000);
            ProjectId = Pagedetails[0];
            if (!ObjectType.equals("Task")) {
                EntityTypeId = Pagedetails[1];
            }

            //String frameid=_getFrameIdfromSubmenu(PageMenuTagName,"",driver);
            //driver.switchTo().frame(frameid);
            if (SearchType.equals("Last")) {
                searchno = SearchText.substring(4);
                if (ObjectType.equals("Task") && PageMenuTagName.equals("Home")) {
                    query = "select top " + searchno + " ItemIDInProject from tTask where ItemID in(select ItemID from tTaskOwners where ItemID is not NULL and UserId in (select UserID from tUser where LoginId='" + USerId + "')) and statusID <>5 order by CreationDate desc";
                } else if (ObjectType.equals("Task") && PageMenuTagName.equals("Task")) {
                    query = "select top " + searchno + " ItemIDInProject from tTask  where ProjectID=" + ProjectId + " and TaskType is not NULL order by CreationDate desc";
                } else if (ObjectType.equals("Entity")) {
                    query = "select top " + searchno + " ItemIDInProject from tentityitem where projectid=" + ProjectId + " and EntityTypeid=" + EntityTypeId + " order by CreationDate desc";
                }
            } else if (SearchType.equals("Text")) {
                if (ObjectType.equals("Task") && PageMenuTagName.equals("Home")) {
                    query = "select ItemIDInProject from tTask where ItemID in (select ItemID from tTaskOwners where ItemID is not NULL and ItemID in (select ItemID from tTask where title like '%" + SearchText + "%' and statusID <>5) and UserId in (select UserID from tUser where LoginId='" + USerId + "')) order by CreationDate desc";
                } else if (ObjectType.equals("Task") && PageMenuTagName.equals("Task")) {
                    query = "select ItemIDInProject from tTask  where title like '%" + SearchText + "%' and ProjectID=" + ProjectId + " and TaskType is not NULL order by CreationDate desc";
                } else if (ObjectType.equals("Entity")) {
                    query = "select ItemIDInProject from tentityitem where projectid=" + ProjectId + " and EntityTypeid=" + EntityTypeId + " and title like '%" + SearchText + "%' order by CreationDate desc";
                }
            } else if (SearchType.equals("Greater Than") || SearchType.equals("Less Than")) {
                if (SearchText.length() == 1) {

                    if (ObjectType.equals("Task") && PageMenuTagName.equals("Home")) {
                        _query = "select top 1 ItemIDInProject from tTask where ItemID in(select ItemID from tTaskOwners where ItemID is not NULL and UserId in (select UserID from tUser where LoginId='" + USerId + "')) and statusID <>5 and ProjectID=" + ProjectId + "order by CreationDate desc";
                    } else if (ObjectType.equals("Task") && PageMenuTagName.equals("Task")) {
                        _query = "select top 1 ItemIDInProject from tTask  where ProjectID=" + ProjectId + " and TaskType is not NULL order by CreationDate desc";
                    } else if (ObjectType.equals("Entity")) {
                        _query = "select top 1 ItemIDInProject from tentityitem where projectid=" + ProjectId + " and EntityTypeid=" + EntityTypeId + " order by CreationDate desc";
                    }
                    String value1[][] = getSQLresult(_query);
                    if (value1.length != 0) {
                        int ID = Integer.parseInt(value1[0][0]);
                        if (ID >= 10 && (SearchType.equals("Greater Than"))) {
                            ID = ID - 10;
                        } else {
                            ID = 10;
                        }
                        SearchText = SearchText + ID;
                    }
                }
                if (ObjectType.equals("Task") && PageMenuTagName.equals("Home")) {
                    query = "select ItemIDInProject from tTask where ItemID in(select ItemID from tTaskOwners where ItemID is not NULL and ItemIDInProject" + SearchText + " and UserId in (select UserID from tUser where LoginId='" + USerId + "')) and statusID <>5 order by CreationDate desc";
                } else if (ObjectType.equals("Task") && PageMenuTagName.equals("Task")) {
                    query = "select ItemIDInProject from tTask where ItemIDInProject" + SearchText + " and ProjectID=" + ProjectId + " and TaskType is not NULL order by CreationDate desc";
                } else if (ObjectType.equals("Entity")) {
                    query = "select ItemIDInProject from tentityitem where projectid=" + ProjectId + " and EntityTypeid=" + EntityTypeId + " and ItemIDInProject" + SearchText + " order by CreationDate desc";
                }
            } else if (SearchType.equals("Comma")) {
                if (SearchText.length() == 1) {
                    if (ObjectType.equals("Task") && PageMenuTagName.equals("Home")) {
                        _query = "select top 1 ItemIDInProject from tTask where ItemID in(select ItemID from tTaskOwners where ItemID is not NULL and UserId in (select UserID from tUser where LoginId='" + USerId + "')) and statusID <>5 order by CreationDate desc";
                    } else if (ObjectType.equals("Task") && PageMenuTagName.equals("Task")) {
                        _query = "select top 1 ItemIDInProject from tTask where ProjectID=" + ProjectId + " and TaskType is not NULL order by CreationDate desc";
                    } else if (ObjectType.equals("Entity")) {
                        _query = "select top 1 ItemIDInProject from tentityitem where projectid=" + ProjectId + " and EntityTypeid=" + EntityTypeId + " order by CreationDate desc";
                    }
                    String value1[][] = getSQLresult(_query);
                    int ID = Integer.parseInt(value1[0][0]);
                    SearchText = ID + "," + (ID - 1) + "," + (ID - 2) + "," + (ID - 3);
                }
                if (ObjectType.equals("Task") && PageMenuTagName.equals("Home")) {
                    query = "select ItemIDInProject from tTask where ItemID in (select ItemID from tTaskOwners where ItemID is not NULL and ItemID in (select ItemID from tTask where ItemIDInProject in (" + SearchText + ") and statusID <>5) and UserId in (select UserID from tUser where  LoginId='" + USerId + "')) order by CreationDate desc";
                } else if (ObjectType.equals("Task") && PageMenuTagName.equals("Task")) {
                    query = "select ItemIDInProject from tTask  where ItemIDInProject in (" + SearchText + ") and ProjectID=" + ProjectId + " and TaskType is not NULL order by CreationDate desc";
                } else if (ObjectType.equals("Entity")) {
                    query = "select ItemIDInProject from tentityitem where projectid=" + ProjectId + " and EntityTypeid=" + EntityTypeId + " and ItemIDInProject in (" + SearchText + ") order by CreationDate desc";
                }
            }
            Thread.sleep(3000);
            if (!query.isEmpty()) {
                //int rowcnt=_getSearchRecordCount(SearchText,"",driver); 
                System.out.println(SearchText);
                EndUser_ListPage_SearchBox(SearchText, "N", "", driver);
                Thread.sleep(2000);
                String _recno = driver.findElement(By.xpath("//div[@id='PageBar-targetEl']/div[7]")).getText().toString().trim();
                int pos1 = 0, pos2 = 0;
                if (_recno.contains("Total")) {
                    pos1 = (_recno.indexOf("Total ") + 6);
                    pos2 = _recno.indexOf(" record(s)");
                } else if (_recno.contains("Retrieved")) {
                    pos1 = (_recno.indexOf("Retrieved ") + 10);
                    pos2 = _recno.indexOf(" record(s)");
                }
                int rowcnt = Integer.parseInt(_recno.substring(pos1, pos2));
                String value[][] = getSQLresult(query);
                Thread.sleep(2000);
                if (value == null) {
                    TestExeStatus = "No Records are fetched by SQL query.";
                    return TestExeStatus;
                }
                i = value.length;
                if (rowcnt > 0) {
                    if (i == rowcnt) {
                        while (i != 0 && i < 11) {
                            Thread.sleep(1500);
                            shownval = GetSpecificFieldValue(View, "ID", i, driver);
                            try {
                                if (!shownval.equals(value[i - 1][0])) {
                                    SortSpecificField("", "Title", driver);
                                    Thread.sleep(1000);
                                    SortSpecificField("", "ID", driver);
                                    shownval = GetSpecificFieldValue("", "ID", i, driver);
                                    if (!shownval.equals(value[i - 1][0])) {
                                        SortSpecificField("", "ID", driver);
                                        shownval = GetSpecificFieldValue("", "ID", i, driver);
                                        if (!shownval.equals(value[i - 1][0])) {
                                            TestExeStatus = "Search Result didn't match.";
                                            return TestExeStatus;
                                        }
                                    }
                                }
                            } catch (Exception e) {
                            }
                            i--;
                            View = "";
                        }
                        TestExeStatus = "Passed";
                    } else {
                        TestExeStatus = "Record count didn't match.";
                    }
                } else {
                    if (value == null) {
                        TestExeStatus = "Passed";
                    }
                }
            }
        } catch (Exception e1) {
            TestExeStatus = "Page Level Error." + e1.getMessage();
        }
        return TestExeStatus;
    }

    public static String List_ActionMenu_Command_click(String ItemName, String PageName, String CommandText, String ListPageType, WebDriver driver) throws Exception {
        String ActionMenuIdPart = null;
        String trid = null;
        try {
            if (ItemName.isEmpty()) {
                ActionMenuIdPart = "PlaceHolderPopUp";
            } else {
                Thread.sleep(3000);
                trid = ListPage_SearchBox(ItemName, PageName, ListPageType, driver);
                Thread.sleep(2000);
                if (trid != null) {
                    try {
                        driver.findElement(By.id(trid)).click();
                    } catch (Exception e1) {
                        trid = Get_specific_tr_id(ItemName, PageName, ListPageType, driver);
                        driver.findElement(By.id(trid)).click();
                    }
                } else {
                    TestExeStatus = "No such " + PageName + " found.";
                    return TestExeStatus;
                }
                ActionMenuIdPart = "KovairMaster_Main";
            }
            Thread.sleep(2000);
            TestExeStatus = List_ActionMenu_Command_clickExecute(ItemName, CommandText, PageName, trid, driver);
        } catch (Exception e) {
            TestExeStatus = "Page Level Error.";
        }
        return TestExeStatus;
    }
//

    public static String List_ActionMenu_Command_clickExecute(String ItemName, String CommandText, String PageName, String trid, WebDriver driver) throws Exception {
        if (trid != null || ItemName == "") {
            driver.findElement(By.id("ActionButton-btnIconEl")).click();
            String Elementidpart = "RMAction";
            if (PageName.equals("Lookup")) {
                Elementidpart = "LookupList";
            } else if (PageName.equals("Report")) {
                Elementidpart = "ReportList";
            }
//            int elesize2 = driver.findElements(By.xpath("//div[@id='KovairMaster_Main_" + Elementidpart + "Menu_detached']/ul/li/a/span")).size();
            int elesize2 = driver.findElements(By.xpath("//div[@id='FormMenu-targetEl']/div/a/span")).size();
            if (elesize2 > 0) {
                Thread.sleep(1500);
                for (int j = 1; j <= elesize2; j++) {
                    Thread.sleep(1000);
                    try {
//                        WebElement rightclickoption = driver.findElement(By.xpath("//div[@id='KovairMaster_Main_" + Elementidpart + "Menu_detached']/ul/li[" + j + "]/a/span[starts-with(text()," + CommandText + ")]"));
                        WebElement rightclickoption = driver.findElement(By.xpath("//div[@id='FormMenu-targetEl']/div[" + j + "]/a/span"));
                        if (rightclickoption.getText().toString().trim().equals(CommandText)) {
                            //String fvdfv=driver.findElement(By.xpath("//div[@id='KovairMaster_Main_"+Elementidpart+"Menu_detached']/ul/li[1]")).getAttribute("text").toString();
                            TestExeStatus = "Passed";
                            JavascriptExecutor executor = (JavascriptExecutor) driver;
                            executor.executeScript("arguments[0].click();", rightclickoption);
                            Thread.sleep(3000);
                            return TestExeStatus;
                            //break;           
                        }
                    } catch (Exception e) {
                        TestExeStatus = CommandText + " not Found.";
                        return TestExeStatus;
                    }
                }
            } else {
                TestExeStatus = "No Action Menu Option found.";
            }
        }
        return TestExeStatus;
    }

    public static String record_context_click(String parentMenuName, String subMenuName, WebElement tr, WebDriver driver) throws Exception {
        String execStatus = null;
        try {
            (new Actions(driver)).contextClick(tr).sendKeys(Keys.ARROW_DOWN).sendKeys(Keys.ARROW_RIGHT).perform();

            WebElement menuHoverLink = driver.findElement(By.linkText(parentMenuName));
            Locatable hoverItem = (Locatable) menuHoverLink;
            Mouse mouse = ((HasInputDevices) driver).getMouse();
            mouse.mouseMove(hoverItem.getCoordinates());
            ((new Actions(driver))).moveToElement(menuHoverLink).build().perform();
            Thread.sleep(3000);

            WebElement subMenuElement = driver.findElement(By.id(subMenuName + "-itemEl"));
            JavascriptExecutor executor = (JavascriptExecutor) driver;
            Thread.sleep(3000);
            executor.executeScript("arguments[0].click();", subMenuElement);
            execStatus = "Passed";

        } catch (Exception e) {
            execStatus = "Failed " + e.getMessage();

        }
        return execStatus;
    }

    public static String RightClickValidation(String ItemName, String ValidationMessage, String PageName, WebDriver driver) throws Exception {
        //String  ValidationMessage="Please select a record from the list to perform an Action on it.";
        //String[] commands={"Edit","View","Clone","Delete"};
        String Elementidpart = "RMAction";
        if (PageName.equals("Lookup")) {
            Elementidpart = "LookupList";
        }
        driver.findElement(By.id("right_action_btn")).click();
        Thread.sleep(1000);
        //int k=0;
        int elesize2 = driver.findElements(By.xpath("//div[@id='KovairMaster_Main_" + Elementidpart + "Menu_detached']/ul/li")).size();
        if (elesize2 > 0) {
            Thread.sleep(1500);
            //for(int j=1;j<=elesize2;j++)
            //{
            WebElement rightclickoption = driver.findElement(By.xpath("//div[@id='KovairMaster_Main_" + Elementidpart + "Menu_detached']/ul/li[1]/a/span"));
            WebDriverWait wait = new WebDriverWait(driver, 120);
            //wait.until(ExpectedConditions.visibilityOf(rightclickoption));
            JavascriptExecutor executor = (JavascriptExecutor) driver;
            executor.executeScript("arguments[0].click();", rightclickoption);
            //if(rightclickoption.getText().toString().trim().equals(commands[k]))
            //{
            TestExeStatus = Modal_Text_Verification(ValidationMessage, driver);
            Modal_OKClick_Verification("OK", driver);
            if (TestExeStatus != "Passed") {
                TestExeStatus = "No Validation Given.";
                return TestExeStatus;
            }
            //break;
            //}
            //}
        }
        return TestExeStatus;
    }

    public static String List_ActionMenu_Command_Availabilty(String ItemName, String PageName, String CommandText, String ListPageType, WebDriver driver) throws Exception {
        String ActionMenuIdPart = null;
        String trid = null;
        if (ItemName == "") {
            ActionMenuIdPart = "PlaceHolderPopUp";
        } else {
            Thread.sleep(3000);
            trid = ListPage_SearchBox(ItemName, PageName, ListPageType, driver);
            try {
                driver.findElement(By.id(trid)).click();
            } catch (Exception e1) {
                trid = Get_specific_tr_id(ItemName, PageName, "OmnibusList", driver);
                driver.findElement(By.id(trid)).click();
            }
            ActionMenuIdPart = "KovairMaster_Main";
        }
        String Elementidpart = "RMAction";
        if (PageName.equals("Lookup")) {
            Elementidpart = "LookupList";
        }
        Thread.sleep(2000);
        if (trid != null || ItemName == "") {
            driver.findElement(By.id("right_action_btn")).click();
            int elesize2 = driver.findElements(By.xpath("//div[@id='" + ActionMenuIdPart + "_" + Elementidpart + "Menu_detached']/ul/li/a/span")).size();
            for (int j = 0; j < elesize2; ++j) {
                WebElement rightclickoption = driver.findElements(By.xpath("//div[@id='" + ActionMenuIdPart + "_" + Elementidpart + "Menu_detached']/ul/li/a/span[@class='rmText']")).get(j);
                if (rightclickoption.getText().equals(CommandText)) {
                    TestExeStatus = "Passed";
                    break;
                }
            }
            if (TestExeStatus != "Passed") {
                TestExeStatus = "Failed";
            }
        } else {
            TestExeStatus = "Failed";
        }
        return TestExeStatus;
    }

    public static String List_RightClick_Command_click(String ItemName, String PageName, String ParentCommandcommandText, String SubCommandcommandText, String ListPageType, WebDriver driver) throws Exception {
        try {
            String ActionMenuIdPart = null;
            String trid = null;
            if (ItemName == "") {
                ActionMenuIdPart = "PlaceHolderPopUp";
            } else {
                Thread.sleep(3000);
                trid = ListPage_SearchBox(ItemName, PageName, ListPageType, driver);
                try {
                    driver.findElement(By.id(trid)).click();
                } catch (Exception e1) {
                    trid = Get_specific_tr_id(ItemName, PageName, ListPageType, driver);
                    driver.findElement(By.id(trid)).click();
                }
                ActionMenuIdPart = "KovairMaster_Main";
            }
            Thread.sleep(2000);
            if (trid != null || ItemName == "") {
                Actions oAction = new Actions(driver);
                oAction.moveToElement(driver.findElement(By.id(trid)));
                oAction.contextClick(driver.findElement(By.id(trid))).build().perform();
                //WebElement elementOpen = driver.findElement(By.linkText(CommandText)); 
                WebElement elementOpen = null;
                if (SubCommandcommandText.equals("")) {
                    elementOpen = driver.findElement(By.linkText(ParentCommandcommandText));
                } else {
                    WebElement elementParentOpen = driver.findElement(By.linkText(ParentCommandcommandText));
                    oAction.moveToElement(elementParentOpen).build().perform();
                    elementOpen = driver.findElement(By.linkText(SubCommandcommandText));
                }
                elementOpen.click();
                TestExeStatus = "Passed";
            }
        } catch (Exception e) {
            TestExeStatus = "Failed";
        }
        return TestExeStatus;
    }

    public static String List_RightClick_Command_Availabilty(String ItemName, String PageName, String ParentCommandcommandText, String SubCommandcommandText, String ListPageType, String IsFirstOption, WebDriver driver) throws Exception {
        String ActionMenuIdPart = null;
        String trid = null;
        if (IsFirstOption == "Y") {
            if (ItemName == "") {
                ActionMenuIdPart = "PlaceHolderPopUp";
            } else {
                Thread.sleep(3000);
                trid = ListPage_SearchBox(ItemName, PageName, ListPageType, driver);
                try {
                    driver.findElement(By.id(trid)).click();
                } catch (Exception e1) {
                    trid = Get_specific_tr_id(ItemName, PageName, ListPageType, driver);
                    driver.findElement(By.id(trid)).click();
                }
                ActionMenuIdPart = "KovairMaster_Main";
            }
            Thread.sleep(2000);
            if (trid != null || ItemName == "") {
                Actions oAction = new Actions(driver);
                oAction.moveToElement(driver.findElement(By.id(trid)));
                oAction.contextClick(driver.findElement(By.id(trid))).build().perform();
            }
        }
        //WebElement elementOpen = driver.findElement(By.linkText(CommandText)); 
        WebElement elementOpen = null;
        if (SubCommandcommandText.equals("")) {
            elementOpen = driver.findElement(By.linkText(ParentCommandcommandText));
        } else {
            WebElement elementParentOpen = driver.findElement(By.linkText(ParentCommandcommandText));
            Actions oAction1 = new Actions(driver);
            oAction1.moveToElement(elementParentOpen).build().perform();
            elementOpen = driver.findElement(By.linkText(SubCommandcommandText));
        }
        TestExeStatus = "Passed";
        return TestExeStatus;
    }
    public static String List_RightClick_Command_Availabilty(String ItemName,String PageName,String ParentCommandcommandText,String SubCommandcommandText,WebDriver driver) throws Exception{
     try
     { 
       String trid=Get_specific_tr_id(ItemName,PageName,"OmnibusList",driver);       
       Actions oAction = new Actions(driver);
       oAction.moveToElement(driver.findElement(By.id(trid)));
       oAction.contextClick(driver.findElement(By.id(trid))).build().perform(); 
       //WebElement elementOpen = driver.findElement(By.linkText(CommandText)); 
        WebElement elementOpen=null;
       if(SubCommandcommandText.equals(""))
        {
            elementOpen = driver.findElement(By.linkText(ParentCommandcommandText)); 
        }
       else 
        {             
          WebElement elementParentOpen = driver.findElement(By.linkText(ParentCommandcommandText)); 
          oAction.moveToElement(elementParentOpen).build().perform();
          elementOpen = driver.findElement(By.linkText(SubCommandcommandText));   
         driver.findElement(By.xpath("//*[@id='KovairMaster_Main_RMActionMenu_detached']/ul/li[8]/a/span ")).click();
         driver.findElement(By.xpath("//*[@id='KovairMaster_Main_RMActionMenu_detached']/ul/li[8]/div/ul/li[5]/a/span")).click();
        }
       TestExeStatus="Passed";
       }
       catch(Exception e)
       {
         TestExeStatus="Failed"; 
       }
        return TestExeStatus;
    }
    public static String List_ActionMenu_Command_Availabilty(String ItemName,String PageName,String CommandText,WebDriver driver) throws Exception{
       String ActionMenuIdPart=null;
       String ActionMenuIdPart2=null;
       String trid=null;
       if(ItemName=="")
       {
           ActionMenuIdPart="PlaceHolderPopUp";
       }
       else
       {
         Thread.sleep(2000);
         trid=Get_specific_tr_id(ItemName,PageName,"OmnibusList",driver);
         driver.findElement(By.id(trid)).click();
         ActionMenuIdPart="KovairMaster_Main";
       }
       if(PageName.equals("Conflict"))
       {
           ActionMenuIdPart2="ConFlictList";
       }
       else 
       {
           ActionMenuIdPart2="RMAction";
       }
       Thread.sleep(2000);
       if(trid != null || ItemName=="")
       {       
        driver.findElement(By.id("right_action_btn")).click();        
        int elesize2= driver.findElements(By.xpath("//div[@id='"+ActionMenuIdPart+"_"+ActionMenuIdPart2+"Menu_detached']/ul/li/a/span")).size();
        for(int j=0;j<elesize2;++j)
         {
           WebElement rightclickoption =driver.findElements(By.xpath("//div[@id='"+ActionMenuIdPart+"_"+ActionMenuIdPart2+"Menu_detached']/ul/li/a/span[@class='rmText']")).get(j); 
           if(rightclickoption.getText().equals(CommandText))
           {
              TestExeStatus="Passed";
              break;           
           }           
         }
         if(TestExeStatus!="Passed")
           TestExeStatus="Failed"; 
       }
       else
          TestExeStatus="Failed"; 
      return TestExeStatus;
    }
    public static String DeleteSpecificItem(String ItemText, String VerificationText, String PageName, String ListPageType, WebDriver driver) throws Exception {
        try {
            String pagname = StringUtils.deleteWhitespace(PageName);
            KovairGenericClass.List_RightClick_Command_click(ItemText, pagname, "Delete", "", ListPageType, driver);
            TestExeStatus = Modal_Text_Verification(VerificationText, driver);
            KovairGenericClass.Modal_OKClick_Verification("OKCANCEL", driver);
            if (PageName.contains("Lookup")) {
                KovairGenericClass.Modal_OKClick_Verification("OKCANCEL", driver);
            }
            else
            {
            KovairGenericClass.Modal_OKClick_Verification("OK", driver);
            }
            Thread.sleep(500);
            //Delete verification
            String trid = KovairGenericClass.Get_specific_tr_id(ItemText, PageName, ListPageType, driver);
            if (trid == null && TestExeStatus == "Passed") {
                TestExeStatus = "Passed";
            } 
                TestExeStatus = PageName + " " + ItemText + "is not deleted.";
            
        } catch (Exception e) {
            TestExeStatus = "Page Level Error.";
        }
        return TestExeStatus;
    }

    public static String DeleteSpecificItem(String ItemText,String PageName,WebDriver driver) throws Exception{
        String pagname=StringUtils.deleteWhitespace(PageName);
        KovairGenericClass.List_RightClick_Command_click(ItemText,pagname,"Delete","",driver);
        KovairGenericClass.Modal_OKClick_Verification("OKCANCEL",driver);
        KovairGenericClass.Modal_OKClick_Verification("OK",driver);
        Thread.sleep(500);
        //Delete verification
        String trid=KovairGenericClass.Get_specific_tr_id(ItemText,PageName,"OmnibusList",driver);
        if(trid == null)
             TestExeStatus="Passed";
        else
          {   TestExeStatus=PageName+" "+ItemText+"is not deleted."; }
         return TestExeStatus;
      }
    public static String NavigationPage(String RecordCount, WebDriver driver) throws Exception {
        Select NoOfRecSelect = new Select(driver.findElement(By.cssSelector("select[id^='KovairMaster_Main_colPanel_GridField_'][id$='_drpDwnPageSize']")));
        //NoOfRecSelect.selectByValue("10");   
        NoOfRecSelect.selectByValue(RecordCount);
        Thread.sleep(1000);
        try {
            if (driver.findElement(By.cssSelector("img[id^='KovairMaster_Main_colPanel_GridField_'][id$='_imgNext']")).isDisplayed()) {
                driver.findElement(By.cssSelector("img[id^='KovairMaster_Main_colPanel_GridField_'][id$='_imgNext']")).click();
            }
            Thread.sleep(2000);
            if (driver.findElement(By.cssSelector("img[id^='KovairMaster_Main_colPanel_GridField_'][id$='_imgPrev']")).isDisplayed()) {
                driver.findElement(By.cssSelector("img[id^='KovairMaster_Main_colPanel_GridField_'][id$='_imgPrev']")).click();
            }
            Thread.sleep(2000);
            if (driver.findElement(By.cssSelector("img[id^='KovairMaster_Main_colPanel_GridField_'][id$='_imgLast']")).isDisplayed()) {
                driver.findElement(By.cssSelector("img[id^='KovairMaster_Main_colPanel_GridField_'][id$='_imgLast']")).click();
            }
            Thread.sleep(2000);
            if (driver.findElement(By.cssSelector("img[id^='KovairMaster_Main_colPanel_GridField_'][id$='_imgFirst']")).isDisplayed()) {
                driver.findElement(By.cssSelector("img[id^='KovairMaster_Main_colPanel_GridField_'][id$='_imgFirst']")).click();
            }
            Thread.sleep(2000);
            TestExeStatus = "Passed";
        } catch (WebDriverException e) {
            TestExeStatus = "Failed";
            TestErrDesc = e.getMessage();
        }
        return TestExeStatus;

    }

    public static String FilterSelection(String FilterName, String IsRuntimeFilter, String frameid, WebDriver driver) throws Exception {

        String filterID = null;

        String title = null;
        try {
            if (!frameid.isEmpty()) {
                WebElement frame = driver.findElement(By.id(frameid));
                driver.switchTo().frame(frameid);
            }
            String srchbox = "KovairMaster_Main_txtSearchByIdOrTxt";
            if (driver.findElement(By.id(srchbox)) != null) {
                WebElement searchbox = driver.findElement(By.id(srchbox));
                Thread.sleep(1000);
                searchbox.clear();
            }
            driver.findElement(By.id("KovairMaster_Main_FilterControl_OuterLabel")).click();

            //int FilterCount = driver.findElements(By.xpath("//ul[@id='KovairMaster_Main_FilterControl_UlDisplay']/li")).size();
            if (FilterName.isEmpty()) {
                filterID = driver.findElement(By.xpath("//div[@id='KovairMaster_Main_FilterControl_DisplayContainer']/ul/li[" + 2 + "]")).getAttribute("id");
                title = driver.findElement(By.xpath("//li[@id='" + filterID + "']/a")).getAttribute("title");
            } else {
                try {
                    filterID = driver.findElement(By.xpath("//ul[@id='KovairMaster_Main_FilterControl_UlDisplay']/li[@valuetext='" + FilterName + "']")).getAttribute("id").toString().trim();

                } catch (Exception e1) {
                    TestExeStatus = "Filter is not found.";
                    return TestExeStatus;
                }
                /*for (int k = 2; k <= Filterount; k++) {
                 String thisfilterID = driver.findElement(By.xpath("//div[@id='KovairMaster_Main_FilterControl_DisplayContainer']/ul/li[" + k + "]")).getAttribute("id");
                 title = driver.findElement(By.xpath("//li[@id='" + thisfilterID + "']/a")).getAttribute("title");
                 if (title.equals(FilterName)) {
                 filterID = thisfilterID;
                 break;
                 }
                 }*/
            }
            if (filterID != null) {
                try {
                    WebElement filterli = driver.findElement(By.id(filterID));
                    ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", filterli);
                    Thread.sleep(2000);
                    JavascriptExecutor executor = (JavascriptExecutor) driver;
                    executor.executeScript("arguments[0].click();", filterli);

//                       try
//                   {
//                        if (driver.findElement(By.id("modal")).isDisplayed()){
//                        FindError.checkPageError(driver);
//                        Thread.sleep(3000);
//                        }
//                           System.out.println("No Error");
//                   }
//                        catch(Exception e){
//                                 Thread.sleep(5000);
//                        }
                    WebDriverWait wait = new WebDriverWait(driver, 10);
                    wait.until(ExpectedConditions.invisibilityOfElementLocated(By.id("img_loading")));
                    TestExeStatus = "Passed";
                } catch (Exception e1) {
                    TestExeStatus = "filter is not found.";
                }
            }
        } catch (Exception e) {
            TestExeStatus = "filter is not selected.";
        }
        if (TestExeStatus.equals("Passed") && FilterName.isEmpty()) {
            return title;
        } else {
            return TestExeStatus;
        }
    }
    
    public static WebDriver launchBrowserwithoption(String _browser,ChromeOptions option) throws Exception {

        System.setProperty("webdriver.chrome.driver", ChromedriverPath);

        if (_browser.equals("IE")) {
            // driver = new InternetExplorerDriver();
            driver = null;
        }
        if (_browser.equals("Chrome")) {
            driver = new ChromeDriver(option);
        } else if (_browser.equals("Firefox")) {
            driver = new FirefoxDriver();
        }
        driver.manage().timeouts().implicitlyWait(25, TimeUnit.SECONDS);
        getBrowserDetail(driver);
        return driver;
    }


    public static String ViewSelection(String ViewName, String IsPopUp, String FieldType, String frameid, WebDriver driver) throws Exception {
        String viewID = null;
        String title = null;
        String controlid = "KovairMaster_Main_";
        String Fieldidpart = "";
        WebElement Outerlabel = null;

        if (IsPopUp == "Y") {
            //For User List
            if (FieldType.equals("User")) {
                Fieldidpart = "User";
                controlid = "PlaceHolderPopUp_SelectedUserList_SelectedUserList_UserControl_SelectedUserList_UserControl_";
                driver.findElement(By.id(controlid + "ViewControl_OuterLabel"));
            } //For Relational Lookup Field
            else if (FieldType.equals("Relational Lookup")) {
                Fieldidpart = "Entity";
                controlid = "PlaceHolderPopUp_Selected" + Fieldidpart + "List_Selected" + Fieldidpart + "List_" + Fieldidpart + "ListControl_Selected" + Fieldidpart + "List_" + Fieldidpart + "ListControl_";
                Outerlabel = driver.findElement(By.id(controlid + "ViewControl_OuterLabel"));
            } //For Relate Existing List of Relation section
            else if (FieldType.equals("Relation")) {
                Outerlabel = driver.findElement(By.cssSelector("span[id$='ViewControl_OuterLabel']"));
                controlid = Outerlabel.getAttribute("id").toString().trim();
                controlid = controlid.replace("ViewControl_OuterLabel", "").trim();
            }
        } else {
            Thread.sleep(1000);
            Outerlabel = driver.findElement(By.id(controlid + "ViewControl_OuterLabel"));

        }

        if (!frameid.isEmpty()) {
            WebElement frame = driver.findElement(By.id(frameid));
            driver.switchTo().frame(frameid);
        }
        try {
            Outerlabel.click();
            Thread.sleep(2000);
            /*int ViewCount = driver.findElements(By.xpath("//ul[@id='" + controlid + "ViewControl_UlDisplay']/li")).size() - 1;

             String _thisviewID = driver.findElement(By.xpath("//div[@id='" + controlid + "ViewControl_DisplayContainer']/ul/li[2]")).getAttribute("id");
             Thread.sleep(500);
             title = driver.findElement(By.xpath("//li[@id='" + _thisviewID + "']/a")).getAttribute("title").toString().trim();
             if (title.equals("None")) {
             ViewCount += 1;
             }*/

            if (ViewName.isEmpty() || ViewName == null) {
                if (IsPopUp == "N") {
                    viewID = driver.findElements(By.xpath("//div[@id='" + controlid + "ViewControl_DisplayContainer']/ul/li")).get(2).getAttribute("id");
                } else {
                    viewID = driver.findElement(By.xpath("//div[@id='" + controlid + "ViewControl_DisplayContainer']/ul/li[" + 1 + "]")).getAttribute("id");
                }
                title = driver.findElement(By.xpath("//li[@id='" + viewID + "']/a")).getAttribute("title");
            } else {
                try {
                    viewID = driver.findElement(By.xpath("//ul[@id='" + controlid + "ViewControl_UlDisplay']/li[@valuetext='" + ViewName + "']")).getAttribute("id").toString().trim();
                } catch (Exception e1) {
                    TestExeStatus = "View is not found.";
                    return TestExeStatus;
                }
                /*for (int k = 0; k <= ViewCount; k++) {
                 String thisviewID = driver.findElement(By.xpath("//div[@id='" + controlid + "ViewControl_DisplayContainer']/ul/li[" + k + "]")).getAttribute("id");
                 Thread.sleep(1000);
                 title = driver.findElement(By.xpath("//li[@id='" + thisviewID + "']/a")).getAttribute("title");
                 if (title.equals(ViewName)) {
                 viewID = thisviewID;
                 break;
                 }
                 }*/
            }
            if (viewID != null) {
                try {
                    WebElement viewli = driver.findElement(By.id(viewID));
                    ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", viewli);
                    Thread.sleep(2000);
                    JavascriptExecutor executor = (JavascriptExecutor) driver;
                    executor.executeScript("arguments[0].click();", viewli);
                    WebDriverWait wait = new WebDriverWait(driver, 10);
                    wait.until(ExpectedConditions.invisibilityOfElementLocated(By.id("img_loading")));
                    TestExeStatus = "Passed";
                } catch (Exception e1) {
                    TestExeStatus = "Error in View Selection.";
                }
            }
        } catch (Exception e) {
            Outerlabel.click();
            TestExeStatus = "View is not selected.";
        }
        if (TestExeStatus.equals("Passed") && ViewName.isEmpty()) {
            return title;
        } else {
            return TestExeStatus;
        }
    }

     public static String ReloadCurrentFrame(WebDriver driver) {
        WebElement iconSetbg = driver.findElement(By.id("icon_set_bg"));
        WebDriverWait wait = new WebDriverWait(driver, 120);
        java.util.List<WebElement> icons = iconSetbg.findElements(By.tagName("img"));
        for (WebElement icon : icons) {
            String iconTitle = icon.getAttribute("title");
            if (iconTitle.equals("Click here to Reset the page.")) {
                icon.click();
                break;
            }
        }
        wait.until(ExpectedConditions.invisibilityOfElementLocated(By.id("img_loading")));
        return "Frame Reloaded";
    }

    
    public static String RelationSectionViewFilterSelection(String ViewName, String ControlName, String frameid, WebDriver driver) throws Exception {
        try {
            if (!frameid.isEmpty()) {
                WebElement frame = driver.findElement(By.id(frameid));
                driver.switchTo().frame(frameid);
            }
            String controlid = driver.findElement(By.cssSelector("table[id^=" + ControlName + "Combo_][id$='-triggerWrap']")).getAttribute("id").toString().trim();
            WebElement Outerlabel = driver.findElement(By.xpath("//table[@id='" + controlid + "']/tbody/tr/td[2]"));
            Outerlabel.click();
            int _sz = driver.findElements(By.xpath("//div[@class='ellipsis'][@title='" + ViewName + "']")).size();
            if (_sz > 0) {
                WebElement viewli = driver.findElement(By.xpath("//div[@class='ellipsis'][@title='" + ViewName + "']"));
                ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", viewli);
                Thread.sleep(2000);
                JavascriptExecutor executor = (JavascriptExecutor) driver;  
                executor.executeScript("arguments[0].click();", viewli);
                if (ViewName.equals("None")) {
                    return "Failed";
                }
                try {
                    WebDriverWait wait = new WebDriverWait(driver, 10);
                    wait.until(ExpectedConditions.invisibilityOfElementLocated(By.id("img_loading")));
                } catch (Exception _e) {
                }
                TestExeStatus = "Passed";
            }
        } catch (Exception e) {
            TestExeStatus = "View is not selected.";
        }
        return TestExeStatus;
    }

    public static String _getSelectedViewFilter(String ControlType, String IsPopUp, String FieldType, WebDriver driver) throws Exception {
        String viewfiltername = null;
        //PlaceHolderPopUp_SelectedUserList_SelectedUserList_///UserControl_SelectedUserList_///UserControl_ ViewControl_FilterName
        String controlid = "KovairMaster_Main_";
        String Fieldidpart = "";
        if (IsPopUp == "Y") {
            if (FieldType.equals("User")) {
                Fieldidpart = "User";
                controlid = "PlaceHolderPopUp_SelectedUserList_SelectedUserList_UserControl_SelectedUserList_UserControl_";
            } else {
                Fieldidpart = "Entity";
                controlid = "PlaceHolderPopUp_Selected" + Fieldidpart + "List_Selected" + Fieldidpart + "List_" + Fieldidpart + "ListControl_Selected" + Fieldidpart + "List_" + Fieldidpart + "ListControl_";
            }
            //controlid="PlaceHolderPopUp_Selected"+ Fieldidpart+"List_Selected"+ Fieldidpart+"List_"+ Fieldidpart+"ListControl_Selected"+ Fieldidpart+"List_"+ Fieldidpart+"ListControl_";
        }
        try {
            viewfiltername = driver.findElement(By.id(controlid + ControlType + "Control_FilterName")).getText().toString().trim();
        } catch (Exception e) {
            TestExeStatus = "Page Level Error.";
        }
        return viewfiltername;
    }

    public static String StartProcessFromList(String Process, String ProcessPoint, WebDriver driver) throws Exception {
        try {
            PopUp_Frame_Switch(driver);
            if (!Process.isEmpty()) {
                try {
                    Select process_el = new Select(driver.findElement(By.id("PlaceHolderPopUp_ProcessNameDropDown")));
                    process_el.selectByVisibleText(Process);
                } catch (Exception e) {
                }
            }
            if (!ProcessPoint.isEmpty()) {
                Select processpt_el = new Select(driver.findElement(By.id("PlaceHolderPopUp_ProcessStartPointDropDown")));
                processpt_el.selectByVisibleText(ProcessPoint);
            }
            WebElement btndone = driver.findElement(By.id("PlaceHolderPopUp_btnDone"));
            btndone.click();
            Thread.sleep(3000);
            TestExeStatus = "Passed";
            try {
                Modal_OKClick_Verification("OKCANCEL", driver);
                //WebElement _btndone = driver.findElement(By.id("PlaceHolderPopUp_btnDone"));
                //_btndone.click();
            } catch (Exception e) {
            }
            driver.switchTo().parentFrame();
            Thread.sleep(1500);
        } catch (Exception e) {
            TestExeStatus = "Failed";
            TestErrDesc = "Page Level Error." + e.getMessage();
        }
        return TestExeStatus;
    }

    //*********************************************************Modal***************************************************************//
    public static String Modal_UI_Verification(String title, String ModalType, WebDriver driver) throws Exception {
        String ButtonValue = "OK";
        if (ModalType.equals("OKCANCEL")) {
            ButtonValue = "Ok";
        }
        try {

            WebElement Modal = driver.findElement(By.xpath("//div[@id='modal']/table[@id='MsgHeader']/tbody/tr/td"));
            String Modaltxt = Modal.getText();
            WebElement Okbtn = driver.findElement(By.xpath("//table[@id='dialogbtncontainer']/tbody/tr/td/input[@value='" + ButtonValue + "']"));
            if (Modaltxt.equals(title)) {
                TestExeStatus = "Passed";
            }
        } catch (Exception e) {
            TestExeStatus = "Failed";
        }
        return TestExeStatus;
    }

    public static String Modal_Text_Verification(String VerificationText, WebDriver driver) throws Exception {
        WebElement Modal = null;
        String Modaltxt = null;
        try {
            try {
                Modal = driver.findElement(By.xpath("//table[@id='dialog_content']/tbody/tr[2]/td[2]"));
            } catch (Exception e) {
                Modal = driver.findElement(By.xpath("//table[@id='dialog_content']/tbody/tr[1]/td[2]"));
            }
            if (VerificationText.isEmpty()) {
                return Modal.getText().trim().replace("\n", "");
            }
            Modaltxt = StringUtils.deleteWhitespace(Modal.getText().trim());
            VerificationText = StringUtils.deleteWhitespace(VerificationText);
            if (Modaltxt.equalsIgnoreCase(VerificationText)) {
                TestExeStatus = "Passed";
            } else {
                TestExeStatus = "Failed";
            }
        } catch (Exception _e3) {
            TestExeStatus = "Failed";
            TestErrDesc = "Modal Not Found";
        }
        return TestExeStatus;
    }

    public static String Modal_OKClick_Verification(String ModalType, WebDriver driver) throws Exception {
        String ButtonValue = "OK";
        if (ModalType.equals("OKCANCEL")) {
            ButtonValue = "Ok";
        }
        try {
            WebElement Okbtn = driver.findElement(By.xpath("//table[@id='dialogbtncontainer']/tbody/tr/td/input[@value='" + ButtonValue + "']"));
            Okbtn.click();
            TestExeStatus = "Passed";
            Thread.sleep(2000);
        } catch (Exception e) {
            TestExeStatus = "Failed";
        }
        return TestExeStatus;
    }

    public static String Modal_CancelClick_Verification(WebDriver driver) throws Exception {
        try
        {
             WebElement Cancel = driver.findElement(By.xpath("//table[@id='dialogbtncontainer']/tbody/tr/td/input[@value='Cancel']"));
        Cancel.click();
        Thread.sleep(500);
        }
       
        catch(Exception e)
           {
               //break;
               TestExeStatus="Passed";
               
           }
        return TestExeStatus;
    }

    //************************************************Modal Ends********************************************************************//
    /**
     * public static void Home_Menu_click(String MenuText,WebDriver driver)
     * throws Exception { //// int menuCount =
     * driver.findElements(By.xpath("//div[
     *
     * @id='MenuContainer']/div/h2")).size(); //// int countUserDefinedMenu = 0;
     * //// for(int i=1;i<=menuCount;i++){ //// WebElement
     * Menu=driver.findElement(By.xpath("//div[@id='MenuContainer']/div/h2[" + i
     * + "]/a")); //// String menudiv_id=Menu.getAttribute(("id")); ////
     * menudiv_id=menudiv_id.replace("Menu_a","Menu_subMenucontainer"); //// int
     * SubmenuCount=driver.findElements(By.xpath("//div[@id='MenuContainer']/div/div["
     * + i + "]/div/ul/li")).size(); //// if(SubmenuCount!=0) //// { ////
     * countUserDefinedMenu++; ////
     * driver.findElement(By.xpath("//div[@id='MenuContainer']/div/h2[" + i +
     * "]")).click(); //// for(int j=0;j<SubmenuCount;j++) //// { ////
     * WebElement
     * submenuatag=driver.findElements(By.xpath("//div[@id='"+menudiv_id+"']/ul/li/a")).get(j);
     * //// if (submenuatag.getText().contains(MenuText)) //// { ////
     * submenuatag.click(); //// Thread.sleep(5000); //// }; //// } //// } ////
     * if (Menu.getText().contains(MenuText)) //// { //// Menu.click(); ////
     * Thread.sleep(5000); ////
     * driver.findElement(By.xpath(".//*[@id='close6482_240_0']")).click();//Home
     * Tab Close //// }; //// } // // } *
     */
    //public static void RecordList_RightClick_Command_click(String ParentCommandcommandText,String SubCommandcommandText,String frameid,boolean IsPopUp,String PopUpFrameId,String Entity,WebDriver driver) throws Exception{        
    public static String Form_Section_click(String SectionName, WebDriver driver) throws Exception {

        //driver.findElement(By.xpath("//div[@id='icon_set_bg']/table/tbody/tr/td[4]"));
        WebElement Img = driver.findElement(By.xpath("//div[@id='icon_set_bg']/table/tbody/tr/td[4]/img[@title='Click here to see the Available Sections']"));
        Img.click();
        int flag = 0;
        int licount = driver.findElements(By.xpath("//div[@id='KovairMaster_Main_RMPanelMenu_detached']/ul/li")).size();
        for (int m = 1; m <= licount; m++) {
            Thread.sleep(3000);
            WebElement Dropdown = driver.findElement(By.xpath("//div[@id='KovairMaster_Main_RMPanelMenu_detached']/ul/li[" + m + "]/a/span"));
            Thread.sleep(1500);
            if (Dropdown.getText().trim().contains(SectionName)) {
                JavascriptExecutor executor = (JavascriptExecutor) driver;
                executor.executeScript("arguments[0].click();", Dropdown);
                TestExeStatus = "Passed";
                flag = 1;
                break;
            }
        }
        if (flag != 1) {
            TestExeStatus = "Section Not Found in Current Form.";
        }
        //Thread.sleep(2500);
        return TestExeStatus;
    }
    public static void ClickOnSpecifcHeaderAction(String ActionName, WebDriver driver, String frameId) throws Exception {
        try {
            //Find User Position
            Map<String, String> FullPageInfo = GetFullPageInformation(frameId, driver);
            Actions action = new Actions(driver);
            action.moveToElement(driver.findElement(By.cssSelector("img[title='Click here for Header Actions']"))).build().perform();
            Thread.sleep(2000);
            try {
                if (driver.findElements(By.xpath("//span[@class='cap'][contains(text(),'" + ActionName + "')]")).size() > 0
                        && driver.findElement(By.xpath("//span[@class='cap'][contains(text(),'" + ActionName + "')]")).isDisplayed()) {
                    if (!ActionName.equalsIgnoreCase("Hierarchy View") || !ActionName.equalsIgnoreCase("Normal View")
                            || !ActionName.equalsIgnoreCase("Trace View") || !ActionName.equalsIgnoreCase("Document View")) {
                        driver.findElement(By.xpath("//span[@class='cap'][contains(text(),'" + ActionName + "')]")).click();
                        Thread.sleep(5000);
                        _swithchtonewframe(driver);
                    } else {
                        driver.findElement(By.xpath("//span[@class='cap'][contains(text(),'" + ActionName + "')]")).click();
                        Thread.sleep(5000);
                        //No need To Switch
                        Modal_OKClick_Verification("OK", driver);
                    }
                } else {
                    System.out.println("The logged in user has no access to the specified user or the action is not visible");
                }
            } catch (Exception e) {
            }

        } catch (Exception e) {
            System.out.println("Unable to switch to specific page");
        }
    }
    public static boolean IfFormSectionExists(String SectionName, WebDriver driver) throws Exception {
        String Sectionid = "";
        String TestStatus = "";
        try {
            driver.findElement(By.cssSelector("img[src*='icon_quick_navigate']")).click();
            try {
                driver.findElement(By.xpath("//span[@class='rmText'][contains(text(),'" + SectionName + "')]"));
                return true;
            } catch (Exception e) {
                return false;
            }
        } catch (Exception e1) {
        }
        return false;
    }

    public static String FormSection_ExpandCollapse_Mode(String SectionName, String IsSystemSection, WebDriver driver) throws Exception {
        //driver.findElement(By.xpath("//div[@id='icon_set_bg']/table/tbody/tr/td[4]"));
        String Sectionid = "";
        String TestStatus = "";
        if (IsSystemSection == "Y") {
            if (SectionName.equals("Attachments")) {
                Sectionid = "KovairMaster_Main_colPanel_Section_2";
            } else if (SectionName.equals("Comments")) {
                Sectionid = "KovairMaster_Main_colPanel_Section_1";
            } else if (SectionName.equals("Parent Attachments")) {
                Sectionid = "KovairMaster_Main_colPanel_Section_19";
            } else if (SectionName.equals("Parent Comments")) {
                Sectionid = "KovairMaster_Main_colPanel_Section_20";
            } else if (SectionName.contains("Impacts")) {
                Sectionid = "KovairMaster_Main_colPanel_Section_5";
            }
        }
        try {
            WebElement span = driver.findElement(By.xpath("//*[contains(text(),'" + SectionName + "')]"));
            ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", span);
            if (Sectionid.isEmpty()) {
                Sectionid = span.getAttribute("id").toString().trim();
                Sectionid = Sectionid.replace("_Header", "").trim();
            }
            WebElement Img = driver.findElement(By.id(Sectionid + "_button"));
            String Imgtitle = Img.getAttribute("title").toString().trim();
            if (Imgtitle.contains("expand")) {
                TestStatus = "Collapsed";
            } else if (Imgtitle.contains("collapse")) {
                TestStatus = "Expanded";
            }
        } catch (Exception e) {
            TestStatus = e.getMessage();
        }
        return TestStatus;
    }

    public static String CustomSectionId(String SectionName, WebDriver driver) throws Exception {
        //driver.findElement(By.xpath("//div[@id='icon_set_bg']/table/tbody/tr/td[4]"));
        String Sectionid = "";
        try {
            WebElement span = driver.findElement(By.xpath("//*[contains(text(),'" + SectionName + "')]"));
            ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", span);
            Sectionid = span.getAttribute("id").toString().trim();
            Sectionid = Sectionid.replaceAll("[^0-9]", "").trim();
            Sectionid = Sectionid.substring(0, 4);
        } catch (Exception e) {
            Sectionid = null;
        }
        return Sectionid;
    }

    public static String FormSection_ExpandCollapse(String SectionName, String IsSystemSection, WebDriver driver) throws Exception {
        String Sectionid = "";
        if (IsSystemSection == "Y") {
            if (SectionName.equals("Attachments")) {
                Sectionid = "KovairMaster_Main_colPanel_Section_2";
            } else if (SectionName.equals("Comments")) {
                Sectionid = "KovairMaster_Main_colPanel_Section_1";
            } else if (SectionName.equals("Parent Attachments")) {
                Sectionid = "KovairMaster_Main_colPanel_Section_19";
            } else if (SectionName.equals("Parent Comments")) {
                Sectionid = "KovairMaster_Main_colPanel_Section_20";
            } else if (SectionName.contains("Impacts")) {
                Sectionid = "KovairMaster_Main_colPanel_Section_5";
            }
        }
        WebElement span = driver.findElement(By.xpath("//*[contains(text(),'" + SectionName + "')]"));
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", span);
        if (Sectionid.isEmpty()) {
            Sectionid = span.getAttribute("id").toString().trim();
            Sectionid = Sectionid.replace("_Header", "").trim();
        }
        WebElement Img = driver.findElement(By.id(Sectionid + "_button"));
        Img.click();
        Thread.sleep(2000);
        TestExeStatus = "Passed";
        return TestExeStatus;
    }

    public static String IDTextSearchMultiEditPage(String FrameId, WebDriver driver) throws Exception {
        if (!FrameId.isEmpty()) {
            driver.switchTo().defaultContent();
            driver.switchTo().frame(FrameId);
        }
        driver.findElement(By.id("KovairMaster_Main_txtSearchByIdOrTxt")).click();
        driver.findElement(By.id("KovairMaster_Main_txtSearchByIdOrTxt")).clear();
        driver.findElement(By.id("KovairMaster_Main_txtSearchByIdOrTxt")).sendKeys("last1");
        driver.findElement(By.id("KovairMaster_Main_btnSearch")).click();
        Thread.sleep(1000);
        return TestExeStatus;
    }

    public static String ViewTaskByDoubleClick(String frameid, WebDriver driver) throws Exception {
        TestExeStatus = null;
        driver.switchTo().defaultContent();
        WebElement frame = driver.findElement(By.id(frameid));
        driver.switchTo().frame(frameid);
        try {
            String Gridid = (driver.findElement(By.xpath("//div[@id='EntityGrid-body']/div"))).getAttribute("id").toString();
            String tableid = Gridid + "-table";
            int recordCount = driver.findElements(By.xpath("//table[@id='" + tableid + "']/tbody/tr")).size();
            if (recordCount > 0) {
                Thread.sleep(2000);
                WebElement recordElement = driver.findElement(By.xpath("//table[@id='" + tableid + "']/tbody/tr/td[2]/div/a"));
                JavascriptExecutor executor = (JavascriptExecutor) driver;
                executor.executeScript("arguments[0].click();", recordElement);
                Thread.sleep(2000);
                TestExeStatus = "Passed";
            }
        } catch (Exception e) {
            TestExeStatus = "View task by double clicking is not working";
        }
        return TestExeStatus;
    }

    public static String[][] getSQLresult(String query) throws Exception {

        String userName = null;
        String password = null;
        String url = null;

        try {

            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            if (url == null || userName == null || password == null) {
                boolean res = sqlConnection.getAppDBdetails();
                url = sqlConnection.app_url;
                userName = sqlConnection.app_userName;
                password = sqlConnection.app_password;
                if (res == false) {
                    userName = "sa";
                    password = "kov1$air";
                    url = "jdbc:sqlserver://kovair-testdb:1433" + ";databaseName=KovairPPMProd";
                }
            }
            Connection con = DriverManager.getConnection(url, userName, password);
            Statement s1 = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            //Statement s1 = con.createStatement();
//            if(query.split(";").length!=0){
//                for(int i=0;i<query.split(";").length;i++){
//                    s1.addBatch(query.split(";")[i]);
//                }
//            }

            ResultSet rs = s1.executeQuery(query);
            ResultSetMetaData rsmd = rs.getMetaData();
            int columnsNumber = rsmd.getColumnCount();
            rs.last();
            //System.out.println("Row Count = "+rs.getRow());
            String[][] relations = new String[rs.getRow()][rsmd.getColumnCount()];
            int currentRow = 0;
            rs.beforeFirst();
            if (rs != null) {
                //System.out.println("Following relations are available for the entity: "+entityName);	        	  
                while (rs.next()) {
                    for (int i = 0; i < columnsNumber; i++) {
                        relations[currentRow][i] = rs.getString(i + 1);
                    }
                    currentRow++;
                }
            }
            s1.close();
            return relations;
            //String result = new result[20];
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public static String[][] getSQLresultfromSP() throws Exception {
        //exec getFilterCount @Project='Kovair ALM Studio',@Entity='Request',@FieldName='Newfloat'
        String userName = null;
        String password = null;
        String url = null;

        try {

            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            if (url == null || userName == null || password == null) {
                boolean res = sqlConnection.getAppDBdetails();
                url = sqlConnection.app_url;
                userName = sqlConnection.app_userName;
                password = sqlConnection.app_password;
                if (res == false) {
                    userName = "sa";
                    password = "kov1$air";
                    url = "jdbc:sqlserver://databaseperform:1433" + ";databaseName=AMAT BVT";
                }
            }
            Connection con = DriverManager.getConnection(url, userName, password);
            CallableStatement cs = null;

            //custom code
            cs = con.prepareCall("{call getFilterCount(?,?,?)}");
            cs.setString(1, "Kovair ALM Studio");
            cs.setString(2, "Request");
            cs.setString(3, "Newfloat");
            ResultSet rs = cs.executeQuery();

            //custom code ends here
            ResultSetMetaData rsmd = rs.getMetaData();
            int columnsNumber = rsmd.getColumnCount();
            rs.last();
            //System.out.println("Row Count = "+rs.getRow());
            String[][] relations = new String[rs.getRow()][rsmd.getColumnCount()];
            int currentRow = 0;
            rs.beforeFirst();
            if (rs != null) {
                //System.out.println("Following relations are available for the entity: "+entityName);	        	  
                while (rs.next()) {
                    for (int i = 0; i < columnsNumber; i++) {
                        relations[currentRow][i] = rs.getString(i + 1);
                    }
                    currentRow++;
                }
            }
            cs.close();
            return relations;
            //String result = new result[20];
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public static String[] getPageDetails(String Entity, String Workspace, WebDriver driver) throws Exception {
        String query = null;
        String[] result = null;
        String[][] _result = null;
        if (!Entity.isEmpty()) {
            query = "select p.ProjectID,e.EntityTypeID from tentityprojects ep inner join tentity e on e.EntityTypeID=ep.EntityTypeID"
                    + " inner join tProject p on p.ProjectID=ep.ProjectID where p.title like '%" + Workspace + "%' and e.PluralName like '%" + Entity + "%'";
            _result = KovairGenericClass.getSQLresult(query);
            result = new String[_result[0].length];
            result[0] = _result[0][0];
            result[1] = _result[0][1];
        } else {
            query = "select p.ProjectID from tProject p where p.title like '%" + Workspace + "%'";
            _result = KovairGenericClass.getSQLresult(query);
            result = new String[_result.length];
            result[0] = _result[0][0];
        }
        return result;
    }

    public static Integer getLastEntityItemID(String Entity, String Workpspace) throws Exception {
        String query = "select top 1 e.itemidinproject from tEntityItem e inner join tentityprojects ep on e.EntityTypeID=ep.EntityTypeID"
                + " inner join tentity _e on _e.EntityTypeID=ep.EntityTypeID inner join tProject p on p.ProjectID=ep.ProjectID"
                + " where p.title like '%" + Workpspace + "%' and _e.PluralName like '%" + Entity + "%' order by e.CreationDate desc";
        String[][] result = KovairGenericClass.getSQLresult(query);
        Integer EntityID = Integer.parseInt(result[0][0].toString());
        return EntityID;
    }

    public static Integer getLastTaskID(String PageMenuTagName) throws Exception {
        String query = "";
        if (PageMenuTagName.equals("Home")) {
            query = "select top 1 ItemIDInProject from tTask where ItemID in"
                    + "(select ItemID from tTaskOwners where ItemID is not NULL and UserId in (select UserID from tUser where LoginId='" + UserId + "')) "
                    + "and statusID <>5 order by CreationDate desc";
        } else if (PageMenuTagName.equals("Task")) {
            query = "select top 1 t.ItemIDInProject from tTask t inner join tproject p on t.ProjectID=p.ProjectID"
                    + "where p.Title='" + Workspace + "' and t.TaskType is not NULL order by t.CreationDate desc";
        }
        String[][] result = KovairGenericClass.getSQLresult(query);
        Integer EntityID = Integer.parseInt(result[0][0].toString());
        return EntityID;
    }

    public static void _swithchtonewframe(WebDriver driver) throws Exception {
        driver.switchTo().defaultContent();
        try {
            int tabcount = driver.findElements(By.xpath("//div[@id='tabHolder']/p")).size();
            String NewPageFrameId = driver.findElement(By.xpath("//div[@id='tabHolder']/p[" + tabcount + "]")).getAttribute("id").toString();
            NewPageFrameId = NewPageFrameId.replace("c", "cc");
            driver.switchTo().frame(NewPageFrameId);
            TestExeStatus = "Passed";
        } catch (Exception e) {
            TestExeStatus = "Page Level Error.";
        }
    }
    
    public static void select_sitemenu_submenu(String entity,String subentity) throws Exception
    { 
       try
	{
	//****************************Select Site Entity & Setting Submenu********************************//
			
			
    WebElement htmltable1=driver.findElement(By.xpath("//*[@id='MenuContainer']/div"));
    java.util.List<WebElement> rows1=htmltable1.findElements(By.tagName("h2"));
    Thread.sleep(5000);
    WebElement Lastelement1=driver.findElement(By.xpath("//*[@id='MenuContainer']/div/h2["+rows1.size()+"]"));
    Actions actionsobj=new Actions(driver);
    actionsobj.moveToElement(Lastelement1).build().perform();
    System.out.println("The number of menus present:"+rows1.size());

    for( int rno=1;rno<=rows1.size();rno++)
    {
      if(driver.findElement(By.xpath("//*[@id='MenuContainer']/div/h2["+rno+"]/a")).getText().equals(entity))
      {
        System.out.println("Menu is Present");
        int r=rno;
        System.out.println("The Menu " +entity+ " is present in the row:"+r);
        Thread.sleep(9000);
        driver.findElement(By.xpath("//*[@id='MenuContainer']/div/h2["+rno+"]/a")).click();
        try{         
            WebElement htmltable=driver.findElement(By.xpath("//*[@id='MenuContainer']/div/div["+rno+"]/div/ul"));
            java.util.List<WebElement> rows=htmltable.findElements(By.tagName("li"));
            Thread.sleep(5000);
            WebElement Lastelement=driver.findElement(By.xpath("//*[@id='MenuContainer']/div/div["+rno+"]/div/ul/li["+rows.size()+"]"));
            Actions actions=new Actions(driver);
            actions.moveToElement(Lastelement).build().perform();
            System.out.println("The number of Submenus present under " +entity+ ":"+rows.size());
            for(int rnum=1;rnum<=rows.size();rnum++)
            {
              if(driver.findElement(By.xpath("//*[@id='MenuContainer']/div/div["+rno+"]/div/ul/li["+rnum+"]/a")).getText().equals(subentity))
               {
                driver.findElement(By.xpath("//*[@id='MenuContainer']/div/div["+rno+"]/div/ul/li["+rnum+"]/a")).click();
                Thread.sleep(9000);
                break;
             }
            }
        }
        catch (Exception e)
           {
            TestExeStatus="No submenu" +subentity+ "is present in Site-Setting";
           }
        }
       }
      }
	catch (Exception e)
        {
            TestExeStatus="No menu" +entity+ "is present in Site-Setting";
            System.err.println("Caught Exception: " + e.getMessage());
        }
    }

    public static String _clickandSwitchedToOpenedTab(String TabName, String frameid, WebDriver driver) throws Exception {
        driver.switchTo().defaultContent();
        try {
            //driver.switchTo().defaultContent();
            try {
                driver.findElement(By.cssSelector("span[title*='" + TabName + "']")).click();
            } catch (Exception e) {
                try {
                    driver.findElement(By.id("Img5")).click();
                    //driver.findElement(By.cssSelector("div[id='dropDownTabsContainer']/div/ul/li/a[title*='"+TabName+"']")).click();
                    driver.findElement(By.cssSelector("a[title*='" + TabName + "'][class='textEllipsis breadcrumbSpanFloat tabWidth_span']")).click();
                    _clickandSwitchedToOpenedTab(TabName, frameid, driver);
                } catch (Exception _e4) {
                    TestExeStatus = "Specific tab Not Found.";
                }
            }
            driver.switchTo().frame(frameid);
            TestExeStatus = "Passed";
        } catch (Exception e) {
        }
        return TestExeStatus;
    }

    public static void writeViewDetailsInCSV(String EntityName, String ViewName, String TimeTaken, String Error, String Records) throws Exception {
        SimpleDateFormat dateFormatter1 = new SimpleDateFormat("MMMM dd, yyyy");
        Date date = new Date();
        String csv = "\\\\192.168.2.18\\AutomationScreeenshots\\" + dateFormatter1.format(date) + "\\ViewLog.csv";
        CSVWriter writer = new CSVWriter(new FileWriter(csv, true));

        String[] record = (EntityName + "," + ViewName + "," + TimeTaken + "," + Error + "," + Records).split(",");

        writer.writeNext(record);

        writer.close();
    }

    public static void writeFilterDetailsInCSV(String EntityName, String FilterName, String TimeTaken, String Error, String Records) throws Exception {
        SimpleDateFormat dateFormatter1 = new SimpleDateFormat("MMMM dd, yyyy");
        Date date = new Date();
        String csv = "\\\\192.168.2.18\\AutomationScreeenshots\\" + dateFormatter1.format(date) + "\\FilterLog.csv";
        CSVWriter writer = new CSVWriter(new FileWriter(csv, true));

        String[] record = (EntityName + "," + FilterName + "," + TimeTaken + "," + Error + "," + Records).split(",");

        writer.writeNext(record);

        writer.close();
    }

    public static void highlightElement(WebDriver driver, WebElement element) {
        for (int i = 0; i < 3; i++) {
            JavascriptExecutor js = (JavascriptExecutor) driver;
            js.executeScript("arguments[0].setAttribute('style', arguments[1]);", element, "color: yellow; border: 3px solid green;"); //"arguments[0].style.border='3px solid red'"
            js.executeScript("arguments[0].setAttribute('style', arguments[1]);", element, "");
        }

    }

    public static String _getLoggedInUserName(String UserId) throws Exception {
        String UserName = null;
        try {
            String query = "select FirstName,LastName from tuser where LoginId='" + UserId + "'";
            String[][] res = KovairGenericClass.getSQLresult(query);
            UserName = res[0][0] + " " + res[0][1];
        } catch (Exception _e) {
        }
        return UserName;
    }

    public static String getPageInformation(WebDriver driver) throws Exception {
        WebElement CurrentFrame = null;
        String ObjectId = "";
        String ObjectType = "";
        String EntityTypeId = "";
        String ProjectId = "";
        driver.switchTo().defaultContent();
        try {
            int tabcount = driver.findElements(By.xpath("//div[@id='tabHolder']/p")).size();
            String NewPageFrameId = driver.findElement(By.xpath("//div[@id='tabHolder']/p[" + tabcount + "]")).getAttribute("id");
            NewPageFrameId = NewPageFrameId.replace("c", "cc");
            CurrentFrame = driver.findElement(By.id(NewPageFrameId));
            String frameUrl = CurrentFrame.getAttribute("src");
            if (!frameUrl.isEmpty() && frameUrl.contains("ObjectId")) {
                int strIndex = frameUrl.indexOf("ObjectId");
                int endIndex = frameUrl.indexOf("SessionId", strIndex);
                String rawString = frameUrl.substring(strIndex, endIndex - 1);
                String cutString[] = rawString.split("&");
                ObjectId = cutString[0].split("=")[1];
                ProjectId = cutString[1].split("=")[1];
                ObjectType = cutString[2].split("=")[1];
                EntityTypeId = cutString[3].split("=")[1];
            }
            driver.switchTo().frame(NewPageFrameId);
        } catch (Exception e) {
        }
        return ObjectId + "," + EntityTypeId + "," + ObjectType + "," + ProjectId;
    }

    /**
     * Author: How To Use Get Full Page Information Using GetFullPageInformation
     * -------------------------------------------------------------------- Use
     * Following Code Statement To Call This Method
     *
     * public Map<String, String> FullPageIfno =
     * GetFullPageInformation("",driver); if you you want to pass frame id then
     * you can do so
     *
     ***
     */
    public static Map<String, String> GetFullPageInformation(String frameId, WebDriver driver) throws Exception {
        Map<String, String> pageInfo = new HashMap<String, String>();
        WebElement CurrentFrame = null;
        driver.switchTo().defaultContent();
        try {
            String NewPageFrameId = frameId;
            if (NewPageFrameId.isEmpty()) {
                int tabcount = driver.findElements(By.xpath("//div[@id='tabHolder']/p")).size();
                NewPageFrameId = driver.findElement(By.xpath("//div[@id='tabHolder']/p[" + tabcount + "]")).getAttribute("id");
                NewPageFrameId = NewPageFrameId.replace("c", "cc");
            }
            CurrentFrame = driver.findElement(By.id(NewPageFrameId));
            String frameUrl = CurrentFrame.getAttribute("src");
            frameUrl = frameUrl.substring(frameUrl.indexOf("?") + 1);
            String[] rawInfos = frameUrl.split("&");
            for (String rawInfo : rawInfos) {
                pageInfo.put(rawInfo.split("=")[0], rawInfo.split("=")[1]);
            }
        } catch (Exception e) {
        }
        return pageInfo;
    }

//    public static int GetRecordCountForFilter(String FilterId,String EntityTypeId) throws Exception{
//        int filterRelatedRecordCount = 0;
//        try {
//           //String result[][] = getSQLresult("select 'select count(*) from tEntityItem where EntityTypeID='+cast('"+EntityTypeId+"' as varchar)+' and '+replace(SQL,'$FIELDVALUE$',Value2) from tFilterConditionLines where FilterId='"+FilterId+"' and ISNULL(RecordStatus,'A') = 'A'");
//             //String result[][] = getSQLresult("select 'select count(*) from tEntityItem where EntityTypeID='+cast('"+EntityTypeId+"' as varchar)+' and '+replace(SQL,'$FIELDVALUE$',Value2) from tFilterConditionLines where FilterId='"+FilterId+"'"+" and ISNULL(RecordStatus,'A') = 'A'");
//             String result[][] = getSQLresult("select 'select count(*) from tEntityItem where EntityTypeID='+cast('"+EntityTypeId+"' as varchar)+' and ISNULL(RecordStatus,''A'') = ''A'' and '+ replace(SQL,'$FIELDfilterIDVALUE$',Value2) from tFilterConditionLines where FilterId='"+FilterId+"'");
//             if(result[0][0] != null){
//               String sql = result[0][0];
//               String rawValue[][] = getSQLresult(sql);
//               filterRelatedRecordCount = rawValue != null ? Integer.parseInt(rawValue[0][0]) : 0;
//           }
//        } catch (Exception e) {
//        }
//        return filterRelatedRecordCount;
//    }  
//    public static int GetRecordCountForFilter(String FilterId, String EntityTypeId, String FilterType) throws Exception {
//        int filterRelatedRecordCount = 0;
//        if (!FilterType.equals("Advanced")) {
//            try {
//                String result[][] = getSQLresult("select 'select count(*) from tEntityItem where EntityTypeID='+cast('" + EntityTypeId + "' as varchar)+' and ISNULL(RecordStatus,''A'') = ''A'' and '+replace(SQL,'$FIELDVALUE$',Value2) from tFilterConditionLines where FilterId='" + FilterId + "'");
//                if (result[0][0] != null) {
//                    String sql = result[0][0];
//                    String rawValue[][] = getSQLresult(sql);
//                    filterRelatedRecordCount = rawValue != null ? Integer.parseInt(rawValue[0][0]) : 0;
//                }
//            } catch (Exception e) {
//            }
//        }
//        else{
//             try {
//                String result[][] = getSQLresult("select 'select count(*) from tEntityItem where EntityTypeID='+cast('"+EntityTypeId+"' as varchar)+' and ISNULL(RecordStatus,''A'') = ''A'' and '+ExpressionExecSQL from tFilter where FilterId='"+FilterId+"'");
//                if (result[0][0] != null) {
//                    String sql = result[0][0];
//                    String rawValue[][] = getSQLresult(sql);
//                    filterRelatedRecordCount = rawValue != null ? Integer.parseInt(rawValue[0][0]) : 0;
//                }
//            } catch (Exception e) {
//            }
//        }
//        return filterRelatedRecordCount;
//    }
    public static int GetRecordCountForFilter(String FilterId, String EntityTypeId, String FilterType, String ConditionFieldType, String OperatorType, String Projectid) throws Exception {

        int filterRelatedRecordCount = 0;
        Boolean flag = true;
        if (!FilterType.equals("Advanced")) {
            try {
                //for entity
                String result[][] = getSQLresult("select 'select count(*) from tEntityItem where EntityTypeID='+cast('" + EntityTypeId + "' as varchar)+' and ISNULL(RecordStatus,''A'') = ''A'' and '+replace(SQL,'$FIELDVALUE$',Value2) from tFilterConditionLines where FilterId='" + FilterId + "'");

                //for task
                String result1[][] = getSQLresult("select 'select count(*) from tTask where ProjectID='+cast('" + Projectid + "' as varchar)+' and ISNULL(RecordStatus,''A'') = ''A'' and '+replace(SQL,'$FIELDVALUE$',Value2) from tFilterConditionLines where FilterId='" + FilterId + "'");
                if ((OperatorType.equals("Is Empty")) || (OperatorType.equals("Is Not Empty")) || (OperatorType.equals("Is Changed")) || (OperatorType.equals("Is Not Changed"))) {
                    result = getSQLresult("select 'select count(*) from tEntityItem where EntityTypeID='+cast('" + EntityTypeId + "' as varchar)+' and ISNULL(RecordStatus,''A'') = ''A'' and '+SQL from tFilterConditionLines where FilterId='" + FilterId + "'");
                } //                else if ((OperatorType.equals("Is Empty")) || (OperatorType.equals("Is Not Empty"))) {
                //                    result = getSQLresult("select 'select count(*) from tEntityItem where EntityTypeID='+cast('" + EntityTypeId + "' as varchar)+' and ISNULL(RecordStatus,''A'') = ''A'' and '+SQL from tFilterConditionLines where FilterId='" + FilterId + "'");
                //                } //(OperatorType.equals("Is Changed"))||(OperatorType.equals("Is Not Changed"))||
                else if ((OperatorType.equals("Changes From")) || (OperatorType.equals("Changes To")) || (OperatorType.equals("Change Date To")) || (OperatorType.equals("Change Date From"))) {
                    String QueryToInsert = "SELECT Count(*) FROM tChangeHistoryDetail inner join tChangeHistory on tChangeHistoryDetail.HistoryID = tChangeHistory.HistoryID  AND tChangeHistory.ProjectID = '" + Projectid + "'";
                    String RawResult[][] = getSQLresult("select 'select count(*) from tEntityItem where EntityTypeID='+cast('" + EntityTypeId + "' as varchar)+' and ISNULL(RecordStatus,''A'') = ''A'' and '+replace(SQL,'$FIELDVALUE$',Value2) from tFilterConditionLines where FilterId='" + FilterId + "'");
                    String sql = RawResult[0][0]; //"select count(*) from tEntityItem where EntityTypeID=7436 and ISNULL(RecordStatus,'A') = 'A' and EXISTS (SELECT 1 FROM tChangeHistoryDetail WHERE tChangeHistoryDetail.FieldID = 12173 AND tChangeHistoryDetail.ToNum = $FIELDVALUE$ AND tChangeHistoryDetail.HistoryID = tChangeHistory.HistoryID)"
                    sql = sql.split("EXISTS")[1];
                    sql = sql.replace("SELECT 1 FROM tChangeHistoryDetail", QueryToInsert);
                    result = getSQLresult(sql);//("Select '"+sql+"'");
                    return Integer.parseInt(result[0][0]);
                } else if (ConditionFieldType.equals("MLT") || ConditionFieldType.equals("HTML")) {
                    result = getSQLresult("select 'select count(*) from tEntityItem left join tEntityItemMLData on tEntityItem.ItemID = tEntityItemMLData.ItemID where EntityTypeID='+cast('" + EntityTypeId + "' as varchar)+' and ISNULL(RecordStatus,''A'') = ''A'' and '+replace(SQL,'$FIELDVALUE$',Value2) from tFilterConditionLines where FilterId='" + FilterId + "'");
                }

                //if entity
                if (!EntityTypeId.equals("0")) {
//                    if(ConditionFieldType.equals("Lookup")){
//                        result = getSQLresult("select 'select count(*) from tEntityItem where EntityTypeID='+cast('" + EntityTypeId + "' as varchar)+' and ISNULL(RecordStatus,''A'') = ''A'' and '+replace(ExpressionExecSQL,'$PROJECTID$','"+Projectid+"') from tFilter where FilterId='" + FilterId + "'");
//                    }

                    if (result[0][0] != null) {
                        String sql = result[0][0];
                        String rawValue[][] = getSQLresult(result[0][0]);
                        filterRelatedRecordCount = rawValue != null ? Integer.parseInt(rawValue[0][0]) : 0;
                    }

                } //if task
                else if (EntityTypeId.equals("0")) {
                    if (result1[0][0] != null) {
                        String sql = result1[0][0];
                        String rawValue[][] = getSQLresult(sql);
                        filterRelatedRecordCount = rawValue != null ? Integer.parseInt(rawValue[0][0]) : 0;
                    }

                }
            } catch (Exception e) {
                System.out.println("Error:=" + e.getMessage());
            }
        } else {
            try {
                //for entity
                String result[][] = getSQLresult("select 'select count(*) from tEntityItem where EntityTypeID='+cast('" + EntityTypeId + "' as varchar)+' and ISNULL(RecordStatus,''A'') = ''A'' and '+ExpressionExecSQL from tFilter where FilterId='" + FilterId + "'");
                // for task
                String result1[][] = getSQLresult("select 'select count(*) from tTask where ProjectID='+cast('" + Projectid + "' as varchar)+' and  ISNULL(RecordStatus,''A'') = ''A'' and '+ExpressionExecSQL from tFilter where FilterId='" + FilterId + "'");

                //for entity
                if (!EntityTypeId.equals("0")) {
                    if (ConditionFieldType.equals("Lookup")) {
                        result = getSQLresult("select 'select count(*) from tEntityItem where EntityTypeID='+cast('" + EntityTypeId + "' as varchar)+' and ISNULL(RecordStatus,''A'') = ''A'' and '+replace(ExpressionExecSQL,'$PROJECTID$','" + Projectid + "') from tFilter where FilterId='" + FilterId + "'");
                    }
                    if (ConditionFieldType.equals("MLT") || ConditionFieldType.equals("HTML")) {
                        result = getSQLresult("select 'select count(*) from tEntityItem left join tEntityItemMLData on tEntityItem.ItemID = tEntityItemMLData.ItemID where EntityTypeID='+cast('" + EntityTypeId + "' as varchar)+' and ISNULL(RecordStatus,''A'') = ''A'' and '+ExpressionExecSQL from tFilter where FilterId='" + FilterId + "'");
                    }
                    if (result[0][0] != null) {
                        String sql = result[0][0];
                        String rawValue[][] = getSQLresult(sql);
                        filterRelatedRecordCount = rawValue != null ? Integer.parseInt(rawValue[0][0]) : 0;
                    }

                }

                //for task
                if (EntityTypeId.equals("0")) {
                    if (result1[0][0] != null) {
                        String sql = result1[0][0];
                        String rawValue[][] = getSQLresult(sql);
                        filterRelatedRecordCount = rawValue != null ? Integer.parseInt(rawValue[0][0]) : 0;
                    }

                }
            } catch (Exception e) {

                System.out.println("Error:=" + e.getMessage());
            }
        }

        return filterRelatedRecordCount;
    }

    public static int GetRecordCountForFilterForSysFld(String FilterId, String EntityTypeId, String FilterType, String ConditionFieldType, String OperatorType, String Projectid, String SysOrCustomField, String Action) throws Exception {

        int filterRelatedRecordCount = 0;
        Boolean flag = true;
        if (!FilterType.equals("Advanced")) {
            try {
                //for entity  "select count(*) from tEntityItem where EntityTypeID=7534 and ISNULL(RecordStatus,'A') = 'A' and CAST(ISNULL(tEntityItem.Field3,'') AS DATETIME) > '03/22/2017 00:00'"
                String result[][] = getSQLresult("select 'select count(*) from tEntityItem where EntityTypeID='+cast('" + EntityTypeId + "' as varchar)+' and ISNULL(RecordStatus,''A'') = ''A'' and '+replace(SQL,'$FIELDVALUE$',Value2) from tFilterConditionLines where FilterId='" + FilterId + "'");

                //for task
                String result1[][] = getSQLresult("select 'select count(*) from tTask where ProjectID='+cast('" + Projectid + "' as varchar)+' and ISNULL(RecordStatus,''A'') = ''A'' and '+replace(SQL,'$FIELDVALUE$',Value2) from tFilterConditionLines where FilterId='" + FilterId + "'");
                if ((OperatorType.equals("Is Empty")) || (OperatorType.equals("Is Not Empty")) || (OperatorType.equals("Is Changed")) || (OperatorType.equals("Is Not Changed"))) {
                    result = getSQLresult("select 'select count(*) from tEntityItem where EntityTypeID='+cast('" + EntityTypeId + "' as varchar)+' and ISNULL(RecordStatus,''A'') = ''A'' and '+SQL from tFilterConditionLines where FilterId='" + FilterId + "'");
                } else if ((OperatorType.equals("Is Empty")) || (OperatorType.equals("Is Not Empty"))) {
                    result = getSQLresult("select 'select count(*) from tEntityItem where EntityTypeID='+cast('" + EntityTypeId + "' as varchar)+' and ISNULL(RecordStatus,''A'') = ''A'' and '+SQL from tFilterConditionLines where FilterId='" + FilterId + "'");
                } else if ((OperatorType.equals("Change Date To")) || (OperatorType.equals("Change Date From"))) {
                    String QueryToInsert = "SELECT DISTINCT OBjectID FROM tChangeHistoryDetail inner join tChangeHistory on tChangeHistoryDetail.HistoryID = tChangeHistory.HistoryID ";
                    String RawResult[][] = getSQLresult("select 'select DISTINCT OBjectID from tEntityItem where EntityTypeID='+cast('" + EntityTypeId + "' as varchar)+' and ISNULL(RecordStatus,''A'') = ''A'' and '+replace(SQL,'$FIELDVALUE$',Value2) from tFilterConditionLines where FilterId='" + FilterId + "'");
                    String sql = RawResult[0][0]; //"select count(*) from tEntityItem where EntityTypeID=7436 and ISNULL(RecordStatus,'A') = 'A' and EXISTS (SELECT 1 FROM tChangeHistoryDetail WHERE tChangeHistoryDetail.FieldID = 12173 AND tChangeHistoryDetail.ToNum = $FIELDVALUE$ AND tChangeHistoryDetail.HistoryID = tChangeHistory.HistoryID)"
                    sql = sql.split("EXISTS")[1];
                    sql = sql.substring(0, sql.length() - 1);
                    sql = sql.replace("SELECT 1 FROM tChangeHistoryDetail", QueryToInsert);
                    sql = ("SELECT COUNT(1) FROM(").concat(sql);
                    if (SysOrCustomField.equals("System")) {
                        sql = sql.concat(" And Action = '");
                        sql = sql.concat(Action);
                        sql = sql.concat("' AND tChangeHistory.ProjectId ='");
                        sql = sql.concat(Projectid);
                        sql = sql.concat("'))x");
                    }
                    result = getSQLresult(sql);//("Select '"+sql+"'");
                    return Integer.parseInt(result[0][0]);
                } else if ((OperatorType.equals("Changes From")) || (OperatorType.equals("Changes To"))) {
                    String QueryToInsert = "SELECT DISTINCT OBjectID FROM tChangeHistoryDetail inner join tChangeHistory on tChangeHistoryDetail.HistoryID = tChangeHistory.HistoryID ";
                    String RawResult[][] = getSQLresult("select 'select count(*) from tEntityItem where EntityTypeID='+cast('" + EntityTypeId + "' as varchar)+' and ISNULL(RecordStatus,''A'') = ''A'' and '+replace(SQL,'$FIELDVALUE$',Value2) from tFilterConditionLines where FilterId='" + FilterId + "'");
                    String sql = RawResult[0][0]; //"select count(*) from tEntityItem where EntityTypeID=7436 and ISNULL(RecordStatus,'A') = 'A' and EXISTS (SELECT 1 FROM tChangeHistoryDetail WHERE tChangeHistoryDetail.FieldID = 12173 AND tChangeHistoryDetail.ToNum = $FIELDVALUE$ AND tChangeHistoryDetail.HistoryID = tChangeHistory.HistoryID)"
                    sql = sql.split("EXISTS")[1];
                    sql = sql.substring(0, sql.length() - 1);
                    sql = sql.replace("SELECT 1 FROM tChangeHistoryDetail", QueryToInsert);
                    sql = ("SELECT COUNT(1) FROM(").concat(sql);
                    if (SysOrCustomField.equals("System")) {
                        sql = sql.concat(" And Action = '");
                        sql = sql.concat(Action);
                        sql = sql.concat("' AND tChangeHistory.ProjectId ='");
                        sql = sql.concat(Projectid);
                        sql = sql.concat("'))x");
                    }

                    result = getSQLresult(sql);//("Select '"+sql+"'");
                    return Integer.parseInt(result[0][0]);
                }

                //if entity
                if (!EntityTypeId.equals("0")) {
//                    if(ConditionFieldType.equals("Lookup")){
//                        result = getSQLresult("select 'select count(*) from tEntityItem where EntityTypeID='+cast('" + EntityTypeId + "' as varchar)+' and ISNULL(RecordStatus,''A'') = ''A'' and '+replace(ExpressionExecSQL,'$PROJECTID$','"+Projectid+"') from tFilter where FilterId='" + FilterId + "'");
//                    }
                    if (ConditionFieldType.equals("MLT") || ConditionFieldType.equals("HTML")) {
                        result = getSQLresult("select 'select count(*) from tEntityItem left join tEntityItemMLData on tEntityItem.ItemID = tEntityItemMLData.ItemID where EntityTypeID='+cast('" + EntityTypeId + "' as varchar)+' and ISNULL(RecordStatus,''A'') = ''A'' and '+replace(SQL,'$FIELDVALUE$',Value2) from tFilterConditionLines where FilterId='" + FilterId + "'");
                    }

                    if ((ConditionFieldType.equals("Date") || ConditionFieldType.equals("DateTime")) && (OperatorType.contains("Equal to"))) {
                            String sql[][] = getSQLresult("select 'select count(*) from tEntityItem where EntityTypeID='+cast('" + EntityTypeId + "' as varchar)+' and ISNULL(RecordStatus,''A'') = ''A'' and '+replace(replace(SQL,'$STARTDTM$',Value2),'$ENDDTM$',Value2) from tFilterConditionLines where FilterId='" + FilterId + "'");
                            String rawValue[][] = getSQLresult(sql[0][0]);
                            filterRelatedRecordCount = rawValue != null ? Integer.parseInt(rawValue[0][0]) : 0;
                            return filterRelatedRecordCount;
                    }
                    if (result[0][0] != null) {
                        String sql = result[0][0];
                        String rawValue[][] = getSQLresult(result[0][0]);
                        filterRelatedRecordCount = rawValue != null ? Integer.parseInt(rawValue[0][0]) : 0;
                    }

                } //if task
                else if (EntityTypeId.equals("0")) {
                    if (result1[0][0] != null) {
                        String sql = result1[0][0];
                        String rawValue[][] = getSQLresult(sql);
                        filterRelatedRecordCount = rawValue != null ? Integer.parseInt(rawValue[0][0]) : 0;
                    }

                }
            } catch (Exception e) {
                System.out.println("Error:=" + e.getMessage());
            }
        } else {
            try {
                //for entity
                String result[][] = getSQLresult("select 'select count(*) from tEntityItem where EntityTypeID='+cast('" + EntityTypeId + "' as varchar)+' and ISNULL(RecordStatus,''A'') = ''A'' and '+ExpressionExecSQL from tFilter where FilterId='" + FilterId + "'");
                // for task
                String result1[][] = getSQLresult("select 'select count(*) from tTask where ProjectID='+cast('" + Projectid + "' as varchar)+' and  ISNULL(RecordStatus,''A'') = ''A'' and '+ExpressionExecSQL from tFilter where FilterId='" + FilterId + "'");

                //for entity
                if (!EntityTypeId.equals("0")) {
                    if (ConditionFieldType.equals("Lookup")) {
                        result = getSQLresult("select 'select count(*) from tEntityItem where EntityTypeID='+cast('" + EntityTypeId + "' as varchar)+' and ISNULL(RecordStatus,''A'') = ''A'' and '+replace(ExpressionExecSQL,'$PROJECTID$','" + Projectid + "') from tFilter where FilterId='" + FilterId + "'");
                    }
                    if (ConditionFieldType.equals("MLT") || ConditionFieldType.equals("HTML")) {
                        result = getSQLresult("select 'select count(*) from tEntityItem left join tEntityItemMLData on tEntityItem.ItemID = tEntityItemMLData.ItemID where EntityTypeID='+cast('" + EntityTypeId + "' as varchar)+' and ISNULL(RecordStatus,''A'') = ''A'' and '+ExpressionExecSQL from tFilter where FilterId='" + FilterId + "'");
                    }
                    if (result[0][0] != null) {
                        String sql = result[0][0];
                        String rawValue[][] = getSQLresult(sql);
                        filterRelatedRecordCount = rawValue != null ? Integer.parseInt(rawValue[0][0]) : 0;
                    }

                }

                //for task
                if (EntityTypeId.equals("0")) {
                    if (result1[0][0] != null) {
                        String sql = result1[0][0];
                        String rawValue[][] = getSQLresult(sql);
                        filterRelatedRecordCount = rawValue != null ? Integer.parseInt(rawValue[0][0]) : 0;
                    }

                }
            } catch (Exception e) {

                System.out.println("Error:=" + e.getMessage());
            }
        }

        return filterRelatedRecordCount;
    }
     public static String clickMenuAndSubMenuInWorkspaceSetup(String Menu, String SubMenu, String EntityName, WebDriver driver) throws InterruptedException, Exception {
         String frame="";
         driver.switchTo().defaultContent();
        int menuCount = driver.findElements(By.xpath("//*[@id=\"MenuContainer\"]/div/h2")).size();
        for (int i = 1; i <= menuCount; i++) {
            WebElement menu = driver.findElement(By.xpath("//*[@id=\"MenuContainer\"]/div/h2[" + i + "]/a"));
            ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", menu);
            if (menu.getText().trim().equals(Menu)) {
                WebElement subMenu = driver.findElement(By.xpath("//*[@id=\"MenuContainer\"]/div/div[" + i + "]/div/ul/li[1]"));
                if (!subMenu.isDisplayed()) {
                    ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", menu);
                    menu.click();
                }
                Thread.sleep(2000);
                int subMenuCount = driver.findElements(By.xpath("//*[@id=\"MenuContainer\"]/div/div[" + i + "]/div/ul/li")).size();
                for (int j = 1; j <= subMenuCount; j++) {
                    subMenu = driver.findElement(By.xpath("//*[@id=\"MenuContainer\"]/div/div[" + i + "]/div/ul/li[" + j + "]"));
                    ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", subMenu);
                    if (subMenu.getText().equals(SubMenu)) {
                        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", subMenu);
                        subMenu.click();
                        Thread.sleep(10000);
                         frame = KovairGenericClass._getFrameIdfromSubmenu(Menu, SubMenu, driver);
                        driver.switchTo().frame(frame);
                        Select dropdown0 = new Select(driver.findElement(By.id("KovairMaster_Main_EntityList")));
                        dropdown0.selectByVisibleText(EntityName);
                        Thread.sleep(3000);
                        break;
                    }
                  
                }
                break;
              
            }
           
        }
        return frame;
        
    }


    public static void clickMenuAndSubMenuInWorkspaceSetup(String Menu, String SubMenu) throws InterruptedException, Exception {
        driver.switchTo().defaultContent();
        int menuCount = driver.findElements(By.xpath("//*[@id=\"MenuContainer\"]/div/h2")).size();
        for (int i = 1; i <= menuCount; i++) {
            WebElement menu = driver.findElement(By.xpath("//*[@id=\"MenuContainer\"]/div/h2[" + i + "]/a"));
            ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", menu);
            if (menu.getText().trim().equals(Menu)) {
                WebElement subMenu = driver.findElement(By.xpath("//*[@id=\"MenuContainer\"]/div/div[" + i + "]/div/ul/li[1]"));
                if (!subMenu.isDisplayed()) {
                    ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", menu);
                    menu.click();
                }
                Thread.sleep(2000);
                int subMenuCount = driver.findElements(By.xpath("//*[@id=\"MenuContainer\"]/div/div[" + i + "]/div/ul/li")).size();
                for (int j = 1; j <= subMenuCount; j++) {
                    subMenu = driver.findElement(By.xpath("//*[@id=\"MenuContainer\"]/div/div[" + i + "]/div/ul/li[" + j + "]"));
                    ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", subMenu);
                    if (subMenu.getText().equals(SubMenu)) {
                        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", subMenu);
                        subMenu.click();
                        Thread.sleep(10000);
                        String frame = KovairGenericClass._getFrameIdfromSubmenu(Menu, SubMenu, driver);
                        driver.switchTo().frame(frame);
                        break;
                    }
                }
                break;
            }
        }
    }

    public static void Workspace_Setup_DD_click(WebDriver driver) throws Exception {
        try {
            WebDriverWait wait = new WebDriverWait(driver, 30);
            wait.until(ExpectedConditions.invisibilityOfElementLocated(By.id("img_loading")));
            driver.findElement(By.xpath("//div[@id='div_icon']/span")).click();
            wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@id='div_icon']/div/ul/li/a")));
            WebElement ws_setupclick = driver.findElement(By.xpath("//div[@id='div_icon']/div/ul/li/a"));
            JavascriptExecutor executor = (JavascriptExecutor) driver;
            executor.executeScript("arguments[0].click();", ws_setupclick);
//            WebElement we_setupclick = driver.findElement(By.id("ddlHD_txtSearch"));
            
            Thread.sleep(3000);
        } catch (Exception e) {
            TestExeStatus = "Workspace set up Dropdown is not present.";
        }
    }
    
    public static String IfSummaryOperationExistInView(String View,String FieldName,String OperationName,WebDriver driver) throws Exception {            
        String Fldvalue=null;
        try
        {
          if(!View.isEmpty())
          KovairGenericClass.ViewSelection(View, "N","","", driver);
          WebDriverWait _wait = new WebDriverWait(driver,120);        
          Thread.sleep(1500);
         
     //     String summary_operation_div=driver.findElement(By.xpath("//div[@class='x-grid-cell-inner']")).getText();
          
          WebElement webElement = driver.findElement(By.xpath("/html/body/div[3]/div/span/div/div[2]/div/span/div/div/div[3]/div/div[4]/div/table/tbody/tr/td[3]/div"));
          String summary_operation_div = webElement.getText();
          
          
         // System.out.println(summary_operation_div); 
          
        //  Matcher m = Pattern.compile("\\(([^)]+)\\)").matcher(summary_operation_div);
           Matcher m = Pattern.compile("\\((.*?)\\)").matcher(summary_operation_div);
           while(m.find()) {
              System.out.println(m.group(1)); 
              if((m.group(1).equals(OperationName)))
                      {
                         TestExeStatus="Passed"; 
                      }
              else
                {
                    TestExeStatus="Failed";
                    TestErrDesc="Summary Operation does not exist in View.";
                }
            }
      }
         catch(Exception e)
         {
             TestExeStatus="Failed";
             TestErrDesc="Page Level Error";
         }
         return TestExeStatus;
    }
    
    
    public static String clickMenuSubMenuFromWorkspaceSetup(String Menu, String SubMenu, WebDriver driver) throws InterruptedException, Exception {
        driver.switchTo().defaultContent();
//        String frameId = "";
//        int menuCount = driver.findElements(By.xpath("//*[@id=\"MenuContainer\"]/div/h2")).size();
//        for (int i = 1; i <= menuCount; i++) {
//            WebElement menu = driver.findElement(By.xpath("//*[@id=\"MenuContainer\"]/div/h2[" + i + "]/a"));
//            ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", menu);
//            if (menu.getText().trim().equals(Menu)) {
//                WebElement subMenu = driver.findElement(By.xpath("//*[@id=\"MenuContainer\"]/div/div[" + i + "]/div/ul/li[1]"));
//                if (!subMenu.isDisplayed()) {
//                    ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", menu);
//                    menu.click();
//                }
//                Thread.sleep(2000);
//                int subMenuCount = driver.findElements(By.xpath("//*[@id=\"MenuContainer\"]/div/div[" + i + "]/div/ul/li")).size();
//                for (int j = 1; j <= subMenuCount; j++) {
//                    subMenu = driver.findElement(By.xpath("//*[@id=\"MenuContainer\"]/div/div[" + i + "]/div/ul/li[" + j + "]"));
//                    ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", subMenu);
//                    if (subMenu.getText().equals(SubMenu)) {
//                        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", subMenu);
//                        subMenu.click();
//                        Thread.sleep(10000);
//                        frameId = KovairGenericClass._getFrameIdfromSubmenu(Menu, SubMenu, driver);
//                        driver.switchTo().frame(frameId);
//                        break;
//                    }
//                }
//                break;
//            }
//        }
//        return frameId;
        WebElement menu = driver.findElement(By.xpath("//*[@id=\"MenuContainer\"]/div/h2/a[@title='"+Menu+"']"));
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", menu);
        WebElement subMenu = driver.findElement(By.xpath("//*[@id=\"MenuContainer\"]/div/div/div/ul/li/a[text()='"+ SubMenu +"']"));
         if (!subMenu.isDisplayed()) {
              ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", menu);
                    menu.click();
                }
         subMenu.click();
         String frameId = "";  
       frameId = KovairGenericClass._getFrameIdfromSubmenu(Menu, SubMenu, driver);
       driver.switchTo().frame(frameId);
       return frameId;
    }



    public static String CheckAndCloseErrorPopup() {
        java.util.List<WebElement> modals = driver.findElements(By.cssSelector(".modaldiv_two"));
        if (modals.size() > 0) {
            for (WebElement modal : modals) {
                ((JavascriptExecutor) driver).executeScript("arguments[0].click();", modal.findElement(By.id("btnModalOk")));
            }

            TestExeStatus = "Passed";
        } else {
            TestExeStatus = "Failed";
        }
        return TestExeStatus;
    }

    public static int GetRecordCountForAdvancedFilterWithParamFields(String FilterId, String EntityTypeId, String ParamFieldName, String ParamValue, String ParamFieldType, String Projectid) throws Exception {
        int filterRelatedRecordCount = 0;
        try {
            String result[][] = getSQLresult("select 'select count(*) from tEntityItem where EntityTypeID='+cast('" + EntityTypeId + "' as varchar)+' and ISNULL(RecordStatus,''A'') = ''A'' and '+replace(ExpressionExecSQL,'$PARAM$." + ParamFieldName + "','" + ParamValue + "') from tFilter where FilterId='" + FilterId + "'");
            //if entity
            if (!EntityTypeId.equals("0")) {
                if (ParamFieldType.equals("Lookup")) {
                    result = getSQLresult("select 'select count(*) from tEntityItem where EntityTypeID='+cast('" + EntityTypeId + "' as varchar)+' and ISNULL(RecordStatus,''A'') = ''A'' and '+replace(replace(ExpressionExecSQL,'$PARAM$." + ParamFieldName + "','" + ParamValue + "'),'$PROJECTID$','" + Projectid + "') from tFilter where FilterId='" + FilterId + "'");
                }
                if (ParamFieldType.equals("MLT")) {
                    result = getSQLresult("select 'select count(*) from tEntityItem left join tEntityItemMLData on tEntityItem.ItemID = tEntityItemMLData.ItemID  where EntityTypeID='+cast('" + EntityTypeId + "' as varchar)+' and ISNULL(RecordStatus,''A'') = ''A'' and '+replace(ExpressionExecSQL,'$PARAM$." + ParamFieldName + "','" + ParamValue + "') from tFilter where FilterId='" + FilterId + "'");
                }
                if (result[0][0] != null) {
                    String sql = result[0][0];
                    String rawValue[][] = getSQLresult(sql);
                    filterRelatedRecordCount = rawValue != null ? Integer.parseInt(rawValue[0][0]) : 0;
                }

            }
        } catch (Exception e) {
            System.out.println("Error:=" + e.getMessage());
        }
        return filterRelatedRecordCount;
    }

//     public static int GetRecordCountForRunTimeUpdate(String FilterId, String EntityTypeId,String OperatorType, String Value) throws Exception {
//        int filterRelatedRecordCount = 0;
//        Boolean flag= true;
//          try {
//                 //for entity
//                String result[][] = getSQLresult("select 'select count(*) from tEntityItem where EntityTypeID='+cast('" + EntityTypeId + "' as varchar)+' and ISNULL(RecordStatus,''A'') = ''A'' and '+replace(SQL,'$FIELDVALUE$','" + Value + "') from tFilterConditionLines where FilterId='" + FilterId + "'");
//
////                //for task
////                String result1[][] = getSQLresult("select 'select count(*) from tTask where ProjectID='+cast('" + Projectid + "' as varchar)+' and ISNULL(RecordStatus,''A'') = ''A'' and '+replace(SQL,'$FIELDVALUE$','" + Value + "') from tFilterConditionLines where FilterId='" + FilterId + "'");
//                if((OperatorType.equals("Is Empty")) ||(OperatorType.equals("Is Not Empty"))||(OperatorType.equals("Is Changed"))||(OperatorType.equals("Is Not Changed"))) 
//                {
//                     result = getSQLresult("select 'select count(*) from tEntityItem where EntityTypeID='+cast('" + EntityTypeId + "' as varchar)+' and ISNULL(RecordStatus,''A'') = ''A'' and '+SQL from tFilterConditionLines where FilterId='" + FilterId + "'");
//                }
//                else
//                if((OperatorType.equals("Is Empty")) ||(OperatorType.equals("Is Not Empty"))) 
//                {
//                     result = getSQLresult("select 'select count(*) from tEntityItem where EntityTypeID='+cast('" + EntityTypeId + "' as varchar)+' and ISNULL(RecordStatus,''A'') = ''A'' and '+SQL from tFilterConditionLines where FilterId='" + FilterId + "'");
//                }
//                //(OperatorType.equals("Is Changed"))||(OperatorType.equals("Is Not Changed"))||
//               else
//                if((OperatorType.equals("Changes From"))||(OperatorType.equals("Changes To"))||(OperatorType.equals("Change Date To"))||(OperatorType.equals("Change Date From"))){    
//                    String QueryToInsert = "SELECT Count(*) FROM tChangeHistoryDetail inner join tChangeHistory on tChangeHistoryDetail.HistoryID = tChangeHistory.HistoryID ";
//                    String RawResult[][] = getSQLresult("select 'select count(*) from tEntityItem where EntityTypeID='+cast('" + EntityTypeId + "' as varchar)+' and ISNULL(RecordStatus,''A'') = ''A'' and '+replace(SQL,'$FIELDVALUE$','" + Value + "') from tFilterConditionLines where FilterId='" + FilterId + "'");
//                    String sql = RawResult[0][0]; //"select count(*) from tEntityItem where EntityTypeID=7436 and ISNULL(RecordStatus,'A') = 'A' and EXISTS (SELECT 1 FROM tChangeHistoryDetail WHERE tChangeHistoryDetail.FieldID = 12173 AND tChangeHistoryDetail.ToNum = $FIELDVALUE$ AND tChangeHistoryDetail.HistoryID = tChangeHistory.HistoryID)"
//                    sql=sql.split("EXISTS")[1];
//                    sql = sql.replace("SELECT 1 FROM tChangeHistoryDetail",QueryToInsert);
//                    result = getSQLresult(sql);//("Select '"+sql+"'");
//                    return Integer.parseInt(result[0][0]);
//                }
//            if (result[0][0] != null) {
//                String sql = result[0][0];
//                String rawValue[][] = getSQLresult(sql);
//                filterRelatedRecordCount = rawValue != null ? Integer.parseInt(rawValue[0][0]) : 0;
//            }
//        } catch (Exception e) {
//        }
//        return filterRelatedRecordCount;
//    }
//  
    public static int GetRecordCountForRunTimeUpdate(String FilterId, String EntityTypeId, String OperatorType, String ConditionFieldType, String Projectid, String Value) throws Exception {
        int filterRelatedRecordCount = 0;
        Boolean flag = true;
        try {
            //for entity
            String result[][] = getSQLresult("select 'select count(*) from tEntityItem where EntityTypeID='+cast('" + EntityTypeId + "' as varchar)+' and ISNULL(RecordStatus,''A'') = ''A'' and '+replace(SQL,'$FIELDVALUE$','" + Value + "') from tFilterConditionLines where FilterId='" + FilterId + "'");
            if ((OperatorType.equals("Is Changed")) || (OperatorType.equals("Is Not Changed"))) {
                result = getSQLresult("select 'select count(*) from tEntityItem where EntityTypeID='+cast('" + EntityTypeId + "' as varchar)+' and ISNULL(RecordStatus,''A'') = ''A'' and '+SQL from tFilterConditionLines where FilterId='" + FilterId + "'");
            } else if ((OperatorType.equals("Is Empty")) || (OperatorType.equals("Is Not Empty"))) {
                result = getSQLresult("select 'select count(*) from tEntityItem where EntityTypeID='+cast('" + EntityTypeId + "' as varchar)+' and ISNULL(RecordStatus,''A'') = ''A'' and '+SQL from tFilterConditionLines where FilterId='" + FilterId + "'");
            } else if ((OperatorType.equals("Changes From")) || (OperatorType.equals("Changes To")) || (OperatorType.equals("Change Date To")) || (OperatorType.equals("Change Date From"))) {
                String QueryToInsert = "SELECT Count(*) FROM tChangeHistoryDetail inner join tChangeHistory on tChangeHistoryDetail.HistoryID = tChangeHistory.HistoryID  AND tChangeHistory.ProjectID = '" + Projectid + "'";
                String RawResult[][] = getSQLresult("select 'select count(*) from tEntityItem where EntityTypeID='+cast('" + EntityTypeId + "' as varchar)+' and ISNULL(RecordStatus,''A'') = ''A'' and '+replace(SQL,'$FIELDVALUE$','" + Value + "') from tFilterConditionLines where FilterId='" + FilterId + "'");
                String sql = RawResult[0][0]; //"select count(*) from tEntityItem where EntityTypeID=7436 and ISNULL(RecordStatus,'A') = 'A' and EXISTS (SELECT 1 FROM tChangeHistoryDetail WHERE tChangeHistoryDetail.FieldID = 12173 AND tChangeHistoryDetail.ToNum = $FIELDVALUE$ AND tChangeHistoryDetail.HistoryID = tChangeHistory.HistoryID)"
                sql = sql.split("EXISTS")[1];
                sql = sql.replace("SELECT 1 FROM tChangeHistoryDetail", QueryToInsert);
                result = getSQLresult(sql);
                return Integer.parseInt(result[0][0]);

            }
            if (ConditionFieldType.equals("MLT") || ConditionFieldType.equals("HTML")) {
                result = getSQLresult("select 'select count(*) from tEntityItem left join tEntityItemMLData on tEntityItem.ItemID = tEntityItemMLData.ItemID where EntityTypeID='+cast('" + EntityTypeId + "' as varchar)+' and ISNULL(RecordStatus,''A'') = ''A'' and '+replace(SQL,'$FIELDVALUE$','" + Value + "') from tFilterConditionLines where FilterId='" + FilterId + "'");
            }
          
            if (result[0][0] != null) {
                String sql = result[0][0];
                String rawValue[][] = getSQLresult(sql);
                filterRelatedRecordCount = rawValue != null ? Integer.parseInt(rawValue[0][0]) : 0;
            }
        } catch (Exception e) {
        }
        return filterRelatedRecordCount;
    }

  
    public static int GetRecordCountForMultiCondFilter(String FilterId, String EntityTypeId, String FilterType, String ConditionFieldType, String OperatorType, String Projectid) throws Exception {

        int filterRelatedRecordCount = 0;
        Boolean flag = true;
        if (!FilterType.equals("Advanced")) {
            try {
                //for entity
                String result[][] = getSQLresult("select 'select count(*) from tEntityItem where EntityTypeID='+cast('" + EntityTypeId + "' as varchar)+' and ISNULL(RecordStatus,''A'') = ''A'' and '+replace(SQL,'$FIELDVALUE$',Value2) from tFilterConditionLines where FilterId='" + FilterId + "'");

                //for task
                String result1[][] = getSQLresult("select 'select count(*) from tTask where ProjectID='+cast('" + Projectid + "' as varchar)+' and ISNULL(RecordStatus,''A'') = ''A'' and '+replace(SQL,'$FIELDVALUE$',Value2) from tFilterConditionLines where FilterId='" + FilterId + "'");
                if (result.length > 1) {
                    String res2, res3;

                    for (int i = 1; i < result.length; ++i) {
                        res2 = (result[i][0].split("'A'"))[2];
                        result[0][0] = result[0][0].concat(res2);
                    }
//                    result[0][0]=result[0][0].concat("\"");
                }
                //if entity
                if (!EntityTypeId.equals("0")) {

                    if (result[0][0] != null) {
                        String sql = result[0][0];
                        String rawValue[][] = getSQLresult(result[0][0]);
                        filterRelatedRecordCount = rawValue != null ? Integer.parseInt(rawValue[0][0]) : 0;
                    }

                } //if task
                else if (EntityTypeId.equals("0")) {
                    if (result1[0][0] != null) {
                        String sql = result1[0][0];
                        String rawValue[][] = getSQLresult(sql);
                        filterRelatedRecordCount = rawValue != null ? Integer.parseInt(rawValue[0][0]) : 0;
                    }

                }
            } catch (Exception e) {
                System.out.println("Error:=" + e.getMessage());
            }
        }

        return filterRelatedRecordCount;
    }
    
    
    
    public static String Form_Section_ExpandCollapse(String SectionName,WebDriver driver) throws Exception{
        //driver.findElement(By.xpath("//div[@id='icon_set_bg']/table/tbody/tr/td[4]"));
         String Sectionid="";
         if(SectionName.equals("Attachments"))
         {
           Sectionid="KovairMaster_Main_colPanel_Section_2";
         }
         else if(SectionName.equals("Comments"))
         {
           Sectionid="KovairMaster_Main_colPanel_Section_1";
         }
         else if(SectionName.equals("Parent Attachments"))
         {
           Sectionid="KovairMaster_Main_colPanel_Section_19";
         }
         else if(SectionName.equals("Parent Comments"))
         {
           Sectionid="KovairMaster_Main_colPanel_Section_20";
         }
         WebElement Img=driver.findElement(By.id(Sectionid+"_button"));
         ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", Img);
         String Imgtitle=Img.getAttribute("title").toString().trim();
         if(Imgtitle.equals("Click here to expand"))
         { Img.click(); 
            ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", Img);
            Thread.sleep(1000);
         }
         TestExeStatus="Passed";
         return TestExeStatus;
    }
   
    public static String RecordList_RightClick_Command_Click(String ParentCommandcommandText, String SubCommandcommandText,String Entity, WebDriver driver) throws Exception {
        WebElement tr = null;
        try 
        {
            String Gridid = (driver.findElement(By.xpath("//div[@id='EntityGrid-body']/div"))).getAttribute("id").toString().trim();
            String trid = Gridid + "-record-ext-record-";
            try 
            {
                String data_par_div = (driver.findElement(By.xpath("//div[@id='EntityGrid-body']/div"))).getAttribute("id").toString();
                int row_size = driver.findElements(By.xpath("//tbody[@id='" + data_par_div + "-body']/tr")).size();
                Thread.sleep(2000);
                if (row_size > 0) {
                    tr = (driver.findElement(By.xpath("//div[@id='EntityGrid-body']/div/table/tbody/tr[1]")));
                    tr.click();
                   Thread.sleep(2000);
                } else {
                    TestExeStatus = "No Records found.";
                    return TestExeStatus;
                }
            } 
            catch (Exception e1) 
            {
                tr = (driver.findElement(By.xpath("//tr[contains(id,'" + trid + "')]")));
                tr.click();
                Thread.sleep(2000);
            }
            Actions oAction = new Actions(driver);
            oAction.moveToElement(tr);
            oAction.contextClick(tr).build().perform();
            Thread.sleep(2500);
            WebElement elementOpen = null;
            if (SubCommandcommandText.equals("")) 
            {
                try
                {
                     elementOpen = driver.findElement(By.xpath("//span[contains(text(),'" + ParentCommandcommandText + "')]"));
                     TestExeStatus = "Passed";
                }
                catch (Exception _e)
                {
                    TestExeStatus = "Command : '"+ParentCommandcommandText+"' is not avaiable.";
                }
            } 
            else 
            {
                try
                {
                    WebElement elementParentOpen = driver.findElement(By.xpath("//span[contains(text(),'" + ParentCommandcommandText + "')]"));
                    String _id = elementParentOpen.getAttribute("id").toString();
                    String div_id = _id.substring(0, _id.indexOf("-textEl"));
                    WebElement _div = driver.findElement(By.id(div_id));
                    oAction.moveToElement(_div).build().perform();
                    Thread.sleep(1500);
                    try
                    {
                       elementOpen = driver.findElement(By.linkText(SubCommandcommandText));
                       JavascriptExecutor executor = (JavascriptExecutor) driver;
                       executor.executeScript("arguments[0].click();", elementOpen);
                       Thread.sleep(10000);
                       TestExeStatus = "Passed";                 
                    }
                    catch (Exception _e)
                    {
                        TestExeStatus = "Command : '"+SubCommandcommandText+"' is not avaiable.";
                    }
                }
                catch (Exception _e1)
                {
                   TestExeStatus = "Command : '"+ParentCommandcommandText+"' is not avaiable.";
                }
            }
           driver.findElement(By.id("pageTitle")).click();
        } 
        catch (Exception e)
        {
            
            TestExeStatus = "Page Level Error." + e.getMessage();
        }
        return TestExeStatus;
    }
    

    public static String clickMenuAndSubMenuInWorkspaceSetup(String Menu, String SubMenu, WebDriver driver) throws InterruptedException, Exception {
        String frame = "";
        driver.switchTo().defaultContent();
        int menuCount = driver.findElements(By.xpath("//*[@id=\"MenuContainer\"]/div/h2")).size();
        for (int i = 1; i <= menuCount; i++) {
            WebElement menu = driver.findElement(By.xpath("//*[@id=\"MenuContainer\"]/div/h2[" + i + "]/a"));
            ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", menu);
            if (menu.getText().trim().equals(Menu)) {
                WebElement subMenu = driver.findElement(By.xpath("//*[@id=\"MenuContainer\"]/div/div[" + i + "]/div/ul/li[1]"));
                if (!subMenu.isDisplayed()) {
                    ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", menu);
                    menu.click();
                }
                Thread.sleep(2000);
                int subMenuCount = driver.findElements(By.xpath("//*[@id=\"MenuContainer\"]/div/div[" + i + "]/div/ul/li")).size();
                for (int j = 1; j <= subMenuCount; j++) {
                    subMenu = driver.findElement(By.xpath("//*[@id=\"MenuContainer\"]/div/div[" + i + "]/div/ul/li[" + j + "]"));
                    ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", subMenu);
                    if (subMenu.getText().equals(SubMenu)) {
                        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", subMenu);
                        subMenu.click();
                        Thread.sleep(10000);
                        frame = KovairGenericClass._getFrameIdfromSubmenu(Menu, SubMenu, driver);
                        driver.switchTo().frame(frame);
                        break;
                    }
                }
                break;
            }
        }
        return frame;
    }
    public static void navigate_to_Omnibus(String PageName,WebDriver driver) throws Exception {
         try
         {
    	//****************************OMNIBUS*********************************//
        driver.switchTo().defaultContent();
    	WebElement omnibus=driver.findElement(By.xpath("//div[@id='MenuContainer']/div/h2/a[@title='Omnibus']"));
    	((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", omnibus);
        omnibus.click();
    	//****************************Registration*******************************//
        String Omnidiv_Id=omnibus.getAttribute("id");
        Omnidiv_Id=Omnidiv_Id.replace("Menu_a","Menu_subMenucontainer");
        int j=0;
        int Omni_atagsize= driver.findElements(By.xpath("//div[@id='"+Omnidiv_Id+"']/ul/li/a")).size();
        for(j=0;j<Omni_atagsize;j++)
        {
            WebElement Omni_atag=driver.findElements(By.xpath("//div[@id='"+Omnidiv_Id+"']/ul/li/a")).get(j); 
            if(Omni_atag.getText().contains(PageName))
            {
             Omni_atag.click();
             Thread.sleep(1000);             
             break;
            }           
         }
        
          String relmapframe = Omnidiv_Id;
          relmapframe=relmapframe.replace("Menu_subMenucontainer","cc");
          WebElement RelMappingFrameId=driver.findElement(By.id(relmapframe+"_"+(j+1)));
          driver.switchTo().frame(RelMappingFrameId);
         }
            catch (Exception e) {
            TestExeStatus = "Omnibus page not available";
                 }
    }
    public static String List_RightClick_Command_click(String ItemName,String PageName,String ParentCommandcommandText,String SubCommandcommandText,WebDriver driver) throws Exception{
    try
       { 
           String trid=Get_specific_tr_id(ItemName,PageName,"OmnibusList",driver);       
           Actions oAction = new Actions(driver);
           oAction.moveToElement(driver.findElement(By.id(trid)));
           oAction.contextClick(driver.findElement(By.id(trid))).build().perform(); 
           Thread.sleep(1000);
           //WebElement elementOpen = driver.findElement(By.linkText(CommandText)); 
           WebElement elementOpen=null;
           if(SubCommandcommandText.equals(""))
            {
                elementOpen = driver.findElement(By.linkText(ParentCommandcommandText)); 
                Thread.sleep(2000);
            }
          else 
            {             
              WebElement elementParentOpen = driver.findElement(By.linkText(ParentCommandcommandText)); 
              oAction.moveToElement(elementParentOpen).build().perform();
              elementOpen = driver.findElement(By.linkText(SubCommandcommandText));   
              Thread.sleep(2000);
            } 
           elementOpen.click();
           Thread.sleep(2000);
           TestExeStatus="Passed";
       }
       catch(Exception e)
       {
           TestExeStatus="Failed"; 
       }
        return TestExeStatus;
    }
}
