/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.kovair.SearchCapability;

import TaskList.KovairGenericClass;
import com.kovair.common.*;
//import com.kovair.utilities.FindError;
import com.kovair.utilities.sqlConnection;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

/**
 *
 * @author supriyam
 */

public class preRequisitesField {
    static String PageName = "preRequisitesField";
    static String URL = null;
    static String UserId = null;
    static String browser = null;
    static String Password = null;
    static String Workspace = null;
    static WebDriver driver;
    static WebDriver driver1;
    int srlNo = 0;
    String ErrDesc;
    String ExecutionStatus;
    String TCName;
    String tcId;
    int runId;
    int logid1 = 0;
    int logid2 = 0;
    int logid_diff = 0;
    String frameid;
    String ename = "BlankEntity";
    String sectionName = "New Section";
    String formName = "New Form";
    String gridSection = "Grid_Field";
    String DefaultValue = "Default";
    String FScopeSG=null;
    public String SessionId = null;
    String ss[] = {"General", "Description"};
    String cs[] = {"New Section"};
    String PriorityLookupValue[] = {"Low", "Medium", "High", "Very High"};
    String AutoItImageUploaderPath = System.getProperty("user.dir") + "//src/test/java/com/autoit/uploader/ImageUpload.exe";
    String AutoItFileUploaderPath = System.getProperty("user.dir") + "//src/test/java/com/autoit/uploader/FileUpload.exe";
    String imagePath = System.getProperty("user.dir") + "\\src\\test\\java\\com\\autoit\\uploader\\Methods.abc";
    String imagePath2 = System.getProperty("user.dir") + "\\src\\test\\java\\com\\autoit\\uploader\\Tulips.jpg";
    String filePath = System.getProperty("user.dir") + "\\src\\test\\java\\com\\autoit\\uploader\\Methods.abc";

    File fXmlFile_Login = new File(System.getProperty("user.dir") + "//src/test/java/com/kovair/LoginInfo/LoginInfo.xml");

    /**
     *
     * @author pijushad
    preRequisitesField { */
    

      @BeforeClass
    @Parameters({"testEntity","FieldScope"})
    public void beforeClass(@Optional String testEntity,String Fscope) throws Exception {
        Object[] logdata = KovairGenericClass.LoginInfo(fXmlFile_Login);
        URL = logdata[0].toString();
        UserId = logdata[1].toString();
        Password = logdata[2].toString();
        Workspace = logdata[3].toString();
        browser = logdata[4].toString();
        FScopeSG=Fscope;
        driver = KovairGenericClass.launchBrowser(browser);
        if (sqlConnection.RunId == 0) {
            sqlConnection.sqlGetRunId();
        }
        runId = sqlConnection.RunId;
        sqlConnection.BatchName = PageName;
        System.out.println("RunId = " + runId);

        KovairGenericClass.login(URL, UserId, Password, Workspace, driver);
        Thread.sleep(3500);

        //***************************** Session Id********************************************//
        try {
            SessionId = driver.getCurrentUrl();
            SessionId = SessionId.split("SessionId=")[1];
            SessionId = SessionId.split("&")[0];
        } catch (Exception e) {
            try {
                WebDriverWait wait = new WebDriverWait(driver, 120);
                // wait.until(ExpectedConditions.invisibilityOfElementLocated(By.id("img_loading")));
            } catch (Exception ex) {
            }
        }
        FindError.baseUrl = URL;
        FindError.SessionId = SessionId;

        ename = testEntity;

        KovairGenericClass.Workspace_Selection(Workspace, driver);
        Thread.sleep(3500);

        frameid = KovairGenericClass.SpecificMenu_SubMenu_Clicked(ename, driver);
        Thread.sleep(8000);
//        driver.switchTo().frame(frameid);

        //KovairGenericClass.EndUser_ListPage_SearchBox("last 1", "N", PageName, "N", driver);
        //Thread.sleep(5000);
        //............................Default View Selection...........................
     /*   driver.findElement(By.id("KovairMaster_Main_ViewControl_FilterName")).click();
         int viewlist=driver.findElements(By.xpath("//*[@id='KovairMaster_Main_ViewControl_DisplayContainer']/ul/li")).size();
         for(int i=2;i<=viewlist;i++){
         WebElement view=driver.findElement(By.xpath("//*[@id='KovairMaster_Main_ViewControl_DisplayContainer']/ul/li["+i+"]/a[1]/span"));
         Actions actions=new Actions(driver);
         actions.moveToElement(view).build().perform();
         if(driver.findElement(By.xpath("//*[@id='KovairMaster_Main_ViewControl_DisplayContainer']/ul/li["+i+"]/a[1]/span")).getText().contains("Default View")){
         driver.findElement(By.xpath("//*[@id='KovairMaster_Main_ViewControl_DisplayContainer']/ul/li["+i+"]/a[1]/span")).click();
         Thread.sleep(5000);
         break;
         }
         }
         //..........................All Open Items Filter Selection.........................
         driver.findElement(By.id("KovairMaster_Main_FilterControl_FilterName")).click();
         int filterlist=driver.findElements(By.xpath("//*[@id='KovairMaster_Main_FilterControl_DisplayContainer']/ul/li")).size();
         for(int i=2;i<=filterlist;i++){
         WebElement filter=driver.findElement(By.xpath("//*[@id='KovairMaster_Main_FilterControl_DisplayContainer']/ul/li["+i+"]/a[1]/span"));
         Actions actions=new Actions(driver);
         actions.moveToElement(filter).build().perform();
         if(driver.findElement(By.xpath("//*[@id='KovairMaster_Main_FilterControl_DisplayContainer']/ul/li["+i+"]/a[1]/span")).getText().contains("All Open Items")){
         driver.findElement(By.xpath("//*[@id='KovairMaster_Main_FilterControl_DisplayContainer']/ul/li["+i+"]/a[1]/span")).click();
         Thread.sleep(7000);
         break;
         }
         }
         */
    }
    
       @AfterClass
    public void afterClass() throws Exception {
        driver.quit();
    }
    
     @BeforeMethod
    public void BeforeMethod() throws Exception {

        srlNo++;
        ErrDesc = "";
        ExecutionStatus = "";
        TCName = "";
        tcId = "";

        String result[][] = FindError.getSQLresult("select top 1 logid from terrorlogs where SessionId = '" + SessionId + "' order by 1 desc");
        System.out.println("Result Set:");

        try {
            if (result.length != 0) {
                logid1 = Integer.parseInt(result[0][0]);
            } else {
                logid1 = 0;
            }
        } catch (Exception e) {
            logid1 = 0;
        }
    }
    
      @AfterMethod
    public void TestCaseResult() throws Exception {

        Date date = new Date();
        SimpleDateFormat dateFormatter = new SimpleDateFormat("MMMM dd, yyyy hh-mm-ss");
        SimpleDateFormat dateFormatter1 = new SimpleDateFormat("MMMM dd, yyyy");
        String filePath = "";
        File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
        System.out.println("Result Set After Method:");

        if (!ExecutionStatus.equals("Passed")) {
            String result[][] = FindError.getSQLresult("select top 1 logid from terrorlogs where SessionId = '" + SessionId + "' order by 1 desc");
            try {
                if (result.length != 0) {
                    logid2 = Integer.parseInt(result[0][0]);
                } else {
                    logid2 = 0;
                }
            } catch (Exception e) {
                logid2 = 0;
            }

            System.out.println(logid2);
            /*for(int i=0;i<result.length;i++){
             System.out.println("inside for loop");
             System.out.println(result[i][0]);
             }*/
            logid_diff = logid2 - logid1;
            if (logid_diff > 0) {
                filePath = "\\\\DB-QA\\AutomationScreeenshots\\" + dateFormatter1.format(date) + "\\screenshot_" + dateFormatter.format(date) + ".jpg";
                FileUtils.copyFile(scrFile, new File(filePath));
                System.out.println("Test Case Id:" + tcId);
                System.out.println("Test Case Name:" + TCName);

                FindError.checkPageError(driver);
                ExecutionStatus = FindError.ExecutionStatus;
                ErrDesc = FindError.ErrDesc;
                System.out.println("Inside Log: " + ErrDesc);
            } else {
                filePath = "\\\\DB-QA\\AutomationScreeenshots\\" + dateFormatter1.format(date) + "\\screenshot_" + dateFormatter.format(date) + ".jpg";
                Thread.sleep(2000);

                FileUtils.copyFile(scrFile, new File(filePath));

                if (ExecutionStatus.equals("")) {
                    ExecutionStatus = "Not Executed";
                    ErrDesc = "Unknown";
                } else {
                    ExecutionStatus = "Failed";
                }
            }
        }

        System.out.println("srlNo: " + srlNo);
        System.out.println("Run ID: " + runId);
        System.out.println("tcId: " + tcId);
        System.out.println("TCName: " + TCName);
        System.out.println("ExecutionStatus: " + ExecutionStatus);
        System.out.println("ErrDesc: " + ErrDesc);

        sqlConnection.sqlInsert(runId, srlNo, tcId, TCName, ExecutionStatus, ErrDesc, filePath);

    }

        
        @Test
        public void wkspSetupMode() throws Exception {
            tcId = "Wksp_0001";
            TCName = "Verify workspace setup mode functioality";

            try {
                driver.switchTo().defaultContent();
                if(FScopeSG.equals("Shared") || FScopeSG.equals("Entities"))
                driver.findElement(By.id("ddlHD_txtSearch")).click();
                else
                   KovairGenericClass.Site_Setup_click(driver);
                Thread.sleep(10000);
                ExecutionStatus = "Passed";
            } catch (Exception e) {
                ExecutionStatus = "Failed";
                ErrDesc = e.getMessage();
                System.out.println(e.getMessage());
            }
        }

        @Test(dataProvider = "FieldCreation")
        public void createField(String fieldName, String fieldType) throws Exception {
            tcId = "FieldCreation: " + fieldName;
            TCName = "Creating " + fieldType;
            try {
                clickMenuAndSubMenuInWorkspaceSetup("Entities", "Fields");
                switch (fieldType) {
                    case "Start1":
                        createIntegerField(fieldName);
                        break;
                    case "Between1":
                        createIntegerField(fieldName);
                        break;
                    case "Start-":
                        createIntegerField(fieldName);
                        break;
                    case "Between-":
                        createIntegerField(fieldName);
                        break;
                    case "Start_":
                        createIntegerField(fieldName);
                        break;
                    case "Between_":
                        createIntegerField(fieldName);
                        break;

                    default:
                        System.out.println("Invalid field type");
                        throw new IllegalArgumentException();
                }
                ExecutionStatus = "Passed";
                ErrDesc = "";
                org.testng.Assert.assertEquals("Passed", "Passed");
            } catch (Exception ex) {
                clickMenuAndSubMenuInWorkspaceSetup(ename, "Fields");
                ExecutionStatus = "Failed:" + fieldName;
                ErrDesc = ex.getMessage();
                org.testng.Assert.assertEquals("Passed", "Failed");
            }
        }

        private void createIntegerField(String fieldName) throws InterruptedException, Exception {
            try {
                WebElement _createnewlink = driver.findElement(By.xpath("//td[@id='hdrLink']/div/div/ul/li/a"));
                JavascriptExecutor executor = (JavascriptExecutor) driver;
                executor.executeScript("arguments[0].click();", _createnewlink);
                Thread.sleep(10000);
                if(FScopeSG.equals("Shared") || FScopeSG.equals("Global"))
                    driver.findElement(By.id("KovairMaster_Main_btnNextField")).click();
                SelectFieldType("Integer");
                Thread.sleep(2000);
                driver.findElement(By.xpath("//*[@id=\"KovairMaster_Main_txtFieldLabel\"]")).sendKeys(fieldName);
                Thread.sleep(2000);
                driver.findElement(By.xpath("//*[@id=\"KovairMaster_Main_btnNext\"]")).click();
                Thread.sleep(10000);
                driver.findElement(By.xpath("//*[@id=\"KovairMaster_Main_btnSaveAndFinish\"]")).click();
                Thread.sleep(10000);
            } catch (Exception ex) {
                throw new Exception("Failed to create " + fieldName);
            }
        }

        @DataProvider(name = "FieldCreation")
        public Object[][] getFieldNamesForCreation() {
            Object field[][] = new Object[14][2];
            //Integer Field
            field[0][0] = "1Integer_Field";
            field[0][1] = "Start1";

            //Float Field
            field[1][0] = "Int1eger_Field";
            field[1][1] = "Between1";

            //Date Field
            field[2][0] = "-Integer_Field";
            field[2][1] = "Start-";

            //DateTime Field
            field[3][0] = "Int-eger_Field";
            field[3][1] = "Between-";

            //Singleline Field
            field[4][0] = "_Integer_Field";
            field[4][1] = "Start_";

            field[5][0] = "Int_eger_Field";
            field[5][1] = "Between_";

            return field;
        }

        private void clickMenuAndSubMenuInWorkspaceSetup(String Menu, String SubMenu) throws InterruptedException, Exception {
            driver.switchTo().defaultContent();
            int menuCount = driver.findElements(By.xpath("//*[@id=\"MenuContainer\"]/div/h2")).size();
            for (int i = 1; i <= menuCount; i++) {
                WebElement menu = driver.findElement(By.xpath("//*[@id=\"MenuContainer\"]/div/h2[" + i + "]/a"));
                ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", menu);
                if (menu.getText().trim().equals(Menu)) {
                    WebElement subMenu = driver.findElement(By.xpath("//*[@id=\"MenuContainer\"]/div/div[" + i + "]/div/ul/li[1]"));
                    if (!subMenu.isDisplayed()) {
                        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", menu);
                        menu.click();
                    }
                    Thread.sleep(2000);
                    int subMenuCount = driver.findElements(By.xpath("//*[@id=\"MenuContainer\"]/div/div[" + i + "]/div/ul/li")).size();
                    for (int j = 1; j <= subMenuCount; j++) {
                        subMenu = driver.findElement(By.xpath("//*[@id=\"MenuContainer\"]/div/div[" + i + "]/div/ul/li[" + j + "]"));
                        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", subMenu);
                        if (subMenu.getText().equals(SubMenu)) {
                            ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", subMenu);
                            subMenu.click();
                            Thread.sleep(10000);
                            String frame = KovairGenericClass._getFrameIdfromSubmenu(Menu, SubMenu, driver);
                            driver.switchTo().frame(frame);
                            break;
                        }
                    }
                    break;
                }
            }
        }

        private void SelectFieldType(String fieldType) throws InterruptedException {
            int fldtypecnt = driver.findElements(By.xpath("//div[@id='FieldType_Div']/table/tbody/tr")).size();
            for (int i = 1; i <= fldtypecnt; i++) {
                Thread.sleep(5000);
                String Fieldtyp = driver.findElement(By.xpath("//div[@id='FieldType_Div']/table/tbody/tr[" + i + "]/td[2]/span")).getText().toString();
                if (Fieldtyp.equals(fieldType)) {
                    WebElement _FieldType = driver.findElement(By.xpath("//div[@id='FieldType_Div']/table/tbody/tr[" + i + "]/td[1]/input"));
                    ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", _FieldType);
                    _FieldType.click();
                    Thread.sleep(2000);
                    break;
                }
            }
        }

    }
