/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.kovair.SearchCapability;

import TaskList.KovairGenericClass;
import com.kovair.PagelevelModule.KovairEntitiesFieldsModule;
import com.kovair.PagelevelModule.KovairHomePageModule;

import com.kovair.PagelevelModule.KovairLoginPageModule;
import com.kovair.PagelevelModule.WorkspaceSettingsModule;

import com.kovair.utilities.BeforeAfterClassMethods;
import com.kovair.utilities.sqlConnection;
import com.kovair.utilities.sqlQueries;
import java.io.File;
import java.util.List;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;

import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

/**
 *
 * @author trainee
 */
public class SearchCapability_TC {

    static public WebDriver driver;
    static String TCID;
    static String TCName;
    static String ExecutionStatus;
    static String ErrDesc;
    static sqlQueries sql;
    static WorkspaceSettingsModule workspaceSettings;
    static List<String> entityNames = null;
    static KovairLoginPageModule kovairloginpage;
    static KovairHomePageModule kovairhomepage;
    static KovairEntitiesFieldsModule kovairentitiesfields;
    static String s = null;
    static String mod = null;
    static String numeric = null;
    static String subMod = null;
    static String frameid = null;
    static int srlNo = 0;
    static String PageName = "Fields";
    static File fXmlFile_Login = new File(System.getProperty("user.dir") + "//src/test/java/com/kovair/LoginInfo/LoginInfo.xml");

    public SearchCapability_TC() {

    }

    public void clickOnSiteSetup() throws Exception {
        KovairGenericClass.Site_Setup_click(driver);
        Thread.sleep(8000);
    }

    public void clickonWorkspaceSetup() throws Exception {
        kovairhomepage.Workspace_Setup_click(driver);
        Thread.sleep(8000);
    }

    public void edit() throws Exception {
        if (mod.equals("Shared")) {
            kovairentitiesfields.editPage(driver, "CalFieldTestShared");
        } else if (mod.equals("Entities")) {
            kovairentitiesfields.editPage(driver, "CalFieldTest");
        } else {
            kovairentitiesfields.editPage(driver, "CalFieldTestGlobal");
        }

    }

    public String searchKeyNumeric(String regExp, String mode) throws Exception {
        String sKey = null;

        char j = '1';
        List<WebElement> searchLinkTxt = kovairentitiesfields.fieldListStarting(driver);
        Thread.sleep(4000);
        for (WebElement ElemT : searchLinkTxt) {
            String getField = ElemT.getText();
            if (getField.matches(regExp)) {

                sKey = getField;
                break;
            }

        }
        if (sKey != null) {
            for (int count = 0; sKey.charAt(count) != '\0'; count++) {
                if ((sKey.charAt(count) >= '0') && (sKey.charAt(count) <= '9')) {
                    j = sKey.charAt(count);

                    break;
                }
            }
        } 

        
        String searchKey = Character.toString(j);
        return searchKey;

    }

    public static void createNewField() throws Exception {
        create();
        kovairentitiesfields.searchTextBoxEnterValue(driver, "Actual Cost");
        kovairentitiesfields.expressionTextBoxFirst(driver);
        kovairentitiesfields.selectReturnType(driver);
        kovairentitiesfields.saveAndFinish(driver);

    }

    public static void create() throws Exception {
        kovairentitiesfields.clickCreateNewLink(driver);
        if (mod.equals("Shared") || mod.equals("Global")) {
            kovairentitiesfields.clickNextButtonShared(driver);
        }
        kovairentitiesfields.chooseFieldType(driver);
        kovairentitiesfields.chooseFieldTypeStandard(driver);
        kovairentitiesfields.chooseFieldTypeCalculated(driver);
        if (mod.equals("Shared")) {
            kovairentitiesfields.enterFieldLabel(driver, "CalFieldTestShared");
        } else if (mod.equals("Entities")) {
            kovairentitiesfields.enterFieldLabel(driver, "CalFieldTest");
        } else {
            kovairentitiesfields.enterFieldLabel(driver, "CalFieldTestGlobal");
        }
        kovairentitiesfields.clickNextButton(driver);

    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    // @Test
    // public void hello() {}
    @BeforeSuite
    public static void beforeSuite() throws Exception {

        try {
            Object[] logdata = KovairLoginPageModule.LoginInfo(fXmlFile_Login);
            BeforeAfterClassMethods.getLogin(logdata);
            driver = KovairLoginPageModule.launchBrowser(BeforeAfterClassMethods.browser);
            driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
            sqlConnection.enterRunIdInDatabase();
            //  sqlConnection.sqlGetRunId();
            BeforeAfterClassMethods.createRunId(PageName);
            driver.get(BeforeAfterClassMethods.URL);
            kovairloginpage = new KovairLoginPageModule(driver);
            Boolean n = kovairloginpage.KovairLogin(BeforeAfterClassMethods.UserId, BeforeAfterClassMethods.Password, driver);
            if (n.booleanValue()) {
                Thread.sleep(2000);
                kovairhomepage = new KovairHomePageModule(driver);
                kovairhomepage.waitforWorkspaces(driver);
                kovairentitiesfields = new KovairEntitiesFieldsModule(driver);
                kovairhomepage.selectKovairWorkspaces(BeforeAfterClassMethods.Workspace, driver);
                Thread.sleep(4000);
            }

        } catch (Exception ex) {
            System.out.println(ex.getMessage());

        }

    }

    @AfterSuite
    public static void afterSuite() throws Exception {
        kovairloginpage.logout(driver);
        driver.quit();

    }

    @BeforeTest
    @Parameters({"pages", "module", "submodule"})
    public static void beforeTest(String workspaceSiteClick, String module, String subModule) throws Exception {

        s = workspaceSiteClick;
        mod = module;
        subMod = subModule;
        try {

            if (workspaceSiteClick.equals("WorkspaceSetup")) {
                kovairhomepage.Workspace_Setup_click(driver);
                Thread.sleep(8000);
                if (module.equals("Entities") && subModule.equals("Fields")) {
                    frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Entities", "Fields", driver);
                    driver.switchTo().frame(frameid);
//                kanbanTemlateModule = new KovairKanbanTemlateModule(driver);
//                 kanbanTemlateModule.getFullpageWebelment();
                    Thread.sleep(6000);
                    kovairentitiesfields = new KovairEntitiesFieldsModule(driver);

                    if (kovairentitiesfields.fieldAlreadyExists(driver, "CalFieldTest")) {
                        createNewField();
                    }
                }

                if (module.equals("Shared") && subModule.equals("Fields")) {
                    frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Shared", "Fields", driver);
                    driver.switchTo().frame(frameid);
//                kanbanTemlateModule = new KovairKanbanTemlateModule(driver);
//                 kanbanTemlateModule.getFullpageWebelment();
                    Thread.sleep(6000);
                    kovairentitiesfields = new KovairEntitiesFieldsModule(driver);

                    if (kovairentitiesfields.fieldAlreadyExists(driver, "CalFieldTestShared")) {
                        createNewField();
                    }
                }

            }

            if (workspaceSiteClick.equals("SiteSetup")) {

                KovairGenericClass.Site_Setup_click(driver);

                Thread.sleep(8000);
                if (module.equals("Global") && subModule.equals("Fields")) {
                    frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Global", "Fields", driver);
                    driver.switchTo().frame(frameid);
//                kanbanTemlateModule = new KovairKanbanTemlateModule(driver);
//                 kanbanTemlateModule.getFullpageWebelment();
                    Thread.sleep(6000);
                    kovairentitiesfields = new KovairEntitiesFieldsModule(driver);

                    if (kovairentitiesfields.fieldAlreadyExists(driver, "CalFieldTestGlobal")) {
                        createNewField();
                    }
                }

            }

        } catch (Exception e) {
            System.out.println(e);
        }

    }

    @AfterTest
    public static void afterTest() throws Exception {

        driver.switchTo().defaultContent();

    }

    @BeforeClass
    public static void setUpClass() throws Exception {

    }

    @AfterClass
    public static void tearDownClass() throws Exception {
    }

    @Test
    public void SearchBoxVisible_EntFlds() throws Exception {
        TCID = "Search_Capability_1";
        TCName = "Verify that in create/edit field page of workspace setup of calculated field, searchbox  of  expression builder is visible ";
        int createFlag = 0, editFlag = 0;

        try {
            create();
            Thread.sleep(4000);
            if (kovairentitiesfields.searchTextBox(driver) == true) {
                createFlag = 1;
            }
            kovairentitiesfields.cancelButtonClick(driver);
        } catch (Exception e) {
            System.out.println(e.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Entities", "Fields", driver);
            driver.switchTo().frame(frameid);
        }
        try {
            edit();
            Thread.sleep(4000);
            if (kovairentitiesfields.searchTextBox(driver) == true) {
                editFlag = 1;
            }
            kovairentitiesfields.editCancelButtonClick(driver);
            Thread.sleep(3000);
            kovairentitiesfields.editCancelButtonClick(driver);

            if (createFlag == 1 && editFlag == 1) {
                ExecutionStatus = "Passed";
            } else {
                ExecutionStatus = "Failed";
                if (createFlag == 0) {
                    ErrDesc = "Failed in create Step";
                } else {
                    ErrDesc = "Failed in edit Step";
                }
            }

        } catch (Exception e) {
            System.out.println(e.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Entities", "Fields", driver);
            driver.switchTo().frame(frameid);
        }

    }

    @Test
    public void SearchBoxBorderPresent_EntFlds() throws Exception {
        TCID = "Search_Capability_2";
        TCName = "Verify that in create/edit field page of workspace setup of calculated field, searchbox  of  expression builder has a border around it";
        int createFlag = 0, editFlag = 0;

        try {
            create();
            if (kovairentitiesfields.searchTextBoxBorder(driver)) //form-control class contains border element
            {
                createFlag = 1;
            }
            kovairentitiesfields.cancelButtonClick(driver);
        } catch (Exception e) {
            System.out.println(e.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Entities", "Fields", driver);
            driver.switchTo().frame(frameid);
        }

        try {

            edit();
            Thread.sleep(4000);
            if (kovairentitiesfields.searchTextBoxBorder(driver)) {
                editFlag = 1;
            }
            kovairentitiesfields.editCancelButtonClick(driver);
            Thread.sleep(3000);
            kovairentitiesfields.editCancelButtonClick(driver);

            if (createFlag == 1 && editFlag == 1) {
                ExecutionStatus = "Passed";
            } else {
                ExecutionStatus = "Failed";
                if (createFlag == 0) {
                    ErrDesc = "Failed in create Step";
                } else {
                    ErrDesc = "Failed in edit Step";
                }
            }

        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Entities", "Fields", driver);
            driver.switchTo().frame(frameid);

        }
    }

    @Test
    public void SearchBoxPlaceholderPresent_EntFlds() throws Exception {

        TCID = "Search_Capability_3";
        TCName = "Verify that in create/edit field page of workspace setup of calculated field, searchbox  of  expression builder has a placeholder";
        int createFlag = 0, editFlag = 0;

        try {
            create();
            if (kovairentitiesfields.searchTextBoxPlaceholder(driver).equals("Search for...")) {
                createFlag = 1;
            }
            kovairentitiesfields.cancelButtonClick(driver);
        } catch (Exception e) {
            System.out.println(e.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Entities", "Fields", driver);
            driver.switchTo().frame(frameid);
        }
        try {
            edit();
            Thread.sleep(4000);
            if (kovairentitiesfields.searchTextBoxPlaceholder(driver).equals("Search for...")) {
                editFlag = 1;
            }
            kovairentitiesfields.editCancelButtonClick(driver);
            Thread.sleep(3000);
            kovairentitiesfields.editCancelButtonClick(driver);

            if (createFlag == 1 && editFlag == 1) {
                ExecutionStatus = "Passed";
            } else {
                ExecutionStatus = "Failed";
                if (createFlag == 0) {
                    ErrDesc = "Failed in create Step";
                } else {
                    ErrDesc = "Failed in edit Step";
                }
            }

        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Entities", "Fields", driver);
            driver.switchTo().frame(frameid);
        }

    }

    @Test
    public void SearchBoxBorderColor_EntFlds() throws Exception {
        TCID = "Search_Capability_4";
        TCName = "Verify that in create/edit field page of workspace setup of calculated field, border color of searchbox  of  expression builder is grey";
        // System.out.println(kovairentitiesfields.searchTextBoxBorderColor(driver));
        int createFlag = 0, editFlag = 0;
        try {
            create();
            System.out.println(kovairentitiesfields.searchTextBoxBorderColor(driver));

            if (kovairentitiesfields.searchTextBoxBorderColor(driver).equals("rgb(204, 204, 204)")) {
                createFlag = 1;
            }
            kovairentitiesfields.cancelButtonClick(driver);
        } catch (Exception e) {
            System.out.println(e.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Entities", "Fields", driver);
            driver.switchTo().frame(frameid);
        }

        try {
            edit();
            Thread.sleep(4000);
            if (kovairentitiesfields.searchTextBoxBorderColor(driver).equals("rgb(204, 204, 204)")) {
                editFlag = 1;
            }
            kovairentitiesfields.editCancelButtonClick(driver);
            Thread.sleep(3000);
            kovairentitiesfields.editCancelButtonClick(driver);

            if (createFlag == 1 && editFlag == 1) {
                ExecutionStatus = "Passed";
            } else {
                ExecutionStatus = "Failed";
                if (createFlag == 0) {
                    ErrDesc = "Failed in create Step";
                } else {
                    ErrDesc = "Failed in edit Step";
                }
            }
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Entities", "Fields", driver);
            driver.switchTo().frame(frameid);
        }

    }

    @Test
    public void SearchBoxPlaceholderColor_EntFlds() throws Exception {
        TCID = "Search_Capability_5";
        TCName = "Verify that in create/edit field page of workspace setup of calculated field, placeholder  of  searchbox of expression builder is grey in color";
        // System.out.println(kovairentitiesfields.searchTextBoxBorderColor(driver));
        int createFlag = 0, editFlag = 0;
        try {
            create();
            System.out.println(kovairentitiesfields.findFilterSearchPlaceHolderColor(driver));

            if (kovairentitiesfields.findFilterSearchPlaceHolderColor(driver).equalsIgnoreCase("rgb(85, 85, 85)")) {
                createFlag = 1;
            }
            kovairentitiesfields.cancelButtonClick(driver);
        } catch (Exception e) {
            System.out.println(e.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Entities", "Fields", driver);
            driver.switchTo().frame(frameid);
        }

        try {
            edit();
            Thread.sleep(4000);
            if (kovairentitiesfields.findFilterSearchPlaceHolderColor(driver).equalsIgnoreCase("rgb(85, 85, 85)")) {
                editFlag = 1;
            }
            kovairentitiesfields.editCancelButtonClick(driver);
            Thread.sleep(3000);
            kovairentitiesfields.editCancelButtonClick(driver);

            if (createFlag == 1 && editFlag == 1) {
                ExecutionStatus = "Passed";
            } else {
                ExecutionStatus = "Failed";
                if (createFlag == 0) {
                    ErrDesc = "Failed in create Step";
                } else {
                    ErrDesc = "Failed in edit Step";
                }
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Entities", "Fields", driver);
            driver.switchTo().frame(frameid);
        }

    }

    @Test
    public void SearchBoxBorderColorChange_EntFlds() throws Exception {
        TCID = "Search_Capability_6";
        TCName = "Verify that in create/edit field page of workspace setup of calculated field, clicking in the searchbox  of  expression builder changes the box border color to blue";
        int createFlag = 0, editFlag = 0;

        try {
            create();
            kovairentitiesfields.searchTextBoxClick(driver);
            System.out.println(kovairentitiesfields.searchTextBoxBorderColor(driver));
            Thread.sleep(15000);
            if (kovairentitiesfields.searchTextBoxBorderColor(driver).equalsIgnoreCase("rgb(102, 175, 233)")) {
                createFlag = 1;
            }
            kovairentitiesfields.cancelButtonClick(driver);
        } catch (Exception e) {
            System.out.println(e.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Entities", "Fields", driver);
            driver.switchTo().frame(frameid);
        }
        try {
            edit();
            Thread.sleep(4000);
            kovairentitiesfields.searchTextBoxClick(driver);
            System.out.println(kovairentitiesfields.searchTextBoxBorderColor(driver));
            Thread.sleep(15000);
            if (kovairentitiesfields.searchTextBoxBorderColor(driver).equalsIgnoreCase("rgb(102, 175, 233)")) {
                editFlag = 1;
            }
            kovairentitiesfields.editCancelButtonClick(driver);
            Thread.sleep(3000);
            kovairentitiesfields.editCancelButtonClick(driver);

            if (createFlag == 1 && editFlag == 1) {
                ExecutionStatus = "Passed";
            } else {
                ExecutionStatus = "Failed";
                if (createFlag == 0) {
                    ErrDesc = "Failed in create Step";
                } else {
                    ErrDesc = "Failed in edit Step";
                }
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Entities", "Fields", driver);
            driver.switchTo().frame(frameid);
        }

    }

    @Test
    public void SearchBoxPlaceholderBegin_EntFlds() throws Exception {
        TCID = "Search_Capability_7";
        TCName = "Verify that in create/edit field page of workspace setup of calculated field,  the searchbox  of  expression builder placeholder starts from  the beginning of the searchbox";
        int createFlag = 0, editFlag = 0;

        try {
            create();
            if (kovairentitiesfields.searchTextBoxPlaceholder(driver).equals("Search for...")) {
                createFlag = 1;
            }
            kovairentitiesfields.cancelButtonClick(driver);
        } catch (Exception e) {
            System.out.println(e.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Entities", "Fields", driver);
            driver.switchTo().frame(frameid);
        }
        try {
            edit();
            Thread.sleep(4000);
            if (kovairentitiesfields.searchTextBoxPlaceholder(driver).equals("Search for...")) {
                editFlag = 1;
            }
            kovairentitiesfields.editCancelButtonClick(driver);
            Thread.sleep(3000);
            kovairentitiesfields.editCancelButtonClick(driver);

            if (createFlag == 1 && editFlag == 1) {
                ExecutionStatus = "Passed";
            } else {
                ExecutionStatus = "Failed";
                if (createFlag == 0) {
                    ErrDesc = "Failed in create Step";
                } else {
                    ErrDesc = "Failed in edit Step";
                }
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Entities", "Fields", driver);
            driver.switchTo().frame(frameid);
        }

    }

    @Test
    public void SearchBoxPlaceholderRemoved_EntFlds() throws Exception {
        TCID = "Search_Capability_8";
        TCName = "Verify that in create/edit field page of workspace setup of calculated field, typing in the searchbox  of  expression builder removing placeholder";
        int createFlag = 0, editFlag = 0;

        try {
            create();
            kovairentitiesfields.searchTextBoxClick(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, "ftgg");
            if (kovairentitiesfields.searchTextBoxPlaceholder(driver).isEmpty()) {
                createFlag = 1;
            }
            kovairentitiesfields.cancelButtonClick(driver);
        } catch (Exception e) {
            System.out.println(e.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Entities", "Fields", driver);
            driver.switchTo().frame(frameid);
        }
        try {
            edit();
            Thread.sleep(4000);
            kovairentitiesfields.searchTextBoxClick(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, "ftgg");
            if (kovairentitiesfields.searchTextBoxPlaceholder(driver).isEmpty()) {
                editFlag = 1;
            }
            kovairentitiesfields.editCancelButtonClick(driver);
            Thread.sleep(3000);
            kovairentitiesfields.editCancelButtonClick(driver);

            if (createFlag == 1 && editFlag == 1) {
                ExecutionStatus = "Passed";
            } else {
                ExecutionStatus = "Failed";
                if (createFlag == 0) {
                    ErrDesc = "Failed in create Step";
                } else {
                    ErrDesc = "Failed in edit Step";
                }
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Entities", "Fields", driver);
            driver.switchTo().frame(frameid);
        }

    }

    @Test
    public void SearchBoxFieldSelected_EntFlds() throws Exception {
        TCID = "Search_Capability_10";
        TCName = "Verify that  in create/edit field page of workspace setup of calculated field,  in searchbox if group fields are searched using * then single click on any of the group field can select the field";
        int createFlag = 0, editFlag = 0;

        try {

            create();

            String field;
            field = kovairentitiesfields.fieldListBox(driver);
            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, field);

            kovairentitiesfields.expressionTextBoxFirst(driver);

            if (kovairentitiesfields.fieldSelected(driver)) {
                createFlag = 1;
            }
            kovairentitiesfields.cancelButtonClick(driver);
        } catch (Exception e) {
            System.out.println(e.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Entities", "Fields", driver);
            driver.switchTo().frame(frameid);
        }
        try {

            edit();
            Thread.sleep(4000);
            String field;
            field = kovairentitiesfields.fieldListBox(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, field);
            kovairentitiesfields.expressionTextBoxFirst(driver);

            if (kovairentitiesfields.fieldSelected(driver)) {
                editFlag = 1;
            }
            kovairentitiesfields.editCancelButtonClick(driver);
            Thread.sleep(3000);
            kovairentitiesfields.editCancelButtonClick(driver);

            if (createFlag == 1 && editFlag == 1) {
                ExecutionStatus = "Passed";
            } else {
                ExecutionStatus = "Failed";
                if (createFlag == 0) {
                    ErrDesc = "Failed in create Step";
                } else {
                    ErrDesc = "Failed in edit Step";
                }
            }
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Entities", "Fields", driver);
            driver.switchTo().frame(frameid);
        }

    }

    @Test
    public void SearchBoxFieldsLetterStartsWith_EntFlds() throws Exception {
        TCID = "Search_Capability_11";
        TCName = "Verify that  in create/edit field page of workspace setup of calculated field,  in searchbox  search using '<search key>' format and entering any letters as search key only showing those fields whose name starts with the search key";
        int createFlag = 0, editFlag = 0;
        try {
            create();
            String searchKey = "a";
            int Flag = 1;
            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKey);
            Thread.sleep(7000);
            List<WebElement> searchLink = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink) {
                String getField = Elem.getText();
                System.out.println(getField);

                if (getField.startsWith(searchKey.toUpperCase()) || getField.startsWith(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                createFlag = 1;
            }
            kovairentitiesfields.cancelButtonClick(driver);
        } catch (Exception e) {
            System.out.println(e.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Entities", "Fields", driver);
            driver.switchTo().frame(frameid);
        }
        try {

            edit();
            String searchKey = "a";
            int Flag = 1;
            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKey);
            Thread.sleep(7000);
            List<WebElement> searchLink1 = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink1) {
                String getField = Elem.getText();
                System.out.println(getField);

                if (getField.startsWith(searchKey.toUpperCase()) || getField.startsWith(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                editFlag = 1;
            }
            kovairentitiesfields.editCancelButtonClick(driver);
            Thread.sleep(3000);
            kovairentitiesfields.editCancelButtonClick(driver);
            if (createFlag == 1 && editFlag == 1) {
                ExecutionStatus = "Passed";
            } else {
                ExecutionStatus = "Failed";
                if (createFlag == 0) {
                    ErrDesc = "Failed in create Step";
                } else {
                    ErrDesc = "Failed in edit Step";
                }
            }
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Entities", "Fields", driver);
            driver.switchTo().frame(frameid);
        }

    }

    @Test
    public void SearchBoxFieldsLetterStarStartsWith_EntFlds() throws Exception {
        TCID = "Search_Capability_12";
        TCName = "Verify that  in create/edit field page of workspace setup of calculated field,  in searchbox  search using '<search key>*' format and entering any letters as search key only showing those fields whose name starts with the search key";
        int createFlag = 0, editFlag = 0;
        try {
            create();
            String searchKey = "a";
            String searchKeyApp = searchKey + "*";
            int Flag = 1;
            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKeyApp);
            Thread.sleep(7000);
            List<WebElement> searchLink = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink) {
                String getField = Elem.getText();
                System.out.println(getField);

                if (getField.startsWith(searchKey.toUpperCase()) || getField.startsWith(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                createFlag = 1;
            }
            kovairentitiesfields.cancelButtonClick(driver);
        } catch (Exception e) {
            System.out.println(e.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Entities", "Fields", driver);
            driver.switchTo().frame(frameid);
        }
        try {
            edit();
            String searchKey = "a";
            String searchKeyApp = searchKey + "*";
            int Flag = 1;
            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKeyApp);
            Thread.sleep(7000);
            List<WebElement> searchLink1 = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink1) {
                String getField = Elem.getText();
                System.out.println(getField);

                if (getField.startsWith(searchKey.toUpperCase()) || getField.startsWith(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                editFlag = 1;
            }
            kovairentitiesfields.editCancelButtonClick(driver);
            Thread.sleep(3000);
            kovairentitiesfields.editCancelButtonClick(driver);
            if (createFlag == 1 && editFlag == 1) {
                ExecutionStatus = "Passed";
            } else {
                ExecutionStatus = "Failed";
                if (createFlag == 0) {
                    ErrDesc = "Failed in create Step";
                } else {
                    ErrDesc = "Failed in edit Step";
                }
            }
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Entities", "Fields", driver);
            driver.switchTo().frame(frameid);
        }
    }

    @Test
    public void SearchBoxFieldsDigitStartsWith_EntFlds() throws Exception {
        TCID = "Search_Capability_13";
        TCName = "Verify that  in create/edit field page of workspace setup of calculated field,  in searchbox  search using '<search key>' format and entering any digit as search key only showing those fields whose name starts with the search key";
        int createFlag = 0, editFlag = 0;

        try {
            create();

            int Flag = 1;

            String searchKey = searchKeyNumeric("^[0-9]+.*$", "create");

            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKey);
            Thread.sleep(7000);
            List<WebElement> searchLink = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink) {
                String getField = Elem.getText();
                System.out.println(getField);

                if (getField.startsWith(searchKey.toUpperCase()) || getField.startsWith(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                createFlag = 1;
            }
            kovairentitiesfields.cancelButtonClick(driver);
        } catch (Exception e) {
            System.out.println(e.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Entities", "Fields", driver);
            driver.switchTo().frame(frameid);
        }
        try {
            edit();

            int Flag = 1;

            String searchKey = searchKeyNumeric("^[0-9]+.*$", "edit");
            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKey);
            Thread.sleep(7000);
            List<WebElement> searchLink1 = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink1) {
                String getField = Elem.getText();
                System.out.println(getField);

                if (getField.startsWith(searchKey.toUpperCase()) || getField.startsWith(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                editFlag = 1;
            }
            kovairentitiesfields.editCancelButtonClick(driver);
            Thread.sleep(3000);
            kovairentitiesfields.editCancelButtonClick(driver);
            if (createFlag == 1 && editFlag == 1) {
                ExecutionStatus = "Passed";
            } else {
                ExecutionStatus = "Failed";
                if (createFlag == 0) {
                    ErrDesc = "Failed in create Step";
                } else {
                    ErrDesc = "Failed in edit Step";
                }
            }
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Entities", "Fields", driver);
            driver.switchTo().frame(frameid);
        }
    }

    @Test
    public void SearchBoxFieldsDigitStarStartsWith_EntFlds() throws Exception {
        TCID = "Search_Capability_14";
        TCName = "Verify that  in create/edit field page of workspace setup of calculated field,  in searchbox  search using '<search key>*' format and entering any digit as search key only showing those fields whose name starts with the search key";
        int createFlag = 0, editFlag = 0;
        try {
            create();

            int Flag = 1;

            String searchKey = searchKeyNumeric("^[0-9]+.*$", "create");
            String searchKeyApp = searchKey + "*";
            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKeyApp);
            Thread.sleep(7000);
            List<WebElement> searchLink = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink) {
                String getField = Elem.getText();
                System.out.println(getField);

                if (getField.startsWith(searchKey.toUpperCase()) || getField.startsWith(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                createFlag = 1;
            }
            kovairentitiesfields.cancelButtonClick(driver);
        } catch (Exception e) {
            System.out.println(e.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Entities", "Fields", driver);
            driver.switchTo().frame(frameid);
        }
        try {
            edit();

            int Flag = 1;
            String searchKey = searchKeyNumeric("^[0-9]+.*$", "edit");

            String searchKeyApp = searchKey + "*";
            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKeyApp);
            Thread.sleep(7000);
            List<WebElement> searchLink1 = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink1) {
                String getField = Elem.getText();
                System.out.println(getField);

                if (getField.startsWith(searchKey.toUpperCase()) || getField.startsWith(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                editFlag = 1;
            }
            kovairentitiesfields.editCancelButtonClick(driver);
            Thread.sleep(3000);
            kovairentitiesfields.editCancelButtonClick(driver);
            if (createFlag == 1 && editFlag == 1) {
                ExecutionStatus = "Passed";
            } else {
                ExecutionStatus = "Failed";
                if (createFlag == 0) {
                    ErrDesc = "Failed in create Step";
                } else {
                    ErrDesc = "Failed in edit Step";
                }
            }
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Entities", "Fields", driver);
            driver.switchTo().frame(frameid);
        }
    }

    @Test(dataProvider = "specialCharacterData")
    public void SearchBoxFieldsSpCharStartsWith_EntFlds(String spChar) throws Exception {
        TCID = "Search_Capability_15";
        TCName = "Verify that  in create/edit field page of workspace setup of calculated field,  in searchbox  search using '<search key>' format and entering any special character(_,-,$,?) as search key only showing those fields whose name starts with the search key";
        int createFlag = 0, editFlag = 0;

        try {
            create();
            String searchKey = spChar;
            int Flag = 1;
            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKey);
            Thread.sleep(7000);
            List<WebElement> searchLink = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink) {
                String getField = Elem.getText();
                System.out.println(getField);

                if (getField.startsWith(searchKey.toUpperCase()) || getField.startsWith(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                createFlag = 1;
            }
            kovairentitiesfields.cancelButtonClick(driver);
        } catch (Exception e) {
            System.out.println(e.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Entities", "Fields", driver);
            driver.switchTo().frame(frameid);
        }
        try {
            edit();
            String searchKey = spChar;
            int Flag = 1;
            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKey);
            Thread.sleep(7000);
            List<WebElement> searchLink1 = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink1) {
                String getField = Elem.getText();
                System.out.println(getField);

                if (getField.startsWith(searchKey.toUpperCase()) || getField.startsWith(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                editFlag = 1;
            }
            kovairentitiesfields.editCancelButtonClick(driver);
            Thread.sleep(3000);
            kovairentitiesfields.editCancelButtonClick(driver);
            if (createFlag == 1 && editFlag == 1) {
                ExecutionStatus = "Passed";
            } else {
                ExecutionStatus = "Failed";
                if (createFlag == 0) {
                    ErrDesc = "Failed in create Step";
                } else {
                    ErrDesc = "Failed in edit Step";
                }
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Entities", "Fields", driver);
            driver.switchTo().frame(frameid);
        }

    }

    @Test(dataProvider = "specialCharacterData")
    public void SearchBoxFieldsSpCharStarStartsWith_EntFlds(String spChar) throws Exception {
        TCID = "Search_Capability_16";
        TCName = "Verify that  in create/edit field page of workspace setup of calculated field,  in searchbox  search using '<search key>*' format and entering any special character(_,-,$,?) as search key only showing those fields whose name starts with the search key";
        int createFlag = 0, editFlag = 0;
        try {
            create();
            String searchKey = spChar;
            String searchKeyApp = searchKey + "*";
            int Flag = 1;
            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKeyApp);
            Thread.sleep(7000);
            List<WebElement> searchLink = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink) {
                String getField = Elem.getText();
                System.out.println(getField);

                if (getField.startsWith(searchKey.toUpperCase()) || getField.startsWith(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                createFlag = 1;
            }
            kovairentitiesfields.cancelButtonClick(driver);
        } catch (Exception e) {
            System.out.println(e.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Entities", "Fields", driver);
            driver.switchTo().frame(frameid);
        }
        try {
            edit();
            String searchKey = spChar;
            String searchKeyApp = searchKey + "*";
            int Flag = 1;
            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKeyApp);
            Thread.sleep(7000);
            List<WebElement> searchLink1 = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink1) {
                String getField = Elem.getText();
                System.out.println(getField);

                if (getField.startsWith(searchKey.toUpperCase()) || getField.startsWith(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                editFlag = 1;
            }
            kovairentitiesfields.editCancelButtonClick(driver);
            Thread.sleep(3000);
            kovairentitiesfields.editCancelButtonClick(driver);
            if (createFlag == 1 && editFlag == 1) {
                ExecutionStatus = "Passed";
            } else {
                ExecutionStatus = "Failed";
                if (createFlag == 0) {
                    ErrDesc = "Failed in create Step";
                } else {
                    ErrDesc = "Failed in edit Step";
                }
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Entities", "Fields", driver);
            driver.switchTo().frame(frameid);
        }

    }

    @Test
    public void SearchBoxFieldsLetterContains_EntFlds() throws Exception {
        TCID = "Search_Capability_17";
        TCName = "Verify that  in create/edit field page of workspace setup of calculated field,  in searchbox  search using '*<search key>*' format and entering any letters as search key only showing those fields whose name contains the search key";
        int createFlag = 0, editFlag = 0;
        try {
            create();
            String searchKey = "a";
            String searchKeyApp = "*" + searchKey + "*";
            int Flag = 1;
            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKeyApp);
            Thread.sleep(7000);
            List<WebElement> searchLink = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink) {
                String getField = Elem.getText();
                System.out.println(getField);

                if (getField.contains(searchKey.toUpperCase()) || getField.contains(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                createFlag = 1;
            }
            kovairentitiesfields.cancelButtonClick(driver);
        } catch (Exception e) {
            System.out.println(e.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Entities", "Fields", driver);
            driver.switchTo().frame(frameid);
        }
        try {
            edit();
            String searchKey = "a";
            String searchKeyApp = "*" + searchKey + "*";
            int Flag = 1;
            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKeyApp);
            Thread.sleep(7000);
            List<WebElement> searchLink1 = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink1) {
                String getField = Elem.getText();
                System.out.println(getField);

                if (getField.contains(searchKey.toUpperCase()) || getField.contains(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                editFlag = 1;
            }
            kovairentitiesfields.editCancelButtonClick(driver);
            Thread.sleep(3000);
            kovairentitiesfields.editCancelButtonClick(driver);
            if (createFlag == 1 && editFlag == 1) {
                ExecutionStatus = "Passed";
            } else {
                ExecutionStatus = "Failed";
                if (createFlag == 0) {
                    ErrDesc = "Failed in create Step";
                } else {
                    ErrDesc = "Failed in edit Step";
                }
            }
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Entities", "Fields", driver);
            driver.switchTo().frame(frameid);
        }

    }

    @Test
    public void SearchBoxFieldsDigitContains_EntFlds() throws Exception {
        TCID = "Search_Capability_18";
        TCName = "Verify that  in create/edit field page of workspace setup of calculated field, in searchbox  search using '*<search key>*' format and entering any digit as search key only showing those fields whose name contains the search key";
        int createFlag = 0, editFlag = 0;
        try {
            create();

            int Flag = 1;

            String searchKey = searchKeyNumeric("^.*[0-9]+.*$", "create");
            String searchKeyApp = "*" + searchKey + "*";

            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKeyApp);
            Thread.sleep(7000);
            List<WebElement> searchLink = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink) {
                String getField = Elem.getText();
                System.out.println(getField);

                if (getField.contains(searchKey.toUpperCase()) || getField.contains(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                createFlag = 1;
            }
            kovairentitiesfields.cancelButtonClick(driver);
        } catch (Exception e) {
            System.out.println(e.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Entities", "Fields", driver);
            driver.switchTo().frame(frameid);
        }
        try {
            edit();

            int Flag = 1;
            String searchKey = searchKeyNumeric("^.*[0-9]+.*$", "edit");

            String searchKeyApp = "*" + searchKey + "*";

            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKeyApp);
            Thread.sleep(7000);
            List<WebElement> searchLink1 = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink1) {
                String getField = Elem.getText();
                System.out.println(getField);

                if (getField.contains(searchKey.toUpperCase()) || getField.contains(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                editFlag = 1;
            }
            kovairentitiesfields.editCancelButtonClick(driver);
            Thread.sleep(3000);
            kovairentitiesfields.editCancelButtonClick(driver);
            if (createFlag == 1 && editFlag == 1) {
                ExecutionStatus = "Passed";
            } else {
                ExecutionStatus = "Failed";
                if (createFlag == 0) {
                    ErrDesc = "Failed in create Step";
                } else {
                    ErrDesc = "Failed in edit Step";
                }
            }
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Entities", "Fields", driver);
            driver.switchTo().frame(frameid);
        }

    }

    @Test(dataProvider = "specialCharacterData")
    public void SearchBoxFieldsSpCharContains_EntFlds(String spChar) throws Exception {
        TCID = "Search_Capability_19";
        TCName = "Verify that  in create/edit field page of workspace setup of calculated field,  in searchbox  search using '*<search key>*' format and entering any special character(-,_,?,$) as search key only showing those fields whose name contains the search key";
        int createFlag = 0, editFlag = 0;
        try {
            create();
            String searchKey = spChar;
            String searchKeyApp = "*" + searchKey + "*";
            int Flag = 1;
            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKeyApp);
            Thread.sleep(7000);
            List<WebElement> searchLink = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink) {
                String getField = Elem.getText();
                System.out.println(getField);

                if (getField.contains(searchKey.toUpperCase()) || getField.contains(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                createFlag = 1;
            }
            kovairentitiesfields.cancelButtonClick(driver);
        } catch (Exception e) {
            System.out.println(e.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Entities", "Fields", driver);
            driver.switchTo().frame(frameid);
        }
        try {
            edit();
            String searchKey = spChar;
            String searchKeyApp = "*" + searchKey + "*";
            int Flag = 1;
            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKeyApp);
            Thread.sleep(7000);
            List<WebElement> searchLink1 = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink1) {
                String getField = Elem.getText();
                System.out.println(getField);

                if (getField.contains(searchKey.toUpperCase()) || getField.contains(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                editFlag = 1;
            }
            kovairentitiesfields.editCancelButtonClick(driver);
            Thread.sleep(3000);
            kovairentitiesfields.editCancelButtonClick(driver);
            if (createFlag == 1 && editFlag == 1) {
                ExecutionStatus = "Passed";
            } else {
                ExecutionStatus = "Failed";
                if (createFlag == 0) {
                    ErrDesc = "Failed in create Step";
                } else {
                    ErrDesc = "Failed in edit Step";
                }
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Entities", "Fields", driver);
            driver.switchTo().frame(frameid);
        }

    }

    @Test
    public void SearchBoxFieldsLetterEndsWith_EntFlds() throws Exception {
        TCID = "Search_Capability_20";
        TCName = "Verify that  in create/edit field page of workspace setup of calculated field,  in searchbox  search using '*<search key>' format and entering any letters as search key only showing those fields whose name ends with the search key";
        int createFlag = 0, editFlag = 0;
        try {
            create();
            String searchKey = "a";
            String searchKeyApp = "*" + searchKey;
            int Flag = 1;
            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKeyApp);
            Thread.sleep(7000);
            List<WebElement> searchLink = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink) {
                String getField = Elem.getText();
                System.out.println(getField);

                if (getField.contains(searchKey.toUpperCase()) || getField.contains(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                createFlag = 1;
            }
            kovairentitiesfields.cancelButtonClick(driver);
        } catch (Exception e) {
            System.out.println(e.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Entities", "Fields", driver);
            driver.switchTo().frame(frameid);
        }
        try {
            edit();
            String searchKey = "a";
            String searchKeyApp = "*" + searchKey;
            int Flag = 1;
            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKeyApp);
            Thread.sleep(7000);
            List<WebElement> searchLink1 = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink1) {
                String getField = Elem.getText();
                System.out.println(getField);

                if (getField.contains(searchKey.toUpperCase()) || getField.contains(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                editFlag = 1;
            }
            kovairentitiesfields.editCancelButtonClick(driver);
            Thread.sleep(3000);
            kovairentitiesfields.editCancelButtonClick(driver);
            if (createFlag == 1 && editFlag == 1) {
                ExecutionStatus = "Passed";
            } else {
                ExecutionStatus = "Failed";
                if (createFlag == 0) {
                    ErrDesc = "Failed in create Step";
                } else {
                    ErrDesc = "Failed in edit Step";
                }
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Entities", "Fields", driver);
            driver.switchTo().frame(frameid);
        }
    }

    @Test
    public void SearchBoxFieldsDigitEndsWith_EntFlds() throws Exception {
        TCID = "Search_Capability_21";
        TCName = "Verify that  in create/edit field page of workspace setup of calculated field, in searchbox  search using '*<search key>' format and entering any digit as search key only showing those fields whose name ends with the search key";
        int createFlag = 0, editFlag = 0;
        try {
            create();

            int Flag = 1;
            String searchKey = searchKeyNumeric("^.*[0-9]+.*$", "create");

            String searchKeyApp = "*" + searchKey;

            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKeyApp);
            Thread.sleep(7000);
            List<WebElement> searchLink = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink) {
                String getField = Elem.getText();
                System.out.println(getField);

                if (getField.contains(searchKey.toUpperCase()) || getField.contains(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                createFlag = 1;
            }
            kovairentitiesfields.cancelButtonClick(driver);
        } catch (Exception e) {
            System.out.println(e.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Entities", "Fields", driver);
            driver.switchTo().frame(frameid);
        }
        try {
            edit();
            int Flag = 1;
            String searchKey = searchKeyNumeric("^.*[0-9]+.*$", "edit");

            String searchKeyApp = "*" + searchKey;

            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKeyApp);
            Thread.sleep(7000);
            List<WebElement> searchLink1 = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink1) {
                String getField = Elem.getText();
                System.out.println(getField);

                if (getField.contains(searchKey.toUpperCase()) || getField.contains(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                editFlag = 1;
            }
            kovairentitiesfields.editCancelButtonClick(driver);
            Thread.sleep(3000);
            kovairentitiesfields.editCancelButtonClick(driver);
            if (createFlag == 1 && editFlag == 1) {
                ExecutionStatus = "Passed";
            } else {
                ExecutionStatus = "Failed";
                if (createFlag == 0) {
                    ErrDesc = "Failed in create Step";
                } else {
                    ErrDesc = "Failed in edit Step";
                }
            }
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Entities", "Fields", driver);
            driver.switchTo().frame(frameid);
        }
    }

    @Test(dataProvider = "specialCharacterData")
    public void SearchBoxFieldsSpCharEndsWith_EntFlds(String spChar) throws Exception {
        TCID = "Search_Capability_22";
        TCName = "Verify that  in create/edit field page of workspace setup of calculated field,  in searchbox  search using '*<search key>' format and entering any special character(-,_,?,$) as search key only showing those fields whose name ends with the search key";
        int createFlag = 0, editFlag = 0;
        try {
            create();
            String searchKey = spChar;
            String searchKeyApp = "*" + searchKey;
            int Flag = 1;
            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKeyApp);
            Thread.sleep(7000);
            List<WebElement> searchLink = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink) {
                String getField = Elem.getText();
                System.out.println(getField);

                if (getField.contains(searchKey.toUpperCase()) || getField.contains(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                createFlag = 1;
            }
            kovairentitiesfields.cancelButtonClick(driver);
        } catch (Exception e) {
            System.out.println(e.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Entities", "Fields", driver);
            driver.switchTo().frame(frameid);
        }
        try {
            edit();
            String searchKey = spChar;
            String searchKeyApp = "*" + searchKey;
            int Flag = 1;
            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKeyApp);
            Thread.sleep(7000);
            List<WebElement> searchLink1 = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink1) {
                String getField = Elem.getText();
                System.out.println(getField);

                if (getField.contains(searchKey.toUpperCase()) || getField.contains(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                editFlag = 1;
            }
            kovairentitiesfields.editCancelButtonClick(driver);
            Thread.sleep(3000);
            kovairentitiesfields.editCancelButtonClick(driver);
            if (createFlag == 1 && editFlag == 1) {
                ExecutionStatus = "Passed";
            } else {
                ExecutionStatus = "Failed";
                if (createFlag == 0) {
                    ErrDesc = "Failed in create Step";
                } else {
                    ErrDesc = "Failed in edit Step";
                }
            }
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Entities", "Fields", driver);
            driver.switchTo().frame(frameid);
        }
    }

    @Test
    public void SearchBoxFieldsLetterStartsWithToContains_EntFlds() throws Exception {
        TCID = "Search_Capability_23";
        TCName = "Verify that  in create/edit field page of workspace setup of calculated field,  in searchbox  first search using '<search key>*' format and entering any letters as search key and then adding a '*' before search key  is changing the search result from  starts with to contains";
        int createFlag = 0, editFlag = 0;

        try {

            String searchKey = "a";
            String searchKeyApp = searchKey + "*";
            int Flag = 1;
            create();
            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKeyApp);
            Thread.sleep(7000);
            List<WebElement> searchLink = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink) {
                String getField = Elem.getText();

                if (getField.startsWith(searchKey.toUpperCase()) || getField.startsWith(searchKey)) {
                    Flag = 1;
                } else {

                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                kovairentitiesfields.searchTextBoxShiftLeft(driver, "*", searchKeyApp.length());
                Thread.sleep(7000);
                List<WebElement> searchLink1 = kovairentitiesfields.fieldListStarting(driver);

                Thread.sleep(4000);
                for (WebElement Elem : searchLink1) {
                    String getField = Elem.getText();
                    System.out.println(getField);

                    if (getField.contains(searchKey.toUpperCase()) || getField.contains(searchKey)) {
                        Flag = 1;
                    } else {
                        String nextField = searchLink.get(searchLink.indexOf(Elem) + 1).getText();
                        if (nextField.startsWith(getField + ".")) {
                            continue;
                        }
                        Flag = 0;
                        break;
                    }
                }
            }
            if (Flag == 1) {
                createFlag = 1;
            }
            kovairentitiesfields.cancelButtonClick(driver);
        } catch (Exception e) {
            System.out.println(e.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Entities", "Fields", driver);
            driver.switchTo().frame(frameid);
        }
        try {
            edit();
            String searchKey = "a";
            String searchKeyApp = searchKey + "*";
            int Flag = 1;
            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKeyApp);
            Thread.sleep(7000);
            List<WebElement> searchLink2 = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink2) {
                String getField = Elem.getText();

                if (getField.startsWith(searchKey.toUpperCase()) || getField.startsWith(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                kovairentitiesfields.searchTextBoxShiftLeft(driver, "*", searchKeyApp.length());
                Thread.sleep(7000);
                List<WebElement> searchLink1 = kovairentitiesfields.fieldListStarting(driver);

                Thread.sleep(4000);
                for (WebElement Elem : searchLink1) {
                    String getField = Elem.getText();
                    System.out.println(getField);

                    if (getField.contains(searchKey.toUpperCase()) || getField.contains(searchKey)) {
                        Flag = 1;
                    } else {
                        Flag = 0;
                        break;
                    }
                }
            }
            if (Flag == 1) {
                editFlag = 1;
            }

            kovairentitiesfields.editCancelButtonClick(driver);
            Thread.sleep(3000);
            kovairentitiesfields.editCancelButtonClick(driver);
            if (createFlag == 1 && editFlag == 1) {
                ExecutionStatus = "Passed";
            } else {
                ExecutionStatus = "Failed";
                if (createFlag == 0) {
                    ErrDesc = "Failed in create Step";
                } else {
                    ErrDesc = "Failed in edit Step";
                }
            }

        } catch (Exception e) {
            System.out.println(e.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Entities", "Fields", driver);
            driver.switchTo().frame(frameid);

        }

    }

    @Test
    public void SearchBoxFieldsDigitStartsWithToContains_EntFlds() throws Exception {
        TCID = "Search_Capability_24";
        TCName = "Verify that  in create/edit field page of workspace setup of calculated field,  in searchbox  first search using '<search key>*' format and entering any digits as search key and then adding a '*' before search key  is changing the search result from  starts with to contains";
        int createFlag = 0, editFlag = 0;

        try {

            int Flag = 1;
            create();

            String searchKey = searchKeyNumeric("^[0-9]+.*$", "create");

            String searchKeyApp = searchKey + "*";

            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKeyApp);
            Thread.sleep(7000);
            List<WebElement> searchLink = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink) {
                String getField = Elem.getText();

                if (getField.startsWith(searchKey.toUpperCase()) || getField.startsWith(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                kovairentitiesfields.searchTextBoxShiftLeft(driver, "*", searchKeyApp.length());
                Thread.sleep(7000);
                List<WebElement> searchLink1 = kovairentitiesfields.fieldListStarting(driver);

                Thread.sleep(4000);
                for (WebElement Elem : searchLink1) {
                    String getField = Elem.getText();
                    System.out.println(getField);

                    if (getField.contains(searchKey.toUpperCase()) || getField.contains(searchKey)) {
                        Flag = 1;
                    } else {
                        Flag = 0;
                        break;
                    }
                }
            }
            if (Flag == 1) {
                createFlag = 1;
            }
            kovairentitiesfields.cancelButtonClick(driver);
        } catch (Exception e) {
            System.out.println(e.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Entities", "Fields", driver);
            driver.switchTo().frame(frameid);
        }
        try {

            edit();
            int Flag = 1;
            String searchKey = searchKeyNumeric("^[0-9]+.*$", "edit");
            String searchKeyApp = searchKey + "*";

            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKeyApp);
            Thread.sleep(7000);
            List<WebElement> searchLink2 = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink2) {
                String getField = Elem.getText();

                if (getField.startsWith(searchKey.toUpperCase()) || getField.startsWith(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                kovairentitiesfields.searchTextBoxShiftLeft(driver, "*", searchKeyApp.length());
                Thread.sleep(7000);
                List<WebElement> searchLink1 = kovairentitiesfields.fieldListStarting(driver);

                Thread.sleep(4000);
                for (WebElement Elem : searchLink1) {
                    String getField = Elem.getText();
                    System.out.println(getField);

                    if (getField.contains(searchKey.toUpperCase()) || getField.contains(searchKey)) {
                        Flag = 1;
                    } else {
                        Flag = 0;
                        break;
                    }
                }
            }
            if (Flag == 1) {
                editFlag = 1;
            }

            kovairentitiesfields.editCancelButtonClick(driver);
            Thread.sleep(3000);
            kovairentitiesfields.editCancelButtonClick(driver);
            if (createFlag == 1 && editFlag == 1) {
                ExecutionStatus = "Passed";
            } else {
                ExecutionStatus = "Failed";
                if (createFlag == 0) {
                    ErrDesc = "Failed in create Step";
                } else {
                    ErrDesc = "Failed in edit Step";
                }
            }

        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Entities", "Fields", driver);
            driver.switchTo().frame(frameid);
        }
    }

    @Test
    public void SearchBoxFieldsLetterStartsWithToEndsWith_EntFlds() throws Exception {
        TCID = "Search_Capability_26";
        TCName = "Verify that  in create/edit field page of workspace setup of calculated field,  in searchbox  first search using '<search key>' format and entering any letters as search key and then adding a '*' before search key  is changing the search result from  starts with to ends  with";
        int createFlag = 0, editFlag = 0;

        try {

            String searchKey = "c";
            String searchKeyApp = searchKey;
            int Flag = 1;
            create();
            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKeyApp);
            Thread.sleep(7000);
            List<WebElement> searchLink = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink) {
                String getField = Elem.getText();

                if (getField.startsWith(searchKey.toUpperCase()) || getField.startsWith(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                kovairentitiesfields.searchTextBoxShiftLeft(driver, "*", searchKeyApp.length());
                Thread.sleep(7000);
                List<WebElement> searchLink1 = kovairentitiesfields.fieldListStarting(driver);

                Thread.sleep(4000);
                for (WebElement Elem : searchLink1) {
                    String getField = Elem.getText();
                    System.out.println(getField);

                    if (getField.contains(searchKey.toUpperCase()) || getField.contains(searchKey)) {
                        Flag = 1;
                    } else {
                        Flag = 0;
                        break;
                    }
                }
            }
            if (Flag == 1) {
                createFlag = 1;
            }
            kovairentitiesfields.cancelButtonClick(driver);
        } catch (Exception e) {
            System.out.println(e.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Entities", "Fields", driver);
            driver.switchTo().frame(frameid);
        }
        try {
            edit();
            String searchKey = "c";
            String searchKeyApp = searchKey;
            int Flag = 1;
            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKeyApp);
            Thread.sleep(7000);
            List<WebElement> searchLink2 = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink2) {
                String getField = Elem.getText();

                if (getField.startsWith(searchKey.toUpperCase()) || getField.startsWith(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                kovairentitiesfields.searchTextBoxShiftLeft(driver, "*", searchKeyApp.length());
                Thread.sleep(7000);
                List<WebElement> searchLink1 = kovairentitiesfields.fieldListStarting(driver);

                Thread.sleep(4000);
                for (WebElement Elem : searchLink1) {
                    String getField = Elem.getText();
                    System.out.println(getField);

                    if (getField.contains(searchKey.toUpperCase()) || getField.contains(searchKey)) {
                        Flag = 1;
                    } else {
                        Flag = 0;
                        break;
                    }
                }
            }
            if (Flag == 1) {
                editFlag = 1;
            }

            kovairentitiesfields.editCancelButtonClick(driver);
            Thread.sleep(3000);
            kovairentitiesfields.editCancelButtonClick(driver);
            if (createFlag == 1 && editFlag == 1) {
                ExecutionStatus = "Passed";
            } else {
                ExecutionStatus = "Failed";
                if (createFlag == 0) {
                    ErrDesc = "Failed in create Step";
                } else {
                    ErrDesc = "Failed in edit Step";
                }
            }

        } catch (Exception e) {
            System.out.println(e.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Entities", "Fields", driver);
            driver.switchTo().frame(frameid);
        }
    }

    @Test
    public void SearchBoxFieldsDigitStartsWithToEndsWith_EntFlds() throws Exception {
        TCID = "Search_Capability_27";
        TCName = "Verify that  in create/edit field page of workspace setup of calculated field,  in searchbox  first search using '<search key>' format and entering any digits as search key and then adding a '*' before search key  is changing the search result from  starts with to ends with";
        int createFlag = 0, editFlag = 0;

        try {

            int Flag = 1;
            create();
            String searchKey = searchKeyNumeric("^[0-9]+.*$", "create");
            String searchKeyApp = searchKey;

            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKeyApp);
            Thread.sleep(7000);
            List<WebElement> searchLink = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink) {
                String getField = Elem.getText();

                if (getField.startsWith(searchKey.toUpperCase()) || getField.startsWith(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                kovairentitiesfields.searchTextBoxShiftLeft(driver, "*", searchKeyApp.length());
                Thread.sleep(7000);
                List<WebElement> searchLink1 = kovairentitiesfields.fieldListStarting(driver);

                Thread.sleep(4000);
                for (WebElement Elem : searchLink1) {
                    String getField = Elem.getText();
                    System.out.println(getField);

                    if (getField.contains(searchKey.toUpperCase()) || getField.contains(searchKey)) {
                        Flag = 1;
                    } else {
                        Flag = 0;
                        break;
                    }
                }
            }
            if (Flag == 1) {
                createFlag = 1;
            }
            kovairentitiesfields.cancelButtonClick(driver);
        } catch (Exception e) {
            System.out.println(e.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Entities", "Fields", driver);
            driver.switchTo().frame(frameid);
        }
        try {
            edit();
            int Flag = 1;
            String searchKey = searchKeyNumeric("^[0-9]+.*$", "edit");
            String searchKeyApp = searchKey;
            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKeyApp);
            Thread.sleep(7000);
            List<WebElement> searchLink2 = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink2) {
                String getField = Elem.getText();

                if (getField.startsWith(searchKey.toUpperCase()) || getField.startsWith(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                kovairentitiesfields.searchTextBoxShiftLeft(driver, "*", searchKeyApp.length());
                Thread.sleep(7000);
                List<WebElement> searchLink1 = kovairentitiesfields.fieldListStarting(driver);

                Thread.sleep(4000);
                for (WebElement Elem : searchLink1) {
                    String getField = Elem.getText();
                    System.out.println(getField);

                    if (getField.contains(searchKey.toUpperCase()) || getField.contains(searchKey)) {
                        Flag = 1;
                    } else {
                        Flag = 0;
                        break;
                    }
                }
            }
            if (Flag == 1) {
                editFlag = 1;
            }

            kovairentitiesfields.editCancelButtonClick(driver);
            Thread.sleep(3000);
            kovairentitiesfields.editCancelButtonClick(driver);
            if (createFlag == 1 && editFlag == 1) {
                ExecutionStatus = "Passed";
            } else {
                ExecutionStatus = "Failed";
                if (createFlag == 0) {
                    ErrDesc = "Failed in create Step";
                } else {
                    ErrDesc = "Failed in edit Step";
                }
            }

        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Entities", "Fields", driver);
            driver.switchTo().frame(frameid);
        }
    }

    @Test(dataProvider = "specialCharacterData")
    public void SearchBoxFieldsSpCharStartsWithToEndsWith_EntFlds(String spChar) throws Exception {
        TCID = "Search_Capability_28";
        TCName = "Verify that  in create/edit field page of workspace setup of calculated field,  in searchbox  first search using '<search key>' format and entering any special character (-,_,$,?) as search key and then adding a '*' before search key  is changing the search result from  starts with to ends with";
        int createFlag = 0, editFlag = 0;

        try {

            String searchKey = spChar;
            String searchKeyApp = searchKey;
            int Flag = 1;
            create();
            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKeyApp);
            Thread.sleep(7000);
            List<WebElement> searchLink = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink) {
                String getField = Elem.getText();

                if (getField.startsWith(searchKey.toUpperCase()) || getField.startsWith(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                kovairentitiesfields.searchTextBoxShiftLeft(driver, "*", searchKeyApp.length());
                Thread.sleep(7000);
                List<WebElement> searchLink1 = kovairentitiesfields.fieldListStarting(driver);

                Thread.sleep(4000);
                for (WebElement Elem : searchLink1) {
                    String getField = Elem.getText();
                    System.out.println(getField);

                    if (getField.contains(searchKey.toUpperCase()) || getField.contains(searchKey)) {
                        Flag = 1;
                    } else {
                        Flag = 0;
                        break;
                    }
                }
            }
            if (Flag == 1) {
                createFlag = 1;
            }
            kovairentitiesfields.cancelButtonClick(driver);
        } catch (Exception e) {
            System.out.println(e.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Entities", "Fields", driver);
            driver.switchTo().frame(frameid);
        }
        try {
            edit();
            String searchKey = spChar;
            String searchKeyApp = searchKey;
            int Flag = 1;
            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKeyApp);
            Thread.sleep(7000);
            List<WebElement> searchLink2 = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink2) {
                String getField = Elem.getText();

                if (getField.startsWith(searchKey.toUpperCase()) || getField.startsWith(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                kovairentitiesfields.searchTextBoxShiftLeft(driver, "*", searchKeyApp.length());
                Thread.sleep(7000);
                List<WebElement> searchLink1 = kovairentitiesfields.fieldListStarting(driver);

                Thread.sleep(4000);
                for (WebElement Elem : searchLink1) {
                    String getField = Elem.getText();
                    System.out.println(getField);

                    if (getField.contains(searchKey.toUpperCase()) || getField.contains(searchKey)) {
                        Flag = 1;
                    } else {
                        Flag = 0;
                        break;
                    }
                }
            }
            if (Flag == 1) {
                editFlag = 1;
            }

            kovairentitiesfields.editCancelButtonClick(driver);
            Thread.sleep(3000);
            kovairentitiesfields.editCancelButtonClick(driver);
            if (createFlag == 1 && editFlag == 1) {
                ExecutionStatus = "Passed";
            } else {
                ExecutionStatus = "Failed";
                if (createFlag == 0) {
                    ErrDesc = "Failed in create Step";
                } else {
                    ErrDesc = "Failed in edit Step";
                }
            }

        } catch (Exception e) {
            System.out.println(e.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Entities", "Fields", driver);
            driver.switchTo().frame(frameid);
        }
    }

    @Test
    public void SearchBoxFieldsLetterContainsToStartsWith_EntFlds() throws Exception {
        TCID = "Search_Capability_29";
        TCName = "Verify that  in create/edit field page of workspace setup of calculated field,  in search box  first search using '*<search key>*' format and entering any letters as search key and then deleting  '*' at the beginning of the search key  is changing the search result from  contains to starts with";
        int createFlag = 0, editFlag = 0;

        try {

            String searchKey = "a";
            String searchKeyApp = "*" + searchKey + "*";
            int Flag = 1;
            create();
            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKeyApp);
            Thread.sleep(7000);
            List<WebElement> searchLink = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink) {
                String getField = Elem.getText();

                if (getField.contains(searchKey.toUpperCase()) || getField.contains(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                kovairentitiesfields.searchTextBoxDelete(driver, searchKeyApp.length());
                Thread.sleep(7000);
                List<WebElement> searchLink1 = kovairentitiesfields.fieldListStarting(driver);

                Thread.sleep(4000);
                for (WebElement Elem : searchLink1) {
                    String getField = Elem.getText();
                    System.out.println(getField);

                    if (getField.startsWith(searchKey.toUpperCase()) || getField.startsWith(searchKey)) {
                        Flag = 1;
                    } else {
                        Flag = 0;
                        break;
                    }
                }
            }
            if (Flag == 1) {
                createFlag = 1;
            }
            kovairentitiesfields.cancelButtonClick(driver);
        } catch (Exception e) {
            System.out.println(e.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Entities", "Fields", driver);
            driver.switchTo().frame(frameid);
        }
        try {
            edit();
            String searchKey = "a";
            String searchKeyApp = "*" + searchKey + "*";
            int Flag = 1;
            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKeyApp);
            Thread.sleep(7000);
            List<WebElement> searchLink2 = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink2) {
                String getField = Elem.getText();

                if (getField.contains(searchKey.toUpperCase()) || getField.contains(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                kovairentitiesfields.searchTextBoxDelete(driver, searchKeyApp.length());
                Thread.sleep(7000);
                List<WebElement> searchLink1 = kovairentitiesfields.fieldListStarting(driver);

                Thread.sleep(4000);
                for (WebElement Elem : searchLink1) {
                    String getField = Elem.getText();
                    System.out.println(getField);

                    if (getField.startsWith(searchKey.toUpperCase()) || getField.startsWith(searchKey)) {
                        Flag = 1;
                    } else {
                        Flag = 0;
                        break;
                    }
                }
            }
            if (Flag == 1) {
                editFlag = 1;
            }

            kovairentitiesfields.editCancelButtonClick(driver);
            Thread.sleep(3000);
            kovairentitiesfields.editCancelButtonClick(driver);
            if (createFlag == 1 && editFlag == 1) {
                ExecutionStatus = "Passed";
            } else {
                ExecutionStatus = "Failed";
                if (createFlag == 0) {
                    ErrDesc = "Failed in create Step";
                } else {
                    ErrDesc = "Failed in edit Step";
                }
            }

        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Entities", "Fields", driver);
            driver.switchTo().frame(frameid);
        }

    }

    @Test
    public void SearchBoxFieldsDigitContainsToStartsWith_EntFlds() throws Exception {
        TCID = "Search_Capability_30";
        TCName = "Verify that  in create/edit field page of workspace setup of calculated field,  in search box  first search using '*<search key>*' format and entering any digits as search key and then deleting  '*' at the beginning of the search key  is changing the search result from  contains to starts with";
        int createFlag = 0, editFlag = 0;

        try {

            int Flag = 1;
            create();
            String searchKey = searchKeyNumeric("^.*[0-9]+.*$", "create");

            String searchKeyApp = "*" + searchKey + "*";
            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKeyApp);
            Thread.sleep(7000);
            List<WebElement> searchLink = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink) {
                String getField = Elem.getText();

                if (getField.contains(searchKey.toUpperCase()) || getField.contains(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                kovairentitiesfields.searchTextBoxDelete(driver, searchKeyApp.length());
                Thread.sleep(7000);
                List<WebElement> searchLink1 = kovairentitiesfields.fieldListStarting(driver);

                Thread.sleep(4000);
                for (WebElement Elem : searchLink1) {
                    String getField = Elem.getText();
                    System.out.println(getField);

                    if (getField.startsWith(searchKey.toUpperCase()) || getField.startsWith(searchKey)) {
                        Flag = 1;
                    } else {
                        Flag = 0;
                        break;
                    }
                }
            }
            if (Flag == 1) {
                createFlag = 1;
            }
            kovairentitiesfields.cancelButtonClick(driver);
        } catch (Exception e) {
            System.out.println(e.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Entities", "Fields", driver);
            driver.switchTo().frame(frameid);
        }
        try {
            edit();
            int Flag = 1;

            String searchKey = searchKeyNumeric("^.*[0-9]+.*$", "edit");

            String searchKeyApp = "*" + searchKey + "*";
            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKeyApp);
            Thread.sleep(7000);
            List<WebElement> searchLink2 = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink2) {
                String getField = Elem.getText();

                if (getField.contains(searchKey.toUpperCase()) || getField.contains(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                kovairentitiesfields.searchTextBoxDelete(driver, searchKeyApp.length());
                Thread.sleep(7000);
                List<WebElement> searchLink1 = kovairentitiesfields.fieldListStarting(driver);

                Thread.sleep(4000);
                for (WebElement Elem : searchLink1) {
                    String getField = Elem.getText();
                    System.out.println(getField);

                    if (getField.startsWith(searchKey.toUpperCase()) || getField.startsWith(searchKey)) {
                        Flag = 1;
                    } else {
                        Flag = 0;
                        break;
                    }
                }
            }
            if (Flag == 1) {
                editFlag = 1;
            }

            kovairentitiesfields.editCancelButtonClick(driver);
            Thread.sleep(3000);
            kovairentitiesfields.editCancelButtonClick(driver);
            if (createFlag == 1 && editFlag == 1) {
                ExecutionStatus = "Passed";
            } else {
                ExecutionStatus = "Failed";
                if (createFlag == 0) {
                    ErrDesc = "Failed in create Step";
                } else {
                    ErrDesc = "Failed in edit Step";
                }
            }

        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Entities", "Fields", driver);
            driver.switchTo().frame(frameid);
        }

    }

    @Test(dataProvider = "specialCharacterData")
    public void SearchBoxFieldsSpCharContainsToStartsWith_EntFlds(String spChar) throws Exception {
        TCID = "Search_Capability_31";
        TCName = "Verify that  in create/edit field page of workspace setup of calculated field,  in search box  first search using '*<search key>*' format and entering any special characters(-,_,?,$) as search key and then deleting  '*' at the beginning of the search key  is changing the search result from  contains to starts with";
        int createFlag = 0, editFlag = 0;

        try {

            String searchKey = spChar;
            String searchKeyApp = "*" + searchKey + "*";
            int Flag = 1;
            create();
            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKeyApp);
            Thread.sleep(7000);
            List<WebElement> searchLink = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink) {
                String getField = Elem.getText();

                if (getField.contains(searchKey.toUpperCase()) || getField.contains(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                kovairentitiesfields.searchTextBoxDelete(driver, searchKeyApp.length());
                Thread.sleep(7000);
                List<WebElement> searchLink1 = kovairentitiesfields.fieldListStarting(driver);

                Thread.sleep(4000);
                for (WebElement Elem : searchLink1) {
                    String getField = Elem.getText();
                    System.out.println(getField);

                    if (getField.startsWith(searchKey.toUpperCase()) || getField.startsWith(searchKey)) {
                        Flag = 1;
                    } else {
                        Flag = 0;
                        break;
                    }
                }
            }
            if (Flag == 1) {
                createFlag = 1;
            }
            kovairentitiesfields.cancelButtonClick(driver);
        } catch (Exception e) {
            System.out.println(e.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Entities", "Fields", driver);
            driver.switchTo().frame(frameid);
        }
        try {
            edit();
            String searchKey = spChar;
            String searchKeyApp = "*" + searchKey + "*";
            int Flag = 1;
            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKeyApp);
            Thread.sleep(7000);
            List<WebElement> searchLink2 = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink2) {
                String getField = Elem.getText();

                if (getField.contains(searchKey.toUpperCase()) || getField.contains(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                kovairentitiesfields.searchTextBoxDelete(driver, searchKeyApp.length());
                Thread.sleep(7000);
                List<WebElement> searchLink1 = kovairentitiesfields.fieldListStarting(driver);

                Thread.sleep(4000);
                for (WebElement Elem : searchLink1) {
                    String getField = Elem.getText();
                    System.out.println(getField);

                    if (getField.startsWith(searchKey.toUpperCase()) || getField.startsWith(searchKey)) {
                        Flag = 1;
                    } else {
                        Flag = 0;
                        break;
                    }
                }
            }
            if (Flag == 1) {
                editFlag = 1;
            }

            kovairentitiesfields.editCancelButtonClick(driver);
            Thread.sleep(3000);
            kovairentitiesfields.editCancelButtonClick(driver);
            if (createFlag == 1 && editFlag == 1) {
                ExecutionStatus = "Passed";
            } else {
                ExecutionStatus = "Failed";
                if (createFlag == 0) {
                    ErrDesc = "Failed in create Step";
                } else {
                    ErrDesc = "Failed in edit Step";
                }
            }

        } catch (Exception e) {
            System.out.println(e.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Entities", "Fields", driver);
            driver.switchTo().frame(frameid);
        }
    }

    @Test
    public void SearchBoxFieldsLetterContainsToEndsWith_EntFlds() throws Exception {
        TCID = "Search_Capability_32";
        TCName = "Verify that  in create/edit field page of workspace setup of calculated field,  in search box  first search using '*<search key>*' format and entering any letters as search key and then deleting  '*' at the ending of the search key  is changing the search result from  contains to ends with";
        int createFlag = 0, editFlag = 0;

        try {

            String searchKey = "a";
            String searchKeyApp = "*" + searchKey + "*";
            int Flag = 1;
            create();
            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKeyApp);
            Thread.sleep(7000);
            List<WebElement> searchLink = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink) {
                String getField = Elem.getText();

                if (getField.contains(searchKey.toUpperCase()) || getField.contains(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                kovairentitiesfields.searchTextBoxDeleteEnd(driver);
                Thread.sleep(7000);
                List<WebElement> searchLink1 = kovairentitiesfields.fieldListStarting(driver);

                Thread.sleep(4000);
                for (WebElement Elem : searchLink1) {
                    String getField = Elem.getText();
                    System.out.println(getField);

                    if (getField.contains(searchKey.toUpperCase()) || getField.contains(searchKey)) {
                        Flag = 1;
                    } else {
                        Flag = 0;
                        break;
                    }
                }
            }
            if (Flag == 1) {
                createFlag = 1;
            }
            kovairentitiesfields.cancelButtonClick(driver);
        } catch (Exception e) {
            System.out.println(e.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Entities", "Fields", driver);
            driver.switchTo().frame(frameid);
        }
        try {
            edit();
            String searchKey = "a";
            String searchKeyApp = "*" + searchKey + "*";
            int Flag = 1;
            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKeyApp);
            Thread.sleep(7000);
            List<WebElement> searchLink2 = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink2) {
                String getField = Elem.getText();

                if (getField.contains(searchKey.toUpperCase()) || getField.contains(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                kovairentitiesfields.searchTextBoxDeleteEnd(driver);
                Thread.sleep(7000);
                List<WebElement> searchLink1 = kovairentitiesfields.fieldListStarting(driver);

                Thread.sleep(4000);
                for (WebElement Elem : searchLink1) {
                    String getField = Elem.getText();
                    System.out.println(getField);

                    if (getField.contains(searchKey.toUpperCase()) || getField.contains(searchKey)) {
                        Flag = 1;
                    } else {
                        Flag = 0;
                        break;
                    }
                }
            }
            if (Flag == 1) {
                editFlag = 1;
            }

            kovairentitiesfields.editCancelButtonClick(driver);
            Thread.sleep(3000);
            kovairentitiesfields.editCancelButtonClick(driver);
            if (createFlag == 1 && editFlag == 1) {
                ExecutionStatus = "Passed";
            } else {
                ExecutionStatus = "Failed";
                if (createFlag == 0) {
                    ErrDesc = "Failed in create Step";
                } else {
                    ErrDesc = "Failed in edit Step";
                }
            }

        } catch (Exception e) {
            System.out.println(e.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Entities", "Fields", driver);
            driver.switchTo().frame(frameid);
        }
    }

    @Test
    public void SearchBoxFieldsDigitContainsToEndsWith_EntFlds() throws Exception {
        TCID = "Search_Capability_33";
        TCName = "Verify that  in create/edit field page of workspace setup of calculated field,  in search box  first search using '*<search key>*' format and entering any digits as search key and then deleting  '*' at the ending of the search key  is changing the search result from  contains to ends with";
        int createFlag = 0, editFlag = 0;

        try {

            int Flag = 1;
            create();

            String searchKey = searchKeyNumeric("^.*[0-9]+.*$", "create");

            String searchKeyApp = "*" + searchKey + "*";

            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKeyApp);
            Thread.sleep(7000);
            List<WebElement> searchLink = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink) {
                String getField = Elem.getText();

                if (getField.contains(searchKey.toUpperCase()) || getField.contains(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                kovairentitiesfields.searchTextBoxDeleteEnd(driver);
                Thread.sleep(7000);
                List<WebElement> searchLink1 = kovairentitiesfields.fieldListStarting(driver);

                Thread.sleep(4000);
                for (WebElement Elem : searchLink1) {
                    String getField = Elem.getText();
                    System.out.println(getField);

                    if (getField.contains(searchKey.toUpperCase()) || getField.contains(searchKey)) {
                        Flag = 1;
                    } else {
                        Flag = 0;
                        break;
                    }
                }
            }
            if (Flag == 1) {
                createFlag = 1;
            }
            kovairentitiesfields.cancelButtonClick(driver);
        } catch (Exception e) {
            System.out.println(e.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Entities", "Fields", driver);
            driver.switchTo().frame(frameid);
        }
        try {
            edit();
            int Flag = 1;

            String searchKey = searchKeyNumeric("^.*[0-9]+.*$", "edit");

            String searchKeyApp = "*" + searchKey + "*";
            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKeyApp);
            Thread.sleep(7000);
            List<WebElement> searchLink2 = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink2) {
                String getField = Elem.getText();

                if (getField.contains(searchKey.toUpperCase()) || getField.contains(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                kovairentitiesfields.searchTextBoxDeleteEnd(driver);
                Thread.sleep(7000);
                List<WebElement> searchLink1 = kovairentitiesfields.fieldListStarting(driver);

                Thread.sleep(4000);
                for (WebElement Elem : searchLink1) {
                    String getField = Elem.getText();
                    System.out.println(getField);

                    if (getField.contains(searchKey.toUpperCase()) || getField.contains(searchKey)) {
                        Flag = 1;
                    } else {
                        Flag = 0;
                        break;
                    }
                }
            }
            if (Flag == 1) {
                editFlag = 1;
            }

            kovairentitiesfields.editCancelButtonClick(driver);
            Thread.sleep(3000);
            kovairentitiesfields.editCancelButtonClick(driver);
            if (createFlag == 1 && editFlag == 1) {
                ExecutionStatus = "Passed";
            } else {
                ExecutionStatus = "Failed";
                if (createFlag == 0) {
                    ErrDesc = "Failed in create Step";
                } else {
                    ErrDesc = "Failed in edit Step";
                }
            }

        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Entities", "Fields", driver);
            driver.switchTo().frame(frameid);
        }
    }

    @Test(dataProvider = "specialCharacterData")
    public void SearchBoxFieldsSpCharContainsToEndsWith_EntFlds(String spChar) throws Exception {
        TCID = "Search_Capability_34";
        TCName = "Verify that  in create/edit field page of workspace setup of calculated field,  in search box  first search using '*<search key>*' format and entering any special characters(-,_,?,$) as search key and then deleting  '*' at the ending of the search key  is changing the search result from  contains to ends with";
        int createFlag = 0, editFlag = 0;

        try {

            String searchKey = spChar;
            String searchKeyApp = "*" + searchKey + "*";
            int Flag = 1;
            create();
            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKeyApp);
            Thread.sleep(7000);
            List<WebElement> searchLink = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink) {
                String getField = Elem.getText();

                if (getField.contains(searchKey.toUpperCase()) || getField.contains(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                kovairentitiesfields.searchTextBoxDeleteEnd(driver);
                Thread.sleep(7000);
                List<WebElement> searchLink1 = kovairentitiesfields.fieldListStarting(driver);

                Thread.sleep(4000);
                for (WebElement Elem : searchLink1) {
                    String getField = Elem.getText();
                    System.out.println(getField);

                    if (getField.contains(searchKey.toUpperCase()) || getField.contains(searchKey)) {
                        Flag = 1;
                    } else {
                        Flag = 0;
                        break;
                    }
                }
            }
            if (Flag == 1) {
                createFlag = 1;
            }
            kovairentitiesfields.cancelButtonClick(driver);
        } catch (Exception e) {
            System.out.println(e.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Entities", "Fields", driver);
            driver.switchTo().frame(frameid);
        }
        try {
            edit();
            String searchKey = spChar;
            String searchKeyApp = "*" + searchKey + "*";
            int Flag = 1;
            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKeyApp);
            Thread.sleep(7000);
            List<WebElement> searchLink2 = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink2) {
                String getField = Elem.getText();

                if (getField.contains(searchKey.toUpperCase()) || getField.contains(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                kovairentitiesfields.searchTextBoxDeleteEnd(driver);
                Thread.sleep(7000);
                List<WebElement> searchLink1 = kovairentitiesfields.fieldListStarting(driver);

                Thread.sleep(4000);
                for (WebElement Elem : searchLink1) {
                    String getField = Elem.getText();
                    System.out.println(getField);

                    if (getField.contains(searchKey.toUpperCase()) || getField.contains(searchKey)) {
                        Flag = 1;
                    } else {
                        Flag = 0;
                        break;
                    }
                }
            }
            if (Flag == 1) {
                editFlag = 1;
            }

            kovairentitiesfields.editCancelButtonClick(driver);
            Thread.sleep(3000);
            kovairentitiesfields.editCancelButtonClick(driver);
            if (createFlag == 1 && editFlag == 1) {
                ExecutionStatus = "Passed";
            } else {
                ExecutionStatus = "Failed";
                if (createFlag == 0) {
                    ErrDesc = "Failed in create Step";
                } else {
                    ErrDesc = "Failed in edit Step";
                }
            }

        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Entities", "Fields", driver);
            driver.switchTo().frame(frameid);
        }
    }

    @Test
    public void SearchBoxVisible_SharedFlds() throws Exception {
        TCID = "Search_Capability_35";
        TCName = "Verify that in create/edit field page of shared calculated field, searchbox  of  expression builder is visible ";
        int createFlag = 0, editFlag = 0;

        try {
            create();
            Thread.sleep(4000);
            if (kovairentitiesfields.searchTextBox(driver) == true) {
                createFlag = 1;
            }
            kovairentitiesfields.cancelButtonClick(driver);
        } catch (Exception e) {
            System.out.println(e.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Shared", "Fields", driver);
            driver.switchTo().frame(frameid);
        }
        try {
            edit();
            Thread.sleep(4000);
            if (kovairentitiesfields.searchTextBox(driver) == true) {
                editFlag = 1;
            }
            kovairentitiesfields.editCancelButtonClick(driver);
            Thread.sleep(3000);
            kovairentitiesfields.editCancelButtonClick(driver);

            if (createFlag == 1 && editFlag == 1) {
                ExecutionStatus = "Passed";
            } else {
                ExecutionStatus = "Failed";
                if (createFlag == 0) {
                    ErrDesc = "Failed in create Step";
                } else {
                    ErrDesc = "Failed in edit Step";
                }
            }

        } catch (Exception e) {
            System.out.println(e.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Shared", "Fields", driver);
            driver.switchTo().frame(frameid);
        }
    }

    @Test
    public void SearchBoxBorderPresent_SharedFlds() throws Exception {
        TCID = "Search_Capability_36";
        TCName = "Verify that in create/edit field page of shared calculated field, searchbox  of  expression builder has a border around it";
        int createFlag = 0, editFlag = 0;

        try {
            create();
            if (kovairentitiesfields.searchTextBoxBorder(driver)) //form-control class contains border element
            {
                createFlag = 1;
            }
            kovairentitiesfields.cancelButtonClick(driver);
        } catch (Exception e) {
            System.out.println(e.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Shared", "Fields", driver);
            driver.switchTo().frame(frameid);
        }
        try {
            edit();
            Thread.sleep(4000);
            if (kovairentitiesfields.searchTextBoxBorder(driver)) {
                editFlag = 1;
            }
            kovairentitiesfields.editCancelButtonClick(driver);
            Thread.sleep(3000);
            kovairentitiesfields.editCancelButtonClick(driver);

            if (createFlag == 1 && editFlag == 1) {
                ExecutionStatus = "Passed";
            } else {
                ExecutionStatus = "Failed";
                if (createFlag == 0) {
                    ErrDesc = "Failed in create Step";
                } else {
                    ErrDesc = "Failed in edit Step";
                }
            }

        } catch (Exception e) {
            System.out.println(e.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Shared", "Fields", driver);
            driver.switchTo().frame(frameid);

        }
    }

    @Test
    public void SearchBoxPlaceholderPresent_SharedFlds() throws Exception {
        TCID = "Search_Capability_37";
        TCName = "Verify that in create/edit field page of shared calculated field, searchbox  of  expression builder has a placeholder";
        int createFlag = 0, editFlag = 0;

        try {
            create();
            if (kovairentitiesfields.searchTextBoxPlaceholder(driver).equals("Search for...")) {
                createFlag = 1;
            }
            kovairentitiesfields.cancelButtonClick(driver);
        } catch (Exception e) {
            System.out.println(e.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Shared", "Fields", driver);
            driver.switchTo().frame(frameid);
        }
        try {
            edit();
            Thread.sleep(4000);
            if (kovairentitiesfields.searchTextBoxPlaceholder(driver).equals("Search for...")) {
                editFlag = 1;
            }
            kovairentitiesfields.editCancelButtonClick(driver);
            Thread.sleep(3000);
            kovairentitiesfields.editCancelButtonClick(driver);

            if (createFlag == 1 && editFlag == 1) {
                ExecutionStatus = "Passed";
            } else {
                ExecutionStatus = "Failed";
                if (createFlag == 0) {
                    ErrDesc = "Failed in create Step";
                } else {
                    ErrDesc = "Failed in edit Step";
                }
            }

        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Shared", "Fields", driver);
            driver.switchTo().frame(frameid);
        }

    }

    @Test
    public void SearchBoxBorderColor_SharedFlds() throws Exception {
        TCID = "Search_Capability_38";
        TCName = "Verify that in create/edit field page of shared calculated field, border color of searchbox  of  expression builder is grey";
        // System.out.println(kovairentitiesfields.searchTextBoxBorderColor(driver));
        int createFlag = 0, editFlag = 0;
        try {
            create();
            System.out.println(kovairentitiesfields.searchTextBoxBorderColor(driver));

            if (kovairentitiesfields.searchTextBoxBorderColor(driver).equals("rgb(204, 204, 204)")) {
                createFlag = 1;
            }
            kovairentitiesfields.cancelButtonClick(driver);
        } catch (Exception e) {
            System.out.println(e.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Shared", "Fields", driver);
            driver.switchTo().frame(frameid);
        }

        try {
            edit();
            Thread.sleep(4000);
            if (kovairentitiesfields.searchTextBoxBorderColor(driver).equals("rgb(204, 204, 204)")) {
                editFlag = 1;
            }
            kovairentitiesfields.editCancelButtonClick(driver);
            Thread.sleep(3000);
            kovairentitiesfields.editCancelButtonClick(driver);

            if (createFlag == 1 && editFlag == 1) {
                ExecutionStatus = "Passed";
            } else {
                ExecutionStatus = "Failed";
                if (createFlag == 0) {
                    ErrDesc = "Failed in create Step";
                } else {
                    ErrDesc = "Failed in edit Step";
                }
            }
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Shared", "Fields", driver);
            driver.switchTo().frame(frameid);
        }

    }

    @Test
    public void SearchBoxPlaceholderColor_SharedFlds() throws Exception {
        TCID = "Search_Capability_39";
        TCName = "Verify that in create/edit field page of shared calculated field,  placeholder of searchbox  of  expression builder is grey in color";
        // System.out.println(kovairentitiesfields.searchTextBoxBorderColor(driver));
        int createFlag = 0, editFlag = 0;
        try {
            create();
            System.out.println(kovairentitiesfields.findFilterSearchPlaceHolderColor(driver));

            if (kovairentitiesfields.findFilterSearchPlaceHolderColor(driver).equalsIgnoreCase("rgb(85, 85, 85)")) {
                createFlag = 1;
            }
            kovairentitiesfields.cancelButtonClick(driver);
        } catch (Exception e) {
            System.out.println(e.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Shared", "Fields", driver);
            driver.switchTo().frame(frameid);
        }

        try {
            edit();
            Thread.sleep(4000);
            if (kovairentitiesfields.findFilterSearchPlaceHolderColor(driver).equalsIgnoreCase("rgb(85, 85, 85)")) {
                editFlag = 1;
            }
            kovairentitiesfields.editCancelButtonClick(driver);
            Thread.sleep(3000);
            kovairentitiesfields.editCancelButtonClick(driver);

            if (createFlag == 1 && editFlag == 1) {
                ExecutionStatus = "Passed";
            } else {
                ExecutionStatus = "Failed";
                if (createFlag == 0) {
                    ErrDesc = "Failed in create Step";
                } else {
                    ErrDesc = "Failed in edit Step";
                }
            }
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Shared", "Fields", driver);
            driver.switchTo().frame(frameid);
        }

    }

    @Test
    public void SearchBoxBorderColorChange_SharedFlds() throws Exception {
        TCID = "Search_Capability_40";
        TCName = "Verify that in create/edit field page of shared calculated field, clicking in the searchbox  of  expression builder changes the box border color to blue";
        int createFlag = 0, editFlag = 0;

        try {
            create();
            kovairentitiesfields.searchTextBoxClick(driver);
            System.out.println(kovairentitiesfields.searchTextBoxBorderColor(driver));
            Thread.sleep(15000);
            if (kovairentitiesfields.searchTextBoxBorderColor(driver).equalsIgnoreCase("rgb(102, 175, 233)")) {
                createFlag = 1;
            }
            kovairentitiesfields.cancelButtonClick(driver);
        } catch (Exception e) {
            System.out.println(e.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Shared", "Fields", driver);
            driver.switchTo().frame(frameid);
        }

        try {
            edit();
            Thread.sleep(4000);
            kovairentitiesfields.searchTextBoxClick(driver);
            System.out.println(kovairentitiesfields.searchTextBoxBorderColor(driver));
            Thread.sleep(15000);
            if (kovairentitiesfields.searchTextBoxBorderColor(driver).equalsIgnoreCase("rgb(102, 175, 233)")) {
                editFlag = 1;
            }
            kovairentitiesfields.editCancelButtonClick(driver);
            Thread.sleep(3000);
            kovairentitiesfields.editCancelButtonClick(driver);

            if (createFlag == 1 && editFlag == 1) {
                ExecutionStatus = "Passed";
            } else {
                ExecutionStatus = "Failed";
                if (createFlag == 0) {
                    ErrDesc = "Failed in create Step";
                } else {
                    ErrDesc = "Failed in edit Step";
                }
            }
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Shared", "Fields", driver);
            driver.switchTo().frame(frameid);
        }

    }

    @Test
    public void SearchBoxPlaceholderBegin_SharedFlds() throws Exception {
        TCID = "Search_Capability_41";
        TCName = "Verify that in create/edit field page of shared calculated field,  the searchbox  of  expression builder placeholder starts from  the beginning of the searchbox";
        int createFlag = 0, editFlag = 0;

        try {
            create();
            if (kovairentitiesfields.searchTextBoxPlaceholder(driver).equals("Search for...")) {
                createFlag = 1;
            }
            kovairentitiesfields.cancelButtonClick(driver);
        } catch (Exception e) {
            System.out.println(e.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Shared", "Fields", driver);
            driver.switchTo().frame(frameid);
        }

        try {
            edit();
            Thread.sleep(4000);
            if (kovairentitiesfields.searchTextBoxPlaceholder(driver).equals("Search for...")) {
                editFlag = 1;
            }
            kovairentitiesfields.editCancelButtonClick(driver);
            Thread.sleep(3000);
            kovairentitiesfields.editCancelButtonClick(driver);

            if (createFlag == 1 && editFlag == 1) {
                ExecutionStatus = "Passed";
            } else {
                ExecutionStatus = "Failed";
                if (createFlag == 0) {
                    ErrDesc = "Failed in create Step";
                } else {
                    ErrDesc = "Failed in edit Step";
                }
            }
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Shared", "Fields", driver);
            driver.switchTo().frame(frameid);
        }

    }

    @Test
    public void SearchBoxPlaceholderRemoved_SharedFlds() throws Exception {
        TCID = "Search_Capability_42";
        TCName = "Verify that in create/edit field page of shared calculated field, typing in the searchbox  of  expression builder removing placeholder";
        int createFlag = 0, editFlag = 0;

        try {
            create();
            if (kovairentitiesfields.searchTextBoxPlaceholder(driver).equals("Search for...")) {
                createFlag = 1;
            }
            kovairentitiesfields.cancelButtonClick(driver);
        } catch (Exception e) {
            System.out.println(e.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Shared", "Fields", driver);
            driver.switchTo().frame(frameid);
        }

        try {
            edit();
            Thread.sleep(4000);
            if (kovairentitiesfields.searchTextBoxPlaceholder(driver).equals("Search for...")) {
                editFlag = 1;
            }
            kovairentitiesfields.editCancelButtonClick(driver);
            Thread.sleep(3000);
            kovairentitiesfields.editCancelButtonClick(driver);

            if (createFlag == 1 && editFlag == 1) {
                ExecutionStatus = "Passed";
            } else {
                ExecutionStatus = "Failed";
                if (createFlag == 0) {
                    ErrDesc = "Failed in create Step";
                } else {
                    ErrDesc = "Failed in edit Step";
                }
            }
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Shared", "Fields", driver);
            driver.switchTo().frame(frameid);
        }

    }

    @Test
    public void SearchBoxFieldSelected_SharedFlds() throws Exception {
        TCID = "Search_Capability_44";
        TCName = "Verify that  in create/edit field page of shared calculated field,  in searchbox if group fields are searched using * then single click on any of the group field can select the field";
        int createFlag = 0, editFlag = 0;

        try {

            create();
            String field;
            field = kovairentitiesfields.fieldListBox(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, field);
            kovairentitiesfields.expressionTextBoxFirst(driver);

            if (kovairentitiesfields.fieldSelected(driver)) {
                createFlag = 1;
            }
            kovairentitiesfields.cancelButtonClick(driver);
        } catch (Exception e) {
            System.out.println(e.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Shared", "Fields", driver);
            driver.switchTo().frame(frameid);
        }
        try {

            edit();
            Thread.sleep(4000);
            String field;
            field = kovairentitiesfields.fieldListBox(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, field);
            kovairentitiesfields.expressionTextBoxFirst(driver);

            if (kovairentitiesfields.fieldSelected(driver)) {
                editFlag = 1;
            }
            kovairentitiesfields.editCancelButtonClick(driver);
            Thread.sleep(3000);
            kovairentitiesfields.editCancelButtonClick(driver);

            if (createFlag == 1 && editFlag == 1) {
                ExecutionStatus = "Passed";
            } else {
                ExecutionStatus = "Failed";
                if (createFlag == 0) {
                    ErrDesc = "Failed in create Step";
                } else {
                    ErrDesc = "Failed in edit Step";
                }
            }
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Shared", "Fields", driver);
            driver.switchTo().frame(frameid);
        }

    }

    @Test
    public void SearchBoxFieldsLetterStartsWith_SharedFlds() throws Exception {
        TCID = "Search_Capability_45";
        TCName = "Verify that  in create/edit field page of shared calculated field,  in searchbox  search using '<search key>' format and entering any letters as search key only showing those fields whose name starts with the search key";
        int createFlag = 0, editFlag = 0;
        try {
            create();
            String searchKey = "a";
            int Flag = 1;

            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKey);
            Thread.sleep(7000);
            List<WebElement> searchLink = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink) {
                String getField = Elem.getText();
                System.out.println(getField);

                if (getField.startsWith(searchKey.toUpperCase()) || getField.startsWith(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                createFlag = 1;
            }
            kovairentitiesfields.cancelButtonClick(driver);
        } catch (Exception e) {
            System.out.println(e.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Shared", "Fields", driver);
            driver.switchTo().frame(frameid);
        }

        try {
            edit();
            String searchKey = "a";
            int Flag = 1;
            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKey);
            Thread.sleep(7000);
            List<WebElement> searchLink1 = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink1) {
                String getField = Elem.getText();
                System.out.println(getField);

                if (getField.startsWith(searchKey.toUpperCase()) || getField.startsWith(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                editFlag = 1;
            }
            kovairentitiesfields.editCancelButtonClick(driver);
            Thread.sleep(3000);
            kovairentitiesfields.editCancelButtonClick(driver);
            if (createFlag == 1 && editFlag == 1) {
                ExecutionStatus = "Passed";
            } else {
                ExecutionStatus = "Failed";
                if (createFlag == 0) {
                    ErrDesc = "Failed in create Step";
                } else {
                    ErrDesc = "Failed in edit Step";
                }
            }
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Shared", "Fields", driver);
            driver.switchTo().frame(frameid);
        }
    }

    @Test
    public void SearchBoxFieldsLetterStarStartsWith_SharedFlds() throws Exception {
        TCID = "Search_Capability_46";
        TCName = "Verify that  in create/edit field page of shared calculated field,  in searchbox  search using '<search key>*' format and entering any letters as search key only showing those fields whose name starts with the search key";
        int createFlag = 0, editFlag = 0;
        try {
            create();
            String searchKey = "a";
            String searchKeyApp = searchKey + "*";
            int Flag = 1;
            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKeyApp);
            Thread.sleep(7000);
            List<WebElement> searchLink = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink) {
                String getField = Elem.getText();
                System.out.println(getField);

                if (getField.startsWith(searchKey.toUpperCase()) || getField.startsWith(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                createFlag = 1;
            }
            kovairentitiesfields.cancelButtonClick(driver);
        } catch (Exception e) {
            System.out.println(e.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Shared", "Fields", driver);
            driver.switchTo().frame(frameid);
        }

        try {
            edit();
            String searchKey = "a";
            String searchKeyApp = searchKey + "*";
            int Flag = 1;
            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKeyApp);
            Thread.sleep(7000);
            List<WebElement> searchLink1 = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink1) {
                String getField = Elem.getText();
                System.out.println(getField);

                if (getField.startsWith(searchKey.toUpperCase()) || getField.startsWith(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                editFlag = 1;
            }
            kovairentitiesfields.editCancelButtonClick(driver);
            Thread.sleep(3000);
            kovairentitiesfields.editCancelButtonClick(driver);
            if (createFlag == 1 && editFlag == 1) {
                ExecutionStatus = "Passed";
            } else {
                ExecutionStatus = "Failed";
                if (createFlag == 0) {
                    ErrDesc = "Failed in create Step";
                } else {
                    ErrDesc = "Failed in edit Step";
                }
            }
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Shared", "Fields", driver);
            driver.switchTo().frame(frameid);
        }

    }

    @Test
    public void SearchBoxFieldsDigitStartsWith_SharedFlds() throws Exception {
        TCID = "Search_Capability_47";
        TCName = "Verify that  in create/edit field page of shared calculated field,  in searchbox  search using '<search key>' format and entering any digit as search key only showing those fields whose name starts with the search key";
        int createFlag = 0, editFlag = 0;

        try {
            create();

            int Flag = 1;

            String searchKey = searchKeyNumeric("^[0-9]+.*$", "create");

            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKey);
            Thread.sleep(7000);
            List<WebElement> searchLink = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink) {
                String getField = Elem.getText();
                System.out.println(getField);

                if (getField.startsWith(searchKey.toUpperCase()) || getField.startsWith(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                createFlag = 1;
            }
            kovairentitiesfields.cancelButtonClick(driver);
        } catch (Exception e) {
            System.out.println(e.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Shared", "Fields", driver);
            driver.switchTo().frame(frameid);
        }

        try {
            edit();

            int Flag = 1;
            String searchKey = searchKeyNumeric("^[0-9]+.*$", "edit");
            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKey);
            Thread.sleep(7000);
            List<WebElement> searchLink1 = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink1) {
                String getField = Elem.getText();
                System.out.println(getField);

                if (getField.startsWith(searchKey.toUpperCase()) || getField.startsWith(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                editFlag = 1;
            }
            kovairentitiesfields.editCancelButtonClick(driver);
            Thread.sleep(3000);
            kovairentitiesfields.editCancelButtonClick(driver);
            if (createFlag == 1 && editFlag == 1) {
                ExecutionStatus = "Passed";
            } else {
                ExecutionStatus = "Failed";
                if (createFlag == 0) {
                    ErrDesc = "Failed in create Step";
                } else {
                    ErrDesc = "Failed in edit Step";
                }
            }
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Shared", "Fields", driver);
            driver.switchTo().frame(frameid);
        }
    }

    @Test
    public void SearchBoxFieldsDigitStarStartsWith_SharedFlds() throws Exception {
        TCID = "Search_Capability_48";
        TCName = "Verify that  in create/edit field page of shared calculated field,  in searchbox  search using '<search key>*' format and entering any digit as search key only showing those fields whose name starts with the search key";
        int createFlag = 0, editFlag = 0;
        try {
            create();

            int Flag = 1;
            String searchKey = searchKeyNumeric("^[0-9]+.*$", "create");
            String searchKeyApp = searchKey + "*";
            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKeyApp);
            Thread.sleep(7000);
            List<WebElement> searchLink = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink) {
                String getField = Elem.getText();
                System.out.println(getField);

                if (getField.startsWith(searchKey.toUpperCase()) || getField.startsWith(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                createFlag = 1;
            }
            kovairentitiesfields.cancelButtonClick(driver);
        } catch (Exception e) {
            System.out.println(e.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Shared", "Fields", driver);
            driver.switchTo().frame(frameid);
        }

        try {
            edit();
            int Flag = 1;
            String searchKey = searchKeyNumeric("^[0-9]+.*$", "edit");
            String searchKeyApp = searchKey + "*";
            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKeyApp);
            Thread.sleep(7000);
            List<WebElement> searchLink1 = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink1) {
                String getField = Elem.getText();
                System.out.println(getField);

                if (getField.startsWith(searchKey.toUpperCase()) || getField.startsWith(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                editFlag = 1;
            }
            kovairentitiesfields.editCancelButtonClick(driver);
            Thread.sleep(3000);
            kovairentitiesfields.editCancelButtonClick(driver);
            if (createFlag == 1 && editFlag == 1) {
                ExecutionStatus = "Passed";
            } else {
                ExecutionStatus = "Failed";
                if (createFlag == 0) {
                    ErrDesc = "Failed in create Step";
                } else {
                    ErrDesc = "Failed in edit Step";
                }
            }
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Shared", "Fields", driver);
            driver.switchTo().frame(frameid);
        }
    }

    @Test(dataProvider = "specialCharacterData")
    public void SearchBoxFieldsSpCharStartsWith_SharedFlds(String spChar) throws Exception {
        TCID = "Search_Capability_49";
        TCName = "Verify that  in create/edit field page of shared calculated field,  in searchbox  search using '<search key>' format and entering any special character(_,-,$,?) as search key only showing those fields whose name starts with the search key";
        int createFlag = 0, editFlag = 0;

        try {
            create();
            String searchKey = spChar;
            int Flag = 1;
            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKey);
            Thread.sleep(7000);
            List<WebElement> searchLink = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink) {
                String getField = Elem.getText();
                System.out.println(getField);

                if (getField.startsWith(searchKey.toUpperCase()) || getField.startsWith(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                createFlag = 1;
            }
            kovairentitiesfields.cancelButtonClick(driver);
        } catch (Exception e) {
            System.out.println(e);
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Shared", "Fields", driver);
            driver.switchTo().frame(frameid);
        }

        try {
            edit();
            String searchKey = spChar;
            int Flag = 1;
            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKey);
            Thread.sleep(7000);
            List<WebElement> searchLink1 = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink1) {
                String getField = Elem.getText();
                System.out.println(getField);

                if (getField.startsWith(searchKey.toUpperCase()) || getField.startsWith(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                editFlag = 1;
            }
            kovairentitiesfields.editCancelButtonClick(driver);
            Thread.sleep(3000);
            kovairentitiesfields.editCancelButtonClick(driver);
            if (createFlag == 1 && editFlag == 1) {
                ExecutionStatus = "Passed";
            } else {
                ExecutionStatus = "Failed";
                if (createFlag == 0) {
                    ErrDesc = "Failed in create Step";
                } else {
                    ErrDesc = "Failed in edit Step";
                }
            }
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Shared", "Fields", driver);
            driver.switchTo().frame(frameid);
        }
    }

    @Test(dataProvider = "specialCharacterData")
    public void SearchBoxFieldsSpCharStarStartsWith_SharedFlds(String spChar) throws Exception {
        TCID = "Search_Capability_50";
        TCName = "Verify that  in create/edit field page of shared calculated field,  in searchbox  search using '<search key>*' format and entering any special character(_,-,$,?) as search key only showing those fields whose name starts with the search key";
        int createFlag = 0, editFlag = 0;
        try {
            create();
            String searchKey = spChar;
            String searchKeyApp = searchKey + "*";
            int Flag = 1;
            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKeyApp);
            Thread.sleep(7000);
            List<WebElement> searchLink = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink) {
                String getField = Elem.getText();
                System.out.println(getField);

                if (getField.startsWith(searchKey.toUpperCase()) || getField.startsWith(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                createFlag = 1;
            }
            kovairentitiesfields.cancelButtonClick(driver);
        } catch (Exception e) {
            System.out.println(e);
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Shared", "Fields", driver);
            driver.switchTo().frame(frameid);
        }

        try {
            edit();
            String searchKey = spChar;
            String searchKeyApp = searchKey + "*";
            int Flag = 1;
            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKeyApp);
            Thread.sleep(7000);
            List<WebElement> searchLink1 = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink1) {
                String getField = Elem.getText();
                System.out.println(getField);

                if (getField.startsWith(searchKey.toUpperCase()) || getField.startsWith(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                editFlag = 1;
            }
            kovairentitiesfields.editCancelButtonClick(driver);
            Thread.sleep(3000);
            kovairentitiesfields.editCancelButtonClick(driver);
            if (createFlag == 1 && editFlag == 1) {
                ExecutionStatus = "Passed";
            } else {
                ExecutionStatus = "Failed";
                if (createFlag == 0) {
                    ErrDesc = "Failed in create Step";
                } else {
                    ErrDesc = "Failed in edit Step";
                }
            }
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Shared", "Fields", driver);
            driver.switchTo().frame(frameid);
        }

    }

    @Test
    public void SearchBoxFieldsLetterContains_SharedFlds() throws Exception {
        TCID = "Search_Capability_51";
        TCName = "Verify that  in create/edit field page of shared calculated field,  in searchbox  search using '*<search key>*' format and entering any letters as search key only showing those fields whose name contains the search key";
        int createFlag = 0, editFlag = 0;
        try {
            create();
            String searchKey = "a";
            String searchKeyApp = "*" + searchKey + "*";
            int Flag = 1;
            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKeyApp);
            Thread.sleep(7000);
            List<WebElement> searchLink = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink) {
                String getField = Elem.getText();
                System.out.println(getField);

                if (getField.contains(searchKey.toUpperCase()) || getField.contains(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                createFlag = 1;
            }
            kovairentitiesfields.cancelButtonClick(driver);
        } catch (Exception e) {
            System.out.println(e);
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Shared", "Fields", driver);
            driver.switchTo().frame(frameid);
        }

        try {
            edit();
            String searchKey = "a";
            String searchKeyApp = "*" + searchKey + "*";
            int Flag = 1;
            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKeyApp);
            Thread.sleep(7000);
            List<WebElement> searchLink1 = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink1) {
                String getField = Elem.getText();
                System.out.println(getField);

                if (getField.contains(searchKey.toUpperCase()) || getField.contains(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                editFlag = 1;
            }
            kovairentitiesfields.editCancelButtonClick(driver);
            Thread.sleep(3000);
            kovairentitiesfields.editCancelButtonClick(driver);
            if (createFlag == 1 && editFlag == 1) {
                ExecutionStatus = "Passed";
            } else {
                ExecutionStatus = "Failed";
                if (createFlag == 0) {
                    ErrDesc = "Failed in create Step";
                } else {
                    ErrDesc = "Failed in edit Step";
                }
            }
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Shared", "Fields", driver);
            driver.switchTo().frame(frameid);
        }

    }

    @Test
    public void SearchBoxFieldsDigitContains_SharedFlds() throws Exception {
        TCID = "Search_Capability_52";
        TCName = "Verify that  in create/edit field page of shared calculated field, in searchbox  search using '*<search key>*' format and entering any digit as search key only showing those fields whose name contains the search key";
        int createFlag = 0, editFlag = 0;
        try {
            create();

            int Flag = 1;

            String searchKey = searchKeyNumeric("^.*[0-9]+.*$", "create");
            String searchKeyApp = "*" + searchKey + "*";

            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKeyApp);
            Thread.sleep(7000);
            List<WebElement> searchLink = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink) {
                String getField = Elem.getText();
                System.out.println(getField);

                if (getField.contains(searchKey.toUpperCase()) || getField.contains(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                createFlag = 1;
            }
            kovairentitiesfields.cancelButtonClick(driver);
        } catch (Exception e) {
            System.out.println(e);
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Shared", "Fields", driver);
            driver.switchTo().frame(frameid);
        }

        try {
            edit();

            int Flag = 1;

            String searchKey = searchKeyNumeric("^.*[0-9]+.*$", "edit");
            String searchKeyApp = "*" + searchKey + "*";
            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKeyApp);
            Thread.sleep(7000);
            List<WebElement> searchLink1 = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink1) {
                String getField = Elem.getText();
                System.out.println(getField);

                if (getField.contains(searchKey.toUpperCase()) || getField.contains(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                editFlag = 1;
            }
            kovairentitiesfields.editCancelButtonClick(driver);
            Thread.sleep(3000);
            kovairentitiesfields.editCancelButtonClick(driver);
            if (createFlag == 1 && editFlag == 1) {
                ExecutionStatus = "Passed";
            } else {
                ExecutionStatus = "Failed";
                if (createFlag == 0) {
                    ErrDesc = "Failed in create Step";
                } else {
                    ErrDesc = "Failed in edit Step";
                }
            }
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Shared", "Fields", driver);
            driver.switchTo().frame(frameid);
        }

    }

    @Test(dataProvider = "specialCharacterData")
    public void SearchBoxFieldsSpCharContains_SharedFlds(String spChar) throws Exception {
        TCID = "Search_Capability_53";
        TCName = "Verify that  in create/edit field page of shared calculated field,  in searchbox  search using '*<search key>*' format and entering any special character(-,_,?,$) as search key only showing those fields whose name contains the search key";
        int createFlag = 0, editFlag = 0;
        try {
            create();
            String searchKey = spChar;
            String searchKeyApp = "*" + searchKey + "*";
            int Flag = 1;
            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKeyApp);
            Thread.sleep(7000);
            List<WebElement> searchLink = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink) {
                String getField = Elem.getText();
                System.out.println(getField);

                if (getField.contains(searchKey.toUpperCase()) || getField.contains(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                createFlag = 1;
            }
            kovairentitiesfields.cancelButtonClick(driver);
        } catch (Exception e) {
            System.out.println(e);
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Shared", "Fields", driver);
            driver.switchTo().frame(frameid);
        }

        try {
            edit();
            String searchKey = spChar;
            String searchKeyApp = "*" + searchKey + "*";
            int Flag = 1;
            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKeyApp);
            Thread.sleep(7000);
            List<WebElement> searchLink1 = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink1) {
                String getField = Elem.getText();
                System.out.println(getField);

                if (getField.contains(searchKey.toUpperCase()) || getField.contains(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                editFlag = 1;
            }
            kovairentitiesfields.editCancelButtonClick(driver);
            Thread.sleep(3000);
            kovairentitiesfields.editCancelButtonClick(driver);
            if (createFlag == 1 && editFlag == 1) {
                ExecutionStatus = "Passed";
            } else {
                ExecutionStatus = "Failed";
                if (createFlag == 0) {
                    ErrDesc = "Failed in create Step";
                } else {
                    ErrDesc = "Failed in edit Step";
                }
            }
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Shared", "Fields", driver);
            driver.switchTo().frame(frameid);
        }

    }

    @Test
    public void SearchBoxFieldsLetterEndsWith_SharedFlds() throws Exception {
        TCID = "Search_Capability_54";
        TCName = "Verify that  in create/edit field page of shared calculated field,  in searchbox  search using '*<search key>' format and entering any letters as search key only showing those fields whose name ends with the search key";
        int createFlag = 0, editFlag = 0;
        try {
            create();
            String searchKey = "a";
            String searchKeyApp = "*" + searchKey;
            int Flag = 1;
            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKeyApp);
            Thread.sleep(7000);
            List<WebElement> searchLink = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink) {
                String getField = Elem.getText();
                System.out.println(getField);

                if (getField.contains(searchKey.toUpperCase()) || getField.contains(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                createFlag = 1;
            }
            kovairentitiesfields.cancelButtonClick(driver);
        } catch (Exception e) {
            System.out.println(e);
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Shared", "Fields", driver);
            driver.switchTo().frame(frameid);
        }

        try {
            edit();
            String searchKey = "a";
            String searchKeyApp = "*" + searchKey;
            int Flag = 1;
            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKeyApp);
            Thread.sleep(7000);
            List<WebElement> searchLink1 = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink1) {
                String getField = Elem.getText();
                System.out.println(getField);

                if (getField.contains(searchKey.toUpperCase()) || getField.contains(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                editFlag = 1;
            }
            kovairentitiesfields.editCancelButtonClick(driver);
            Thread.sleep(3000);
            kovairentitiesfields.editCancelButtonClick(driver);
            if (createFlag == 1 && editFlag == 1) {
                ExecutionStatus = "Passed";
            } else {
                ExecutionStatus = "Failed";
                if (createFlag == 0) {
                    ErrDesc = "Failed in create Step";
                } else {
                    ErrDesc = "Failed in edit Step";
                }
            }
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Shared", "Fields", driver);
            driver.switchTo().frame(frameid);
        }
    }

    @Test
    public void SearchBoxFieldsDigitEndsWith_SharedFlds() throws Exception {
        TCID = "Search_Capability_55";
        TCName = "Verify that  in create/edit field page of shared calculated field, in searchbox  search using '*<search key>' format and entering any digit as search key only showing those fields whose name ends with the search key";
        int createFlag = 0, editFlag = 0;
        try {
            create();

            int Flag = 1;
            String searchKey = searchKeyNumeric("^.*[0-9]+.*$", "create");
            String searchKeyApp = "*" + searchKey;

            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKeyApp);
            Thread.sleep(7000);
            List<WebElement> searchLink = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink) {
                String getField = Elem.getText();
                System.out.println(getField);

                if (getField.contains(searchKey.toUpperCase()) || getField.contains(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                createFlag = 1;
            }
            kovairentitiesfields.cancelButtonClick(driver);
        } catch (Exception e) {
            System.out.println(e);
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Shared", "Fields", driver);
            driver.switchTo().frame(frameid);
        }

        try {
            edit();
            int Flag = 1;
            String searchKey = searchKeyNumeric("^.*[0-9]+.*$", "edit");
            String searchKeyApp = "*" + searchKey;
            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKeyApp);
            Thread.sleep(7000);
            List<WebElement> searchLink1 = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink1) {
                String getField = Elem.getText();
                System.out.println(getField);

                if (getField.contains(searchKey.toUpperCase()) || getField.contains(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                editFlag = 1;
            }
            kovairentitiesfields.editCancelButtonClick(driver);
            Thread.sleep(3000);
            kovairentitiesfields.editCancelButtonClick(driver);
            if (createFlag == 1 && editFlag == 1) {
                ExecutionStatus = "Passed";
            } else {
                ExecutionStatus = "Failed";
                if (createFlag == 0) {
                    ErrDesc = "Failed in create Step";
                } else {
                    ErrDesc = "Failed in edit Step";
                }
            }
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Shared", "Fields", driver);
            driver.switchTo().frame(frameid);
        }
    }

    @Test(dataProvider = "specialCharacterData")
    public void SearchBoxFieldsSpCharEndsWith_SharedFlds(String spChar) throws Exception {
        TCID = "Search_Capability_56";
        TCName = "Verify that  in create/edit field page of shared calculated field,  in searchbox  search using '*<search key>' format and entering any special character(-,_,?,$) as search key only showing those fields whose name ends with the search key";
        int createFlag = 0, editFlag = 0;
        try {
            create();
            String searchKey = spChar;
            String searchKeyApp = "*" + searchKey;
            int Flag = 1;
            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKeyApp);
            Thread.sleep(7000);
            List<WebElement> searchLink = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink) {
                String getField = Elem.getText();
                System.out.println(getField);

                if (getField.contains(searchKey.toUpperCase()) || getField.contains(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                createFlag = 1;
            }
            kovairentitiesfields.cancelButtonClick(driver);
        } catch (Exception e) {
            System.out.println(e);
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Shared", "Fields", driver);
            driver.switchTo().frame(frameid);
        }

        try {
            edit();
            String searchKey = spChar;
            String searchKeyApp = "*" + searchKey;
            int Flag = 1;
            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKeyApp);
            Thread.sleep(7000);
            List<WebElement> searchLink1 = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink1) {
                String getField = Elem.getText();
                System.out.println(getField);

                if (getField.contains(searchKey.toUpperCase()) || getField.contains(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                editFlag = 1;
            }
            kovairentitiesfields.editCancelButtonClick(driver);
            Thread.sleep(3000);
            kovairentitiesfields.editCancelButtonClick(driver);
            if (createFlag == 1 && editFlag == 1) {
                ExecutionStatus = "Passed";
            } else {
                ExecutionStatus = "Failed";
                if (createFlag == 0) {
                    ErrDesc = "Failed in create Step";
                } else {
                    ErrDesc = "Failed in edit Step";
                }
            }
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Shared", "Fields", driver);
            driver.switchTo().frame(frameid);
        }
    }

    @Test
    public void SearchBoxFieldsLetterStartsWithToContains_SharedFlds() throws Exception {
        TCID = "Search_Capability_57";
        TCName = "Verify that  in create/edit field page of shared calculated field,  in searchbox  first search using '<search key>*' format and entering any letters as search key and then adding a '*' before search key  is changing the search result from  starts with to contains";
        int createFlag = 0, editFlag = 0;

        try {

            String searchKey = "a";
            String searchKeyApp = searchKey + "*";
            int Flag = 1;
            create();
            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKeyApp);
            Thread.sleep(7000);
            List<WebElement> searchLink = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink) {
                String getField = Elem.getText();

                if (getField.startsWith(searchKey.toUpperCase()) || getField.startsWith(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                kovairentitiesfields.searchTextBoxShiftLeft(driver, "*", searchKeyApp.length());
                Thread.sleep(7000);
                List<WebElement> searchLink1 = kovairentitiesfields.fieldListStarting(driver);

                Thread.sleep(4000);
                for (WebElement Elem : searchLink1) {
                    String getField = Elem.getText();
                    System.out.println(getField);

                    if (getField.contains(searchKey.toUpperCase()) || getField.contains(searchKey)) {
                        Flag = 1;
                    } else {
                        Flag = 0;
                        break;
                    }
                }
            }
            if (Flag == 1) {
                createFlag = 1;
            }
            kovairentitiesfields.cancelButtonClick(driver);
        } catch (Exception e) {
            System.out.println(e);
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Shared", "Fields", driver);
            driver.switchTo().frame(frameid);
        }

        try {
            edit();

            String searchKey = "a";
            String searchKeyApp = searchKey + "*";
            int Flag = 1;
            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKeyApp);
            Thread.sleep(7000);
            List<WebElement> searchLink2 = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink2) {
                String getField = Elem.getText();

                if (getField.startsWith(searchKey.toUpperCase()) || getField.startsWith(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                kovairentitiesfields.searchTextBoxShiftLeft(driver, "*", searchKeyApp.length());
                Thread.sleep(7000);
                List<WebElement> searchLink1 = kovairentitiesfields.fieldListStarting(driver);

                Thread.sleep(4000);
                for (WebElement Elem : searchLink1) {
                    String getField = Elem.getText();
                    System.out.println(getField);

                    if (getField.contains(searchKey.toUpperCase()) || getField.contains(searchKey)) {
                        Flag = 1;
                    } else {
                        Flag = 0;
                        break;
                    }
                }
            }
            if (Flag == 1) {
                editFlag = 1;
            }

            kovairentitiesfields.editCancelButtonClick(driver);
            Thread.sleep(3000);
            kovairentitiesfields.editCancelButtonClick(driver);
            if (createFlag == 1 && editFlag == 1) {
                ExecutionStatus = "Passed";
            } else {
                ExecutionStatus = "Failed";
                if (createFlag == 0) {
                    ErrDesc = "Failed in create Step";
                } else {
                    ErrDesc = "Failed in edit Step";
                }
            }

        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Shared", "Fields", driver);
            driver.switchTo().frame(frameid);
        }

    }

    @Test
    public void SearchBoxFieldsDigitStartsWithToContains_SharedFlds() throws Exception {
        TCID = "Search_Capability_58";
        TCName = "Verify that  in create/edit field page of shared calculated field,  in searchbox  first search using '<search key>*' format and entering any digits as search key and then adding a '*' before search key  is changing the search result from  starts with to contains";
        int createFlag = 0, editFlag = 0;

        try {

            int Flag = 1;
            create();
            String searchKey = searchKeyNumeric("^[0-9]+.*$", "create");
            String searchKeyApp = searchKey + "*";

            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKeyApp);
            Thread.sleep(7000);
            List<WebElement> searchLink = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink) {
                String getField = Elem.getText();

                if (getField.startsWith(searchKey.toUpperCase()) || getField.startsWith(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                kovairentitiesfields.searchTextBoxShiftLeft(driver, "*", searchKeyApp.length());
                Thread.sleep(7000);
                List<WebElement> searchLink1 = kovairentitiesfields.fieldListStarting(driver);

                Thread.sleep(4000);
                for (WebElement Elem : searchLink1) {
                    String getField = Elem.getText();
                    System.out.println(getField);

                    if (getField.contains(searchKey.toUpperCase()) || getField.contains(searchKey)) {
                        Flag = 1;
                    } else {
                        Flag = 0;
                        break;
                    }
                }
            }
            if (Flag == 1) {
                createFlag = 1;
            }
            kovairentitiesfields.cancelButtonClick(driver);
        } catch (Exception e) {
            System.out.println(e);
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Shared", "Fields", driver);
            driver.switchTo().frame(frameid);
        }

        try {
            edit();
            int Flag = 1;

            String searchKey = searchKeyNumeric("^[0-9]+.*$", "edit");
            String searchKeyApp = searchKey + "*";
            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKeyApp);
            Thread.sleep(7000);
            List<WebElement> searchLink2 = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink2) {
                String getField = Elem.getText();

                if (getField.startsWith(searchKey.toUpperCase()) || getField.startsWith(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                kovairentitiesfields.searchTextBoxShiftLeft(driver, "*", searchKeyApp.length());
                Thread.sleep(7000);
                List<WebElement> searchLink1 = kovairentitiesfields.fieldListStarting(driver);

                Thread.sleep(4000);
                for (WebElement Elem : searchLink1) {
                    String getField = Elem.getText();
                    System.out.println(getField);

                    if (getField.contains(searchKey.toUpperCase()) || getField.contains(searchKey)) {
                        Flag = 1;
                    } else {
                        Flag = 0;
                        break;
                    }
                }
            }
            if (Flag == 1) {
                editFlag = 1;
            }

            kovairentitiesfields.editCancelButtonClick(driver);
            Thread.sleep(3000);
            kovairentitiesfields.editCancelButtonClick(driver);
            if (createFlag == 1 && editFlag == 1) {
                ExecutionStatus = "Passed";
            } else {
                ExecutionStatus = "Failed";
                if (createFlag == 0) {
                    ErrDesc = "Failed in create Step";
                } else {
                    ErrDesc = "Failed in edit Step";
                }
            }

        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Shared", "Fields", driver);
            driver.switchTo().frame(frameid);
        }
    }

    @Test
    public void SearchBoxFieldsLetterStartsWithToEndsWith_SharedFlds() throws Exception {
        TCID = "Search_Capability_60";
        TCName = "Verify that  in create/edit field page of shared calculated field,  in searchbox  first search using '<search key>' format and entering any letters as search key and then adding a '*' before search key  is changing the search result from  starts with to ends  with";
        int createFlag = 0, editFlag = 0;

        try {

            String searchKey = "c";
            String searchKeyApp = searchKey;
            int Flag = 1;
            create();
            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKeyApp);
            Thread.sleep(7000);
            List<WebElement> searchLink = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink) {
                String getField = Elem.getText();

                if (getField.startsWith(searchKey.toUpperCase()) || getField.startsWith(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                kovairentitiesfields.searchTextBoxShiftLeft(driver, "*", searchKeyApp.length());
                Thread.sleep(7000);
                List<WebElement> searchLink1 = kovairentitiesfields.fieldListStarting(driver);

                Thread.sleep(4000);
                for (WebElement Elem : searchLink1) {
                    String getField = Elem.getText();
                    System.out.println(getField);

                    if (getField.contains(searchKey.toUpperCase()) || getField.contains(searchKey)) {
                        Flag = 1;
                    } else {
                        Flag = 0;
                        break;
                    }
                }
            }
            if (Flag == 1) {
                createFlag = 1;
            }
            kovairentitiesfields.cancelButtonClick(driver);
        } catch (Exception e) {
            System.out.println(e);
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Shared", "Fields", driver);
            driver.switchTo().frame(frameid);
        }

        try {
            edit();
            String searchKey = "c";
            String searchKeyApp = searchKey;
            int Flag = 1;
            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKeyApp);
            Thread.sleep(7000);
            List<WebElement> searchLink2 = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink2) {
                String getField = Elem.getText();

                if (getField.startsWith(searchKey.toUpperCase()) || getField.startsWith(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                kovairentitiesfields.searchTextBoxShiftLeft(driver, "*", searchKeyApp.length());
                Thread.sleep(7000);
                List<WebElement> searchLink1 = kovairentitiesfields.fieldListStarting(driver);

                Thread.sleep(4000);
                for (WebElement Elem : searchLink1) {
                    String getField = Elem.getText();
                    System.out.println(getField);

                    if (getField.contains(searchKey.toUpperCase()) || getField.contains(searchKey)) {
                        Flag = 1;
                    } else {
                        Flag = 0;
                        break;
                    }
                }
            }
            if (Flag == 1) {
                editFlag = 1;
            }

            kovairentitiesfields.editCancelButtonClick(driver);
            Thread.sleep(3000);
            kovairentitiesfields.editCancelButtonClick(driver);
            if (createFlag == 1 && editFlag == 1) {
                ExecutionStatus = "Passed";
            } else {
                ExecutionStatus = "Failed";
                if (createFlag == 0) {
                    ErrDesc = "Failed in create Step";
                } else {
                    ErrDesc = "Failed in edit Step";
                }
            }

        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Shared", "Fields", driver);
            driver.switchTo().frame(frameid);
        }
    }

    @Test
    public void SearchBoxFieldsDigitStartsWithToEndsWith_SharedFlds() throws Exception {
        TCID = "Search_Capability_61";
        TCName = "Verify that  in create/edit field page of shared calculated field,  in searchbox  first search using '<search key>' format and entering any digits as search key and then adding a '*' before search key  is changing the search result from  starts with to ends with";
        int createFlag = 0, editFlag = 0;

        try {

            int Flag = 1;
            create();
            String searchKey = searchKeyNumeric("^[0-9]+.*$", "create");
            String searchKeyApp = searchKey;

            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKeyApp);
            Thread.sleep(7000);
            List<WebElement> searchLink = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink) {
                String getField = Elem.getText();

                if (getField.startsWith(searchKey.toUpperCase()) || getField.startsWith(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                kovairentitiesfields.searchTextBoxShiftLeft(driver, "*", searchKeyApp.length());
                Thread.sleep(7000);
                List<WebElement> searchLink1 = kovairentitiesfields.fieldListStarting(driver);

                Thread.sleep(4000);
                for (WebElement Elem : searchLink1) {
                    String getField = Elem.getText();
                    System.out.println(getField);

                    if (getField.contains(searchKey.toUpperCase()) || getField.contains(searchKey)) {
                        Flag = 1;
                    } else {
                        Flag = 0;
                        break;
                    }
                }
            }
            if (Flag == 1) {
                createFlag = 1;
            }
            kovairentitiesfields.cancelButtonClick(driver);
        } catch (Exception e) {
            System.out.println(e);
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Shared", "Fields", driver);
            driver.switchTo().frame(frameid);
        }

        try {
            edit();
            int Flag = 1;

            String searchKey = searchKeyNumeric("^[0-9]+.*$", "edit");
            String searchKeyApp = searchKey;
            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKeyApp);
            Thread.sleep(7000);
            List<WebElement> searchLink2 = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink2) {
                String getField = Elem.getText();

                if (getField.startsWith(searchKey.toUpperCase()) || getField.startsWith(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                kovairentitiesfields.searchTextBoxShiftLeft(driver, "*", searchKeyApp.length());
                Thread.sleep(7000);
                List<WebElement> searchLink1 = kovairentitiesfields.fieldListStarting(driver);

                Thread.sleep(4000);
                for (WebElement Elem : searchLink1) {
                    String getField = Elem.getText();
                    System.out.println(getField);

                    if (getField.contains(searchKey.toUpperCase()) || getField.contains(searchKey)) {
                        Flag = 1;
                    } else {
                        Flag = 0;
                        break;
                    }
                }
            }
            if (Flag == 1) {
                editFlag = 1;
            }

            kovairentitiesfields.editCancelButtonClick(driver);
            Thread.sleep(3000);
            kovairentitiesfields.editCancelButtonClick(driver);
            if (createFlag == 1 && editFlag == 1) {
                ExecutionStatus = "Passed";
            } else {
                ExecutionStatus = "Failed";
                if (createFlag == 0) {
                    ErrDesc = "Failed in create Step";
                } else {
                    ErrDesc = "Failed in edit Step";
                }
            }

        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Shared", "Fields", driver);
            driver.switchTo().frame(frameid);
        }
    }

    @Test(dataProvider = "specialCharacterData")
    public void SearchBoxFieldsSpCharStartsWithToEndsWith_SharedFlds(String spChar) throws Exception {
        TCID = "Search_Capability_62";
        TCName = "Verify that  in create/edit field page of shared calculated field,  in searchbox  first search using '<search key>' format and entering any special character (-,_,$,?) as search key and then adding a '*' before search key  is changing the search result from  starts with to ends with";
        int createFlag = 0, editFlag = 0;

        try {

            String searchKey = spChar;
            String searchKeyApp = searchKey;
            int Flag = 1;
            create();
            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKeyApp);
            Thread.sleep(7000);
            List<WebElement> searchLink = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink) {
                String getField = Elem.getText();

                if (getField.startsWith(searchKey.toUpperCase()) || getField.startsWith(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                kovairentitiesfields.searchTextBoxShiftLeft(driver, "*", searchKeyApp.length());
                Thread.sleep(7000);
                List<WebElement> searchLink1 = kovairentitiesfields.fieldListStarting(driver);

                Thread.sleep(4000);
                for (WebElement Elem : searchLink1) {
                    String getField = Elem.getText();
                    System.out.println(getField);

                    if (getField.contains(searchKey.toUpperCase()) || getField.contains(searchKey)) {
                        Flag = 1;
                    } else {
                        Flag = 0;
                        break;
                    }
                }
            }
            if (Flag == 1) {
                createFlag = 1;
            }
            kovairentitiesfields.cancelButtonClick(driver);
        } catch (Exception e) {
            System.out.println(e);
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Shared", "Fields", driver);
            driver.switchTo().frame(frameid);
        }

        try {
            edit();
            String searchKey = spChar;
            String searchKeyApp = searchKey;
            int Flag = 1;
            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKeyApp);
            Thread.sleep(7000);
            List<WebElement> searchLink2 = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink2) {
                String getField = Elem.getText();

                if (getField.startsWith(searchKey.toUpperCase()) || getField.startsWith(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                kovairentitiesfields.searchTextBoxShiftLeft(driver, "*", searchKeyApp.length());
                Thread.sleep(7000);
                List<WebElement> searchLink1 = kovairentitiesfields.fieldListStarting(driver);

                Thread.sleep(4000);
                for (WebElement Elem : searchLink1) {
                    String getField = Elem.getText();
                    System.out.println(getField);

                    if (getField.contains(searchKey.toUpperCase()) || getField.contains(searchKey)) {
                        Flag = 1;
                    } else {
                        Flag = 0;
                        break;
                    }
                }
            }
            if (Flag == 1) {
                editFlag = 1;
            }

            kovairentitiesfields.editCancelButtonClick(driver);
            Thread.sleep(3000);
            kovairentitiesfields.editCancelButtonClick(driver);
            if (createFlag == 1 && editFlag == 1) {
                ExecutionStatus = "Passed";
            } else {
                ExecutionStatus = "Failed";
                if (createFlag == 0) {
                    ErrDesc = "Failed in create Step";
                } else {
                    ErrDesc = "Failed in edit Step";
                }
            }

        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Shared", "Fields", driver);
            driver.switchTo().frame(frameid);
        }
    }

    @Test
    public void SearchBoxFieldsLetterContainsToStartsWith_SharedFlds() throws Exception {
        TCID = "Search_Capability_63";
        TCName = "Verify that  in create/edit field page of shared calculated field,  in search box  first search using '*<search key>*' format and entering any letters as search key and then deleting  '*' at the beginning of the search key  is changing the search result from  contains to starts with";
        int createFlag = 0, editFlag = 0;

        try {

            String searchKey = "a";
            String searchKeyApp = "*" + searchKey + "*";
            int Flag = 1;
            create();
            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKeyApp);
            Thread.sleep(7000);
            List<WebElement> searchLink = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink) {
                String getField = Elem.getText();

                if (getField.contains(searchKey.toUpperCase()) || getField.contains(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                kovairentitiesfields.searchTextBoxDelete(driver, searchKeyApp.length());
                Thread.sleep(7000);
                List<WebElement> searchLink1 = kovairentitiesfields.fieldListStarting(driver);

                Thread.sleep(4000);
                for (WebElement Elem : searchLink1) {
                    String getField = Elem.getText();
                    System.out.println(getField);

                    if (getField.startsWith(searchKey.toUpperCase()) || getField.startsWith(searchKey)) {
                        Flag = 1;
                    } else {
                        Flag = 0;
                        break;
                    }
                }
            }
            if (Flag == 1) {
                createFlag = 1;
            }
            kovairentitiesfields.cancelButtonClick(driver);
        } catch (Exception e) {
            System.out.println(e);
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Shared", "Fields", driver);
            driver.switchTo().frame(frameid);
        }

        try {
            edit();
            String searchKey = "a";
            String searchKeyApp = "*" + searchKey + "*";
            int Flag = 1;
            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKeyApp);
            Thread.sleep(7000);
            List<WebElement> searchLink2 = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink2) {
                String getField = Elem.getText();

                if (getField.contains(searchKey.toUpperCase()) || getField.contains(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                kovairentitiesfields.searchTextBoxDelete(driver, searchKeyApp.length());
                Thread.sleep(7000);
                List<WebElement> searchLink1 = kovairentitiesfields.fieldListStarting(driver);

                Thread.sleep(4000);
                for (WebElement Elem : searchLink1) {
                    String getField = Elem.getText();
                    System.out.println(getField);

                    if (getField.startsWith(searchKey.toUpperCase()) || getField.startsWith(searchKey)) {
                        Flag = 1;
                    } else {
                        Flag = 0;
                        break;
                    }
                }
            }
            if (Flag == 1) {
                editFlag = 1;
            }

            kovairentitiesfields.editCancelButtonClick(driver);
            Thread.sleep(3000);
            kovairentitiesfields.editCancelButtonClick(driver);
            if (createFlag == 1 && editFlag == 1) {
                ExecutionStatus = "Passed";
            } else {
                ExecutionStatus = "Failed";
                if (createFlag == 0) {
                    ErrDesc = "Failed in create Step";
                } else {
                    ErrDesc = "Failed in edit Step";
                }
            }

        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Shared", "Fields", driver);
            driver.switchTo().frame(frameid);
        }

    }

    @Test
    public void SearchBoxFieldsDigitContainsToStartsWith_SharedFlds() throws Exception {
        TCID = "Search_Capability_64";
        TCName = "Verify that  in create/edit field page of shared calculated field,  in search box  first search using '*<search key>*' format and entering any digits as search key and then deleting  '*' at the beginning of the search key  is changing the search result from  contains to starts with";
        int createFlag = 0, editFlag = 0;

        try {

            int Flag = 1;
            create();
            String searchKey = searchKeyNumeric("^.*[0-9]+.*$", "create");

            String searchKeyApp = "*" + searchKey + "*";
            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKeyApp);
            Thread.sleep(7000);
            List<WebElement> searchLink = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink) {
                String getField = Elem.getText();

                if (getField.contains(searchKey.toUpperCase()) || getField.contains(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                kovairentitiesfields.searchTextBoxDelete(driver, searchKeyApp.length());
                Thread.sleep(7000);
                List<WebElement> searchLink1 = kovairentitiesfields.fieldListStarting(driver);

                Thread.sleep(4000);
                for (WebElement Elem : searchLink1) {
                    String getField = Elem.getText();
                    System.out.println(getField);

                    if (getField.startsWith(searchKey.toUpperCase()) || getField.startsWith(searchKey)) {
                        Flag = 1;
                    } else {
                        Flag = 0;
                        break;
                    }
                }
            }
            if (Flag == 1) {
                createFlag = 1;
            }
            kovairentitiesfields.cancelButtonClick(driver);
        } catch (Exception e) {
            System.out.println(e);
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Shared", "Fields", driver);
            driver.switchTo().frame(frameid);
        }

        try {
            edit();
            int Flag = 1;

            String searchKey = searchKeyNumeric("^.*[0-9]+.*$", "edit");

            String searchKeyApp = "*" + searchKey + "*";
            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKeyApp);
            Thread.sleep(7000);
            List<WebElement> searchLink2 = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink2) {
                String getField = Elem.getText();

                if (getField.contains(searchKey.toUpperCase()) || getField.contains(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                kovairentitiesfields.searchTextBoxDelete(driver, searchKeyApp.length());
                Thread.sleep(7000);
                List<WebElement> searchLink1 = kovairentitiesfields.fieldListStarting(driver);

                Thread.sleep(4000);
                for (WebElement Elem : searchLink1) {
                    String getField = Elem.getText();
                    System.out.println(getField);

                    if (getField.startsWith(searchKey.toUpperCase()) || getField.startsWith(searchKey)) {
                        Flag = 1;
                    } else {
                        Flag = 0;
                        break;
                    }
                }
            }
            if (Flag == 1) {
                editFlag = 1;
            }

            kovairentitiesfields.editCancelButtonClick(driver);
            Thread.sleep(3000);
            kovairentitiesfields.editCancelButtonClick(driver);
            if (createFlag == 1 && editFlag == 1) {
                ExecutionStatus = "Passed";
            } else {
                ExecutionStatus = "Failed";
                if (createFlag == 0) {
                    ErrDesc = "Failed in create Step";
                } else {
                    ErrDesc = "Failed in edit Step";
                }
            }

        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Shared", "Fields", driver);
            driver.switchTo().frame(frameid);
        }

    }

    @Test(dataProvider = "specialCharacterData")
    public void SearchBoxFieldsSpCharContainsToStartsWith_SharedFlds(String spChar) throws Exception {
        TCID = "Search_Capability_65";
        TCName = "Verify that  in create/edit field page of shared calculated field,  in search box  first search using '*<search key>*' format and entering any special characters(-,_,?,$) as search key and then deleting  '*' at the beginning of the search key  is changing the search result from  contains to starts with";
        int createFlag = 0, editFlag = 0;

        try {

            String searchKey = spChar;
            String searchKeyApp = "*" + searchKey + "*";
            int Flag = 1;
            create();
            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKeyApp);
            Thread.sleep(7000);
            List<WebElement> searchLink = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink) {
                String getField = Elem.getText();

                if (getField.contains(searchKey.toUpperCase()) || getField.contains(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                kovairentitiesfields.searchTextBoxDelete(driver, searchKeyApp.length());
                Thread.sleep(7000);
                List<WebElement> searchLink1 = kovairentitiesfields.fieldListStarting(driver);

                Thread.sleep(4000);
                for (WebElement Elem : searchLink1) {
                    String getField = Elem.getText();
                    System.out.println(getField);

                    if (getField.startsWith(searchKey.toUpperCase()) || getField.startsWith(searchKey)) {
                        Flag = 1;
                    } else {
                        Flag = 0;
                        break;
                    }
                }
            }
            if (Flag == 1) {
                createFlag = 1;
            }
            kovairentitiesfields.cancelButtonClick(driver);
        } catch (Exception e) {
            System.out.println(e);
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Shared", "Fields", driver);
            driver.switchTo().frame(frameid);
        }

        try {
            edit();
            String searchKey = spChar;
            String searchKeyApp = "*" + searchKey + "*";
            int Flag = 1;
            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKeyApp);
            Thread.sleep(7000);
            List<WebElement> searchLink2 = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink2) {
                String getField = Elem.getText();

                if (getField.contains(searchKey.toUpperCase()) || getField.contains(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                kovairentitiesfields.searchTextBoxDelete(driver, searchKeyApp.length());
                Thread.sleep(7000);
                List<WebElement> searchLink1 = kovairentitiesfields.fieldListStarting(driver);

                Thread.sleep(4000);
                for (WebElement Elem : searchLink1) {
                    String getField = Elem.getText();
                    System.out.println(getField);

                    if (getField.startsWith(searchKey.toUpperCase()) || getField.startsWith(searchKey)) {
                        Flag = 1;
                    } else {
                        Flag = 0;
                        break;
                    }
                }
            }
            if (Flag == 1) {
                editFlag = 1;
            }

            kovairentitiesfields.editCancelButtonClick(driver);
            Thread.sleep(3000);
            kovairentitiesfields.editCancelButtonClick(driver);
            if (createFlag == 1 && editFlag == 1) {
                ExecutionStatus = "Passed";
            } else {
                ExecutionStatus = "Failed";
                if (createFlag == 0) {
                    ErrDesc = "Failed in create Step";
                } else {
                    ErrDesc = "Failed in edit Step";
                }
            }

        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Shared", "Fields", driver);
            driver.switchTo().frame(frameid);
        }
    }

    @Test
    public void SearchBoxFieldsLetterContainsToEndsWith_SharedFlds() throws Exception {
        TCID = "Search_Capability_66";
        TCName = "Verify that  in create/edit field page of shared calculated field,  in search box  first search using '*<search key>*' format and entering any letters as search key and then deleting  '*' at the ending of the search key  is changing the search result from  contains to ends with";
        int createFlag = 0, editFlag = 0;

        try {

            String searchKey = "a";
            String searchKeyApp = "*" + searchKey + "*";
            int Flag = 1;
            create();
            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKeyApp);
            Thread.sleep(7000);
            List<WebElement> searchLink = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink) {
                String getField = Elem.getText();

                if (getField.contains(searchKey.toUpperCase()) || getField.contains(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                kovairentitiesfields.searchTextBoxDeleteEnd(driver);
                Thread.sleep(7000);
                List<WebElement> searchLink1 = kovairentitiesfields.fieldListStarting(driver);

                Thread.sleep(4000);
                for (WebElement Elem : searchLink1) {
                    String getField = Elem.getText();
                    System.out.println(getField);

                    if (getField.contains(searchKey.toUpperCase()) || getField.contains(searchKey)) {
                        Flag = 1;
                    } else {
                        Flag = 0;
                        break;
                    }
                }
            }
            if (Flag == 1) {
                createFlag = 1;
            }
            kovairentitiesfields.cancelButtonClick(driver);
        } catch (Exception e) {
            System.out.println(e);
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Shared", "Fields", driver);
            driver.switchTo().frame(frameid);
        }

        try {
            edit();
            String searchKey = "a";
            String searchKeyApp = "*" + searchKey + "*";
            int Flag = 1;
            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKeyApp);
            Thread.sleep(7000);
            List<WebElement> searchLink2 = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink2) {
                String getField = Elem.getText();

                if (getField.contains(searchKey.toUpperCase()) || getField.contains(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                kovairentitiesfields.searchTextBoxDeleteEnd(driver);
                Thread.sleep(7000);
                List<WebElement> searchLink1 = kovairentitiesfields.fieldListStarting(driver);

                Thread.sleep(4000);
                for (WebElement Elem : searchLink1) {
                    String getField = Elem.getText();
                    System.out.println(getField);

                    if (getField.contains(searchKey.toUpperCase()) || getField.contains(searchKey)) {
                        Flag = 1;
                    } else {
                        Flag = 0;
                        break;
                    }
                }
            }
            if (Flag == 1) {
                editFlag = 1;
            }

            kovairentitiesfields.editCancelButtonClick(driver);
            Thread.sleep(3000);
            kovairentitiesfields.editCancelButtonClick(driver);
            if (createFlag == 1 && editFlag == 1) {
                ExecutionStatus = "Passed";
            } else {
                ExecutionStatus = "Failed";
                if (createFlag == 0) {
                    ErrDesc = "Failed in create Step";
                } else {
                    ErrDesc = "Failed in edit Step";
                }
            }

        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Shared", "Fields", driver);
            driver.switchTo().frame(frameid);
        }
    }

    @Test
    public void SearchBoxFieldsDigitContainsToEndsWith_SharedFlds() throws Exception {
        TCID = "Search_Capability_67";
        TCName = "Verify that  in create/edit field page of shared calculated field,  in search box  first search using '*<search key>*' format and entering any digits as search key and then deleting  '*' at the ending of the search key  is changing the search result from  contains to ends with";
        int createFlag = 0, editFlag = 0;

        try {

            int Flag = 1;
            create();
            String searchKey = searchKeyNumeric("^.*[0-9]+.*$", "create");
            String searchKeyApp = "*" + searchKey + "*";

            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKeyApp);
            Thread.sleep(7000);
            List<WebElement> searchLink = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink) {
                String getField = Elem.getText();

                if (getField.contains(searchKey.toUpperCase()) || getField.contains(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                kovairentitiesfields.searchTextBoxDeleteEnd(driver);
                Thread.sleep(7000);
                List<WebElement> searchLink1 = kovairentitiesfields.fieldListStarting(driver);

                Thread.sleep(4000);
                for (WebElement Elem : searchLink1) {
                    String getField = Elem.getText();
                    System.out.println(getField);

                    if (getField.contains(searchKey.toUpperCase()) || getField.contains(searchKey)) {
                        Flag = 1;
                    } else {
                        Flag = 0;
                        break;
                    }
                }
            }
            if (Flag == 1) {
                createFlag = 1;
            }
            kovairentitiesfields.cancelButtonClick(driver);
        } catch (Exception e) {
            System.out.println(e);
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Shared", "Fields", driver);
            driver.switchTo().frame(frameid);
        }

        try {
            int Flag = 1;
            edit();
            String searchKey = searchKeyNumeric("^.*[0-9]+.*$", "edit");
            String searchKeyApp = "*" + searchKey + "*";
            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKeyApp);
            Thread.sleep(7000);
            List<WebElement> searchLink2 = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink2) {
                String getField = Elem.getText();

                if (getField.contains(searchKey.toUpperCase()) || getField.contains(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                kovairentitiesfields.searchTextBoxDeleteEnd(driver);
                Thread.sleep(7000);
                List<WebElement> searchLink1 = kovairentitiesfields.fieldListStarting(driver);

                Thread.sleep(4000);
                for (WebElement Elem : searchLink1) {
                    String getField = Elem.getText();
                    System.out.println(getField);

                    if (getField.contains(searchKey.toUpperCase()) || getField.contains(searchKey)) {
                        Flag = 1;
                    } else {
                        Flag = 0;
                        break;
                    }
                }
            }
            if (Flag == 1) {
                editFlag = 1;
            }

            kovairentitiesfields.editCancelButtonClick(driver);
            Thread.sleep(3000);
            kovairentitiesfields.editCancelButtonClick(driver);
            if (createFlag == 1 && editFlag == 1) {
                ExecutionStatus = "Passed";
            } else {
                ExecutionStatus = "Failed";
                if (createFlag == 0) {
                    ErrDesc = "Failed in create Step";
                } else {
                    ErrDesc = "Failed in edit Step";
                }
            }

        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Shared", "Fields", driver);
            driver.switchTo().frame(frameid);
        }
    }

    @Test(dataProvider = "specialCharacterData")
    public void SearchBoxFieldsSpCharContainsToEndsWith_SharedFlds(String spChar) throws Exception {
        TCID = "Search_Capability_68";
        TCName = "Verify that  in create/edit field page of shared calculated field,  in search box  first search using '*<search key>*' format and entering any special characters(-,_,?,$) as search key and then deleting  '*' at the ending of the search key  is changing the search result from  contains to ends with";
        int createFlag = 0, editFlag = 0;

        try {

            String searchKey = spChar;
            String searchKeyApp = "*" + searchKey + "*";
            int Flag = 1;
            create();
            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKeyApp);
            Thread.sleep(7000);
            List<WebElement> searchLink = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink) {
                String getField = Elem.getText();

                if (getField.contains(searchKey.toUpperCase()) || getField.contains(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                kovairentitiesfields.searchTextBoxDeleteEnd(driver);
                Thread.sleep(7000);
                List<WebElement> searchLink1 = kovairentitiesfields.fieldListStarting(driver);

                Thread.sleep(4000);
                for (WebElement Elem : searchLink1) {
                    String getField = Elem.getText();
                    System.out.println(getField);

                    if (getField.contains(searchKey.toUpperCase()) || getField.contains(searchKey)) {
                        Flag = 1;
                    } else {
                        Flag = 0;
                        break;
                    }
                }
            }
            if (Flag == 1) {
                createFlag = 1;
            }
            kovairentitiesfields.cancelButtonClick(driver);
        } catch (Exception e) {
            System.out.println(e);
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Shared", "Fields", driver);
            driver.switchTo().frame(frameid);
        }

        try {
            edit();
            String searchKey = spChar;
            String searchKeyApp = "*" + searchKey + "*";
            int Flag = 1;
            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKeyApp);
            Thread.sleep(7000);
            List<WebElement> searchLink2 = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink2) {
                String getField = Elem.getText();

                if (getField.contains(searchKey.toUpperCase()) || getField.contains(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                kovairentitiesfields.searchTextBoxDeleteEnd(driver);
                Thread.sleep(7000);
                List<WebElement> searchLink1 = kovairentitiesfields.fieldListStarting(driver);

                Thread.sleep(4000);
                for (WebElement Elem : searchLink1) {
                    String getField = Elem.getText();
                    System.out.println(getField);

                    if (getField.contains(searchKey.toUpperCase()) || getField.contains(searchKey)) {
                        Flag = 1;
                    } else {
                        Flag = 0;
                        break;
                    }
                }
            }
            if (Flag == 1) {
                editFlag = 1;
            }

            kovairentitiesfields.editCancelButtonClick(driver);
            Thread.sleep(3000);
            kovairentitiesfields.editCancelButtonClick(driver);
            if (createFlag == 1 && editFlag == 1) {
                ExecutionStatus = "Passed";
            } else {
                ExecutionStatus = "Failed";
                if (createFlag == 0) {
                    ErrDesc = "Failed in create Step";
                } else {
                    ErrDesc = "Failed in edit Step";
                }
            }

        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Shared", "Fields", driver);
            driver.switchTo().frame(frameid);
        }
    }

    @Test
    public void SearchBoxVisible_GblFlds() throws Exception {
        TCID = "Search_Capability_69";
        TCName = "Verify that in create/edit field page of global calculated field, searchbox  of  expression builder is visible ";
        int createFlag = 0, editFlag = 0;

        try {
            create();
            Thread.sleep(4000);
            if (kovairentitiesfields.searchTextBox(driver) == true) {
                createFlag = 1;
            }
            kovairentitiesfields.cancelButtonClick(driver);
        } catch (Exception e) {
            System.out.println(e);
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Global", "Fields", driver);
            driver.switchTo().frame(frameid);
        }

        try {
            edit();
            Thread.sleep(4000);
            if (kovairentitiesfields.searchTextBox(driver) == true) {
                editFlag = 1;
            }
            kovairentitiesfields.editCancelButtonClick(driver);
            Thread.sleep(3000);
            kovairentitiesfields.editCancelButtonClick(driver);

            if (createFlag == 1 && editFlag == 1) {
                ExecutionStatus = "Passed";
            } else {
                ExecutionStatus = "Failed";
                if (createFlag == 0) {
                    ErrDesc = "Failed in create Step";
                } else {
                    ErrDesc = "Failed in edit Step";
                }
            }

        } catch (Exception e) {
            System.out.println(e);
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Global", "Fields", driver);
            driver.switchTo().frame(frameid);
        }

    }

    @Test
    public void SearchBoxBorderPresent_GblFlds() throws Exception {
        TCID = "Search_Capability_70";
        TCName = "Verify that in create/edit field page of global calculated field, searchbox  of  expression builder has a border around it";
        int createFlag = 0, editFlag = 0;

        try {
            create();
            if (kovairentitiesfields.searchTextBoxBorder(driver)) //form-control class contains border element
            {
                createFlag = 1;
            }
            kovairentitiesfields.cancelButtonClick(driver);
        } catch (Exception e) {
            System.out.println(e);
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Global", "Fields", driver);
            driver.switchTo().frame(frameid);
        }

        try {
            edit();
            Thread.sleep(4000);
            if (kovairentitiesfields.searchTextBoxBorder(driver)) {
                editFlag = 1;
            }
            kovairentitiesfields.editCancelButtonClick(driver);
            Thread.sleep(3000);
            kovairentitiesfields.editCancelButtonClick(driver);

            if (createFlag == 1 && editFlag == 1) {
                ExecutionStatus = "Passed";
            } else {
                ExecutionStatus = "Failed";
                if (createFlag == 0) {
                    ErrDesc = "Failed in create Step";
                } else {
                    ErrDesc = "Failed in edit Step";
                }
            }

        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Global", "Fields", driver);
            driver.switchTo().frame(frameid);

        }
    }

    @Test
    public void SearchBoxPlaceholderPresent_GblFlds() throws Exception {

        TCID = "Search_Capability_71";
        TCName = "Verify that in create/edit field page of global calculated field, searchbox  of  expression builder has a placeholder";
        int createFlag = 0, editFlag = 0;

        try {
            create();
            if (kovairentitiesfields.searchTextBoxPlaceholder(driver).equals("Search for...")) {
                createFlag = 1;
            }
            kovairentitiesfields.cancelButtonClick(driver);
        } catch (Exception e) {
            System.out.println(e);
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Global", "Fields", driver);
            driver.switchTo().frame(frameid);
        }

        try {
            edit();
            Thread.sleep(4000);
            if (kovairentitiesfields.searchTextBoxPlaceholder(driver).equals("Search for...")) {
                editFlag = 1;
            }
            kovairentitiesfields.editCancelButtonClick(driver);
            Thread.sleep(3000);
            kovairentitiesfields.editCancelButtonClick(driver);

            if (createFlag == 1 && editFlag == 1) {
                ExecutionStatus = "Passed";
            } else {
                ExecutionStatus = "Failed";
                if (createFlag == 0) {
                    ErrDesc = "Failed in create Step";
                } else {
                    ErrDesc = "Failed in edit Step";
                }
            }

        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Global", "Fields", driver);
            driver.switchTo().frame(frameid);
        }

    }

    @Test
    public void SearchBoxBorderColor_GblFlds() throws Exception {
        TCID = "Search_Capability_72";
        TCName = "Verify that in create/edit field page of global calculated field, border color of searchbox  of  expression builder is grey";
        // System.out.println(kovairentitiesfields.searchTextBoxBorderColor(driver));
        int createFlag = 0, editFlag = 0;
        try {
            create();
            System.out.println(kovairentitiesfields.searchTextBoxBorderColor(driver));

            if (kovairentitiesfields.searchTextBoxBorderColor(driver).equals("rgb(204, 204, 204)")) {
                createFlag = 1;
            }
            kovairentitiesfields.cancelButtonClick(driver);
        } catch (Exception e) {
            System.out.println(e);
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Global", "Fields", driver);
            driver.switchTo().frame(frameid);
        }

        try {
            edit();
            Thread.sleep(4000);
            if (kovairentitiesfields.searchTextBoxBorderColor(driver).equals("rgb(204, 204, 204)")) {
                editFlag = 1;
            }
            kovairentitiesfields.editCancelButtonClick(driver);
            Thread.sleep(3000);
            kovairentitiesfields.editCancelButtonClick(driver);

            if (createFlag == 1 && editFlag == 1) {
                ExecutionStatus = "Passed";
            } else {
                ExecutionStatus = "Failed";
                if (createFlag == 0) {
                    ErrDesc = "Failed in create Step";
                } else {
                    ErrDesc = "Failed in edit Step";
                }
            }
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Global", "Fields", driver);
            driver.switchTo().frame(frameid);
        }

    }

    @Test
    public void SearchBoxPlaceholderColor_GblFlds() throws Exception {
        TCID = "Search_Capability_73";
        TCName = "Verify that in create/edit field page of global calculated field,  placeholder of searchbox  of  expression builder is grey in color";
        // System.out.println(kovairentitiesfields.searchTextBoxBorderColor(driver));
        int createFlag = 0, editFlag = 0;
        try {
            create();
            System.out.println(kovairentitiesfields.findFilterSearchPlaceHolderColor(driver));

            if (kovairentitiesfields.findFilterSearchPlaceHolderColor(driver).equalsIgnoreCase("rgb(85, 85, 85)")) {
                createFlag = 1;
            }
            kovairentitiesfields.cancelButtonClick(driver);
        } catch (Exception e) {
            System.out.println(e);
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Global", "Fields", driver);
            driver.switchTo().frame(frameid);
        }

        try {
            edit();
            Thread.sleep(4000);
            if (kovairentitiesfields.findFilterSearchPlaceHolderColor(driver).equalsIgnoreCase("rgb(85, 85, 85)")) {
                editFlag = 1;
            }
            kovairentitiesfields.editCancelButtonClick(driver);
            Thread.sleep(3000);
            kovairentitiesfields.editCancelButtonClick(driver);

            if (createFlag == 1 && editFlag == 1) {
                ExecutionStatus = "Passed";
            } else {
                ExecutionStatus = "Failed";
                if (createFlag == 0) {
                    ErrDesc = "Failed in create Step";
                } else {
                    ErrDesc = "Failed in edit Step";
                }
            }
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Global", "Fields", driver);
            driver.switchTo().frame(frameid);
        }

    }

    @Test
    public void SearchBoxBorderColorChange_GblFlds() throws Exception {
        TCID = "Search_Capability_74";
        TCName = "Verify that in create/edit field page of global calculated field, clicking in the searchbox  of  expression builder changes the box border color to blue";
        int createFlag = 0, editFlag = 0;

        try {
            create();
            kovairentitiesfields.searchTextBoxClick(driver);
            System.out.println(kovairentitiesfields.searchTextBoxBorderColor(driver));
            Thread.sleep(15000);
            if (kovairentitiesfields.searchTextBoxBorderColor(driver).equalsIgnoreCase("rgb(102, 175, 233)")) {
                createFlag = 1;
            }
            kovairentitiesfields.cancelButtonClick(driver);
        } catch (Exception e) {
            System.out.println(e);
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Global", "Fields", driver);
            driver.switchTo().frame(frameid);
        }

        try {
            edit();
            Thread.sleep(4000);
            kovairentitiesfields.searchTextBoxClick(driver);
            System.out.println(kovairentitiesfields.searchTextBoxBorderColor(driver));
            Thread.sleep(15000);
            if (kovairentitiesfields.searchTextBoxBorderColor(driver).equalsIgnoreCase("rgb(102, 175, 233)")) {
                editFlag = 1;
            }
            kovairentitiesfields.editCancelButtonClick(driver);
            Thread.sleep(3000);
            kovairentitiesfields.editCancelButtonClick(driver);

            if (createFlag == 1 && editFlag == 1) {
                ExecutionStatus = "Passed";
            } else {
                ExecutionStatus = "Failed";
                if (createFlag == 0) {
                    ErrDesc = "Failed in create Step";
                } else {
                    ErrDesc = "Failed in edit Step";
                }
            }
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Global", "Fields", driver);
            driver.switchTo().frame(frameid);
        }

    }

    @Test
    public void SearchBoxPlaceholderBegin_GblFlds() throws Exception {
        TCID = "Search_Capability_75";
        TCName = "Verify that in create/edit field page of global calculated field,  the searchbox  of  expression builder placeholder starts from  the beginning of the searchbox";
        int createFlag = 0, editFlag = 0;

        try {
            create();
            if (kovairentitiesfields.searchTextBoxPlaceholder(driver).equals("Search for...")) {
                createFlag = 1;
            }
            kovairentitiesfields.cancelButtonClick(driver);
        } catch (Exception e) {
            System.out.println(e);
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Global", "Fields", driver);
            driver.switchTo().frame(frameid);
        }

        try {
            edit();
            Thread.sleep(4000);
            if (kovairentitiesfields.searchTextBoxPlaceholder(driver).equals("Search for...")) {
                editFlag = 1;
            }
            kovairentitiesfields.editCancelButtonClick(driver);
            Thread.sleep(3000);
            kovairentitiesfields.editCancelButtonClick(driver);

            if (createFlag == 1 && editFlag == 1) {
                ExecutionStatus = "Passed";
            } else {
                ExecutionStatus = "Failed";
                if (createFlag == 0) {
                    ErrDesc = "Failed in create Step";
                } else {
                    ErrDesc = "Failed in edit Step";
                }
            }
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Global", "Fields", driver);
            driver.switchTo().frame(frameid);
        }

    }

    @Test
    public void SearchBoxPlaceholderRemoved_GblFlds() throws Exception {
        TCID = "Search_Capability_76";
        TCName = "Verify that in create/edit field page of global calculated field, typing in the searchbox  of  expression builder removing placeholder";
        int createFlag = 0, editFlag = 0;

        try {
            create();
            kovairentitiesfields.searchTextBoxClick(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, "ftgg");
            if (kovairentitiesfields.searchTextBoxPlaceholder(driver).isEmpty()) {
                createFlag = 1;
            }
            kovairentitiesfields.cancelButtonClick(driver);
        } catch (Exception e) {
            System.out.println(e);
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Global", "Fields", driver);
            driver.switchTo().frame(frameid);
        }

        try {
            edit();
            Thread.sleep(4000);
            kovairentitiesfields.searchTextBoxClick(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, "ftgg");
            if (kovairentitiesfields.searchTextBoxPlaceholder(driver).isEmpty()) {
                editFlag = 1;
            }
            kovairentitiesfields.editCancelButtonClick(driver);
            Thread.sleep(3000);
            kovairentitiesfields.editCancelButtonClick(driver);

            if (createFlag == 1 && editFlag == 1) {
                ExecutionStatus = "Passed";
            } else {
                ExecutionStatus = "Failed";
                if (createFlag == 0) {
                    ErrDesc = "Failed in create Step";
                } else {
                    ErrDesc = "Failed in edit Step";
                }
            }
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Global", "Fields", driver);
            driver.switchTo().frame(frameid);
        }

    }

    @Test
    public void SearchBoxFieldSelected_GblFlds() throws Exception {
        TCID = "Search_Capability_78";
        TCName = "Verify that  in create/edit field page of global calculated field,  in searchbox if group fields are searched using * then single click on any of the group field can select the field";
        int createFlag = 0, editFlag = 0;

        try {

            create();
            String field;
            field = kovairentitiesfields.fieldListBox(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, field);
            kovairentitiesfields.expressionTextBoxFirst(driver);

            if (kovairentitiesfields.fieldSelected(driver)) {
                createFlag = 1;
            }
            kovairentitiesfields.cancelButtonClick(driver);
        } catch (Exception e) {
            System.out.println(e.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Global", "Fields", driver);
            driver.switchTo().frame(frameid);
        }
        try {

            edit();
            Thread.sleep(4000);
            String field;
            field = kovairentitiesfields.fieldListBox(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, field);
            kovairentitiesfields.expressionTextBoxFirst(driver);

            if (kovairentitiesfields.fieldSelected(driver)) {
                editFlag = 1;
            }
            kovairentitiesfields.editCancelButtonClick(driver);
            Thread.sleep(3000);
            kovairentitiesfields.editCancelButtonClick(driver);

            if (createFlag == 1 && editFlag == 1) {
                ExecutionStatus = "Passed";
            } else {
                ExecutionStatus = "Failed";
                if (createFlag == 0) {
                    ErrDesc = "Failed in create Step";
                } else {
                    ErrDesc = "Failed in edit Step";
                }
            }
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Global", "Fields", driver);
            driver.switchTo().frame(frameid);
        }

    }

    @Test
    public void SearchBoxFieldsLetterStartsWith_GblFlds() throws Exception {
        TCID = "Search_Capability_79";
        TCName = "Verify that  in create/edit field page of global calculated field,  in searchbox  search using '<search key>' format and entering any letters as search key only showing those fields whose name starts with the search key";
        int createFlag = 0, editFlag = 0;
        try {
            create();
            String searchKey = "a";
            int Flag = 1;
            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKey);
            Thread.sleep(7000);
            List<WebElement> searchLink = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink) {
                String getField = Elem.getText();
                System.out.println(getField);

                if (getField.startsWith(searchKey.toUpperCase()) || getField.startsWith(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                createFlag = 1;
            }
            kovairentitiesfields.cancelButtonClick(driver);
        } catch (Exception e) {
            System.out.println(e);
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Global", "Fields", driver);
            driver.switchTo().frame(frameid);
        }

        try {
            edit();
            String searchKey = "a";
            int Flag = 1;
            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKey);
            Thread.sleep(7000);
            List<WebElement> searchLink1 = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink1) {
                String getField = Elem.getText();
                System.out.println(getField);

                if (getField.startsWith(searchKey.toUpperCase()) || getField.startsWith(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                editFlag = 1;
            }
            kovairentitiesfields.editCancelButtonClick(driver);
            Thread.sleep(3000);
            kovairentitiesfields.editCancelButtonClick(driver);
            if (createFlag == 1 && editFlag == 1) {
                ExecutionStatus = "Passed";
            } else {
                ExecutionStatus = "Failed";
                if (createFlag == 0) {
                    ErrDesc = "Failed in create Step";
                } else {
                    ErrDesc = "Failed in edit Step";
                }
            }
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Global", "Fields", driver);
            driver.switchTo().frame(frameid);
        }

    }

    @Test
    public void SearchBoxFieldsLetterStarStartsWith_GblFlds() throws Exception {
        TCID = "Search_Capability_80";
        TCName = "Verify that  in create/edit field page of global calculated field,  in searchbox  search using '<search key>*' format and entering any letters as search key only showing those fields whose name starts with the search key";
        int createFlag = 0, editFlag = 0;
        try {
            create();
            String searchKey = "a";
            String searchKeyApp = searchKey + "*";
            int Flag = 1;
            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKeyApp);
            Thread.sleep(7000);
            List<WebElement> searchLink = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink) {
                String getField = Elem.getText();
                System.out.println(getField);

                if (getField.startsWith(searchKey.toUpperCase()) || getField.startsWith(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                createFlag = 1;
            }
            kovairentitiesfields.cancelButtonClick(driver);
        } catch (Exception e) {
            System.out.println(e);
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Global", "Fields", driver);
            driver.switchTo().frame(frameid);
        }

        try {
            edit();
            int Flag = 1;
            String searchKey = "a";
            String searchKeyApp = searchKey + "*";
            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKeyApp);
            Thread.sleep(7000);
            List<WebElement> searchLink1 = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink1) {
                String getField = Elem.getText();
                System.out.println(getField);

                if (getField.startsWith(searchKey.toUpperCase()) || getField.startsWith(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                editFlag = 1;
            }
            kovairentitiesfields.editCancelButtonClick(driver);
            Thread.sleep(3000);
            kovairentitiesfields.editCancelButtonClick(driver);
            if (createFlag == 1 && editFlag == 1) {
                ExecutionStatus = "Passed";
            } else {
                ExecutionStatus = "Failed";
                if (createFlag == 0) {
                    ErrDesc = "Failed in create Step";
                } else {
                    ErrDesc = "Failed in edit Step";
                }
            }
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Global", "Fields", driver);
            driver.switchTo().frame(frameid);
        }
    }

    @Test
    public void SearchBoxFieldsDigitStartsWith_GblFlds() throws Exception {
        TCID = "Search_Capability_81";
        TCName = "Verify that  in create/edit field page of global calculated field,  in searchbox  search using '<search key>' format and entering any digit as search key only showing those fields whose name starts with the search key";
        int createFlag = 0, editFlag = 0;

        try {
            create();

            int Flag = 1;

            String searchKey = searchKeyNumeric("^[0-9]+.*$", "create");
            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKey);
            Thread.sleep(7000);
            List<WebElement> searchLink = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink) {
                String getField = Elem.getText();
                System.out.println(getField);

                if (getField.startsWith(searchKey.toUpperCase()) || getField.startsWith(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                createFlag = 1;
            }
            kovairentitiesfields.cancelButtonClick(driver);
        } catch (Exception e) {
            System.out.println(e);
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Global", "Fields", driver);
            driver.switchTo().frame(frameid);
        }

        try {
            edit();
            int Flag = 1;
            String searchKey = searchKeyNumeric("^[0-9]+.*$", "edit");
            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKey);
            Thread.sleep(7000);
            List<WebElement> searchLink1 = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink1) {
                String getField = Elem.getText();
                System.out.println(getField);

                if (getField.startsWith(searchKey.toUpperCase()) || getField.startsWith(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                editFlag = 1;
            }
            kovairentitiesfields.editCancelButtonClick(driver);
            Thread.sleep(3000);
            kovairentitiesfields.editCancelButtonClick(driver);
            if (createFlag == 1 && editFlag == 1) {
                ExecutionStatus = "Passed";
            } else {
                ExecutionStatus = "Failed";
                if (createFlag == 0) {
                    ErrDesc = "Failed in create Step";
                } else {
                    ErrDesc = "Failed in edit Step";
                }
            }
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Global", "Fields", driver);
            driver.switchTo().frame(frameid);
        }
    }

    @Test
    public void SearchBoxFieldsDigitStarStartsWith_GblFlds() throws Exception {
        TCID = "Search_Capability_82";
        TCName = "Verify that  in create/edit field page of global calculated field,  in searchbox  search using '<search key>*' format and entering any digit as search key only showing those fields whose name starts with the search key";
        int createFlag = 0, editFlag = 0;
        try {
            create();

            int Flag = 1;
            String searchKey = searchKeyNumeric("^[0-9]+.*$", "create");
            String searchKeyApp = searchKey + "*";
            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKeyApp);
            Thread.sleep(7000);
            List<WebElement> searchLink = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink) {
                String getField = Elem.getText();
                System.out.println(getField);

                if (getField.startsWith(searchKey.toUpperCase()) || getField.startsWith(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                createFlag = 1;
            }
            kovairentitiesfields.cancelButtonClick(driver);
        } catch (Exception e) {
            System.out.println(e);
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Global", "Fields", driver);
            driver.switchTo().frame(frameid);
        }

        try {
            edit();
            int Flag = 1;
            String searchKey = searchKeyNumeric("^[0-9]+.*$", "edit");
            String searchKeyApp = searchKey + "*";
            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKeyApp);
            Thread.sleep(7000);
            List<WebElement> searchLink1 = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink1) {
                String getField = Elem.getText();
                System.out.println(getField);

                if (getField.startsWith(searchKey.toUpperCase()) || getField.startsWith(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                editFlag = 1;
            }
            kovairentitiesfields.editCancelButtonClick(driver);
            Thread.sleep(3000);
            kovairentitiesfields.editCancelButtonClick(driver);
            if (createFlag == 1 && editFlag == 1) {
                ExecutionStatus = "Passed";
            } else {
                ExecutionStatus = "Failed";
                if (createFlag == 0) {
                    ErrDesc = "Failed in create Step";
                } else {
                    ErrDesc = "Failed in edit Step";
                }
            }
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Global", "Fields", driver);
            driver.switchTo().frame(frameid);
        }
    }

    @Test(dataProvider = "specialCharacterData")
    public void SearchBoxFieldsSpCharStartsWith_GblFlds(String spChar) throws Exception {
        TCID = "Search_Capability_83";
        TCName = "Verify that  in create/edit field page of global calculated field,  in searchbox  search using '<search key>' format and entering any special character(_,-,$,?) as search key only showing those fields whose name starts with the search key";
        int createFlag = 0, editFlag = 0;

        try {
            create();
            String searchKey = spChar;
            int Flag = 1;
            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKey);
            Thread.sleep(7000);
            List<WebElement> searchLink = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink) {
                String getField = Elem.getText();
                System.out.println(getField);

                if (getField.startsWith(searchKey.toUpperCase()) || getField.startsWith(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                createFlag = 1;
            }
            kovairentitiesfields.cancelButtonClick(driver);
        } catch (Exception e) {
            System.out.println(e);
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Global", "Fields", driver);
            driver.switchTo().frame(frameid);
        }

        try {
            edit();
            String searchKey = spChar;
            int Flag = 1;
            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKey);
            Thread.sleep(7000);
            List<WebElement> searchLink1 = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink1) {
                String getField = Elem.getText();
                System.out.println(getField);

                if (getField.startsWith(searchKey.toUpperCase()) || getField.startsWith(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                editFlag = 1;
            }
            kovairentitiesfields.editCancelButtonClick(driver);
            Thread.sleep(3000);
            kovairentitiesfields.editCancelButtonClick(driver);
            if (createFlag == 1 && editFlag == 1) {
                ExecutionStatus = "Passed";
            } else {
                ExecutionStatus = "Failed";
                if (createFlag == 0) {
                    ErrDesc = "Failed in create Step";
                } else {
                    ErrDesc = "Failed in edit Step";
                }
            }
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Global", "Fields", driver);
            driver.switchTo().frame(frameid);
        }

    }

    @Test(dataProvider = "specialCharacterData")
    public void SearchBoxFieldsSpCharStarStartsWith_GblFlds(String spChar) throws Exception {
        TCID = "Search_Capability_84";
        TCName = "Verify that  in create/edit field page of global calculated field,  in searchbox  search using '<search key>*' format and entering any special character(_,-,$,?) as search key only showing those fields whose name starts with the search key";
        int createFlag = 0, editFlag = 0;
        try {
            create();
            String searchKey = spChar;
            String searchKeyApp = searchKey + "*";
            int Flag = 1;
            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKeyApp);
            Thread.sleep(7000);
            List<WebElement> searchLink = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink) {
                String getField = Elem.getText();
                System.out.println(getField);

                if (getField.startsWith(searchKey.toUpperCase()) || getField.startsWith(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                createFlag = 1;
            }
            kovairentitiesfields.cancelButtonClick(driver);
        } catch (Exception e) {
            System.out.println(e);
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Global", "Fields", driver);
            driver.switchTo().frame(frameid);
        }

        try {
            edit();
            String searchKey = spChar;
            String searchKeyApp = searchKey + "*";
            int Flag = 1;
            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKeyApp);
            Thread.sleep(7000);
            List<WebElement> searchLink1 = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink1) {
                String getField = Elem.getText();
                System.out.println(getField);

                if (getField.startsWith(searchKey.toUpperCase()) || getField.startsWith(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                editFlag = 1;
            }
            kovairentitiesfields.editCancelButtonClick(driver);
            Thread.sleep(3000);
            kovairentitiesfields.editCancelButtonClick(driver);
            if (createFlag == 1 && editFlag == 1) {
                ExecutionStatus = "Passed";
            } else {
                ExecutionStatus = "Failed";
                if (createFlag == 0) {
                    ErrDesc = "Failed in create Step";
                } else {
                    ErrDesc = "Failed in edit Step";
                }
            }
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Global", "Fields", driver);
            driver.switchTo().frame(frameid);
        }

    }

    @Test
    public void SearchBoxFieldsLetterContains_GblFlds() throws Exception {
        TCID = "Search_Capability_85";
        TCName = "Verify that  in create/edit field page of global calculated field,  in searchbox  search using '*<search key>*' format and entering any letters as search key only showing those fields whose name contains the search key";
        int createFlag = 0, editFlag = 0;
        try {
            create();
            String searchKey = "a";
            String searchKeyApp = "*" + searchKey + "*";
            int Flag = 1;
            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKeyApp);
            Thread.sleep(7000);
            List<WebElement> searchLink = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink) {
                String getField = Elem.getText();
                System.out.println(getField);

                if (getField.contains(searchKey.toUpperCase()) || getField.contains(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                createFlag = 1;
            }
            kovairentitiesfields.cancelButtonClick(driver);
        } catch (Exception e) {
            System.out.println(e);
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Global", "Fields", driver);
            driver.switchTo().frame(frameid);
        }

        try {
            edit();
            String searchKey = "a";
            String searchKeyApp = "*" + searchKey + "*";
            int Flag = 1;
            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKeyApp);
            Thread.sleep(7000);
            List<WebElement> searchLink1 = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink1) {
                String getField = Elem.getText();
                System.out.println(getField);

                if (getField.contains(searchKey.toUpperCase()) || getField.contains(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                editFlag = 1;
            }
            kovairentitiesfields.editCancelButtonClick(driver);
            Thread.sleep(3000);
            kovairentitiesfields.editCancelButtonClick(driver);
            if (createFlag == 1 && editFlag == 1) {
                ExecutionStatus = "Passed";
            } else {
                ExecutionStatus = "Failed";
                if (createFlag == 0) {
                    ErrDesc = "Failed in create Step";
                } else {
                    ErrDesc = "Failed in edit Step";
                }
            }
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Global", "Fields", driver);
            driver.switchTo().frame(frameid);
        }

    }

    @Test
    public void SearchBoxFieldsDigitContains_GblFlds() throws Exception {
        TCID = "Search_Capability_86";
        TCName = "Verify that  in create/edit field page of global calculated field, in searchbox  search using '*<search key>*' format and entering any digit as search key only showing those fields whose name contains the search key";
        int createFlag = 0, editFlag = 0;
        try {
            create();

            int Flag = 1;

            String searchKey = searchKeyNumeric("^.*[0-9]+.*$", "create");
            String searchKeyApp = "*" + searchKey + "*";

            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKeyApp);
            Thread.sleep(7000);
            List<WebElement> searchLink = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink) {
                String getField = Elem.getText();
                System.out.println(getField);

                if (getField.contains(searchKey.toUpperCase()) || getField.contains(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                createFlag = 1;
            }
            kovairentitiesfields.cancelButtonClick(driver);
        } catch (Exception e) {
            System.out.println(e);
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Global", "Fields", driver);
            driver.switchTo().frame(frameid);
        }

        try {
            edit();
            int Flag = 1;

            String searchKey = searchKeyNumeric("^.*[0-9]+.*$", "edit");
            String searchKeyApp = "*" + searchKey + "*";
            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKeyApp);
            Thread.sleep(7000);
            List<WebElement> searchLink1 = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink1) {
                String getField = Elem.getText();
                System.out.println(getField);

                if (getField.contains(searchKey.toUpperCase()) || getField.contains(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                editFlag = 1;
            }
            kovairentitiesfields.editCancelButtonClick(driver);
            Thread.sleep(3000);
            kovairentitiesfields.editCancelButtonClick(driver);
            if (createFlag == 1 && editFlag == 1) {
                ExecutionStatus = "Passed";
            } else {
                ExecutionStatus = "Failed";
                if (createFlag == 0) {
                    ErrDesc = "Failed in create Step";
                } else {
                    ErrDesc = "Failed in edit Step";
                }
            }
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Global", "Fields", driver);
            driver.switchTo().frame(frameid);
        }

    }

    @Test(dataProvider = "specialCharacterData")
    public void SearchBoxFieldsSpCharContains_GblFlds(String spChar) throws Exception {
        TCID = "Search_Capability_87";
        TCName = "Verify that  in create/edit field page of global calculated field,  in searchbox  search using '*<search key>*' format and entering any special character(-,_,?,$) as search key only showing those fields whose name contains the search key";
        int createFlag = 0, editFlag = 0;
        try {
            create();
            String searchKey = spChar;
            String searchKeyApp = "*" + searchKey + "*";
            int Flag = 1;
            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKeyApp);
            Thread.sleep(7000);
            List<WebElement> searchLink = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink) {
                String getField = Elem.getText();
                System.out.println(getField);

                if (getField.contains(searchKey.toUpperCase()) || getField.contains(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                createFlag = 1;
            }
            kovairentitiesfields.cancelButtonClick(driver);
        } catch (Exception e) {
            System.out.println(e);
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Global", "Fields", driver);
            driver.switchTo().frame(frameid);
        }

        try {
            edit();
            String searchKey = spChar;
            String searchKeyApp = "*" + searchKey + "*";
            int Flag = 1;
            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKeyApp);
            Thread.sleep(7000);
            List<WebElement> searchLink1 = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink1) {
                String getField = Elem.getText();
                System.out.println(getField);

                if (getField.contains(searchKey.toUpperCase()) || getField.contains(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                editFlag = 1;
            }
            kovairentitiesfields.editCancelButtonClick(driver);
            Thread.sleep(3000);
            kovairentitiesfields.editCancelButtonClick(driver);
            if (createFlag == 1 && editFlag == 1) {
                ExecutionStatus = "Passed";
            } else {
                ExecutionStatus = "Failed";
                if (createFlag == 0) {
                    ErrDesc = "Failed in create Step";
                } else {
                    ErrDesc = "Failed in edit Step";
                }
            }
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Global", "Fields", driver);
            driver.switchTo().frame(frameid);
        }

    }

    @Test
    public void SearchBoxFieldsLetterEndsWith_GblFlds() throws Exception {
        TCID = "Search_Capability_88";
        TCName = "Verify that  in create/edit field page of global calculated field,  in searchbox  search using '*<search key>' format and entering any letters as search key only showing those fields whose name ends with the search key";
        int createFlag = 0, editFlag = 0;
        try {
            create();
            String searchKey = "a";
            String searchKeyApp = "*" + searchKey;
            int Flag = 1;
            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKeyApp);
            Thread.sleep(7000);
            List<WebElement> searchLink = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink) {
                String getField = Elem.getText();
                System.out.println(getField);

                if (getField.contains(searchKey.toUpperCase()) || getField.contains(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                createFlag = 1;
            }
            kovairentitiesfields.cancelButtonClick(driver);
        } catch (Exception e) {
            System.out.println(e);
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Global", "Fields", driver);
            driver.switchTo().frame(frameid);
        }

        try {
            edit();
            String searchKey = "a";
            String searchKeyApp = "*" + searchKey;
            int Flag = 1;
            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKeyApp);
            Thread.sleep(7000);
            List<WebElement> searchLink1 = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink1) {
                String getField = Elem.getText();
                System.out.println(getField);

                if (getField.contains(searchKey.toUpperCase()) || getField.contains(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                editFlag = 1;
            }
            kovairentitiesfields.editCancelButtonClick(driver);
            Thread.sleep(3000);
            kovairentitiesfields.editCancelButtonClick(driver);
            if (createFlag == 1 && editFlag == 1) {
                ExecutionStatus = "Passed";
            } else {
                ExecutionStatus = "Failed";
                if (createFlag == 0) {
                    ErrDesc = "Failed in create Step";
                } else {
                    ErrDesc = "Failed in edit Step";
                }
            }
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Global", "Fields", driver);
            driver.switchTo().frame(frameid);
        }
    }

    @Test
    public void SearchBoxFieldsDigitEndsWith_GblFlds() throws Exception {
        TCID = "Search_Capability_89";
        TCName = "Verify that  in create/edit field page of global calculated field, in searchbox  search using '*<search key>' format and entering any digit as search key only showing those fields whose name ends with the search key";
        int createFlag = 0, editFlag = 0;
        try {
            create();

            int Flag = 1;
            String searchKey = searchKeyNumeric("^.*[0-9]+.*$", "create");

            String searchKeyApp = "*" + searchKey;

            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKeyApp);
            Thread.sleep(7000);
            List<WebElement> searchLink = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink) {
                String getField = Elem.getText();
                System.out.println(getField);

                if (getField.contains(searchKey.toUpperCase()) || getField.contains(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                createFlag = 1;
            }
            kovairentitiesfields.cancelButtonClick(driver);
        } catch (Exception e) {
            System.out.println(e);
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Global", "Fields", driver);
            driver.switchTo().frame(frameid);
        }

        try {

            edit();
            int Flag = 1;
            String searchKey = searchKeyNumeric("^.*[0-9]+.*$", "edit");

            String searchKeyApp = "*" + searchKey;
            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKeyApp);
            Thread.sleep(7000);
            List<WebElement> searchLink1 = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink1) {
                String getField = Elem.getText();
                System.out.println(getField);

                if (getField.contains(searchKey.toUpperCase()) || getField.contains(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                editFlag = 1;
            }
            kovairentitiesfields.editCancelButtonClick(driver);
            Thread.sleep(3000);
            kovairentitiesfields.editCancelButtonClick(driver);
            if (createFlag == 1 && editFlag == 1) {
                ExecutionStatus = "Passed";
            } else {
                ExecutionStatus = "Failed";
                if (createFlag == 0) {
                    ErrDesc = "Failed in create Step";
                } else {
                    ErrDesc = "Failed in edit Step";
                }
            }
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Global", "Fields", driver);
            driver.switchTo().frame(frameid);
        }
    }

    @Test(dataProvider = "specialCharacterData")
    public void SearchBoxFieldsSpCharEndsWith_GblFlds(String spChar) throws Exception {
        TCID = "Search_Capability_90";
        TCName = "Verify that  in create/edit field page of global calculated field,  in searchbox  search using '*<search key>' format and entering any special character(-,_,?,$) as search key only showing those fields whose name ends with the search key";
        int createFlag = 0, editFlag = 0;
        try {
            create();
            String searchKey = spChar;
            String searchKeyApp = "*" + searchKey;
            int Flag = 1;
            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKeyApp);
            Thread.sleep(7000);
            List<WebElement> searchLink = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink) {
                String getField = Elem.getText();
                System.out.println(getField);

                if (getField.contains(searchKey.toUpperCase()) || getField.contains(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                createFlag = 1;
            }
            kovairentitiesfields.cancelButtonClick(driver);
        } catch (Exception e) {
            System.out.println(e);
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Global", "Fields", driver);
            driver.switchTo().frame(frameid);
        }

        try {
            edit();
            String searchKey = spChar;
            String searchKeyApp = "*" + searchKey;
            int Flag = 1;
            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKeyApp);
            Thread.sleep(7000);
            List<WebElement> searchLink1 = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink1) {
                String getField = Elem.getText();
                System.out.println(getField);

                if (getField.contains(searchKey.toUpperCase()) || getField.contains(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                editFlag = 1;
            }
            kovairentitiesfields.editCancelButtonClick(driver);
            Thread.sleep(3000);
            kovairentitiesfields.editCancelButtonClick(driver);
            if (createFlag == 1 && editFlag == 1) {
                ExecutionStatus = "Passed";
            } else {
                ExecutionStatus = "Failed";
                if (createFlag == 0) {
                    ErrDesc = "Failed in create Step";
                } else {
                    ErrDesc = "Failed in edit Step";
                }
            }
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Global", "Fields", driver);
            driver.switchTo().frame(frameid);
        }
    }

    @Test
    public void SearchBoxFieldsLetterStartsWithToContains_GblFlds() throws Exception {
        TCID = "Search_Capability_91";
        TCName = "Verify that  in create/edit field page of global calculated field,  in searchbox  first search using '<search key>*' format and entering any letters as search key and then adding a '*' before search key  is changing the search result from  starts with to contains";
        int createFlag = 0, editFlag = 0;

        try {

            String searchKey = "a";
            String searchKeyApp = searchKey + "*";
            int Flag = 1;
            create();
            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKeyApp);
            Thread.sleep(7000);
            List<WebElement> searchLink = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink) {
                String getField = Elem.getText();

                if (getField.startsWith(searchKey.toUpperCase()) || getField.startsWith(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                kovairentitiesfields.searchTextBoxShiftLeft(driver, "*", searchKeyApp.length());
                Thread.sleep(7000);
                List<WebElement> searchLink1 = kovairentitiesfields.fieldListStarting(driver);

                Thread.sleep(4000);
                for (WebElement Elem : searchLink1) {
                    String getField = Elem.getText();
                    System.out.println(getField);

                    if (getField.contains(searchKey.toUpperCase()) || getField.contains(searchKey)) {
                        Flag = 1;
                    } else {
                        Flag = 0;
                        break;
                    }
                }
            }
            if (Flag == 1) {
                createFlag = 1;
            }
            kovairentitiesfields.cancelButtonClick(driver);
        } catch (Exception e) {
            System.out.println(e);
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Global", "Fields", driver);
            driver.switchTo().frame(frameid);
        }

        try {
            edit();
            String searchKey = "a";
            String searchKeyApp = searchKey + "*";
            int Flag = 1;
            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKeyApp);
            Thread.sleep(7000);
            List<WebElement> searchLink2 = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink2) {
                String getField = Elem.getText();

                if (getField.startsWith(searchKey.toUpperCase()) || getField.startsWith(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                kovairentitiesfields.searchTextBoxShiftLeft(driver, "*", searchKeyApp.length());
                Thread.sleep(7000);
                List<WebElement> searchLink1 = kovairentitiesfields.fieldListStarting(driver);

                Thread.sleep(4000);
                for (WebElement Elem : searchLink1) {
                    String getField = Elem.getText();
                    System.out.println(getField);

                    if (getField.contains(searchKey.toUpperCase()) || getField.contains(searchKey)) {
                        Flag = 1;
                    } else {
                        Flag = 0;
                        break;
                    }
                }
            }
            if (Flag == 1) {
                editFlag = 1;
            }

            kovairentitiesfields.editCancelButtonClick(driver);
            Thread.sleep(3000);
            kovairentitiesfields.editCancelButtonClick(driver);
            if (createFlag == 1 && editFlag == 1) {
                ExecutionStatus = "Passed";
            } else {
                ExecutionStatus = "Failed";
                if (createFlag == 0) {
                    ErrDesc = "Failed in create Step";
                } else {
                    ErrDesc = "Failed in edit Step";
                }
            }

        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Global", "Fields", driver);
            driver.switchTo().frame(frameid);

        }

    }

    @Test
    public void SearchBoxFieldsDigitStartsWithToContains_GblFlds() throws Exception {
        TCID = "Search_Capability_92";
        TCName = "Verify that  in create/edit field page of global calculated field,  in searchbox  first search using '<search key>*' format and entering any digits as search key and then adding a '*' before search key  is changing the search result from  starts with to contains";
        int createFlag = 0, editFlag = 0;

        try {

            int Flag = 1;
            create();

            String searchKey = searchKeyNumeric("^[0-9]+.*$", "create");

            String searchKeyApp = searchKey + "*";

            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKeyApp);
            Thread.sleep(7000);
            List<WebElement> searchLink = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink) {
                String getField = Elem.getText();

                if (getField.startsWith(searchKey.toUpperCase()) || getField.startsWith(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                kovairentitiesfields.searchTextBoxShiftLeft(driver, "*", searchKeyApp.length());
                Thread.sleep(7000);
                List<WebElement> searchLink1 = kovairentitiesfields.fieldListStarting(driver);

                Thread.sleep(4000);
                for (WebElement Elem : searchLink1) {
                    String getField = Elem.getText();
                    System.out.println(getField);

                    if (getField.contains(searchKey.toUpperCase()) || getField.contains(searchKey)) {
                        Flag = 1;
                    } else {
                        Flag = 0;
                        break;
                    }
                }
            }
            if (Flag == 1) {
                createFlag = 1;
            }
            kovairentitiesfields.cancelButtonClick(driver);
        } catch (Exception e) {
            System.out.println(e);
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Global", "Fields", driver);
            driver.switchTo().frame(frameid);
        }

        try {
            edit();
            int Flag = 1;
            String searchKey = searchKeyNumeric("^[0-9]+.*$", "edit");

            String searchKeyApp = searchKey + "*";
            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKeyApp);
            Thread.sleep(7000);
            List<WebElement> searchLink2 = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink2) {
                String getField = Elem.getText();

                if (getField.startsWith(searchKey.toUpperCase()) || getField.startsWith(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                kovairentitiesfields.searchTextBoxShiftLeft(driver, "*", searchKeyApp.length());
                Thread.sleep(7000);
                List<WebElement> searchLink1 = kovairentitiesfields.fieldListStarting(driver);

                Thread.sleep(4000);
                for (WebElement Elem : searchLink1) {
                    String getField = Elem.getText();
                    System.out.println(getField);

                    if (getField.contains(searchKey.toUpperCase()) || getField.contains(searchKey)) {
                        Flag = 1;
                    } else {
                        Flag = 0;
                        break;
                    }
                }
            }
            if (Flag == 1) {
                editFlag = 1;
            }

            kovairentitiesfields.editCancelButtonClick(driver);
            Thread.sleep(3000);
            kovairentitiesfields.editCancelButtonClick(driver);
            if (createFlag == 1 && editFlag == 1) {
                ExecutionStatus = "Passed";
            } else {
                ExecutionStatus = "Failed";
                if (createFlag == 0) {
                    ErrDesc = "Failed in create Step";
                } else {
                    ErrDesc = "Failed in edit Step";
                }
            }

        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Global", "Fields", driver);
            driver.switchTo().frame(frameid);
        }
    }

    @Test
    public void SearchBoxFieldsLetterStartsWithToEndsWith_GblFlds() throws Exception {
        TCID = "Search_Capability_94";
        TCName = "Verify that  in create/edit field page of global calculated field,  in searchbox  first search using '<search key>' format and entering any letters as search key and then adding a '*' before search key  is changing the search result from  starts with to ends  with";
        int createFlag = 0, editFlag = 0;

        try {

            String searchKey = "c";
            String searchKeyApp = searchKey;
            int Flag = 1;
            create();
            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKeyApp);
            Thread.sleep(7000);
            List<WebElement> searchLink = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink) {
                String getField = Elem.getText();

                if (getField.startsWith(searchKey.toUpperCase()) || getField.startsWith(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                kovairentitiesfields.searchTextBoxShiftLeft(driver, "*", searchKeyApp.length());
                Thread.sleep(7000);
                List<WebElement> searchLink1 = kovairentitiesfields.fieldListStarting(driver);

                Thread.sleep(4000);
                for (WebElement Elem : searchLink1) {
                    String getField = Elem.getText();
                    System.out.println(getField);

                    if (getField.contains(searchKey.toUpperCase()) || getField.contains(searchKey)) {
                        Flag = 1;
                    } else {
                        Flag = 0;
                        break;
                    }
                }
            }
            if (Flag == 1) {
                createFlag = 1;
            }
            kovairentitiesfields.cancelButtonClick(driver);
        } catch (Exception e) {
            System.out.println(e);
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Global", "Fields", driver);
            driver.switchTo().frame(frameid);
        }

        try {
            edit();

            String searchKey = "c";
            String searchKeyApp = searchKey;
            int Flag = 1;
            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKeyApp);
            Thread.sleep(7000);
            List<WebElement> searchLink2 = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink2) {
                String getField = Elem.getText();

                if (getField.startsWith(searchKey.toUpperCase()) || getField.startsWith(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                kovairentitiesfields.searchTextBoxShiftLeft(driver, "*", searchKeyApp.length());
                Thread.sleep(7000);
                List<WebElement> searchLink1 = kovairentitiesfields.fieldListStarting(driver);

                Thread.sleep(4000);
                for (WebElement Elem : searchLink1) {
                    String getField = Elem.getText();
                    System.out.println(getField);

                    if (getField.contains(searchKey.toUpperCase()) || getField.contains(searchKey)) {
                        Flag = 1;
                    } else {
                        Flag = 0;
                        break;
                    }
                }
            }
            if (Flag == 1) {
                editFlag = 1;
            }

            kovairentitiesfields.editCancelButtonClick(driver);
            Thread.sleep(3000);
            kovairentitiesfields.editCancelButtonClick(driver);
            if (createFlag == 1 && editFlag == 1) {
                ExecutionStatus = "Passed";
            } else {
                ExecutionStatus = "Failed";
                if (createFlag == 0) {
                    ErrDesc = "Failed in create Step";
                } else {
                    ErrDesc = "Failed in edit Step";
                }
            }

        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Shared", "Fields", driver);
            driver.switchTo().frame(frameid);
        }
    }

    @Test
    public void SearchBoxFieldsDigitStartsWithToEndsWith_GblFlds() throws Exception {
        TCID = "Search_Capability_95";
        TCName = "Verify that  in create/edit field page of global calculated field,  in searchbox  first search using '<search key>' format and entering any digits as search key and then adding a '*' before search key  is changing the search result from  starts with to ends with";
        int createFlag = 0, editFlag = 0;

        try {

            int Flag = 1;
            create();
            String searchKey = searchKeyNumeric("^[0-9]+.*$", "create");

            String searchKeyApp = searchKey;

            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKeyApp);
            Thread.sleep(7000);
            List<WebElement> searchLink = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink) {
                String getField = Elem.getText();

                if (getField.startsWith(searchKey.toUpperCase()) || getField.startsWith(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                kovairentitiesfields.searchTextBoxShiftLeft(driver, "*", searchKeyApp.length());
                Thread.sleep(7000);
                List<WebElement> searchLink1 = kovairentitiesfields.fieldListStarting(driver);

                Thread.sleep(4000);
                for (WebElement Elem : searchLink1) {
                    String getField = Elem.getText();
                    System.out.println(getField);

                    if (getField.contains(searchKey.toUpperCase()) || getField.contains(searchKey)) {
                        Flag = 1;
                    } else {
                        Flag = 0;
                        break;
                    }
                }
            }
            if (Flag == 1) {
                createFlag = 1;
            }
            kovairentitiesfields.cancelButtonClick(driver);
        } catch (Exception e) {
            System.out.println(e);
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Global", "Fields", driver);
            driver.switchTo().frame(frameid);
        }

        try {
            edit();
            String searchKey = searchKeyNumeric("^[0-9]+.*$", "edit");
            int Flag = 1;
            String searchKeyApp = searchKey;
            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKeyApp);
            Thread.sleep(7000);
            List<WebElement> searchLink2 = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink2) {
                String getField = Elem.getText();

                if (getField.startsWith(searchKey.toUpperCase()) || getField.startsWith(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                kovairentitiesfields.searchTextBoxShiftLeft(driver, "*", searchKeyApp.length());
                Thread.sleep(7000);
                List<WebElement> searchLink1 = kovairentitiesfields.fieldListStarting(driver);

                Thread.sleep(4000);
                for (WebElement Elem : searchLink1) {
                    String getField = Elem.getText();
                    System.out.println(getField);

                    if (getField.contains(searchKey.toUpperCase()) || getField.contains(searchKey)) {
                        Flag = 1;
                    } else {
                        Flag = 0;
                        break;
                    }
                }
            }
            if (Flag == 1) {
                editFlag = 1;
            }

            kovairentitiesfields.editCancelButtonClick(driver);
            Thread.sleep(3000);
            kovairentitiesfields.editCancelButtonClick(driver);
            if (createFlag == 1 && editFlag == 1) {
                ExecutionStatus = "Passed";
            } else {
                ExecutionStatus = "Failed";
                if (createFlag == 0) {
                    ErrDesc = "Failed in create Step";
                } else {
                    ErrDesc = "Failed in edit Step";
                }
            }

        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Global", "Fields", driver);
            driver.switchTo().frame(frameid);
        }
    }

    @Test(dataProvider = "specialCharacterData")
    public void SearchBoxFieldsSpCharStartsWithToEndsWith_GblFlds(String spChar) throws Exception {
        TCID = "Search_Capability_96";
        TCName = "Verify that  in create/edit field page of shared calculated field,  in searchbox  first search using '<search key>' format and entering any special character (-,_,$,?) as search key and then adding a '*' before search key  is changing the search result from  starts with to ends with";
        int createFlag = 0, editFlag = 0;

        try {

            String searchKey = spChar;
            String searchKeyApp = searchKey;
            int Flag = 1;
            create();
            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKeyApp);
            Thread.sleep(7000);
            List<WebElement> searchLink = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink) {
                String getField = Elem.getText();

                if (getField.startsWith(searchKey.toUpperCase()) || getField.startsWith(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                kovairentitiesfields.searchTextBoxShiftLeft(driver, "*", searchKeyApp.length());
                Thread.sleep(7000);
                List<WebElement> searchLink1 = kovairentitiesfields.fieldListStarting(driver);

                Thread.sleep(4000);
                for (WebElement Elem : searchLink1) {
                    String getField = Elem.getText();
                    System.out.println(getField);

                    if (getField.contains(searchKey.toUpperCase()) || getField.contains(searchKey)) {
                        Flag = 1;
                    } else {
                        Flag = 0;
                        break;
                    }
                }
            }
            if (Flag == 1) {
                createFlag = 1;
            }
            kovairentitiesfields.cancelButtonClick(driver);
        } catch (Exception e) {
            System.out.println(e);
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Global", "Fields", driver);
            driver.switchTo().frame(frameid);
        }

        try {
            edit();
            String searchKey = spChar;
            String searchKeyApp = searchKey;
            int Flag = 1;
            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKeyApp);
            Thread.sleep(7000);
            List<WebElement> searchLink2 = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink2) {
                String getField = Elem.getText();

                if (getField.startsWith(searchKey.toUpperCase()) || getField.startsWith(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                kovairentitiesfields.searchTextBoxShiftLeft(driver, "*", searchKeyApp.length());
                Thread.sleep(7000);
                List<WebElement> searchLink1 = kovairentitiesfields.fieldListStarting(driver);

                Thread.sleep(4000);
                for (WebElement Elem : searchLink1) {
                    String getField = Elem.getText();
                    System.out.println(getField);

                    if (getField.contains(searchKey.toUpperCase()) || getField.contains(searchKey)) {
                        Flag = 1;
                    } else {
                        Flag = 0;
                        break;
                    }
                }
            }
            if (Flag == 1) {
                editFlag = 1;
            }

            kovairentitiesfields.editCancelButtonClick(driver);
            Thread.sleep(3000);
            kovairentitiesfields.editCancelButtonClick(driver);
            if (createFlag == 1 && editFlag == 1) {
                ExecutionStatus = "Passed";
            } else {
                ExecutionStatus = "Failed";
                if (createFlag == 0) {
                    ErrDesc = "Failed in create Step";
                } else {
                    ErrDesc = "Failed in edit Step";
                }
            }

        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Global", "Fields", driver);
            driver.switchTo().frame(frameid);
        }
    }

    @Test
    public void SearchBoxFieldsLetterContainsToStartsWith_GblFlds() throws Exception {
        TCID = "Search_Capability_97";
        TCName = "Verify that  in create/edit field page of global calculated field,  in search box  first search using '*<search key>*' format and entering any letters as search key and then deleting  '*' at the beginning of the search key  is changing the search result from  contains to starts with";
        int createFlag = 0, editFlag = 0;

        try {

            String searchKey = "a";
            String searchKeyApp = "*" + searchKey + "*";
            int Flag = 1;
            create();
            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKeyApp);
            Thread.sleep(7000);
            List<WebElement> searchLink = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink) {
                String getField = Elem.getText();

                if (getField.contains(searchKey.toUpperCase()) || getField.contains(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                kovairentitiesfields.searchTextBoxDelete(driver, searchKeyApp.length());
                Thread.sleep(7000);
                List<WebElement> searchLink1 = kovairentitiesfields.fieldListStarting(driver);

                Thread.sleep(4000);
                for (WebElement Elem : searchLink1) {
                    String getField = Elem.getText();
                    System.out.println(getField);

                    if (getField.startsWith(searchKey.toUpperCase()) || getField.startsWith(searchKey)) {
                        Flag = 1;
                    } else {
                        Flag = 0;
                        break;
                    }
                }
            }
            if (Flag == 1) {
                createFlag = 1;
            }
            kovairentitiesfields.cancelButtonClick(driver);
        } catch (Exception e) {
            System.out.println(e);
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Global", "Fields", driver);
            driver.switchTo().frame(frameid);
        }

        try {
            edit();
            String searchKey = "a";
            String searchKeyApp = "*" + searchKey + "*";
            int Flag = 1;
            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKeyApp);
            Thread.sleep(7000);
            List<WebElement> searchLink2 = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink2) {
                String getField = Elem.getText();

                if (getField.contains(searchKey.toUpperCase()) || getField.contains(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                kovairentitiesfields.searchTextBoxDelete(driver, searchKeyApp.length());
                Thread.sleep(7000);
                List<WebElement> searchLink1 = kovairentitiesfields.fieldListStarting(driver);

                Thread.sleep(4000);
                for (WebElement Elem : searchLink1) {
                    String getField = Elem.getText();
                    System.out.println(getField);

                    if (getField.startsWith(searchKey.toUpperCase()) || getField.startsWith(searchKey)) {
                        Flag = 1;
                    } else {
                        Flag = 0;
                        break;
                    }
                }
            }
            if (Flag == 1) {
                editFlag = 1;
            }

            kovairentitiesfields.editCancelButtonClick(driver);
            Thread.sleep(3000);
            kovairentitiesfields.editCancelButtonClick(driver);
            if (createFlag == 1 && editFlag == 1) {
                ExecutionStatus = "Passed";
            } else {
                ExecutionStatus = "Failed";
                if (createFlag == 0) {
                    ErrDesc = "Failed in create Step";
                } else {
                    ErrDesc = "Failed in edit Step";
                }
            }

        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Global", "Fields", driver);
            driver.switchTo().frame(frameid);
        }

    }

    @Test
    public void SearchBoxFieldsDigitContainsToStartsWith_GblFlds() throws Exception {
        TCID = "Search_Capability_98";
        TCName = "Verify that  in create/edit field page of global calculated field,  in search box  first search using '*<search key>*' format and entering any digits as search key and then deleting  '*' at the beginning of the search key  is changing the search result from  contains to starts with";
        int createFlag = 0, editFlag = 0;

        try {

            int Flag = 1;
            create();

            String searchKey = searchKeyNumeric("^.*[0-9]+.*$", "create");
            String searchKeyApp = "*" + searchKey + "*";
            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKeyApp);
            Thread.sleep(7000);
            List<WebElement> searchLink = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink) {
                String getField = Elem.getText();

                if (getField.contains(searchKey.toUpperCase()) || getField.contains(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                kovairentitiesfields.searchTextBoxDelete(driver, searchKeyApp.length());
                Thread.sleep(7000);
                List<WebElement> searchLink1 = kovairentitiesfields.fieldListStarting(driver);

                Thread.sleep(4000);
                for (WebElement Elem : searchLink1) {
                    String getField = Elem.getText();
                    System.out.println(getField);

                    if (getField.startsWith(searchKey.toUpperCase()) || getField.startsWith(searchKey)) {
                        Flag = 1;
                    } else {
                        Flag = 0;
                        break;
                    }
                }
            }
            if (Flag == 1) {
                createFlag = 1;
            }
            kovairentitiesfields.cancelButtonClick(driver);
        } catch (Exception e) {
            System.out.println(e);
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Global", "Fields", driver);
            driver.switchTo().frame(frameid);
        }

        try {
            edit();
            int Flag = 1;

            String searchKey = searchKeyNumeric("^.*[0-9]+.*$", "edit");
            String searchKeyApp = "*" + searchKey + "*";
            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKeyApp);
            Thread.sleep(7000);
            List<WebElement> searchLink2 = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink2) {
                String getField = Elem.getText();

                if (getField.contains(searchKey.toUpperCase()) || getField.contains(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                kovairentitiesfields.searchTextBoxDelete(driver, searchKeyApp.length());
                Thread.sleep(7000);
                List<WebElement> searchLink1 = kovairentitiesfields.fieldListStarting(driver);

                Thread.sleep(4000);
                for (WebElement Elem : searchLink1) {
                    String getField = Elem.getText();
                    System.out.println(getField);

                    if (getField.startsWith(searchKey.toUpperCase()) || getField.startsWith(searchKey)) {
                        Flag = 1;
                    } else {
                        Flag = 0;
                        break;
                    }
                }
            }
            if (Flag == 1) {
                editFlag = 1;
            }

            kovairentitiesfields.editCancelButtonClick(driver);
            Thread.sleep(3000);
            kovairentitiesfields.editCancelButtonClick(driver);
            if (createFlag == 1 && editFlag == 1) {
                ExecutionStatus = "Passed";
            } else {
                ExecutionStatus = "Failed";
                if (createFlag == 0) {
                    ErrDesc = "Failed in create Step";
                } else {
                    ErrDesc = "Failed in edit Step";
                }
            }

        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Global", "Fields", driver);
            driver.switchTo().frame(frameid);
        }

    }

    @Test(dataProvider = "specialCharacterData")
    public void SearchBoxFieldsSpCharContainsToStartsWith_GblFlds(String spChar) throws Exception {
        TCID = "Search_Capability_99";
        TCName = "Verify that  in create/edit field page of global calculated field,  in search box  first search using '*<search key>*' format and entering any special characters(-,_,?,$) as search key and then deleting  '*' at the beginning of the search key  is changing the search result from  contains to starts with";
        int createFlag = 0, editFlag = 0;

        try {

            String searchKey = spChar;
            String searchKeyApp = "*" + searchKey + "*";
            int Flag = 1;
            create();
            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKeyApp);
            Thread.sleep(7000);
            List<WebElement> searchLink = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink) {
                String getField = Elem.getText();

                if (getField.contains(searchKey.toUpperCase()) || getField.contains(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                kovairentitiesfields.searchTextBoxDelete(driver, searchKeyApp.length());
                Thread.sleep(7000);
                List<WebElement> searchLink1 = kovairentitiesfields.fieldListStarting(driver);

                Thread.sleep(4000);
                for (WebElement Elem : searchLink1) {
                    String getField = Elem.getText();
                    System.out.println(getField);

                    if (getField.startsWith(searchKey.toUpperCase()) || getField.startsWith(searchKey)) {
                        Flag = 1;
                    } else {
                        Flag = 0;
                        break;
                    }
                }
            }
            if (Flag == 1) {
                createFlag = 1;
            }
            kovairentitiesfields.cancelButtonClick(driver);
        } catch (Exception e) {
            System.out.println(e);
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Global", "Fields", driver);
            driver.switchTo().frame(frameid);
        }

        try {
            edit();
            String searchKey = spChar;
            String searchKeyApp = "*" + searchKey + "*";
            int Flag = 1;
            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKeyApp);
            Thread.sleep(7000);
            List<WebElement> searchLink2 = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink2) {
                String getField = Elem.getText();

                if (getField.contains(searchKey.toUpperCase()) || getField.contains(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                kovairentitiesfields.searchTextBoxDelete(driver, searchKeyApp.length());
                Thread.sleep(7000);
                List<WebElement> searchLink1 = kovairentitiesfields.fieldListStarting(driver);

                Thread.sleep(4000);
                for (WebElement Elem : searchLink1) {
                    String getField = Elem.getText();
                    System.out.println(getField);

                    if (getField.startsWith(searchKey.toUpperCase()) || getField.startsWith(searchKey)) {
                        Flag = 1;
                    } else {
                        Flag = 0;
                        break;
                    }
                }
            }
            if (Flag == 1) {
                editFlag = 1;
            }

            kovairentitiesfields.editCancelButtonClick(driver);
            Thread.sleep(3000);
            kovairentitiesfields.editCancelButtonClick(driver);
            if (createFlag == 1 && editFlag == 1) {
                ExecutionStatus = "Passed";
            } else {
                ExecutionStatus = "Failed";
                if (createFlag == 0) {
                    ErrDesc = "Failed in create Step";
                } else {
                    ErrDesc = "Failed in edit Step";
                }
            }

        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Global", "Fields", driver);
            driver.switchTo().frame(frameid);
        }
    }

    @Test
    public void SearchBoxFieldsLetterContainsToEndsWith_GblFlds() throws Exception {
        TCID = "Search_Capability_100";
        TCName = "Verify that  in create/edit field page of global calculated field,  in search box  first search using '*<search key>*' format and entering any letters as search key and then deleting  '*' at the ending of the search key  is changing the search result from  contains to ends with";
        int createFlag = 0, editFlag = 0;

        try {

            String searchKey = "a";
            String searchKeyApp = "*" + searchKey + "*";
            int Flag = 1;
            create();
            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKeyApp);
            Thread.sleep(7000);
            List<WebElement> searchLink = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink) {
                String getField = Elem.getText();

                if (getField.contains(searchKey.toUpperCase()) || getField.contains(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                kovairentitiesfields.searchTextBoxDeleteEnd(driver);
                Thread.sleep(7000);
                List<WebElement> searchLink1 = kovairentitiesfields.fieldListStarting(driver);

                Thread.sleep(4000);
                for (WebElement Elem : searchLink1) {
                    String getField = Elem.getText();
                    System.out.println(getField);

                    if (getField.contains(searchKey.toUpperCase()) || getField.contains(searchKey)) {
                        Flag = 1;
                    } else {
                        Flag = 0;
                        break;
                    }
                }
            }
            if (Flag == 1) {
                createFlag = 1;
            }
            kovairentitiesfields.cancelButtonClick(driver);
        } catch (Exception e) {
            System.out.println(e);
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Global", "Fields", driver);
            driver.switchTo().frame(frameid);
        }

        try {
            edit();
            String searchKey = "a";
            String searchKeyApp = "*" + searchKey + "*";
            int Flag = 1;
            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKeyApp);
            Thread.sleep(7000);
            List<WebElement> searchLink2 = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink2) {
                String getField = Elem.getText();

                if (getField.contains(searchKey.toUpperCase()) || getField.contains(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                kovairentitiesfields.searchTextBoxDeleteEnd(driver);
                Thread.sleep(7000);
                List<WebElement> searchLink1 = kovairentitiesfields.fieldListStarting(driver);

                Thread.sleep(4000);
                for (WebElement Elem : searchLink1) {
                    String getField = Elem.getText();
                    System.out.println(getField);

                    if (getField.contains(searchKey.toUpperCase()) || getField.contains(searchKey)) {
                        Flag = 1;
                    } else {
                        Flag = 0;
                        break;
                    }
                }
            }
            if (Flag == 1) {
                editFlag = 1;
            }

            kovairentitiesfields.editCancelButtonClick(driver);
            Thread.sleep(3000);
            kovairentitiesfields.editCancelButtonClick(driver);
            if (createFlag == 1 && editFlag == 1) {
                ExecutionStatus = "Passed";
            } else {
                ExecutionStatus = "Failed";
                if (createFlag == 0) {
                    ErrDesc = "Failed in create Step";
                } else {
                    ErrDesc = "Failed in edit Step";
                }
            }

        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Global", "Fields", driver);
            driver.switchTo().frame(frameid);
        }
    }

    @Test
    public void SearchBoxFieldsDigitContainsToEndsWith_GblFlds() throws Exception {
        TCID = "Search_Capability_101";
        TCName = "Verify that  in create/edit field page of global calculated field,  in search box  first search using '*<search key>*' format and entering any digits as search key and then deleting  '*' at the ending of the search key  is changing the search result from  contains to ends with";
        int createFlag = 0, editFlag = 0;

        try {

            int Flag = 1;
            create();

            String searchKey = searchKeyNumeric("^.*[0-9]+.*$", "create");
            String searchKeyApp = "*" + searchKey + "*";

            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKeyApp);
            Thread.sleep(7000);
            List<WebElement> searchLink = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink) {
                String getField = Elem.getText();

                if (getField.contains(searchKey.toUpperCase()) || getField.contains(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                kovairentitiesfields.searchTextBoxDeleteEnd(driver);
                Thread.sleep(7000);
                List<WebElement> searchLink1 = kovairentitiesfields.fieldListStarting(driver);

                Thread.sleep(4000);
                for (WebElement Elem : searchLink1) {
                    String getField = Elem.getText();
                    System.out.println(getField);

                    if (getField.contains(searchKey.toUpperCase()) || getField.contains(searchKey)) {
                        Flag = 1;
                    } else {
                        Flag = 0;
                        break;
                    }
                }
            }
            if (Flag == 1) {
                createFlag = 1;
            }
            kovairentitiesfields.cancelButtonClick(driver);
        } catch (Exception e) {
            System.out.println(e);
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Global", "Fields", driver);
            driver.switchTo().frame(frameid);
        }

        try {
            edit();
            int Flag = 1;
            String searchKey = searchKeyNumeric("^.*[0-9]+.*$", "edit");
            String searchKeyApp = "*" + searchKey + "*";
            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKeyApp);
            Thread.sleep(7000);
            List<WebElement> searchLink2 = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink2) {
                String getField = Elem.getText();

                if (getField.contains(searchKey.toUpperCase()) || getField.contains(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                kovairentitiesfields.searchTextBoxDeleteEnd(driver);
                Thread.sleep(7000);
                List<WebElement> searchLink1 = kovairentitiesfields.fieldListStarting(driver);

                Thread.sleep(4000);
                for (WebElement Elem : searchLink1) {
                    String getField = Elem.getText();
                    System.out.println(getField);

                    if (getField.contains(searchKey.toUpperCase()) || getField.contains(searchKey)) {
                        Flag = 1;
                    } else {
                        Flag = 0;
                        break;
                    }
                }
            }
            if (Flag == 1) {
                editFlag = 1;
            }

            kovairentitiesfields.editCancelButtonClick(driver);
            Thread.sleep(3000);
            kovairentitiesfields.editCancelButtonClick(driver);
            if (createFlag == 1 && editFlag == 1) {
                ExecutionStatus = "Passed";
            } else {
                ExecutionStatus = "Failed";
                if (createFlag == 0) {
                    ErrDesc = "Failed in create Step";
                } else {
                    ErrDesc = "Failed in edit Step";
                }
            }

        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Global", "Fields", driver);
            driver.switchTo().frame(frameid);
        }
    }

    @Test(dataProvider = "specialCharacterData")
    public void SearchBoxFieldsSpCharContainsToEndsWith_GblFlds(String spChar) throws Exception {
        TCID = "Search_Capability_102";
        TCName = "Verify that  in create/edit field page of global calculated field,  in search box  first search using '*<search key>*' format and entering any special characters(-,_,?,$) as search key and then deleting  '*' at the ending of the search key  is changing the search result from  contains to ends with";
        int createFlag = 0, editFlag = 0;

        try {

            String searchKey = spChar;
            String searchKeyApp = "*" + searchKey + "*";
            int Flag = 1;
            create();
            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKeyApp);
            Thread.sleep(7000);
            List<WebElement> searchLink = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink) {
                String getField = Elem.getText();

                if (getField.contains(searchKey.toUpperCase()) || getField.contains(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                kovairentitiesfields.searchTextBoxDeleteEnd(driver);
                Thread.sleep(7000);
                List<WebElement> searchLink1 = kovairentitiesfields.fieldListStarting(driver);

                Thread.sleep(4000);
                for (WebElement Elem : searchLink1) {
                    String getField = Elem.getText();
                    System.out.println(getField);

                    if (getField.contains(searchKey.toUpperCase()) || getField.contains(searchKey)) {
                        Flag = 1;
                    } else {
                        Flag = 0;
                        break;
                    }
                }
            }
            if (Flag == 1) {
                createFlag = 1;
            }
            kovairentitiesfields.cancelButtonClick(driver);
        } catch (Exception e) {
            System.out.println(e);
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Global", "Fields", driver);
            driver.switchTo().frame(frameid);
        }

        try {
            edit();
            String searchKey = spChar;
            String searchKeyApp = "*" + searchKey + "*";
            int Flag = 1;
            kovairentitiesfields.searchTextBoxClear(driver);
            kovairentitiesfields.searchTextBoxEnterValue(driver, searchKeyApp);
            Thread.sleep(7000);
            List<WebElement> searchLink2 = kovairentitiesfields.fieldListStarting(driver);
            Thread.sleep(4000);
            for (WebElement Elem : searchLink2) {
                String getField = Elem.getText();

                if (getField.contains(searchKey.toUpperCase()) || getField.contains(searchKey)) {
                    Flag = 1;
                } else {
                    Flag = 0;
                    break;
                }
            }

            if (Flag == 1) {
                kovairentitiesfields.searchTextBoxDeleteEnd(driver);
                Thread.sleep(7000);
                List<WebElement> searchLink1 = kovairentitiesfields.fieldListStarting(driver);

                Thread.sleep(4000);
                for (WebElement Elem : searchLink1) {
                    String getField = Elem.getText();
                    System.out.println(getField);

                    if (getField.contains(searchKey.toUpperCase()) || getField.contains(searchKey)) {
                        Flag = 1;
                    } else {
                        Flag = 0;
                        break;
                    }
                }
            }
            if (Flag == 1) {
                editFlag = 1;
            }

            kovairentitiesfields.editCancelButtonClick(driver);
            Thread.sleep(3000);
            kovairentitiesfields.editCancelButtonClick(driver);
            if (createFlag == 1 && editFlag == 1) {
                ExecutionStatus = "Passed";
            } else {
                ExecutionStatus = "Failed";
                if (createFlag == 0) {
                    ErrDesc = "Failed in create Step";
                } else {
                    ErrDesc = "Failed in edit Step";
                }
            }

        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            ErrDesc = "";
            ExecutionStatus = "Not Executed";
            driver.switchTo().defaultContent();
            frameid = kovairhomepage.clickMenuSubMenuInWorkspaceSetup("Global", "Fields", driver);
            driver.switchTo().frame(frameid);
        }
    }

    @BeforeMethod
    public void setUpMethod() throws Exception {
        srlNo++;
        ErrDesc = "";
        ExecutionStatus = "";
        TCName = "";
        TCID = "";
        BeforeAfterClassMethods.getLogid();

    }

    @AfterMethod
    public void tearDownMethod() throws Exception {

        String filePath = BeforeAfterClassMethods.takingScreenshot(srlNo, TCID, TCName, ExecutionStatus, ErrDesc, driver);
        sqlConnection.sqlInsert(BeforeAfterClassMethods.runId, srlNo, TCID, TCName.replace("'", ""), ExecutionStatus, ErrDesc, filePath);

    }

    @DataProvider
    public static Object[][] specialCharacterData() {
        Object[][] obj = new Object[][]{
            {"-"}, {"_"}};
        return obj;
    }

}
