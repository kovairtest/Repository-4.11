
package com.kovair.utilities;

import TaskList.*;
import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.openqa.selenium.support.ui.Select;
import java.util.List;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.testng.Assert;
//import junit.framework.Assert;
import org.openqa.selenium.JavascriptExecutor;
import org.testng.annotations.AfterTest;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
//import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

public class FindError {
    
    static String userName = "";
    static String password = "";
    static String url = "";
    static String baseUrl="";
    
    int logid1=0;
    int logid2=0;
    int logid_diff=0;
    static int lasterrorid=0;
    
    public static String ExecutionStatus = null;
    public static String ErrDesc=null;
    public static String SessionId=null;
    
    static File fXmlFile_DBdetails= new File(System.getProperty("user.dir") + "//src/test/java/com/kovair/LoginInfo/LoginInfo.xml");
        
        public static boolean getDBdetails() throws Exception{ 
          try
           {
            String[] logdata = new String[5];
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.parse(fXmlFile_DBdetails);
            doc.getDocumentElement().normalize();
            //System.out.println("Root element :" + doc.getDocumentElement().getNodeName());
            //Build
            NodeList __nNode1 =doc.getElementsByTagName("Build");
            for (int temp1 = 0; temp1 < __nNode1.getLength(); temp1++) 
            {
               Node Node1 = __nNode1.item(temp1);
               if (Node1 instanceof Element) 
               {
               Element _eElement = (Element) Node1;    
               String sol=_eElement.getAttribute("Solution").toString().trim();
               if(sol.trim().contains(sqlConnection.Solution))
               {
                NodeList DataList = _eElement.getElementsByTagName("DataBase");
                for (int temp = 0; temp < DataList.getLength(); temp++) {
                    Node nNode = DataList.item(temp);
                    if (nNode.getNodeType() == Node.ELEMENT_NODE) {
                        Element eElement = (Element) nNode;  
                        String DBType=eElement.getAttribute("type").toString().trim();
                        if(DBType.contains("Application DataBase"))
                        {
                            logdata[0] = eElement.getElementsByTagName("DBType").item(0).getTextContent();
                            logdata[1] = eElement.getElementsByTagName("ServerIP").item(0).getTextContent();
                            logdata[2] = eElement.getElementsByTagName("ServerName").item(0).getTextContent();
                            logdata[3] = eElement.getElementsByTagName("DataBaseName").item(0).getTextContent();
                            logdata[4] = eElement.getElementsByTagName("Port").item(0).getTextContent();
                            userName   = eElement.getElementsByTagName("DBUserName").item(0).getTextContent();
                            password   = eElement.getElementsByTagName("DBPassword").item(0).getTextContent();                      
                            url ="jdbc:"+logdata[0]+"://"+logdata[2]+":"+logdata[4]+";databaseName="+logdata[3];
                            return true;
                        }
                    }
                  } 
                }
               }}}
            catch(Exception e)
            {
               return false;
            }
          return false;         
       }
        
        public static String[][] getSQLresult(String query) throws Exception{
		    
  
		  try{
			  Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");  
                          
                          if(url.isEmpty() || userName.isEmpty() || password.isEmpty() )
                          {
                                boolean res=getDBdetails();
                                
                                if(res==false)
                                {
                                      if(baseUrl.contains("http://kovair-ibmsrv2/AMAT2Kovair7")){
                                              userName = "sa";
                                              password = "ST1PL2";
                                              url = "jdbc:sqlserver://KOVAIR-IBMSRV2:1433"+";databaseName=Amat_13Sep";
                                      }
                                      else if(baseUrl.contains("http://kovair-srv17/Kovair7")){
                                              userName = "sa";
                                              password = "ST1PL2";
                                              url = "jdbc:sqlserver://KOVAIR-SRV17:1433"+";databaseName=Kovair7Import";
                                      }
                                      else if(baseUrl.contains("http://192.168.2.112/Kovair7")){
                                              userName = "sa";
                                              password = "kov1$air";
                                              url = "jdbc:sqlserver://192.168.2.18:1433"+";databaseName=kovair";
                                      }
                                      else if(baseUrl.contains("http://192.168.2.17/Kovair8")){
                                              userName="sa";
                                              password="kov1$air";
                                              url="jdbc:sqlserver://192.168.2.19:1433"+";databaseName=Kovair_BlankDB";
                                      }
                                      else if(baseUrl.contains("http://192.168.2.112/AMATStaging") || baseUrl.contains("http://applicationperformance/AMATStaging")){
                                          userName = "sa";
                                          password = "kov1$air";
                                          url = "jdbc:sqlserver://192.168.2.18:1433"+";databaseName=Amat_production";
                                      }
                                      else if(baseUrl.contains("http://kovair-ibmsrv2/Kovair7")){
                                              userName = "sa";
                                              password = "ST1PL2";
                                              url = "jdbc:sqlserver://KOVAIR-IBMSRV2:1433"+";databaseName=Kovair7Import";
                                      }
                                      else if(baseUrl.contains("http://kovair-ibmsrv2/kovair_amatscrub")){
                                              userName = "sa";
                                              password = "ST1PL2";
                                              url = "jdbc:sqlserver://KOVAIR-SRV14\\Amat"+";databaseName=Amat_Scrubbed";
                                      }
                                      else{
                                          return null;
                                      }
                                }
                          }
                          
                          Connection con = DriverManager.getConnection(url, userName, password);
                          Statement s1 = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
                          //s1.executeQuery("insert into TestResult values (1,1,'TestCase 1','Pass',null)");
                          ResultSet rs=s1.executeQuery(query);	        		  							          
                          ResultSetMetaData rsmd = rs.getMetaData();
                          int columnsNumber = rsmd.getColumnCount();
                          rs.last();
                          //System.out.println("Row Count = "+rs.getRow());
                          String[][] relations=new String[rs.getRow()][rsmd.getColumnCount()];
                          int currentRow=0;	          
                          rs.beforeFirst();	          	          
                          if(rs!=null){	        	  
	        	  //System.out.println("Following relations are available for the entity: "+entityName);	        	  
	              while (rs.next()){	            	  
	            	  for(int i=0;i<columnsNumber;i++){	            		  
	            		  relations[currentRow][i]=rs.getObject(i+1).toString();
	            		  //System.out.print(rs.getString(i+1)+" ");
	            	  }
	            	  //System.out.print("\n");
	            	  currentRow++;
	              }
	          }
	          s1.close();
	          
	          return relations;

	          //String result = new result[20];
		  }
		  catch (Exception e)
		  {
			  e.printStackTrace();
			  return null;
		  }
	  }
        
        public static boolean checkPageError(WebDriver driver) throws Exception{
            boolean flagError=false;
            File scrFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
            if(driver.findElements(By.xpath("//div[starts-with(text(),'Error Occurred in page')]")).size()!=0){
                    //int countBRTags = driver.findElements(By.xpath("//span[@id='KovairMaster_Main_MessagePanel']")).size();
                    String errorMessage=driver.findElement(By.xpath("//span[@id='KovairMaster_Main_MessagePanel']")).getText();
                    System.out.println("Error Message displayed: "+errorMessage);
                    if(!errorMessage.isEmpty()){
                            ExecutionStatus="Failed";
                            ErrDesc="Page Error: "+errorMessage;
                            flagError=true;
                    }
                    driver.switchTo().defaultContent();
                    //_findOmnibusid(driver,"Service Flow");
                }
            else if(driver.findElements(By.xpath("//html/body/div[2]/div[@id='modal']")).size()!=0){
                    driver.findElement(By.xpath("//div[@id='modal']/table[@id='dialogbtncontainer']/tbody/tr/td[3]/a")).click();
                    String errorMessage= driver.findElement(By.xpath("//div[@id='modal']/table[@id='DetailSection']/tbody/tr/td/div")).getText();
                    System.out.println("Error Message displayed: "+errorMessage);
                    driver.findElement(By.xpath("//div[@id='modal']/table[@id='dialogbtncontainer']/tbody/tr/td[2]/input")).click();
                    if(!errorMessage.isEmpty()){
                        ExecutionStatus="Failed";
                        ErrDesc="Validation Error: "+errorMessage;
                        flagError=true;
                    }
                }
            else if(driver.findElements(By.xpath("//td[text()='Validation Message']")).size()!=0){
                    if(driver.findElements(By.cssSelector("input[class='CancelErrorButton']")).size()!=0){
                        driver.findElement(By.xpath("//div[@id='modal']/table[@id='dialogbtncontainer']/tbody/tr/td[3]/a")).click();
                        String errorMessage= driver.findElement(By.xpath("//div[@id='modal']/table[@id='DetailSection']/tbody/tr/td/div")).getText();
                        System.out.println("Error Message displayed: "+errorMessage);
                        driver.findElement(By.xpath("//div[@id='modal']/table[@id='dialogbtncontainer']/tbody/tr/td[2]/input")).click();
                        if(!errorMessage.isEmpty()){
                            ExecutionStatus="Failed";
                            ErrDesc="Page Error: "+errorMessage;
                            flagError=true;
                        }
    			driver.findElement(By.cssSelector("input[class='CancelErrorButton']")).click();
    		}
    		flagError=true;
            }
            else if(driver.findElements(By.xpath("//td[text()='Web Method Error']")).size()!=0){
                String errorMessage="";
                    if(driver.findElements(By.xpath("//a[starts-with(text(),'Details')]")).size()!=0){
                    driver.findElement(By.xpath("//a[starts-with(text(),'Details')]")).click();
                    
                        if(driver.findElements(By.xpath("//table[@id='DetailSection']/tbody/tr/td/div")).size()!=0){
                            errorMessage=driver.findElement(By.xpath("//table[@id='DetailSection']/tbody/tr/td/div")).getText();
                        }
                    }
                
                    if(driver.findElements(By.cssSelector("input[class='CancelErrorButton']")).size()!=0){
    			driver.findElement(By.cssSelector("input[class='CancelErrorButton']")).click();
                    }
                    ExecutionStatus="Failed";
                
                    ErrDesc="Web Method Error: "+errorMessage;
                    flagError=true;
                }
            
            
            
            else{
                    String result[][]=FindError.getSQLresult("select top 1 ErrorDescription,LogID from terrorlogs where SessionId = '"+SessionId+"' order by LogID desc");
                    try
                    {
                      ErrDesc=(result[0][1]+"-"+result[0][0]);
                      if(lasterrorid!=Integer.parseInt(result[0][1])){
                          flagError=true;
                          ExecutionStatus="Failed";
                      }
                      lasterrorid=Integer.parseInt(result[0][1]);
                    }
                    catch(Exception e){
                      //ErrDesc="Error not displayed in Page";
                    }
            }
            
            
            return flagError;
        }
}
