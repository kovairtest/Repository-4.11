/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.kovair.utilities;

import java.util.ArrayList;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

/**
 *
 * @author sreyag
 */
public class SeleniumModules { 
    List<WebElement> lists=null;
    
    //It takes the webelement of a button and click it
    public static void buttonClick(WebElement n,WebDriver driver)
    {
     n.click();
    } 
    
    //It takes the webelement of a button and click it using javascript executor
    public static void buttonClickWithJavaScript(WebElement n,WebDriver driver)
    {
     ((JavascriptExecutor) driver).executeScript("arguments[0].click();", n);
    } 
    
    //It takes the webelement of a drodown and the option to choose. It choose the option from the dropdown
    public static void selectDataFromList(WebElement n,String data,WebDriver driver)
    {
     ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", n);
            Select assignedPolicy = new Select(n);
            assignedPolicy.selectByVisibleText(data);
    } 
    
    //It takes the webelement of a dropdown and and returns all the options as webelement list
    public static List<WebElement> retuenAllDataFromList(WebElement n,WebDriver driver)
    {
     List<WebElement> data=null;
     ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", n);
     Select assignedPolicy = new Select(n);
     return assignedPolicy.getOptions();
    } 
    
    //This takes the webelement of a dropdown multi selection list and returns all the selected elements as webelement list 
    public static List<WebElement> retuenAllSelectedOptionsFromList(WebElement n,WebDriver driver)
    {
     List<String> data=null;
     ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", n);
     Select assignedPolicy = new Select(n); 
     return assignedPolicy.getAllSelectedOptions();
    }
    
    //This takes the webelement of a dropdown select a option from a dropdown using it's index value
    public static void selectDataByIndFromList(WebElement n,int ind,WebDriver driver)
    {
       n.click();
//      ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", n);
      Select assignedPolicy = new Select(n);
      assignedPolicy.selectByIndex(ind);
    } 
    
    //This takes the webelement and the value to enter. Then it enters the value in that element
    public static void sendDataIntoTxt(WebElement n,String data,WebDriver driver)
    {
     n.click();
     n.clear();
     n.sendKeys(data);
    }  
    
    //This takes the webelement of a dropdown and returns the value of selected option as string
    public static String getSelectDataFromList(WebElement n,WebDriver driver)
    {
      ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", n);
            Select assignedPolicy = new Select(n);
            WebElement data = assignedPolicy.getFirstSelectedOption();
            String l=data.getText();
            return l;
    } 
    
    //This takes the webelement of a dropdown and returns all the option as a string list
    public static List<String> getFullDataFromList(WebElement n,WebDriver driver)
    {
     ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", n);
            Select assignedPolicy = new Select(n);
            List<WebElement> l= assignedPolicy.getOptions();
            List<String> sl=new ArrayList();
            for (WebElement li : l) {
             sl.add(li.getText());
            }
            return sl;
    } 
    
    //It takes a webelement as input and returns the text value inside it as string
    public static String getFromTxt(WebElement n,WebDriver driver)
    { 
     String l;
     l=n.getText();
     return l;
    } 
    
    //This takes a webelement as input and return total count of that element in the page
     public static int getCount(String l,WebDriver driver)
    { 
     int n;
     n=driver.findElements(By.xpath(l)).size();
     return n;
    } 
     
     public static void rightClick(WebElement n, WebDriver driver) {
        Actions action = new Actions(driver).contextClick(n);
        action.build().perform();
    } 
}
