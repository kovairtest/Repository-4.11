/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.kovair.utilities;

//import TaskList.TestKanbanCards;
import com.kovair.PagelevelModule.KovairKanbanBoardModule;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;
import java.util.ArrayList;
//import TaskList.TestKanbanCards;
import com.kovair.TestPackages.TestKanbanBoards;
import javax.print.DocFlavor;
/**
 *
 * @author sreyag
 */
public class sqlQueries { 
    public static String n;
    public static String projectID = "select * from tProject where Title='" + BeforeAfterClassMethods.Workspace + "'";
    public static String entityOfProject="select EntityTypeID,SingularName,IsSystemDefined,IsKanban from tEntity where EntityTypeID in(select EntityTypeID from tEntityProjects where ProjectID In(select ProjectID from tProject where Title='" + BeforeAfterClassMethods.Workspace + "')";
    public static String userName="select * from tuser where LoginID='"+BeforeAfterClassMethods.UserId+"'";
    
    //It returns the full name of current user
    public static String userFullName="select FirstName+' '+LastName as Name from tuser where LoginID='"+BeforeAfterClassMethods.UserId+"'";
    
    //Kanban
    public static String activeBoardsOfProject = "select KBNBoardID,BoardName from tKBNBoard where ProjectID=(select ProjectID from tProject where Title='" + BeforeAfterClassMethods.Workspace + "') and IsArchived='N'";
//    public static String activeBoardOfProject = "Select tKBNBoard.KBNBoardID from tKBNBoard ,tKanbanBoardUsages where tKBNBoard.IsArchived='N' and tKanbanBoardUsages.UserID In(select UserID from tuser where LoginID='"+BeforeAfterClassMethods.UserId+"' COLLATE SQL_Latin1_General_CP1_CS_AS) \n" +
//"and tKanbanBoardUsages.ProjectID IN(select ProjectID from tproject where Title='" + BeforeAfterClassMethods.Workspace + "' COLLATE SQL_Latin1_General_CP1_CS_AS) and tKanbanBoardUsages.KBNBoardID=tKBNBoard.KBNBoardID";
        public static String activeBoardOfProject = "Select tKBNBoard.KBNBoardID,tKBNBoard.BoardName from tKBNBoard ,tKanbanBoardUsages where tKBNBoard.IsArchived='N' and tKanbanBoardUsages.UserID In(select UserID from tuser where LoginID='"+BeforeAfterClassMethods.UserId+"' COLLATE SQL_Latin1_General_CP1_CS_AS) \n" +
"and tKanbanBoardUsages.ProjectID IN(select ProjectID from tproject where Title='" + BeforeAfterClassMethods.Workspace + "' COLLATE SQL_Latin1_General_CP1_CS_AS) and tKanbanBoardUsages.KBNBoardID=tKBNBoard.KBNBoardID";
  
    
    public static String boardUsageOfProject="select KBNBoardID from tKanbanBoardUsages,tProject,tUser where tKanbanBoardUsages.ProjectID=tProject.ProjectID and tProject.Title='"+BeforeAfterClassMethods.Workspace+"' and tKanbanBoardUsages.UserID=tUser.UserID and tUser.LoginID='"+BeforeAfterClassMethods.UserId+"' COLLATE SQL_Latin1_General_CP1_CS_AS";
    
    public static String activeBoardColumns="select ValueID,ValueText,OrderNo,WIPLimit,BufferLimit,FirstTimeLimit,SecondTimeLimit,MaxTimeLimit,CycleTime,TimeUnit from tKBNColumn \n" +
"where KBNBoardID in(Select tKBNBoard.KBNBoardID from tKBNBoard ,tKanbanBoardUsages where tKBNBoard.IsArchived='N' and tKanbanBoardUsages.UserID In(select UserID from tuser where LoginID='"+BeforeAfterClassMethods.UserId+"' COLLATE SQL_Latin1_General_CP1_CS_AS) \n" +
"and tKanbanBoardUsages.ProjectID IN(select ProjectID from tproject where Title='" + BeforeAfterClassMethods.Workspace + "' COLLATE SQL_Latin1_General_CP1_CS_AS) and tKanbanBoardUsages.KBNBoardID=tKBNBoard.KBNBoardID\n" +
")";
    public static String archivedBoardOfProject = "select KBNBoardID,BoardName from tKBNBoard where ProjectID=(select ProjectID from tProject where Title='" + BeforeAfterClassMethods.Workspace + "') and IsArchived='Y'";
    public static String firstArchivedBoardOfProject = "SELECT KBNBoardID, BoardName\n"
            + "FROM (SELECT KBNBoardID,BoardName,ROW_NUMBER() OVER(ORDER BY KBNBoardID) AS RN from tKBNBoard where ProjectID=(select ProjectID from tProject\n"
            + "where Title='" + BeforeAfterClassMethods.Workspace + "') and IsArchived='Y') qBid WHERE RN = 1";

    public static String cardsOfActiveBoard = "select ItemID from tKBNCardData \n" +
"where KBNBoardID=(Select tKBNBoard.KBNBoardID from tKBNBoard ,tKanbanBoardUsages where tKBNBoard.IsArchived='N' and tKanbanBoardUsages.UserID In(select UserID from tuser where LoginID='"+BeforeAfterClassMethods.UserId+"' COLLATE SQL_Latin1_General_CP1_CS_AS) \n" +
"and tKanbanBoardUsages.ProjectID IN(select ProjectID from tproject where Title='" + BeforeAfterClassMethods.Workspace + "' COLLATE SQL_Latin1_General_CP1_CS_AS) and tKanbanBoardUsages.KBNBoardID=tKBNBoard.KBNBoardID)";
    
    public static String backlogCardsOfActiveBoard = "select ItemID from tKBNCardData where KBNBoardID=(select KBNBoardID from tKBNBoard where ProjectID=" + projectID + " and IsArchived='N') and IsBackLog not in('N')";
    public static String completedCardsOfActiveBoard = "select * from tEntityItem where ItemID In(\n"
            + "select ItemID from tKBNCardData where KBNBoardID=(select KBNBoardID from tKBNBoard where ProjectID=\n"
            + "(select ProjectID from tProject where Title='" + BeforeAfterClassMethods.Workspace + "') and IsArchived='N')) and KBNStatusID not in\n"
            + "(select LookupID from tLookupValues where LookupTypeID=50 and Category='Closed')";

   // public static String itemIDOfCard = "select ItemID from tEntityItem where Title='"+TestKanbanCards.cardName+"'";
    
    //public static String itemIDInProjectofCard="select ItemIDInProject from tEntityItem where Title='"+TestKanbanCards.cardName+"' and ItemID=\n" +
//"(select ItemID from tKBNCardData where KBNBoardID=(Select KBNBoardID from tKBNBoard where BoardName='"+TestKanbanCards.activeBoard+"') \n" +
//"and IsArchived='N')";
//    public static String entityOfCard="select SingularName from tEntity where EntityTypeID in(select EntityTypeID from tEntityItem where Title='"+sqlQueries.n+"')";
    //public static String entityOfCard="select SingularName from tEntity where EntityTypeID in(select EntityTypeID from tEntityItem where Title='"+TestKanbanCards.cardName+"')";
 //   public static String entityOfCard="select SingularName from tEntity where EntityTypeID in(select EntityTypeID from tEntityItem where Title='"+TestKanbanCards.cardName+"' and ItemID=\n" +
//"(select ItemID from tKBNCardData where KBNBoardID=(Select KBNBoardID from tKBNBoard where BoardName='"+TestKanbanCards.activeBoard+"') \n" +
//"and IsArchived='N'))";
    
    public static String kanban_cardStatusInActiveBoard = "select * from tKBNBoard";
    public static String kanban_cardsTitleOfActiveBoard = "select * from tEntityItem where ItemID in(42884,43143,43142)";
    
    //it is a system defined lookup which LookupTypeID=50 and ProjectID=1
    public static String kanbanStatusLookups = "select LookupID,LookupText,Category,DisplayOrder from tLookupValues where LookupTypeID=50 and ProjectID=1";
    
    //23/8
    public static String kanbanBoardColumns="select OrderNo,ValueText from tKBNColumn where KBNBoardID in(select KBNBoardID from tKBNBoard where BoardName='"+KovairKanbanBoardModule.boardname+"')";
    
    public static String itemIDOfBacklogedCard="select title,ItemID from tEntityItem where ItemID in(\n" +
"select ItemID from tKBNCardData where KBNBoardID in(select KBNBoardID from tKBNBoard where ProjectID="+projectID+" and IsArchived='N') and IsBackLog not in ('N') and ItemID='"+n+"'\n" +
")";
    
    public static String kanban_TemplateOfProject="select TemplateID,TemplateName from tKBNTemplate where ProjectID in(select ProjectID from tProject where Title='"+BeforeAfterClassMethods.Workspace+"')";
    
   //It returns the first created Template for the Project,this Template would be selected by default at board creation
    public static String firstTemplateBoardOfProject = "select TemplateID,TemplateName FROM (SELECT TemplateID,TemplateName,ROW_NUMBER() \n" +
"OVER(ORDER BY TemplateID) AS TN from tKBNTemplate where ProjectID=(select ProjectID from tProject \n" +
"where Title='"+BeforeAfterClassMethods.Workspace+"')) qtid WHERE TN = 1";
    
   //It returns bord policy and swimlane for a Template in a workspace
    public static String kanban_policy_SwimlaneList_OfTemplate="select EventList,SwimlaneList from tKBNTemplate\n" +
" where TemplateName='"+KovairKanbanBoardModule.boardTemplate+"' and ProjectID In(select ProjectID from tProject where Title='" + BeforeAfterClassMethods.Workspace + "')";

    //This returns column details of a template
    public static String kanbanTemplateColumns="select ValueID,ValueText,ParentID,WIPLimit,BufferLimit,OrderNo from tKBNColumn where TemplateID=(select TemplateID from tKBNTemplate where TemplateName='"+TestKanbanBoards.selectedTemplate+"')order by OrderNo asc";
    
//    It returns policy value and tag as per set
    public static String kanban_policy="select EventID,EventName from tKBNPolicy";
    
    public static String[][] getSQLresult(String query) throws Exception {

        String userName = null;
        String password = null;
        String url = null;

        try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            if (url == null || userName == null || password == null) {
                boolean res = sqlConnection.getAppDBdetails();
                url = sqlConnection.app_url;
                userName = sqlConnection.app_userName;
                password = sqlConnection.app_password;
                if (res == false) {
                    userName = "sa";
                    password = "kov1$air";
                    url = "jdbc:sqlserver://databaseperform:1433" + ";databaseName=AMAT BVT";
                }
            }
            Connection con = DriverManager.getConnection(url, userName, password);
            Statement s1 = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            ResultSet rs = s1.executeQuery(query);
            ResultSetMetaData rsmd = rs.getMetaData();
            int columnsNumber = rsmd.getColumnCount();
            rs.last();
            //System.out.println("Row Count = "+rs.getRow());
            String[][] relations = new String[rs.getRow()][rsmd.getColumnCount()];
            int currentRow = 0;
            rs.beforeFirst();
            if (rs != null) {
                while (rs.next()) {
                    for (int i = 0; i < columnsNumber; i++) {
                        relations[currentRow][i] = rs.getString(i + 1);
                    }
                    currentRow++;
                }
            }
            s1.close();
            return relations;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    } 
    
    public static ResultSet getEntireSQLresult(String query) throws Exception {

        String userName = null;
        String password = null;
        String url = null;
        try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            if (url == null || userName == null || password == null) {
                boolean res = sqlConnection.getAppDBdetails();
                url = sqlConnection.app_url;
                userName = sqlConnection.app_userName;
                password = sqlConnection.app_password;
                if (res == false) {
                    userName = "sa";
                    password = "kov1$air";
                    url = "jdbc:sqlserver://databaseperform:1433" + ";databaseName=AMAT BVT";
                }
            }
            Connection con = DriverManager.getConnection(url, userName, password);
            Statement s1 = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            ResultSet rs = s1.executeQuery(query);
            ResultSetMetaData rsmd = rs.getMetaData();
//            int columnsNumber = rsmd.getColumnCount();
//            rs.last();
//            String[][] relations = new String[rs.getRow()][rsmd.getColumnCount()];
//            int currentRow = 0;
//            rs.beforeFirst();
//            if (rs != null) {
//                while (rs.next()) {
//                    for (int i = 0; i < columnsNumber; i++) {
//                        relations[currentRow][i] = rs.getString(i + 1);
//                    }
//                    currentRow++;
//                }
//            }
//            s1.close();
            return rs;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    } 
    
//    public static String setIntoSql(String t,String sl) throws Exception
//    {
//     try{
//       sqlQueries.n=new String();
//       sqlQueries.n=t;
//      }
//      catch(Exception e)
//      { 
//        System.out.println(e.getMessage());
//    }
//    return n; 
//  }
}
