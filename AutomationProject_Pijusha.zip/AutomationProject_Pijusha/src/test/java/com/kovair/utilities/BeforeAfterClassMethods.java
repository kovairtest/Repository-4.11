/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.kovair.utilities;

import com.kovair.PagelevelModule.KovairLoginPageModule;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;


/**
 *
 * @author sreyag
 */
public class BeforeAfterClassMethods { 
    public static String SessionId = null;
    public static String URL=null;
    public static String UserId=null;
    public static String Password=null;
    public static String Workspace=null;
    public static String browser=null;
    public static int runId=0;
    static int logid1 = 0;
    static int logid2 = 0;
    static int logid_diff = 0;
    
    public static void getLogin(Object logdata[]) throws Exception
    {
            System.out.println(logdata[0].toString());
            URL = logdata[0].toString();
            System.out.println(logdata[1].toString());
            UserId = logdata[1].toString();
            System.out.println(logdata[2].toString());
            Password = logdata[2].toString();
            System.out.println(logdata[2].toString());
            Workspace = logdata[3].toString();
            browser = logdata[4].toString();
   } 
   
   public static int createRunId(String PageName) throws Exception
   { 
      try{
      if (sqlConnection.RunId == 0) {
            sqlConnection.sqlGetRunId();
        }
        runId = sqlConnection.RunId;
        sqlConnection.BatchName = PageName;
        System.out.println("RunId = " + runId); 
        return runId;
      }
      catch(Exception e)
      {
      System.out.println(e.getMessage());
      return runId;
      }
   } 
   
   public static int getLogid() throws Exception
   {
    try{
     String result[][] = FindError.getSQLresult("select top 1 logid from terrorlogs order by 1 desc");
            System.out.println("Result Set:");
            logid1 = Integer.parseInt(result[0][0]);
            System.out.println(logid1);
            return logid1;
    } 
    catch (Exception e) {
            System.out.println(e.getMessage());
            return logid1;
        }
   }
    
   public static String takingScreenshot(int srlNo,String TCID,String TCName,String ExecutionStatus,String ErrDesc,WebDriver driver) throws Exception
   {
        String result[][] = FindError.getSQLresult("select top 1 logid from terrorlogs where SessionId = '" + SessionId + "' order by 1 desc");
        Date date = new Date();
        SimpleDateFormat dateFormatter = new SimpleDateFormat("MMMM dd, yyyy hh-mm-ss");
        SimpleDateFormat dateFormatter1 = new SimpleDateFormat("MMMM dd, yyyy");
        String filePath = "";
        File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
        System.out.println("Result Set After Method:");
        //logid2=Integer.parseInt(result[0][0]);
        try {
            if (result.length != 0) {
                logid2 = Integer.parseInt(result[0][0]);
            } else {
                logid2 = 0;
            }
        } catch (Exception e) {
            logid2 = 0;
        }

        System.out.println(logid2);
        /*for(int i=0;i<result.length;i++){
         System.out.println("inside for loop");
         System.out.println(result[i][0]);
         }*/
        logid_diff = logid2 - logid1;
        if (logid_diff > 0) {
            filePath = "\\\\DB-QA\\AutomationScreeenshots\\" + dateFormatter1.format(date) + "\\screenshot_" + dateFormatter.format(date) + ".jpg";
            FileUtils.copyFile(scrFile, new File(filePath));
            System.out.println("Test Case Id:" + TCID);
            System.out.println("Test Case Name:" + TCName);

            FindError.checkPageError(driver);
            ExecutionStatus = FindError.ExecutionStatus;
            ErrDesc = FindError.ErrDesc;
            System.out.println("Inside Log: " + ErrDesc);
        }

        System.out.println("srlNo: " + srlNo);
        System.out.println("tcId: " + TCID);
        System.out.println("TCName: " + TCName);
        System.out.println("ExecutionStatus: " + ExecutionStatus);
        System.out.println("ErrDesc: " + ErrDesc);

        if (!ExecutionStatus.equals("Passed") && filePath == "") {

            try {
                filePath = "\\\\DB-QA\\AutomationScreeenshots\\" + dateFormatter1.format(date) + "\\screenshot_" + dateFormatter.format(date) + ".jpg";
                FileUtils.copyFile(scrFile, new File(filePath));
            } catch (Exception e) {
            }
            if (ExecutionStatus.equals("")) {
                ExecutionStatus = "Not Executed";
                ErrDesc = "Unknown";
            } else {

            }
        }
     return filePath;
   }
}
